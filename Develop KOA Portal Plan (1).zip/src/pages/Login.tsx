import React, { useState, useRef, useEffect } from 'react'
import type { PersonType } from '../context/DemoContext'

const OTP_LENGTH = 6
const DEMO_OTP = '248731'

const DOC_TYPES = [
  { value: 'CC', label: 'CC', desc: 'Cédula de Ciudadanía' },
  { value: 'CE', label: 'CE', desc: 'Cédula de Extranjería' },
  { value: 'PA', label: 'PA', desc: 'Pasaporte' },
]

type Step = 'form' | 'otp' | 'validating' | 'otp-error'

interface LoginProps {
  onLogin: (personType: PersonType) => void
}

/* ─── OTP validating overlay ──────────────────────────────── */
function ValidatingOverlay({ phase, isError }: { phase: number; isError: boolean }) {
  const steps = [
    'Verificando código…',
    'Confirmando identidad…',
    isError ? 'Código incorrecto' : 'Acceso autorizado',
  ]
  return (
    <div className="flex flex-col items-center justify-center gap-8 py-10">
      <div className="relative flex items-center justify-center">
        <div
          className="absolute w-24 h-24 rounded-full border-2 animate-spin"
          style={{ animationDuration: '2.5s', borderColor: 'transparent', borderTopColor: isError ? '#EF4444' : '#00DB8E' }}
        />
        <div
          className="absolute w-16 h-16 rounded-full border-2 animate-spin"
          style={{ animationDuration: '1.8s', animationDirection: 'reverse', borderColor: 'transparent', borderBottomColor: isError ? '#EF4444' : '#06005A', opacity: 0.22 }}
        />
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
          isError ? 'bg-[#EF4444]' : phase >= 2 ? 'bg-[#00DB8E]' : 'bg-[#06005A]'
        }`}>
          {!isError && phase >= 2 ? (
            <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          ) : isError ? (
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg" alt="KOA" className="h-5 w-auto" />
          )}
        </div>
      </div>

      <div className="space-y-2.5 w-full max-w-[220px]">
        {steps.map((s, i) => {
          const done = i < phase || (!isError && phase >= 2)
          const active = i === phase && (!isError || i < 2)
          const err = isError && i === phase
          return (
            <div key={i} className={`flex items-center gap-3 transition-all duration-300 ${i <= phase ? 'opacity-100' : 'opacity-20'}`}>
              <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
                done ? 'bg-[#00DB8E]' : err ? 'bg-[#EF4444]' : active ? 'border-2 border-[#06005A]' : 'bg-[#F0F0F0]'
              }`}>
                {done ? (
                  <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                ) : err ? (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : active ? (
                  <div className="w-2 h-2 rounded-full bg-[#06005A] animate-pulse" />
                ) : null}
              </div>
              <p className={`text-[13px] transition-colors duration-300 ${
                err ? 'text-[#DC2626] font-bold' : done ? 'text-[#005E3C] font-semibold' : active ? 'text-[#2A3036] font-bold' : 'text-gray-300'
              }`}>{s}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ─── Left branding panel ─────────────────────────────────── */
function BrandPanel() {
  return (
    <div className="hidden lg:flex relative flex-col justify-between p-10 overflow-hidden h-full" style={{ background: '#06005A' }}>
      {/* Decorative orbs */}
      <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(0,219,142,0.08) 0%, transparent 65%)' }} />
      <div className="absolute -left-16 bottom-1/3 w-56 h-56 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(255,255,255,0.025) 0%, transparent 65%)' }} />
      <div className="absolute right-0 bottom-0 w-48 h-48 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(0,219,142,0.05) 0%, transparent 65%)' }} />
      {/* Dot grid */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.035] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="login-dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.3" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#login-dots)" />
      </svg>

      <div className="relative z-10">
        <img
          src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg"
          alt="KOA"
          className="h-11 w-auto object-contain"
        />
      </div>

      <div className="relative z-10 space-y-8">
        <div>
          <h1 className="text-white font-black leading-none mb-3" style={{ fontSize: 'clamp(32px, 3.5vw, 44px)' }}>
            Banca digital.<br />Simple.
          </h1>
          <p className="text-white/50 text-[15px] leading-relaxed max-w-xs">
            Gestiona tus CDTs, créditos de libranza y más desde un solo lugar, seguro y sin filas.
          </p>
        </div>

        <div className="space-y-3">
          {[
            { icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', label: 'Acceso seguro con doble verificación' },
            { icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6', label: 'Tasas CDT hasta 12,20 % E.A.' },
            { icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z', label: 'Crédito libranza sin trámites en caja' },
          ].map(f => (
            <div key={f.label} className="flex items-center gap-3">
              <div className="w-7 h-7 rounded-lg bg-[#00DB8E]/15 border border-[#00DB8E]/20 flex items-center justify-center flex-shrink-0">
                <svg className="w-3.5 h-3.5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={f.icon} />
                </svg>
              </div>
              <p className="text-white/65 text-[13px]">{f.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="relative z-10 flex items-center gap-5 pt-8 border-t border-white/[0.1]">
        <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/SFC_Color.png" alt="SFC" className="h-9 w-auto object-contain opacity-80" />
        <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-fogafin.png" alt="Fogafin" className="h-7 w-auto object-contain opacity-80" />
        <p className="text-white/30 text-[10px] leading-tight ml-auto text-right">
          Vigilado SFC<br />Depósitos asegurados
        </p>
      </div>
    </div>
  )
}

/* ─── Main login component ────────────────────────────────── */
export default function Login({ onLogin }: LoginProps) {
  const [personType, setPersonType] = useState<PersonType>('natural')
  const [docType, setDocType] = useState('CC')
  const [docNum, setDocNum] = useState('')
  const [nit, setNit] = useState('')
  const [clave, setClave] = useState('')
  const [showClave, setShowClave] = useState(false)
  const [step, setStep] = useState<Step>('form')
  const [formError, setFormError] = useState('')

  // OTP state
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(OTP_LENGTH).fill(''))
  const [otpSeconds, setOtpSeconds] = useState(180)
  const [otpResent, setOtpResent] = useState(false)
  const [validPhase, setValidPhase] = useState(0)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])
  const isCorrectRef = useRef(false)

  // OTP countdown
  useEffect(() => {
    if (step !== 'otp' || otpSeconds <= 0) return
    const t = setInterval(() => setOtpSeconds(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [step, otpSeconds])

  // Auto-validate OTP
  const otpCode = otpDigits.join('')
  useEffect(() => {
    if (otpCode.length === OTP_LENGTH && step === 'otp') {
      isCorrectRef.current = otpCode === DEMO_OTP
      setStep('validating')
      setValidPhase(0)
      const t1 = setTimeout(() => setValidPhase(1), 700)
      const t2 = setTimeout(() => setValidPhase(2), 1400)
      const t3 = setTimeout(() => {
        if (isCorrectRef.current) {
          onLogin(personType)
        } else {
          setStep('otp-error')
          setTimeout(() => {
            setStep('otp')
            setOtpDigits(Array(OTP_LENGTH).fill(''))
            setTimeout(() => otpRefs.current[0]?.focus(), 30)
          }, 1400)
        }
      }, 2100)
      return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
    }
  }, [otpCode])

  function handleOtpDigit(i: number, v: string) {
    if (step !== 'otp') return
    const ch = v.replace(/\D/g, '').slice(-1)
    const next = [...otpDigits]; next[i] = ch; setOtpDigits(next)
    if (ch && i < OTP_LENGTH - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpKey(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !otpDigits[i] && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowLeft' && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < OTP_LENGTH - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpPaste(e: React.ClipboardEvent) {
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, OTP_LENGTH)
    const next = [...otpDigits]; pasted.split('').forEach((c, i) => { next[i] = c }); setOtpDigits(next)
    otpRefs.current[Math.min(pasted.length, OTP_LENGTH - 1)]?.focus()
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setFormError('')
    if (!docNum.trim()) { setFormError('Ingresa tu número de documento'); return }
    if (personType === 'juridica' && !nit.trim()) { setFormError('Ingresa el NIT de tu empresa'); return }
    if (!clave.trim()) { setFormError('Ingresa tu clave'); return }
    setStep('otp')
    setOtpDigits(Array(OTP_LENGTH).fill(''))
    setOtpSeconds(180)
    setTimeout(() => otpRefs.current[0]?.focus(), 80)
  }

  function resendOtp() {
    setOtpDigits(Array(OTP_LENGTH).fill(''))
    setOtpSeconds(180)
    setOtpResent(true)
    setTimeout(() => setOtpResent(false), 3000)
    setTimeout(() => otpRefs.current[0]?.focus(), 30)
  }

  const mins = String(Math.floor(otpSeconds / 60)).padStart(2, '0')
  const secs = String(otpSeconds % 60).padStart(2, '0')

  const maskedDoc = docNum.length > 4
    ? docNum.slice(0, 2) + '****' + docNum.slice(-2)
    : '****'

  return (
    <div className="min-h-screen lg:h-screen lg:overflow-hidden flex" style={{ background: '#06005A' }}>
      {/* Left: branding */}
      <div className="lg:w-[400px] xl:w-[440px] flex-shrink-0 lg:h-full">
        <BrandPanel />
      </div>

      {/* Right: form panel */}
      <div className="flex-1 flex flex-col min-h-screen lg:h-screen lg:overflow-hidden" style={{ background: '#F7F7F7' }}>
        {/* Mobile logo bar */}
        <div className="lg:hidden flex items-center justify-between px-6 py-5" style={{ background: '#06005A' }}>
          <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg" alt="KOA" className="h-9 w-auto" />
          <div className="flex items-center gap-2">
            <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/SFC_Color.png" alt="SFC" className="h-6 w-auto opacity-70" />
            <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-fogafin.png" alt="Fogafin" className="h-5 w-auto opacity-70" />
          </div>
        </div>

        <div className="flex-1 flex items-center justify-center px-5 py-8 sm:py-10 lg:py-0 overflow-y-auto lg:overflow-visible">
          <div className="w-full max-w-md">

            {/* OTP header — only shown when not on form step */}
            {step !== 'form' && (
              <div className="mb-5 lg:mb-4">
                <h2 className="text-[24px] font-black text-[#2A3036] leading-tight">Verifica tu identidad</h2>
                <p className="text-gray-400 text-[13px] mt-1">
                  Código enviado al correo vinculado a {docType} {maskedDoc}
                </p>
              </div>
            )}

            {/* Card */}
            <div className="bg-white rounded-3xl border border-[#E8ECF2] shadow-sm overflow-hidden">

              {/* ── Form step ── */}
              {step === 'form' && (
                <form onSubmit={handleSubmit} className="p-6 lg:p-5 space-y-4 lg:space-y-3.5">

                  {/* Person type toggle */}
                  <div className="flex rounded-2xl p-1 gap-1" style={{ background: '#F0F2F5' }}>
                    {(['natural', 'juridica'] as PersonType[]).map(pt => (
                      <button
                        key={pt}
                        type="button"
                        onClick={() => { setPersonType(pt); setFormError('') }}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 lg:py-1.5 rounded-xl text-[13px] font-bold transition-all duration-150 cursor-pointer ${
                          personType === pt
                            ? 'bg-white text-[#06005A] shadow-sm'
                            : 'text-gray-400 hover:text-gray-600'
                        }`}
                      >
                        <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          {pt === 'natural'
                            ? <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            : <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                          }
                        </svg>
                        {pt === 'natural' ? 'Persona Natural' : 'Persona Jurídica'}
                      </button>
                    ))}
                  </div>

                  {/* Divider */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-[#F0F0F0]" />
                    <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Datos de acceso</p>
                    <div className="flex-1 h-px bg-[#F0F0F0]" />
                  </div>

                  {/* Document type chips */}
                  <div>
                    <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-1.5">
                      Tipo de documento
                    </label>
                    <div className="flex gap-2">
                      {DOC_TYPES.map(dt => (
                        <button
                          key={dt.value}
                          type="button"
                          onClick={() => setDocType(dt.value)}
                          title={dt.desc}
                          className={`flex-1 py-2 lg:py-1.5 rounded-xl text-[12px] font-bold transition-all duration-150 cursor-pointer ${
                            docType === dt.value
                              ? 'bg-[#06005A] text-white shadow-md shadow-[#06005A]/20'
                              : 'bg-[#F0F2F5] text-gray-400 hover:bg-[#E8ECF2] hover:text-gray-600'
                          }`}
                        >
                          {dt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Document number */}
                  <div>
                    <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-1.5">
                      Número de documento
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      placeholder="Ej. 1000123456"
                      value={docNum}
                      onChange={e => setDocNum(e.target.value.replace(/\D/g, ''))}
                      className="w-full h-11 px-4 rounded-xl border-2 border-[#E8ECF2] font-figures text-[15px] text-[#2A3036] placeholder-gray-300 outline-none focus:border-[#06005A] transition-colors"
                    />
                  </div>

                  {/* NIT empresa — solo jurídica */}
                  {personType === 'juridica' && (
                    <div>
                      <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-1.5">
                        NIT de la empresa
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        placeholder="Ej. 900123456-7"
                        value={nit}
                        onChange={e => setNit(e.target.value)}
                        className="w-full h-11 px-4 rounded-xl border-2 border-[#E8ECF2] font-figures text-[15px] text-[#2A3036] placeholder-gray-300 outline-none focus:border-[#06005A] transition-colors"
                      />
                    </div>
                  )}

                  {/* Clave */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-[11px] font-bold tracking-[0.1em] uppercase text-gray-400">
                        Clave
                      </label>
                      <button
                        type="button"
                        className="text-[11px] font-semibold text-[#06005A] hover:underline cursor-pointer"
                      >
                        ¿Olvidaste tu clave?
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showClave ? 'text' : 'password'}
                        inputMode="numeric"
                        placeholder="••••••"
                        value={clave}
                        onChange={e => setClave(e.target.value)}
                        className="w-full h-11 pl-4 pr-12 rounded-xl border-2 border-[#E8ECF2] font-figures text-[16px] text-[#2A3036] placeholder-gray-300 outline-none focus:border-[#06005A] transition-colors tracking-[0.2em]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowClave(!showClave)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer transition-colors"
                      >
                        {showClave ? (
                          <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                          </svg>
                        ) : (
                          <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Error */}
                  {formError && (
                    <div className="flex items-center gap-2 bg-[#FEF2F2] border border-red-200 rounded-xl px-4 py-3">
                      <svg className="w-4 h-4 text-[#EF4444] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                      <p className="text-[12px] font-semibold text-[#DC2626]">{formError}</p>
                    </div>
                  )}

                  {/* Submit */}
                  <button
                    type="submit"
                    className="w-full bg-[#06005A] hover:bg-[#08007A] text-white font-black text-[14px] rounded-2xl transition-colors cursor-pointer shadow-lg shadow-[#06005A]/25 flex items-center justify-center gap-2.5"
                    style={{ height: '48px' }}
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                    </svg>
                    Ingresar
                  </button>

                  {/* Demo hint */}
                  <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3.5 py-2.5 flex items-center gap-2">
                    <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p className="text-[11px] text-[#005E3C]">
                      <span className="font-bold">Demo:</span> cualquier documento y clave son válidos. OTP: <span className="font-figures font-black">{DEMO_OTP}</span>
                    </p>
                  </div>
                </form>
              )}

              {/* ── OTP step ── */}
              {(step === 'otp' || step === 'otp-error') && (
                <div className="p-6 lg:p-5">
                  <div className="flex flex-col items-center gap-5">
                    {/* Icon */}
                    <div className="w-14 h-14 rounded-2xl bg-[#06005A] flex items-center justify-center relative">
                      <svg className="w-7 h-7 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#00DB8E] flex items-center justify-center">
                        <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    </div>

                    {/* OTP boxes */}
                    <div className="flex gap-2 justify-center" onPaste={handleOtpPaste}>
                      {otpDigits.map((d, i) => (
                        <input
                          key={i}
                          ref={el => { otpRefs.current[i] = el }}
                          type="text"
                          inputMode="numeric"
                          maxLength={1}
                          value={d}
                          onChange={e => handleOtpDigit(i, e.target.value)}
                          onKeyDown={e => handleOtpKey(i, e)}
                          className={`w-12 h-14 text-center font-figures font-black text-[22px] rounded-xl border-2 outline-none transition-all duration-150 ${
                            step === 'otp-error'
                              ? 'border-[#EF4444] bg-[#FEF2F2] text-[#DC2626] animate-[shake_0.3s_ease-in-out]'
                              : d
                                ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
                                : 'border-[#E8ECF2] bg-white text-[#2A3036] focus:border-[#06005A]'
                          }`}
                        />
                      ))}
                    </div>

                    {/* Timer */}
                    <div className="text-center">
                      {otpSeconds > 0 ? (
                        <p className="text-[12px] text-gray-400">
                          Vence en <span className="font-figures font-bold text-[#2A3036]">{mins}:{secs}</span>
                        </p>
                      ) : (
                        <p className="text-[12px] text-[#EF4444] font-semibold">El código expiró</p>
                      )}
                      <button onClick={resendOtp} className="text-[12px] font-bold text-[#06005A] hover:underline mt-1 cursor-pointer">
                        {otpResent ? '✓ Código reenviado' : 'Reenviar código'}
                      </button>
                    </div>

                    {/* Demo hint */}
                    <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-4 py-3 flex items-start gap-2.5 w-full">
                      <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-[11px] text-[#005E3C] leading-snug">
                        <span className="font-bold">Demo:</span> el código es{' '}
                        <button
                          onClick={() => {
                            setOtpDigits(DEMO_OTP.split(''))
                            setTimeout(() => otpRefs.current[OTP_LENGTH - 1]?.focus(), 0)
                          }}
                          className="font-figures font-black underline cursor-pointer"
                        >
                          {DEMO_OTP}
                        </button>
                      </p>
                    </div>

                    <button
                      onClick={() => { setStep('form'); setOtpDigits(Array(OTP_LENGTH).fill('')) }}
                      className="text-[12px] font-semibold text-gray-400 hover:text-gray-600 cursor-pointer transition-colors"
                    >
                      ← Volver al formulario
                    </button>
                  </div>
                </div>
              )}

              {/* ── Validating step ── */}
              {step === 'validating' && (
                <div className="px-7">
                  <ValidatingOverlay phase={validPhase} isError={false} />
                </div>
              )}
            </div>

            {/* Footer */}
            <p className="text-center text-[11px] text-gray-400 mt-4 leading-relaxed">
              Al ingresar aceptas los{' '}
              <button className="font-semibold text-[#06005A] hover:underline cursor-pointer">términos y condiciones</button>
              {' '}y la{' '}
              <button className="font-semibold text-[#06005A] hover:underline cursor-pointer">política de privacidad</button>
              {' '}de KOA.
            </p>
          </div>
        </div>

        {/* Mobile trust footer */}
        <div className="lg:hidden border-t border-[#E8ECF2] px-5 py-4 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/SFC_Color.png" alt="SFC" className="h-7 w-auto" />
            <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-fogafin.png" alt="Fogafin" className="h-5 w-auto" />
          </div>
          <p className="text-[10px] text-gray-400 text-right">
            © 2026 KOA C.F.<br />Compañía de Financiamiento S.A.
          </p>
        </div>
      </div>
    </div>
  )
}
