import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import Btn from '../components/Btn'
import { formatPesos } from '../data/mockData'

export type ModoMedios = 'apertura' | 'aumento'

interface MediosDePagoProps {
  modo: ModoMedios
  monto: number
  cdtId?: string
  onExito?: () => void
  onVolver?: () => void
}

type Medio = 'seleccion' | 'pse' | 'transferencia' | 'cheque' | 'exito' | 'error'
type ErrorTipo = 'fondos' | 'sesion' | 'rechazo' | 'timeout'

const ERRORES: Record<ErrorTipo, { titulo: string; desc: string }> = {
  fondos: { titulo: 'Fondos insuficientes', desc: 'Tu cuenta no tiene saldo suficiente para completar esta transacción. Verifica tu saldo e intenta nuevamente.' },
  sesion: { titulo: 'Sesión expirada', desc: 'Tu sesión en el banco expiró. Inicia el proceso nuevamente para continuar.' },
  rechazo: { titulo: 'Transacción rechazada', desc: 'El banco rechazó la transacción. Comunícate con tu banco o intenta con otro medio de pago.' },
  timeout: { titulo: 'Tiempo de espera agotado', desc: 'La transacción tardó demasiado tiempo. Si el débito fue realizado, contacta a KOA.' },
}

const BANCOS_PSE = ['Bancolombia', 'Davivienda', 'Banco de Bogotá', 'BBVA', 'Banco Popular', 'Banco Agrario', 'Colpatria', 'Scotiabank Colpatria']

function UploadIcon() {
  return <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
}

export default function MediosDePago({ modo, monto, cdtId, onExito, onVolver }: MediosDePagoProps) {
  const navigate = useNavigate()
  const [pantalla, setPantalla] = useState<Medio>('seleccion')
  const [errorTipo, setErrorTipo] = useState<ErrorTipo>('rechazo')
  const [bancoPSE, setBancoPSE] = useState('')
  const [advertenciaPSE, setAdvertenciaPSE] = useState(false)
  const [procesando, setProcesando] = useState(false)

  // Transferencia
  const [comprobante, setComprobante] = useState<File | null>(null)
  const [errComprobante, setErrComprobante] = useState('')
  const [enviandoTransferencia, setEnviandoTransferencia] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  // Cheque
  const [numeroCheque, setNumeroCheque] = useState('')
  const [bancoCheque, setBancoCheque] = useState('')
  const [comprobantesCheque, setComprobantesCheque] = useState<File[]>([])
  const [enviandoCheque, setEnviandoCheque] = useState(false)
  const chequeRef = useRef<HTMLInputElement>(null)

  const titulo = modo === 'apertura' ? 'Medio de pago' : 'Aumento de CDT — Medio de pago'

  const handlePSEContinuar = () => {
    if (!bancoPSE) return
    setAdvertenciaPSE(true)
  }

  const handlePSEConfirmar = () => {
    setAdvertenciaPSE(false)
    setProcesando(true)
    setTimeout(() => {
      setProcesando(false)
      setPantalla('exito')
    }, 2200)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (f: File | null) => void, errSetter: (s: string) => void) => {
    const file = e.target.files?.[0]
    if (!file) return
    const valid = ['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)
    const size = file.size <= 5 * 1024 * 1024
    if (!valid) { errSetter('Solo se aceptan archivos PDF, JPG o PNG.'); return }
    if (!size) { errSetter('El archivo no puede superar los 5 MB.'); return }
    errSetter('')
    setter(file)
  }

  const handleMultiFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    const valid = files.filter(f => ['application/pdf', 'image/jpeg', 'image/png'].includes(f.type) && f.size <= 5 * 1024 * 1024)
    setComprobantesCheque(prev => [...prev, ...valid].slice(0, 3))
  }

  const handleEnviarTransferencia = () => {
    if (!comprobante) { setErrComprobante('Adjunta el comprobante de transferencia.'); return }
    setEnviandoTransferencia(true)
    setTimeout(() => { setEnviandoTransferencia(false); setPantalla('exito') }, 1800)
  }

  const handleEnviarCheque = () => {
    if (!numeroCheque || !bancoCheque || comprobantesCheque.length === 0) return
    setEnviandoCheque(true)
    setTimeout(() => { setEnviandoCheque(false); setPantalla('exito') }, 1800)
  }

  const handleExito = () => {
    if (onExito) { onExito(); return }
    navigate('/cdt')
  }

  if (pantalla === 'exito') {
    return (
      <div className="max-w-md mx-auto space-y-6 py-8 text-center">
        <div className="w-20 h-20 bg-[#EFFFF7] rounded-full flex items-center justify-center mx-auto">
          <svg className="w-10 h-10 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        </div>
        <div>
          <p className="font-bold text-[22px] text-[#2A3036]">
            {modo === 'apertura' ? '¡CDT abierto con éxito!' : '¡Aumento registrado!'}
          </p>
          <p className="text-[14px] text-gray-500 mt-2 leading-relaxed">
            {modo === 'apertura'
              ? 'Tu Certificado de Depósito a Término ha sido creado. Recibirás una confirmación en tu correo.'
              : 'El aumento de tu CDT ha sido procesado. Recibirás una confirmación en tu correo.'}
          </p>
        </div>
        <div className="bg-gray-50 rounded-2xl p-4 text-left space-y-2">
          <div className="flex justify-between text-[13px]">
            <span className="text-gray-500">Monto</span>
            <span className="font-figures font-semibold text-[#2A3036]">{formatPesos(monto)}</span>
          </div>
          <div className="flex justify-between text-[13px]">
            <span className="text-gray-500">Estado</span>
            <span className="font-semibold text-[#005E3C]">Procesado</span>
          </div>
        </div>
        <Btn variant="mint" size="lg" className="w-full" onClick={handleExito}>
          {modo === 'apertura' ? 'Ver mi CDT' : 'Volver al CDT'}
        </Btn>
      </div>
    )
  }

  if (pantalla === 'error') {
    const err = ERRORES[errorTipo]
    return (
      <div className="max-w-md mx-auto space-y-6 py-8 text-center">
        <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto">
          <svg className="w-10 h-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M5.07 19H19a2 2 0 001.75-2.95L13.75 4.05a2 2 0 00-3.5 0L4.32 16.05A2 2 0 005.07 19z" /></svg>
        </div>
        <div>
          <p className="font-bold text-[20px] text-[#2A3036]">{err.titulo}</p>
          <p className="text-[13px] text-gray-500 mt-2 leading-relaxed">{err.desc}</p>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" size="md" className="flex-1" onClick={() => setPantalla('seleccion')}>Otro medio</Btn>
          <Btn variant="primary" size="md" className="flex-1" onClick={() => setPantalla('pse')}>Reintentar</Btn>
        </div>
      </div>
    )
  }

  if (pantalla === 'seleccion') {
    return (
      <div className="space-y-4">
        <div>
          <p className="font-bold text-[17px] text-[#2A3036]">{titulo}</p>
          <p className="text-[13px] text-gray-500 mt-0.5">Elige cómo realizarás el pago de <span className="font-figures font-semibold text-[#2A3036]">{formatPesos(monto)}</span></p>
        </div>

        {[
          {
            id: 'pse', nombre: 'PSE — Débito a cuenta', desc: 'Débito inmediato desde tu cuenta bancaria.',
            icon: <svg className="w-5 h-5 text-[#0A1F44]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>,
          },
          {
            id: 'transferencia', nombre: 'Transferencia bancaria', desc: 'Transfiere a la cuenta KOA y sube el comprobante.',
            icon: <svg className="w-5 h-5 text-[#0A1F44]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>,
          },
          {
            id: 'cheque', nombre: 'Cheque', desc: 'Entrega o envía el cheque a nombre de KOA.',
            icon: <svg className="w-5 h-5 text-[#0A1F44]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
          },
        ].map(m => (
          <button
            key={m.id}
            onClick={() => setPantalla(m.id as Medio)}
            className="w-full bg-white border border-[#E5E7EB] rounded-2xl p-4 flex items-center gap-4 hover:border-[#0A1F44] hover:shadow-sm transition-all cursor-pointer text-left"
          >
            <span className="w-10 h-10 rounded-xl bg-[#F5F7FA] flex items-center justify-center flex-shrink-0">{m.icon}</span>
            <div className="flex-1">
              <p className="font-semibold text-[14px] text-[#2A3036]">{m.nombre}</p>
              <p className="text-[12px] text-gray-500 mt-0.5">{m.desc}</p>
            </div>
            <svg className="w-5 h-5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
          </button>
        ))}

        {onVolver && (
          <Btn variant="ghost" size="md" className="w-full" onClick={onVolver}>← Volver</Btn>
        )}
      </div>
    )
  }

  if (pantalla === 'pse') {
    return (
      <>
        <div className="space-y-4">
          <button onClick={() => setPantalla('seleccion')} className="flex items-center gap-1.5 text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
            Volver
          </button>
          <div>
            <p className="font-bold text-[17px] text-[#2A3036]">Pago con PSE</p>
            <p className="text-[13px] text-gray-500 mt-0.5">Débito de <span className="font-figures font-semibold">{formatPesos(monto)}</span> a tu cuenta</p>
          </div>
          <div>
            <label className="block text-[12px] font-semibold text-gray-500 mb-1">Selecciona tu banco</label>
            <select
              value={bancoPSE}
              onChange={e => setBancoPSE(e.target.value)}
              className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] bg-white outline-none focus:border-[#0A1F44] cursor-pointer"
            >
              <option value="">— Selecciona —</option>
              {BANCOS_PSE.map(b => <option key={b}>{b}</option>)}
            </select>
          </div>
          <Btn variant="primary" size="lg" className="w-full" disabled={!bancoPSE} loading={procesando} onClick={handlePSEContinuar}>
            Continuar con PSE
          </Btn>
        </div>

        {/* Advertencia PSE — no salteable */}
        {advertenciaPSE && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
            <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
              <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center">
                <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              </div>
              <div>
                <p className="font-bold text-[16px] text-[#2A3036]">Importante antes de continuar</p>
                <ul className="mt-2 space-y-1.5 text-[13px] text-gray-600">
                  <li className="flex gap-2"><span className="text-[#2A3036] font-bold mt-0.5">•</span>Serás redirigido al portal de tu banco para completar el pago.</li>
                  <li className="flex gap-2"><span className="text-[#2A3036] font-bold mt-0.5">•</span>No cierres la ventana mientras el pago está en proceso.</li>
                  <li className="flex gap-2"><span className="text-[#2A3036] font-bold mt-0.5">•</span>Una vez confirmado el débito, el CDT se activará automáticamente.</li>
                  <li className="flex gap-2"><span className="text-[#2A3036] font-bold mt-0.5">•</span>En caso de error, comunícate con KOA antes de reintentar.</li>
                </ul>
              </div>
              <div className="flex gap-2">
                <Btn variant="secondary" size="md" className="flex-1" onClick={() => setAdvertenciaPSE(false)}>Cancelar</Btn>
                <Btn variant="primary" size="md" className="flex-1" loading={procesando} onClick={handlePSEConfirmar}>Entendido, continuar</Btn>
              </div>
            </div>
          </div>
        )}
      </>
    )
  }

  if (pantalla === 'transferencia') {
    return (
      <div className="space-y-4">
        <button onClick={() => setPantalla('seleccion')} className="flex items-center gap-1.5 text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          Volver
        </button>
        <div>
          <p className="font-bold text-[17px] text-[#2A3036]">Transferencia bancaria</p>
          <p className="text-[13px] text-gray-500 mt-0.5">Realiza la transferencia y adjunta el comprobante.</p>
        </div>
        <div className="bg-gray-50 rounded-2xl p-4 space-y-2 text-[13px]">
          <p className="font-semibold text-[#2A3036]">Datos bancarios KOA</p>
          {[
            { l: 'Banco', v: 'Bancolombia' },
            { l: 'Tipo', v: 'Cuenta corriente' },
            { l: 'Número', v: '123-456789-00', fig: true },
            { l: 'NIT', v: '900.222.111-1', fig: true },
            { l: 'Concepto', v: `Apertura CDT — ${formatPesos(monto)}`, fig: true },
          ].map(r => (
            <div key={r.l} className="flex justify-between">
              <span className="text-gray-500">{r.l}</span>
              <span className={`font-semibold text-[#2A3036] ${r.fig ? 'font-figures' : ''}`}>{r.v}</span>
            </div>
          ))}
        </div>
        <div>
          <label className="block text-[12px] font-semibold text-gray-500 mb-1">Adjuntar comprobante (PDF, JPG, PNG · máx. 5 MB)</label>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.jpg,.jpeg,.png"
            className="hidden"
            onChange={e => handleFileChange(e, setComprobante, setErrComprobante)}
          />
          {comprobante ? (
            <div className="flex items-center gap-2 bg-[#EFFFF7] border border-[#00DB8E]/30 rounded-xl px-4 py-3">
              <svg className="w-4 h-4 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              <span className="flex-1 text-[13px] text-[#2A3036] truncate">{comprobante.name}</span>
              <button onClick={() => setComprobante(null)} className="text-gray-400 hover:text-red-400 cursor-pointer">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          ) : (
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full border-2 border-dashed border-[#E5E7EB] rounded-xl px-4 py-5 flex flex-col items-center gap-2 hover:border-[#0A1F44] hover:bg-gray-50 transition-colors cursor-pointer"
            >
              <UploadIcon />
              <span className="text-[13px] text-gray-500">Haz clic para subir el comprobante</span>
            </button>
          )}
          {errComprobante && <p className="text-[12px] text-red-500 mt-1">{errComprobante}</p>}
        </div>
        <Btn variant="primary" size="lg" className="w-full" loading={enviandoTransferencia} onClick={handleEnviarTransferencia}>
          Enviar comprobante
        </Btn>
      </div>
    )
  }

  if (pantalla === 'cheque') {
    return (
      <div className="space-y-4">
        <button onClick={() => setPantalla('seleccion')} className="flex items-center gap-1.5 text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          Volver
        </button>
        <div>
          <p className="font-bold text-[17px] text-[#2A3036]">Pago con cheque</p>
          <p className="text-[13px] text-gray-500 mt-0.5">El cheque debe emitirse a nombre de <strong>KOA Compañía de Financiamiento S.A.</strong></p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-[12px] font-semibold text-gray-500 mb-1">Número del cheque</label>
            <input type="text" inputMode="numeric" value={numeroCheque} onChange={e => setNumeroCheque(e.target.value.replace(/\D/g, ''))}
              placeholder="Ej. 00123456"
              className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] font-figures text-[#2A3036] outline-none focus:border-[#0A1F44]" />
          </div>
          <div>
            <label className="block text-[12px] font-semibold text-gray-500 mb-1">Banco emisor</label>
            <select value={bancoCheque} onChange={e => setBancoCheque(e.target.value)}
              className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] bg-white outline-none focus:border-[#0A1F44] cursor-pointer">
              <option value="">— Selecciona —</option>
              {BANCOS_PSE.map(b => <option key={b}>{b}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-[12px] font-semibold text-gray-500 mb-1">Imágenes del cheque (anverso y reverso · máx. 3 archivos, 5 MB c/u)</label>
          <input ref={chequeRef} type="file" accept=".pdf,.jpg,.jpeg,.png" multiple className="hidden" onChange={handleMultiFile} />
          <div className="space-y-2">
            {comprobantesCheque.map((f, i) => (
              <div key={i} className="flex items-center gap-2 bg-[#EFFFF7] border border-[#00DB8E]/30 rounded-xl px-3 py-2">
                <svg className="w-4 h-4 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                <span className="flex-1 text-[13px] text-[#2A3036] truncate">{f.name}</span>
                <button onClick={() => setComprobantesCheque(prev => prev.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-400 cursor-pointer">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
            ))}
            {comprobantesCheque.length < 3 && (
              <button onClick={() => chequeRef.current?.click()}
                className="w-full border-2 border-dashed border-[#E5E7EB] rounded-xl px-4 py-4 flex items-center justify-center gap-2 hover:border-[#0A1F44] hover:bg-gray-50 transition-colors cursor-pointer text-[13px] text-gray-500">
                <UploadIcon /> Adjuntar imagen
              </button>
            )}
          </div>
        </div>
        <Btn variant="primary" size="lg" className="w-full"
          disabled={!numeroCheque || !bancoCheque || comprobantesCheque.length === 0}
          loading={enviandoCheque}
          onClick={handleEnviarCheque}>
          Enviar cheque
        </Btn>
      </div>
    )
  }

  return null
}
