import SectionHeader from '../components/SectionHeader'

export default function EducacionFinanciera() {
  return (
    <div>
      <SectionHeader title="Educación financiera" subtitle="Aprende a gestionar mejor tu dinero" />
      <div className="bg-white rounded-2xl border border-[#E5E7EB] p-8 text-center text-gray-400">
        <p className="text-[15px]">Esta sección está en construcción.</p>
      </div>
    </div>
  )
}
