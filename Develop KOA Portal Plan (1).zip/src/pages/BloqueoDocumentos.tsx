import { useState, useRef } from 'react'
import Btn from '../components/Btn'
import SectionHeader from '../components/SectionHeader'

interface ArchivoSubido {
  nombre: string
  tamano: number
}

function FilePDF({ file, onRemove }: { file: ArchivoSubido; onRemove?: () => void }) {
  return (
    <div className="flex items-center gap-2 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2">
      <svg className="w-4 h-4 text-[#005E3C] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
      <span className="flex-1 text-[12px] text-[#2A3036] truncate">{file.nombre}</span>
      <span className="text-[11px] text-gray-400 font-figures">{(file.tamano / 1024 / 1024).toFixed(1)} MB</span>
      {onRemove && (
        <button onClick={onRemove} className="text-gray-400 hover:text-red-400 cursor-pointer">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      )}
    </div>
  )
}

function UploadZone({ onFile, err }: { onFile: (f: File) => void; err?: string }) {
  const ref = useRef<HTMLInputElement>(null)
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (f) onFile(f)
    if (ref.current) ref.current.value = ''
  }
  return (
    <div>
      <input ref={ref} type="file" accept=".pdf" className="hidden" onChange={handleChange} />
      <button
        onClick={() => ref.current?.click()}
        className="w-full border-2 border-dashed border-[#E5E7EB] rounded-xl px-4 py-4 flex flex-col items-center gap-1.5 hover:border-[#0A1F44] hover:bg-gray-50 transition-colors cursor-pointer"
      >
        <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
        <span className="text-[12px] text-gray-500">Clic para subir PDF · máx. 5 MB</span>
      </button>
      {err && <p className="text-[12px] text-red-500 mt-1">{err}</p>}
    </div>
  )
}

interface SeccionDocumentosProps {
  titulo: string
  descripcion: string
  docs: string[]
  bloqueadaRazon?: string
}

function SeccionDocumentos({ titulo, descripcion, docs, bloqueadaRazon }: SeccionDocumentosProps) {
  const [archivos, setArchivos] = useState<ArchivoSubido[]>([])
  const [errs, setErrs] = useState<Record<number, string>>({})
  const [enviando, setEnviando] = useState(false)
  const [enviado, setEnviado] = useState(false)

  const agregar = (docIdx: number, file: File) => {
    if (file.type !== 'application/pdf') { setErrs(e => ({ ...e, [docIdx]: 'Solo se aceptan archivos PDF.' })); return }
    if (file.size > 5 * 1024 * 1024) { setErrs(e => ({ ...e, [docIdx]: 'El archivo no puede superar 5 MB.' })); return }
    setErrs(e => { const n = { ...e }; delete n[docIdx]; return n })
    setArchivos(prev => {
      const n = [...prev]
      n[docIdx] = { nombre: file.name, tamano: file.size }
      return n
    })
  }

  const quitar = (i: number) => setArchivos(prev => { const n = [...prev]; n[i] = undefined as unknown as ArchivoSubido; return n })

  const handleEnviar = () => {
    if (archivos.filter(Boolean).length !== docs.length) return
    setEnviando(true)
    setTimeout(() => { setEnviando(false); setEnviado(true) }, 1600)
  }

  if (bloqueadaRazon) {
    return (
      <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5 opacity-60">
        <div className="flex items-center gap-2 mb-1">
          <p className="font-semibold text-[15px] text-[#2A3036]">{titulo}</p>
          <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
        </div>
        <p className="text-[12px] text-gray-400">{bloqueadaRazon}</p>
      </div>
    )
  }

  if (enviado) {
    return (
      <div className="bg-white rounded-2xl border border-[#00DB8E]/40 p-5">
        <div className="flex items-center gap-2 mb-1">
          <p className="font-semibold text-[15px] text-[#2A3036]">{titulo}</p>
          <svg className="w-5 h-5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        </div>
        <p className="text-[12px] text-[#005E3C] font-medium">Documentos enviados. En revisión por KOA.</p>
        <div className="mt-3 space-y-2">
          {archivos.filter(Boolean).map((a, i) => <FilePDF key={i} file={a} />)}
        </div>
      </div>
    )
  }

  const listos = archivos.filter(Boolean).length
  return (
    <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5 space-y-4">
      <div>
        <p className="font-semibold text-[15px] text-[#2A3036]">{titulo}</p>
        <p className="text-[12px] text-gray-500 mt-0.5">{descripcion}</p>
      </div>
      <div className="space-y-3">
        {docs.map((doc, i) => (
          <div key={doc} className="space-y-1.5">
            <p className="text-[12px] font-semibold text-gray-500">{doc}</p>
            {archivos[i] ? (
              <FilePDF file={archivos[i]} onRemove={() => quitar(i)} />
            ) : (
              <UploadZone onFile={f => agregar(i, f)} err={errs[i]} />
            )}
          </div>
        ))}
      </div>
      <Btn
        variant="primary"
        size="md"
        className="w-full"
        disabled={listos !== docs.length}
        loading={enviando}
        onClick={handleEnviar}
      >
        Enviar documentos ({listos}/{docs.length})
      </Btn>
    </div>
  )
}

type TipoBloqueo = 'A' | 'B'

interface BloqueoCDTProps {
  tipo: TipoBloqueo
}

function BloqueoCDT({ tipo }: BloqueoCDTProps) {
  const [dialogoOpen, setDialogoOpen] = useState(false)
  const [cargueOpen, setCargueOpen] = useState(false)

  if (tipo === 'A') {
    return (
      <>
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-[14px] text-[#2A3036]">CDT bloqueado — Acción requerida</p>
              <p className="text-[12px] text-gray-500 mt-0.5 leading-relaxed">
                Tu CDT fue bloqueado por una alerta de seguridad. Para desbloquearlo debes cargar los documentos requeridos.
              </p>
            </div>
          </div>
          <Btn variant="danger" size="md" className="w-full mt-4" onClick={() => setCargueOpen(true)}>
            Cargar documentos para desbloqueo
          </Btn>
        </div>

        {cargueOpen && (
          <SeccionDocumentos
            titulo="Documentos de desbloqueo"
            descripcion="Carga los documentos solicitados para desbloquear tu CDT."
            docs={['Cédula de ciudadanía (frente)', 'Cédula de ciudadanía (reverso)', 'Selfie con cédula']}
          />
        )}
      </>
    )
  }

  // Tipo B
  return (
    <>
      <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-[14px] text-[#2A3036]">Verificación pendiente</p>
            <p className="text-[12px] text-gray-500 mt-0.5 leading-relaxed">
              KOA necesita verificar información adicional. Comunícate con nosotros o espera que un asesor te contacte.
            </p>
          </div>
        </div>
        <Btn variant="secondary" size="md" className="w-full mt-4 opacity-60" disabled onClick={() => setDialogoOpen(true)}>
          Ver detalles
        </Btn>
      </div>

      {dialogoOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setDialogoOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
            <p className="font-bold text-[16px] text-[#2A3036]">Verificación en proceso</p>
            <p className="text-[13px] text-gray-600 leading-relaxed">
              Nuestro equipo está revisando tu información. Este proceso puede demorar hasta 2 días hábiles. Te notificaremos por correo electrónico cuando se resuelva.
            </p>
            <p className="text-[13px] text-gray-600 leading-relaxed">
              Si tienes alguna duda, comunícate con nosotros al <span className="font-figures font-semibold text-[#2A3036]">018000 123 456</span> o por el chat de la plataforma.
            </p>
            <Btn variant="primary" size="md" className="w-full" onClick={() => setDialogoOpen(false)}>Entendido</Btn>
          </div>
        </div>
      )}
    </>
  )
}

export default function BloqueoDocumentos() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <SectionHeader title="Bloqueos y documentos" subtitle="Gestiona alertas de seguridad y sube documentos requeridos" />

      {/* Bloqueos activos */}
      <div className="space-y-3">
        <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400">Alertas activas</p>
        <BloqueoCDT tipo="A" />
        <BloqueoCDT tipo="B" />
      </div>

      {/* Documentos requeridos */}
      <div className="space-y-3">
        <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400">Documentos requeridos</p>

        <SeccionDocumentos
          titulo="Identidad"
          descripcion="Cédula de ciudadanía vigente, ambas caras en PDF escaneado."
          docs={['Cédula frente (PDF)', 'Cédula reverso (PDF)', 'RUT actualizado (PDF)']}
        />

        <SeccionDocumentos
          titulo="Soporte financiero"
          descripcion="Documentación de origen de fondos para cumplimiento SARLAFT."
          docs={['Declaración de renta o carta de no declarante (PDF)', 'Extractos bancarios últimos 3 meses (PDF)', 'Certificado de ingresos (PDF)']}
          bloqueadaRazon="Esta sección se habilitará una vez que envíes los documentos de identidad."
        />

        <SeccionDocumentos
          titulo="Documentos laborales"
          descripcion="Acredita tu situación laboral o empresarial actual."
          docs={['Certificado laboral o cámara de comercio (PDF)', 'Contrato de trabajo o RUT empresarial (PDF)', 'Carta de autorización de descuento libranza (PDF)']}
          bloqueadaRazon="Esta sección se habilitará después del soporte financiero."
        />
      </div>
    </div>
  )
}
