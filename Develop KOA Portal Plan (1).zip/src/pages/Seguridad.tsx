import { useState, useEffect, useRef } from 'react'
import SectionHeader from '../components/SectionHeader'

const DEMO_OTP = '248731'
const D = 6

type FlowStep = 'idle' | 'otp' | 'validating' | 'otp-error' | 'new-pin' | 'pin-error' | 'saving' | 'success'

const OTP_STEPS = ['Verificando código…', 'Confirmando identidad…', '']

function ShieldCheckIcon() {
  return (
    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  )
}

function KeyIcon() {
  return (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
    </svg>
  )
}

/* ── Digit row ──────────────────────────────────────── */
interface DigitRowProps {
  digits: string[]
  inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>
  onChange: (i: number, v: string) => void
  onKeyDown: (i: number, e: React.KeyboardEvent<HTMLInputElement>) => void
  onPaste?: (e: React.ClipboardEvent) => void
  shake?: boolean
  autoFocus?: boolean
}

function DigitRow({ digits, inputRefs, onChange, onKeyDown, onPaste, shake, autoFocus }: DigitRowProps) {
  return (
    <div
      className={`flex gap-2 justify-center ${shake ? 'animate-[shake_0.35s_ease-in-out]' : ''}`}
      onPaste={onPaste}
    >
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { inputRefs.current[i] = el }}
          type="password"
          inputMode="numeric"
          maxLength={1}
          value={d}
          autoFocus={autoFocus && i === 0}
          onChange={e => onChange(i, e.target.value)}
          onKeyDown={e => onKeyDown(i, e)}
          className={`w-11 h-[52px] text-center font-figures font-black text-[22px] rounded-xl border-2 outline-none transition-all duration-150 ${
            shake
              ? 'border-[#EF4444] bg-[#FEF2F2] text-[#DC2626]'
              : d
                ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
                : 'border-[#E8ECF2] bg-white focus:border-[#06005A]'
          }`}
        />
      ))}
    </div>
  )
}

/* ── Validating overlay ─────────────────────────────── */
function ValidatingOverlay({
  phase, isSuccess, isError,
}: {
  phase: number
  isSuccess: boolean
  isError: boolean
}) {
  const steps = [
    OTP_STEPS[0],
    OTP_STEPS[1],
    isError ? 'Código incorrecto' : 'Acceso autorizado',
  ]
  return (
    <div className="flex flex-col items-center justify-center gap-8 py-10">
      <div className="relative flex items-center justify-center">
        <div
          className="absolute w-24 h-24 rounded-full border-2 animate-spin"
          style={{
            animationDuration: '2.5s',
            borderColor: 'transparent',
            borderTopColor: isError ? '#EF4444' : '#00DB8E',
          }}
        />
        <div
          className="absolute w-16 h-16 rounded-full border-2 animate-spin"
          style={{
            animationDuration: '1.8s',
            animationDirection: 'reverse',
            borderColor: 'transparent',
            borderBottomColor: isError ? '#EF4444' : '#06005A',
            opacity: 0.2,
          }}
        />
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
          isSuccess ? 'bg-[#00DB8E]' : isError ? 'bg-[#EF4444]' : 'bg-[#06005A]'
        }`}>
          {isSuccess ? (
            <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          ) : isError ? (
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <KeyIcon />
          )}
        </div>
      </div>

      <div className="space-y-3 w-full max-w-[200px]">
        {steps.map((s, i) => {
          const done = i < phase || isSuccess
          const active = i === phase && !isSuccess
          const err = isError && i === phase
          return (
            <div key={i} className={`flex items-center gap-3 transition-all duration-400 ${i <= phase ? 'opacity-100' : 'opacity-20'}`}>
              <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
                done ? 'bg-[#00DB8E]' : err ? 'bg-[#EF4444]' : active ? 'border-2 border-[#06005A] bg-[#06005A]/08' : 'bg-[#F0F0F0]'
              }`}>
                {done ? (
                  <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                ) : err ? (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : active ? (
                  <div className="w-2 h-2 rounded-full bg-[#06005A] animate-pulse" />
                ) : null}
              </div>
              <p className={`text-[13px] transition-colors duration-300 ${
                err ? 'text-[#DC2626] font-bold' : done ? 'text-[#005E3C] font-semibold' : active ? 'text-[#2A3036] font-bold' : 'text-gray-300'
              }`}>{s}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ── Main component ─────────────────────────────────── */
export default function Seguridad() {
  const [step, setStep] = useState<FlowStep>('idle')
  const isCorrectRef = useRef(false)

  /* OTP state */
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(D).fill(''))
  const [otpSeconds, setOtpSeconds] = useState(180)
  const [otpResent, setOtpResent] = useState(false)
  const [validPhase, setValidPhase] = useState(0)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  /* New PIN state */
  const [newPin, setNewPin] = useState<string[]>(Array(D).fill(''))
  const [confirmPin, setConfirmPin] = useState<string[]>(Array(D).fill(''))
  const [shakeNew, setShakeNew] = useState(false)
  const [shakeConfirm, setShakeConfirm] = useState(false)
  const newPinRefs = useRef<(HTMLInputElement | null)[]>([])
  const confirmPinRefs = useRef<(HTMLInputElement | null)[]>([])

  /* OTP countdown */
  useEffect(() => {
    if (step !== 'otp' || otpSeconds <= 0) return
    const t = setInterval(() => setOtpSeconds(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [step, otpSeconds])

  /* Auto-validate OTP on 6 digits */
  const otpCode = otpDigits.join('')
  useEffect(() => {
    if (otpCode.length === D && step === 'otp') {
      isCorrectRef.current = otpCode === DEMO_OTP
      runOtpValidation()
    }
  }, [otpCode])

  function runOtpValidation() {
    setStep('validating')
    setValidPhase(0)
    const t1 = setTimeout(() => setValidPhase(1), 700)
    const t2 = setTimeout(() => setValidPhase(2), 1400)
    const t3 = setTimeout(() => {
      if (isCorrectRef.current) {
        setStep('new-pin')
        setOtpDigits(Array(D).fill(''))
        setTimeout(() => newPinRefs.current[0]?.focus(), 60)
      } else {
        setStep('otp-error')
        setTimeout(() => {
          setStep('otp')
          setOtpDigits(Array(D).fill(''))
          setTimeout(() => otpRefs.current[0]?.focus(), 30)
        }, 1400)
      }
    }, 2000)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
  }

  /* Auto-focus confirmPin when newPin is full */
  const newCode = newPin.join('')
  useEffect(() => {
    if (newCode.length === D && step === 'new-pin') {
      setTimeout(() => confirmPinRefs.current[0]?.focus(), 30)
    }
  }, [newCode])

  /* Check confirm PIN match when full */
  const confirmCode = confirmPin.join('')
  useEffect(() => {
    if (confirmCode.length === D && step === 'new-pin') {
      if (confirmCode === newCode) {
        setStep('saving')
        setTimeout(() => setStep('success'), 1200)
      } else {
        setShakeConfirm(true)
        setTimeout(() => {
          setShakeConfirm(false)
          setConfirmPin(Array(D).fill(''))
          confirmPinRefs.current[0]?.focus()
        }, 500)
      }
    }
  }, [confirmCode])

  function handleOtpDigit(i: number, v: string) {
    if (step !== 'otp') return
    const ch = v.replace(/\D/g, '').slice(-1)
    const next = [...otpDigits]; next[i] = ch; setOtpDigits(next)
    if (ch && i < D - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpKey(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !otpDigits[i] && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowLeft' && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < D - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpPaste(e: React.ClipboardEvent) {
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, D)
    const next = [...otpDigits]; pasted.split('').forEach((ch, i) => { next[i] = ch }); setOtpDigits(next)
    otpRefs.current[Math.min(pasted.length, D - 1)]?.focus()
  }

  function makePinHandlers(
    digits: string[], setDigits: (d: string[]) => void,
    refs: React.MutableRefObject<(HTMLInputElement | null)[]>,
    nextRefs?: React.MutableRefObject<(HTMLInputElement | null)[]>
  ) {
    const onChange = (i: number, v: string) => {
      if (step !== 'new-pin') return
      const ch = v.replace(/\D/g, '').slice(-1)
      const next = [...digits]; next[i] = ch; setDigits(next)
      if (ch && i < D - 1) refs.current[i + 1]?.focus()
      if (ch && i === D - 1 && nextRefs) setTimeout(() => nextRefs.current[0]?.focus(), 30)
    }
    const onKeyDown = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Backspace' && !digits[i] && i > 0) refs.current[i - 1]?.focus()
      if (e.key === 'ArrowLeft' && i > 0) refs.current[i - 1]?.focus()
      if (e.key === 'ArrowRight' && i < D - 1) refs.current[i + 1]?.focus()
    }
    return { onChange, onKeyDown }
  }

  const newPinHandlers = makePinHandlers(newPin, setNewPin, newPinRefs, confirmPinRefs)
  const confirmPinHandlers = makePinHandlers(confirmPin, setConfirmPin, confirmPinRefs)

  function resendOtp() {
    setOtpDigits(Array(D).fill(''))
    setOtpSeconds(180)
    setOtpResent(true)
    setTimeout(() => setOtpResent(false), 3000)
    setTimeout(() => otpRefs.current[0]?.focus(), 30)
  }

  function reset() {
    setStep('idle')
    setOtpDigits(Array(D).fill(''))
    setOtpSeconds(180)
    setOtpResent(false)
    setNewPin(Array(D).fill(''))
    setConfirmPin(Array(D).fill(''))
    setValidPhase(0)
  }

  const mins = String(Math.floor(otpSeconds / 60)).padStart(2, '0')
  const secs = String(otpSeconds % 60).padStart(2, '0')

  /* ── Render ── */
  return (
    <div className="max-w-2xl mx-auto">
      <SectionHeader title="Seguridad" subtitle="Gestiona tus contraseñas y accesos" />

      <div className="space-y-5">

        {/* ── Banner ──────────────────────────────── */}
        <div className="relative bg-[#06005A] rounded-3xl overflow-hidden card-enter">
          <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-44 h-44 rounded-full bg-white/[0.025] pointer-events-none" />
          <div className="relative px-6 py-5 flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-[#00DB8E]/15 border border-[#00DB8E]/25 flex items-center justify-center flex-shrink-0">
              <div className="text-[#00DB8E]"><ShieldCheckIcon /></div>
            </div>
            <div>
              <p className="text-white font-bold text-[16px] leading-tight mb-0.5">Cuenta protegida</p>
              <p className="text-white/45 text-[12px]">Tus accesos y datos están seguros</p>
            </div>
          </div>
        </div>

        {/* ── Cambiar clave ────────────────────────── */}
        <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-1">

          {/* Header always visible */}
          <div className="px-5 pt-5 pb-4 flex items-center gap-3 border-b border-[#F0F2F5]">
            <div className="w-9 h-9 rounded-xl bg-[#F0F0FF] flex items-center justify-center flex-shrink-0 text-[#06005A]">
              <KeyIcon />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-[15px] text-[#2A3036]">Clave de acceso</p>
              <p className="text-[12px] text-gray-400 mt-0.5">Clave numérica de 6 dígitos</p>
            </div>
            {step !== 'idle' && step !== 'success' && (
              <button
                onClick={reset}
                className="text-[12px] font-semibold text-gray-400 hover:text-gray-600 cursor-pointer transition-colors"
              >
                Cancelar
              </button>
            )}
          </div>

          {/* ── Step: idle ── */}
          {step === 'idle' && (
            <div className="px-5 py-5">
              <p className="text-[13px] text-gray-500 mb-4 leading-relaxed">
                Para cambiar tu clave, primero verificaremos tu identidad enviando un código a tu correo registrado.
              </p>
              <button
                onClick={() => setStep('otp')}
                className="flex items-center gap-2 bg-[#06005A] text-white text-[13px] font-bold px-5 py-2.5 rounded-xl hover:bg-[#08007A] transition-colors cursor-pointer shadow-md shadow-[#06005A]/20"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
                Cambiar clave
              </button>
            </div>
          )}

          {/* ── Step: OTP entry ── */}
          {step === 'otp' && (
            <div className="px-5 py-6 flex flex-col items-center gap-5">
              {/* Email icon */}
              <div className="flex flex-col items-center gap-2 text-center">
                <div className="w-12 h-12 rounded-2xl bg-[#06005A] flex items-center justify-center relative">
                  <svg className="w-6 h-6 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#00DB8E] flex items-center justify-center">
                    <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </span>
                </div>
                <div>
                  <p className="font-black text-[16px] text-[#2A3036]">Verifica tu identidad</p>
                  <p className="text-[12px] text-gray-400 mt-0.5">
                    Código enviado a <span className="font-semibold text-[#2A3036]">a****s@correo.com</span>
                  </p>
                </div>
              </div>

              {/* OTP boxes */}
              <DigitRow
                digits={otpDigits}
                inputRefs={otpRefs}
                onChange={handleOtpDigit}
                onKeyDown={handleOtpKey}
                onPaste={handleOtpPaste}
                autoFocus
              />

              {/* Timer */}
              <div className="text-center">
                {otpSeconds > 0 ? (
                  <p className="text-[12px] text-gray-400">
                    Vence en <span className="font-figures font-bold text-[#2A3036]">{mins}:{secs}</span>
                  </p>
                ) : (
                  <p className="text-[12px] text-[#EF4444] font-semibold">El código expiró</p>
                )}
                <button
                  onClick={resendOtp}
                  className="text-[12px] font-bold text-[#06005A] hover:underline cursor-pointer mt-1"
                >
                  {otpResent ? '✓ Código reenviado' : 'Reenviar código'}
                </button>
              </div>

              {/* Demo hint */}
              <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-4 py-2.5 flex items-center gap-2 w-full max-w-xs">
                <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-[11px] text-[#005E3C]">
                  <span className="font-bold">Demo:</span> el código es{' '}
                  <button
                    onClick={() => {
                      setOtpDigits(DEMO_OTP.split(''))
                      setTimeout(() => otpRefs.current[D - 1]?.focus(), 0)
                    }}
                    className="font-figures font-black underline cursor-pointer"
                  >
                    {DEMO_OTP}
                  </button>
                </p>
              </div>
            </div>
          )}

          {/* ── Step: validating OTP ── */}
          {(step === 'validating' || step === 'otp-error') && (
            <div className="px-5">
              <ValidatingOverlay
                phase={validPhase}
                isSuccess={false}
                isError={step === 'otp-error'}
              />
            </div>
          )}

          {/* ── Step: new PIN entry ── */}
          {step === 'new-pin' && (
            <div className="px-5 py-6 flex flex-col items-center gap-6">
              <div className="text-center">
                <p className="font-black text-[16px] text-[#2A3036]">Elige tu nueva clave</p>
                <p className="text-[12px] text-gray-400 mt-0.5">Ingresa y confirma tu clave de 6 dígitos</p>
              </div>

              <div className="space-y-5 w-full flex flex-col items-center">
                <div className="flex flex-col items-center gap-2">
                  <p className="text-[10px] font-black tracking-[0.18em] uppercase text-gray-400">Nueva clave</p>
                  <DigitRow
                    digits={newPin}
                    inputRefs={newPinRefs}
                    onChange={newPinHandlers.onChange}
                    onKeyDown={newPinHandlers.onKeyDown}
                    shake={shakeNew}
                    autoFocus
                  />
                </div>

                <div className={`flex flex-col items-center gap-2 transition-all duration-300 ${newCode.length === D ? 'opacity-100' : 'opacity-40'}`}>
                  <p className="text-[10px] font-black tracking-[0.18em] uppercase text-gray-400">Confirmar clave</p>
                  <DigitRow
                    digits={confirmPin}
                    inputRefs={confirmPinRefs}
                    onChange={confirmPinHandlers.onChange}
                    onKeyDown={confirmPinHandlers.onKeyDown}
                    shake={shakeConfirm}
                  />
                  {shakeConfirm && (
                    <p className="text-[11px] font-bold text-[#DC2626]">Las claves no coinciden</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── Step: saving ── */}
          {step === 'saving' && (
            <div className="px-5 py-10 flex flex-col items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#06005A] flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              </div>
              <p className="text-[13px] font-semibold text-gray-500">Actualizando clave…</p>
            </div>
          )}

          {/* ── Step: success ── */}
          {step === 'success' && (
            <div className="px-5 py-8 flex flex-col items-center gap-4 text-center">
              <div className="w-14 h-14 rounded-2xl bg-[#EFFFF7] border border-[#00DB8E]/30 flex items-center justify-center scale-in">
                <svg className="w-7 h-7 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <p className="font-black text-[16px] text-[#2A3036]">Clave actualizada</p>
                <p className="text-[12px] text-gray-400 mt-1">Tu nueva clave está activa desde ahora</p>
              </div>
              <button
                onClick={reset}
                className="text-[13px] font-bold text-[#06005A] hover:underline cursor-pointer mt-1"
              >
                Listo
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  )
}
