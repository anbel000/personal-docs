import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import LoadingSkeleton from '../components/LoadingSkeleton'
import Btn from '../components/Btn'
import PazYSalvoFlow from '../libranza/PazYSalvoFlow'
import { creditos, kpiLibranza, formatPesos, type Credito } from '../data/mockData'
import { useDemoContext } from '../context/DemoContext'

/* ─── Shared floating particles ─────────────────────────── */
const PARTICLES = [
  { size: 5, top: '12%', left: '6%',  dur: '3.5s', delay: '0s',   op: 0.22, fy: '-14px' },
  { size: 3, top: '68%', left: '10%', dur: '4.2s', delay: '1.1s', op: 0.16, fy: '-10px' },
  { size: 4, top: '22%', right: '8%', dur: '3.9s', delay: '0.6s', op: 0.28, fy: '-18px' },
  { size: 6, top: '76%', right: '14%',dur: '2.7s', delay: '1.8s', op: 0.13, fy: '-12px' },
  { size: 3, top: '48%', left: '44%', dur: '5s',   delay: '2.3s', op: 0.11, fy: '-8px'  },
]

function CardParticles() {
  return (
    <>
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            width: p.size, height: p.size,
            top: p.top, left: p.left, right: p.right,
            background: '#059669',
            opacity: p.op,
            ['--dur' as string]: p.dur,
            ['--delay' as string]: p.delay,
            ['--fy' as string]: p.fy,
            ['--op' as string]: p.op,
          }}
        />
      ))}
    </>
  )
}

function DotGrid({ id }: { id: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.04] pointer-events-none" preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id={id} x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  )
}

/* ─── Summary hero ───────────────────────────────────────── */
function SummaryHero({ onPazYSalvo }: { onPazYSalvo: () => void }) {
  return (
    <div
      className="rounded-3xl overflow-hidden card-enter relative"
      style={{ background: '#06005A' }}
    >
      <DotGrid id="dots-lib-hero" />
      <CardParticles />
      <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-[#059669]/[0.08] pointer-events-none" />
      <div className="absolute left-1/2 bottom-0 w-48 h-48 rounded-full bg-white/[0.02] pointer-events-none" />

      <div className="relative z-10 px-8 pt-8 pb-6">
        {/* Top label */}
        <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/50 mb-5">
          Créditos de Libranza · KOA
        </p>

        {/* Main metric */}
        <div className="flex flex-wrap items-end justify-between gap-6 mb-6">
          <div>
            <p className="text-white/60 text-[12px] font-semibold mb-1">Deuda total</p>
            <p
              className="font-figures text-white font-black leading-none animate-number-pop"
              style={{ fontSize: 'clamp(32px, 6vw, 48px)', ['--delay' as string]: '0.08s' }}
            >
              {formatPesos(kpiLibranza.deudaTotal)}
            </p>
          </div>

          <div className="flex items-end gap-8 pb-1">
            <div>
              <p className="text-white/50 text-[9px] font-bold tracking-[0.16em] uppercase mb-1.5">Créditos activos</p>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#059669] animate-pulse flex-shrink-0" />
                <p className="font-figures text-white text-[26px] font-black leading-none animate-number-pop"
                  style={{ ['--delay' as string]: '0.16s' }}>
                  {kpiLibranza.creditosActivos}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Divider + action */}
        <div className="border-t border-white/[0.1] pt-5 flex items-center justify-between gap-4">
          <p className="text-white/40 text-[11px] leading-snug max-w-xs">
            Descuento automático por nómina o pensión
          </p>
          <button
            onClick={onPazYSalvo}
            className="flex items-center gap-2 bg-white/[0.1] hover:bg-white/[0.17] border border-white/[0.12] text-white text-[12px] font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer flex-shrink-0"
          >
            <svg className="w-3.5 h-3.5 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>
            Generar paz y salvo
          </button>
        </div>
      </div>
    </div>
  )
}

/* ─── Credit card ────────────────────────────────────────── */
function CreditoCard({ credito, delay = 0 }: { credito: Credito; delay?: number }) {
  const navigate = useNavigate()
  const pct = Math.round((credito.cuotaActual / credito.totalCuotas) * 100)
  const enMora = credito.estado === 'en-mora'
  const cuotasRestantes = credito.totalCuotas - credito.cuotaActual

  return (
    <div
      className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden cursor-pointer group card-enter hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
      style={{ animationDelay: `${delay}s` }}
      onClick={() => navigate(`/libranza/credito/${credito.id}`)}
    >
      {/* Colored top accent */}
      <div className={`h-1 w-full ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669]'}`} />

      <div className="p-5">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="min-w-0">
            <p className="font-bold text-[#2A3036] text-[15px] leading-tight truncate">{credito.pagaduria}</p>
            <p className="font-figures text-[12px] text-gray-400 mt-0.5">{credito.numeroMascarado}</p>
          </div>
          <div className="flex-shrink-0 flex items-center gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669] animate-pulse'}`} />
            <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
              enMora
                ? 'bg-[#FEF2F2] text-[#DC2626]'
                : 'bg-[#ECFDF5] text-[#065F46]'
            }`}>
              {enMora ? 'En mora' : 'Al día'}
            </span>
          </div>
        </div>

        {/* Saldo principal */}
        <div className="mb-4">
          <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Saldo pendiente</p>
          <p className="font-figures text-[28px] font-black text-[#2A3036] leading-none animate-number-pop"
            style={{ ['--delay' as string]: `${delay + 0.1}s` }}>
            {formatPesos(credito.saldo)}
          </p>
        </div>

        {/* Info chips */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Cuota</p>
            <p className="font-figures text-[13px] font-black text-[#2A3036] leading-tight">{formatPesos(credito.cuotaMensual)}</p>
          </div>
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Tasa</p>
            <p className="font-figures text-[13px] font-black text-[#2A3036] leading-tight">{credito.tasa} %</p>
          </div>
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Restantes</p>
            <p className="font-figures text-[13px] font-black text-[#2A3036] leading-tight">{cuotasRestantes} cuotas</p>
          </div>
        </div>

        {/* Progress */}
        <div>
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] text-gray-400">Cuota {credito.cuotaActual} de {credito.totalCuotas}</span>
            <span className="font-figures text-[11px] font-bold text-[#2A3036]">{pct} % pagado</span>
          </div>
          <div className="h-1.5 bg-[#F0F0F0] rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669]'}`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-5 pb-4 flex items-center justify-between">
        <p className="text-[11px] text-gray-400">{credito.pagaduria}</p>
        <div className="flex items-center gap-1 text-[12px] font-bold text-[#06005A] group-hover:gap-2 transition-all">
          <span>Ver detalle</span>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  )
}

/* ─── Empty: Jurídica ────────────────────────────────────── */
function LibranzaJuridicaBlock() {
  const navigate = useNavigate()
  return (
    <div
      className="relative overflow-hidden rounded-3xl card-enter"
      style={{ background: '#06005A', minHeight: 320 }}
    >
      <DotGrid id="dots-jur" />
      <CardParticles />
      <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-[#059669]/[0.09] pointer-events-none" />
      <div className="absolute -left-8 bottom-0 w-36 h-36 rounded-full bg-white/[0.02] pointer-events-none" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[0, 1].map(i => (
          <div
            key={i}
            className="absolute rounded-full border"
            style={{
              width: 110 + i * 50, height: 110 + i * 50,
              borderColor: `rgba(5,150,105,${0.15 - i * 0.05})`,
              animation: `pulseRing 3s ease-out ${i * 1.2}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center text-center px-8 py-14 gap-5">
        <div className="w-14 h-14 rounded-2xl bg-[#059669]/20 border border-[#059669]/20 flex items-center justify-center animate-number-pop"
          style={{ ['--delay' as string]: '0.08s' }}>
          <svg className="w-7 h-7 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
        </div>
        <div className="space-y-2 animate-number-pop" style={{ ['--delay' as string]: '0.16s' }}>
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/50">Libranza · KOA</p>
          <h2 className="text-white font-black text-[24px] tracking-tight">Crédito empresarial</h2>
          <p className="text-white/50 text-[13px] max-w-xs leading-relaxed">
            Los créditos de libranza para personas jurídicas requieren atención personalizada con un asesor especializado.
          </p>
        </div>
        <div className="animate-number-pop" style={{ ['--delay' as string]: '0.24s' }}>
          <Btn variant="mint" size="lg" onClick={() => navigate('/contactanos')}>
            Hablar con un asesor
          </Btn>
        </div>
      </div>
    </div>
  )
}

/* ─── Empty: sin producto ────────────────────────────────── */
function LibranzaSinProducto() {
  const navigate = useNavigate()
  return (
    <div
      className="relative overflow-hidden rounded-3xl card-enter"
      style={{ background: '#06005A', minHeight: 320 }}
    >
      <DotGrid id="dots-empty-lib" />
      <CardParticles />
      <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-[#059669]/[0.09] pointer-events-none" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[0, 1].map(i => (
          <div
            key={i}
            className="absolute rounded-full border"
            style={{
              width: 110 + i * 45, height: 110 + i * 45,
              borderColor: `rgba(5,150,105,${0.12 - i * 0.04})`,
              animation: `pulseRing 3s ease-out ${i * 1.1}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center text-center px-8 py-14 gap-5">
        <div className="w-14 h-14 rounded-2xl bg-[#059669]/20 border border-[#059669]/20 flex items-center justify-center animate-number-pop"
          style={{ ['--delay' as string]: '0.08s' }}>
          <svg className="w-7 h-7 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <div className="space-y-2 animate-number-pop" style={{ ['--delay' as string]: '0.16s' }}>
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/50">Libranza · KOA</p>
          <h2 className="text-white font-black text-[24px] tracking-tight">Sin créditos activos</h2>
          <p className="text-white/50 text-[13px] max-w-xs leading-relaxed">
            No tienes créditos de libranza con nosotros. Descuento directo de nómina o pensión, sin fiador.
          </p>
        </div>
        <div className="animate-number-pop" style={{ ['--delay' as string]: '0.24s' }}>
          <Btn variant="mint" size="lg" onClick={() => navigate('/contactanos')}>
            Solicitar crédito
          </Btn>
        </div>
      </div>
    </div>
  )
}

/* ─── Skeleton ───────────────────────────────────────────── */
function LibranzaSkeleton() {
  return (
    <div className="space-y-5">
      <div className="rounded-3xl overflow-hidden" style={{ background: '#06005A' }}>
        <div className="px-8 py-7 space-y-4">
          <LoadingSkeleton className="h-2.5 w-32 rounded-full opacity-25" />
          <LoadingSkeleton className="h-3 w-20 rounded-full opacity-20" />
          <LoadingSkeleton className="h-12 w-48 rounded-2xl opacity-35" />
          <div className="flex gap-8 pt-2">
            <LoadingSkeleton className="h-7 w-24 rounded-xl opacity-25" />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {[0, 1, 2].map(i => (
          <div key={i} className="bg-white rounded-2xl border border-[#E8ECF2] p-5 space-y-4">
            <div className="flex justify-between">
              <LoadingSkeleton className="h-4 w-36 rounded-full" />
              <LoadingSkeleton className="h-5 w-14 rounded-full" />
            </div>
            <LoadingSkeleton className="h-8 w-44 rounded-xl" />
            <div className="grid grid-cols-3 gap-2">
              {[0,1,2].map(j => <LoadingSkeleton key={j} className="h-14 rounded-xl" />)}
            </div>
            <LoadingSkeleton className="h-1.5 rounded-full" />
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function Libranza() {
  const { personType, productos } = useDemoContext()
  const navigate = useNavigate()
  const [pazYSalvoOpen, setPazYSalvoOpen] = useState(false)
  const [loading, setLoading] = useState(true)

  const hasLibranza = (productos === 'ambos' || productos === 'solo-libranza') && personType === 'natural'

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => {
      setLoading(false)
      if (hasLibranza && creditos.length === 1) {
        navigate(`/libranza/credito/${creditos[0].id}`, { replace: true })
      }
    }, 800)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <LibranzaSkeleton />
  if (personType === 'juridica') return <LibranzaJuridicaBlock />
  if (!hasLibranza) return <LibranzaSinProducto />
  if (creditos.length === 1) return null

  return (
    <div className="space-y-5">
      <SummaryHero onPazYSalvo={() => setPazYSalvoOpen(true)} />

      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 px-0.5 mb-3">
          Tus créditos · {creditos.length} activos
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {creditos.map((c, i) => (
            <CreditoCard key={c.id} credito={c} delay={i * 0.05} />
          ))}
        </div>
      </div>

      {pazYSalvoOpen && <PazYSalvoFlow onClose={() => setPazYSalvoOpen(false)} />}
    </div>
  )
}
