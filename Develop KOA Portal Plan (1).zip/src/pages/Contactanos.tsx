import { useState } from 'react'
import SectionHeader from '../components/SectionHeader'

const HORARIO = 'Lun – Vie · 8:00 a.m. – 5:00 p.m.'

function DotGrid({ id }: { id: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.04] pointer-events-none" preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id={id} x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  )
}

function HorarioBadge({ dark }: { dark?: boolean }) {
  return (
    <div className={`flex items-center gap-1.5 ${dark ? 'text-white/55' : 'text-gray-400'}`}>
      <svg className="w-3 h-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      <span className="text-[11px] font-medium">{HORARIO}</span>
    </div>
  )
}

/* ── Copy button ─────────────────────────────────────────── */
function CopyBtn({ value, dark }: { value: string; dark?: boolean }) {
  const [copied, setCopied] = useState(false)

  function handleCopy(e: React.MouseEvent) {
    e.preventDefault()
    e.stopPropagation()
    try {
      const ta = document.createElement('textarea')
      ta.value = value
      ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0'
      document.body.appendChild(ta)
      ta.focus()
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
    } catch (_) { /* silent */ }
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (dark) {
    return (
      <button
        onClick={handleCopy}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
          copied
            ? 'bg-[#00DB8E] text-[#06005A]'
            : 'bg-white/[0.1] text-white/70 hover:bg-white/[0.18] hover:text-white'
        }`}
      >
        {copied ? (
          <>
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
            Copiado
          </>
        ) : (
          <>
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            Copiar
          </>
        )}
      </button>
    )
  }

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer border ${
        copied
          ? 'bg-[#EFFFF7] text-[#005E3C] border-[#00DB8E]/30'
          : 'bg-[#F7F7F7] text-gray-500 border-transparent hover:bg-[#EAEAEA] hover:text-[#2A3036]'
      }`}
    >
      {copied ? (
        <>
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
          Copiado
        </>
      ) : (
        <>
          <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
          Copiar
        </>
      )}
    </button>
  )
}

export default function Contactanos() {
  return (
    <div className="space-y-8">
      <SectionHeader title="Contáctanos" subtitle="Elige el canal que mejor se adapte a tu necesidad" />

      {/* ── Canales directos ─────────────────────────────────── */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 px-0.5 mb-3">Contacto directo</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

          {/* WhatsApp — canal estrella */}
          <div className="relative overflow-hidden rounded-3xl" style={{ background: '#06005A' }}>
            <DotGrid id="dots-wa" />
            <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-[#00DB8E]/[0.08] pointer-events-none" />
            <div className="absolute left-1/3 bottom-0 w-36 h-36 rounded-full bg-white/[0.02] pointer-events-none" />

            <div className="relative z-10 p-7 flex flex-col gap-5">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-[#00DB8E]/20 border border-[#00DB8E]/15 flex items-center justify-center flex-shrink-0">
                    <svg className="w-6 h-6 text-[#00DB8E]" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-white/50">WhatsApp</p>
                    <span className="text-[10px] font-bold text-[#00DB8E] bg-[#00DB8E]/15 px-2 py-0.5 rounded-full mt-0.5 inline-block">Canal más rápido</span>
                  </div>
                </div>
              </div>

              {/* Number + copy */}
              <div>
                <p className="font-figures text-white font-black text-[30px] leading-none tracking-tight mb-1">315 770 6670</p>
                <p className="text-white/55 text-[12px] leading-snug">
                  Escríbenos a cualquier hora. Atención personalizada en horario hábil.
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2.5">
                <a
                  href="https://wa.me/573157706670"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 bg-[#00DB8E] hover:bg-[#00C57E] text-[#06005A] font-black text-[13px] py-3 rounded-2xl transition-colors"
                  onClick={e => e.stopPropagation()}
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  Escribir ahora
                </a>
                <CopyBtn value="3157706670" dark />
              </div>

              <div className="pt-3 border-t border-white/[0.1]">
                <HorarioBadge dark />
              </div>
            </div>
          </div>

          {/* Teléfono */}
          <div className="relative overflow-hidden rounded-3xl" style={{ background: 'linear-gradient(135deg, #0A0070 0%, #06005A 100%)' }}>
            <DotGrid id="dots-tel" />
            <div className="absolute -left-10 -bottom-10 w-48 h-48 rounded-full bg-white/[0.03] pointer-events-none" />
            <div className="absolute right-6 top-1/2 w-28 h-28 -translate-y-1/2 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />

            <div className="relative z-10 p-7 flex flex-col gap-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-white/50">Teléfono</p>
              </div>

              <div>
                <p className="font-figures text-white font-black text-[30px] leading-none tracking-tight mb-1">(601) 745 4095</p>
                <p className="text-white/55 text-[12px] leading-snug">
                  Atención personalizada para créditos, CDT, PQRS y actualización de datos.
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2.5">
                <a
                  href="tel:+576017454095"
                  className="flex-1 flex items-center justify-center gap-2 bg-white/[0.12] hover:bg-white/[0.2] text-white font-bold text-[13px] py-3 rounded-2xl transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  Llamar ahora
                </a>
                <CopyBtn value="6017454095" dark />
              </div>

              <div className="pt-3 border-t border-white/[0.1]">
                <HorarioBadge dark />
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* ── Canales escritos ─────────────────────────────────── */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 px-0.5 mb-3">PQRS y comunicaciones</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

          {/* Correo */}
          <div className="card p-6 flex flex-col gap-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] bg-[#06005A]" />
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#06005A]/08 flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#06005A] mb-0.5">Correo electrónico</p>
                <p className="font-bold text-[#2A3036] text-[13px] leading-tight break-all">servicioalcliente@koa.co</p>
              </div>
            </div>
            <p className="text-gray-400 text-[12px] leading-snug">
              Canal escrito para radicar Peticiones, Quejas, Reclamos y Sugerencias.
            </p>
            <div className="flex items-center gap-2 mt-auto pt-1">
              <a
                href="mailto:servicioalcliente@koa.co"
                className="flex-1 flex items-center justify-center gap-1.5 bg-[#06005A]/08 hover:bg-[#06005A]/14 text-[#06005A] font-bold text-[12px] py-2.5 rounded-xl transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                Enviar correo
              </a>
              <CopyBtn value="servicioalcliente@koa.co" />
            </div>
          </div>

          {/* Portal Web PQRS */}
          <div className="card p-6 flex flex-col gap-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] bg-[#00DB8E]" />
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#EFFFF7] flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#005E3C] mb-0.5">Portal web · PQRS</p>
                <p className="font-bold text-[#2A3036] text-[13px] leading-tight">koa.co/pqrs</p>
              </div>
            </div>
            <p className="text-gray-400 text-[12px] leading-snug">
              Formulario en línea habilitado para la radicación de PQRS.
            </p>
            <div className="mt-auto pt-1">
              <a
                href="https://koa.co/pqrs/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 bg-[#EFFFF7] hover:bg-[#D5F8E8] text-[#005E3C] font-bold text-[12px] py-2.5 rounded-xl transition-colors w-full"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
                Ir al formulario
              </a>
            </div>
          </div>

        </div>
      </div>

      {/* ── Oficinas + Línea de Ética ────────────────────────── */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 px-0.5 mb-3">Más canales</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

          {/* Oficinas */}
          <div className="card p-6 flex flex-col gap-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] bg-[#3B82F6]" />
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#3B82F6]/10 flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#3B82F6] mb-0.5">Oficinas</p>
                <p className="font-bold text-[#2A3036] text-[13px] leading-tight">Atención presencial</p>
              </div>
            </div>
            <p className="text-gray-400 text-[12px] leading-snug">
              Visítanos para solicitar créditos, consultar CDTs, radicar PQRS, actualizar datos y trámites en general.
            </p>
            <div className="flex items-center justify-between mt-auto pt-1">
              <HorarioBadge />
              <a
                href="https://koa.co/oficinas/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-[11px] font-bold text-[#3B82F6] hover:underline"
              >
                Ver sedes
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </a>
            </div>
          </div>

          {/* Línea de Ética */}
          <div className="card p-6 flex flex-col gap-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] bg-[#F59E0B]" />
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#F59E0B]/10 flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <div className="flex-1">
                <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#F59E0B] mb-0.5">Línea de Ética</p>
                <p className="font-figures font-bold text-[#2A3036] text-[13px] leading-tight">(601) 390 8246</p>
              </div>
            </div>
            <p className="text-gray-400 text-[12px] leading-snug">
              Reporta conductas que vayan en contra de los valores y el ADN de KOA. Canal confidencial.
            </p>
            <div className="flex items-center gap-2 mt-auto pt-1">
              <a
                href="tel:+576013908246"
                className="flex-1 flex items-center justify-center gap-1.5 bg-[#F59E0B]/10 hover:bg-[#F59E0B]/18 text-[#92400E] font-bold text-[12px] py-2.5 rounded-xl transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                Llamar
              </a>
              <CopyBtn value="6013908246" />
            </div>
          </div>

        </div>
      </div>

      {/* ── Nota horario ─────────────────────────────────────── */}
      <div className="flex items-start gap-3 bg-[#F7F7F7] rounded-2xl px-5 py-4">
        <svg className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-[12px] text-gray-400 leading-relaxed">
          Horario de atención: <span className="font-semibold text-gray-600">lunes a viernes de 8:00 a.m. a 5:00 p.m.</span> en jornada continua. Los mensajes de WhatsApp fuera de este horario serán respondidos el siguiente día hábil.
        </p>
      </div>

    </div>
  )
}
