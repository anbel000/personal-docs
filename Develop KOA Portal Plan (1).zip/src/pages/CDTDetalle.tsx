import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import Btn from '../components/Btn'
import LoadingSkeleton from '../components/LoadingSkeleton'
import CDTRenovacion from '../cdt/CDTRenovacion'
import CuentaDesembolso from '../cdt/CuentaDesembolso'
import FirmaElectronica from '../cdt/FirmaElectronica'
import { cdts, cdtsTerminados, formatPesos } from '../data/mockData'

/* ── Count-up hook ──────────────────────────────────── */
function useCountUp(target: number, duration = 1100, active = true) {
  const [value, setValue] = useState(0)
  const raf = useRef<number>(0)
  useEffect(() => {
    if (!active) return
    const start = performance.now()
    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)
      setValue(Math.round(target * ease))
      if (t < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [target, duration, active])
  return value
}

/* ── Icons ──────────────────────────────────────────── */
function CopyIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
}
function DownloadIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
}
function InfoIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 16v-4m0-4h.01" /></svg>
}
function EditIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
}

/* ── Toast ──────────────────────────────────────────── */
function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  useState(() => {
    const t = setTimeout(onDone, 3000)
    return () => clearTimeout(t)
  })
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#0A1F44] text-white px-5 py-3 rounded-xl shadow-lg text-[14px] font-medium z-50 flex items-center gap-2">
      <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
      {msg}
    </div>
  )
}

/* ── Hero skeleton ──────────────────────────────────── */
function HeroSkeleton() {
  return (
    <div className="rounded-3xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)', minHeight: 220 }}>
      <div className="px-6 sm:px-8 py-8 space-y-5">
        <div className="flex items-center justify-between">
          <LoadingSkeleton className="h-3 w-24 rounded-full opacity-30" />
          <LoadingSkeleton className="h-6 w-20 rounded-full opacity-20" />
        </div>
        <LoadingSkeleton className="h-12 w-52 rounded-2xl opacity-40" />
        <div className="flex gap-4 flex-wrap">
          {[0, 1, 2].map(i => <LoadingSkeleton key={i} className="h-14 w-28 rounded-xl opacity-20" />)}
        </div>
        <LoadingSkeleton className="h-2 w-full rounded-full opacity-20" />
      </div>
    </div>
  )
}

type Alerta = { id: string; tipo: 'info' | 'warning' | 'error'; texto: string }

export default function CDTDetalle() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { productos } = useDemoContext()
  const hasCDT = productos === 'ambos' || productos === 'solo-cdt'
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<string | null>(null)
  const [downloading, setDownloading] = useState<string | null>(null)

  const [proposito, setProposito] = useState('Ahorro de largo plazo')
  const [infoProposito, setInfoProposito] = useState(false)
  const [editProposito, setEditProposito] = useState(false)
  const [propositoTemp, setPropositoTemp] = useState('')
  const [firmaProposito, setFirmaProposito] = useState(false)

  const [alertas, setAlertas] = useState<Alerta[]>([
    { id: 'a1', tipo: 'warning', texto: 'Tu CDT vence en menos de 60 días. Considera tus opciones de renovación.' },
    { id: 'a2', tipo: 'info', texto: 'Recuerda inscribir tu cuenta de desembolso para recibir el pago al vencimiento.' },
  ])

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(t)
  }, [])

  const allCdts = [...cdts, ...cdtsTerminados]
  const cdt = allCdts.find(c => c.id === id) ?? cdts[0]
  const terminado = cdt.estado === 'terminado'

  const montoAnimado = useCountUp(cdt.montoInvertido, 1100, !loading)
  const rendAnimado = useCountUp(cdt.rendimientos, 950, !loading)

  const handleDownload = (docId: string) => {
    setDownloading(docId)
    setTimeout(() => { setDownloading(null); setToast('Documento descargado') }, 900)
  }
  const copyNumero = () => {
    navigator.clipboard.writeText(cdt.numeroCompleto).catch(() => {})
    setToast('Número copiado')
  }
  const handleEditarProposito = () => { setPropositoTemp(proposito); setEditProposito(true) }
  const handleGuardarProposito = () => { if (!propositoTemp.trim()) return; setEditProposito(false); setFirmaProposito(true) }
  const handleFirmaPropositoSuccess = () => { setFirmaProposito(false); setProposito(propositoTemp); setToast('Propósito actualizado') }
  const dismissAlerta = (alertaId: string) => setAlertas(prev => prev.filter(a => a.id !== alertaId))

  /* Conditions grid */
  const condiciones = [
    { label: 'Tasa fija', value: `${cdt.tasa} % E.A.`, highlight: true },
    { label: 'Periodicidad', value: cdt.periodicidad },
    { label: 'Apertura', value: cdt.fechaApertura },
    { label: 'Vencimiento', value: cdt.fechaVencimiento },
    { label: 'Estado', value: terminado ? 'Terminado' : 'Activo' },
    { label: 'Renovación', value: terminado ? '—' : cdt.renovacionAutomatica ? 'Automática' : 'Manual' },
    { label: 'Rendimientos fin.', value: formatPesos(Math.round(cdt.montoInvertido * parseFloat(cdt.tasa.replace(',', '.')) / 100)) },
    { label: 'Días restantes', value: terminado ? '—' : `${cdt.diasRestantes ?? '—'} días` },
  ]

  /* Alert styles — KOA tokens */
  const alertaStyle: Record<string, { wrap: string; path: string; color: string }> = {
    warning: {
      wrap: 'bg-[#FFFBEB] border border-[#F59E0B]/40',
      path: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
      color: 'text-[#F59E0B]',
    },
    info: {
      wrap: 'bg-[#EFF6FF] border border-[#3B82F6]/30',
      path: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
      color: 'text-[#3B82F6]',
    },
    error: {
      wrap: 'bg-[#FEF2F2] border border-[#EF4444]/30',
      path: 'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
      color: 'text-[#EF4444]',
    },
  }

  /* Cert documents */
  const certs = [
    { id: 'cert-deposito', nombre: 'Certificado de depósito', desc: 'Certifica tu inversión a término.', habilitado: true, band: '#06005A', iconColor: '#00DB8E' },
    { id: 'cert-terminos', nombre: 'Términos y condiciones', desc: 'Condiciones del certificado a término.', habilitado: true, band: '#0E4D8A', iconColor: '#7DD3FC' },
  ]

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <LoadingSkeleton className="h-5 w-36" />
        <HeroSkeleton />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[0, 1, 2, 3].map(i => <LoadingSkeleton key={i} className="h-20 rounded-2xl" />)}
        </div>
        <LoadingSkeleton className="h-40 rounded-2xl" />
        <LoadingSkeleton className="h-56 rounded-2xl" />
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Back */}
      <button
        onClick={() => navigate('/cdt')}
        className="flex items-center gap-1.5 text-[13px] font-semibold text-[#3B82F6] hover:underline cursor-pointer"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
        Volver a mis CDT
      </button>

      {/* ── Alertas ── */}
      {alertas.length > 0 && (
        <div className="space-y-2">
          {alertas.map(a => {
            const s = alertaStyle[a.tipo]
            return (
              <div key={a.id} className={`flex items-start gap-2.5 rounded-xl px-4 py-3 ${s.wrap}`}>
                <svg className={`w-4 h-4 flex-shrink-0 mt-0.5 ${s.color}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={s.path} />
                </svg>
                <span className="flex-1 text-[12px] font-medium leading-snug text-[#2A3036]">{a.texto}</span>
                <button onClick={() => dismissAlerta(a.id)} className="hover:opacity-60 cursor-pointer flex-shrink-0 text-gray-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
            )
          })}
        </div>
      )}

      {/* ── HERO ── */}
      <div
        className="relative rounded-3xl overflow-hidden card-enter"
        style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}
      >
        <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-[#3B82F6]/[0.08] pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />
        <div className="absolute top-1/3 right-1/3 w-20 h-20 rounded-full bg-[#3B82F6]/[0.04] pointer-events-none" />
        {/* Chart decoration */}
        <div className="absolute bottom-0 right-0 w-48 h-28 opacity-[0.07] pointer-events-none overflow-hidden">
          <svg viewBox="0 0 200 100" fill="none" className="w-full h-full">
            <polyline points="0,80 40,58 80,42 120,26 160,16 200,6" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="0,95 40,80 80,70 120,58 160,48 200,38" stroke="#00DB8E" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="4 3" />
          </svg>
        </div>

        <div className="relative z-10 px-6 sm:px-8 pt-7 pb-6">
          {/* Header row */}
          <div className="flex items-start justify-between gap-3 mb-5">
            <div>
              <p className="text-white/35 text-[10px] font-bold tracking-[0.22em] uppercase mb-1.5">CDT Digital · KOA</p>
              {proposito ? (
                <>
                  <div className="flex items-start gap-2">
                    <h1 className="text-white font-black text-[22px] sm:text-[24px] leading-tight mb-1 flex-1">{proposito}</h1>
                    {!terminado && (
                      <button onClick={handleEditarProposito} className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer text-white/50 flex-shrink-0 mt-0.5">
                        <EditIcon />
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-figures text-white/40 text-[13px]">{cdt.numeroCompleto}</span>
                    <button onClick={copyNumero} className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer text-white/50">
                      <CopyIcon />
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h1 className="font-figures text-white font-black text-[20px] tracking-tight">{cdt.numeroCompleto}</h1>
                    <button onClick={copyNumero} className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer text-white/60"><CopyIcon /></button>
                  </div>
                  {!terminado && (
                    <button onClick={handleEditarProposito} className="flex items-center gap-1.5 mt-1.5 text-white/40 hover:text-white/70 text-[11px] transition-colors cursor-pointer">
                      <EditIcon />
                      Añadir propósito de inversión
                    </button>
                  )}
                </>
              )}
            </div>
            {terminado && (
              <span className="flex-shrink-0 flex items-center gap-1.5 text-[11px] font-bold px-3 py-1.5 rounded-full bg-gray-400/20 text-gray-300 border border-gray-400/25">
                <span className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                Terminado
              </span>
            )}
          </div>

          {/* Main amount */}
          <div className="mb-5">
            <p className="text-white/40 text-[11px] font-bold tracking-[0.16em] uppercase mb-1">Monto invertido</p>
            <p className="font-figures text-white font-black leading-none" style={{ fontSize: 'clamp(30px, 6vw, 42px)' }}>
              {formatPesos(montoAnimado)}
            </p>
          </div>

          {/* Stats chips */}
          <div className="flex flex-wrap gap-2.5 mb-6">
            {[
              { label: 'Tasa E.A.', value: `${cdt.tasa} %`, accent: false },
              { label: 'Rendimientos', value: `+${formatPesos(rendAnimado)}`, accent: true },
              { label: terminado ? 'Venció' : 'Vencimiento', value: cdt.fechaVencimiento, accent: false },
            ].map(chip => (
              <div key={chip.label} className="bg-white/[0.07] border border-white/10 rounded-xl px-3.5 py-2.5">
                <p className="text-white/35 text-[10px] font-bold tracking-[0.12em] uppercase mb-0.5">{chip.label}</p>
                <p className={`font-figures font-black text-[14px] ${chip.accent ? 'text-[#00DB8E]' : 'text-white'}`}>{chip.value}</p>
              </div>
            ))}
          </div>

          {/* Progress bar */}
          {!terminado && (
            <div>
              <div className="flex justify-between text-[10px] font-figures mb-1.5">
                <span className="text-white/30">{cdt.fechaApertura}</span>
                <span className="text-white/30">{cdt.fechaVencimiento}</span>
              </div>
              <div className="h-2 rounded-full overflow-hidden bg-white/10">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${cdt.progresoPct}%`,
                    background: 'linear-gradient(90deg, #3B82F6 0%, #00B4D8 60%, #00DB8E 100%)',
                    boxShadow: '0 0 10px rgba(59,130,246,0.5)',
                    transition: 'width 0.8s cubic-bezier(0.22,1,0.36,1)',
                  }}
                />
              </div>
              <div className="flex justify-between items-center mt-1.5">
                <span className="text-white/30 text-[10px]">Plazo transcurrido · {cdt.progresoPct}%</span>
                {cdt.diasRestantes !== undefined && (
                  <span className="font-figures text-[#93C5FD] text-[11px] font-bold">Faltan {cdt.diasRestantes} días</span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Conditions grid ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-1">
        <div className="px-5 pt-4 pb-3 border-b border-[#F0F2F5]">
          <p className="font-bold text-[14px] text-[#2A3036]">Condiciones del CDT</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4">
          {condiciones.map((c, i) => (
            <div
              key={c.label}
              className={`px-4 py-3.5 ${i % 2 === 0 ? 'bg-white' : 'bg-[#FAFAFA]'} ${
                Math.floor(i / 4) < Math.floor((condiciones.length - 1) / 4) ? 'border-b border-[#F0F2F5]' : ''
              } ${i % 4 !== 3 ? 'sm:border-r sm:border-[#F0F2F5]' : ''}`}
            >
              <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-1">{c.label}</p>
              <p className={`font-figures font-bold text-[13px] leading-snug ${c.highlight ? 'text-[#3B82F6]' : 'text-[#2A3036]'}`}>{c.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Cuenta de desembolso ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-3">
        <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5]">
          <p className="font-bold text-[15px] text-[#2A3036]">Cuenta de desembolso</p>
          <p className="text-[12px] text-gray-400 mt-0.5">Recibirás tu capital e intereses aquí al vencimiento</p>
        </div>
        <div className="p-5">
          <CuentaDesembolso estadoInicial={cdt.cuentaEstado} onToast={msg => setToast(msg)} />
        </div>
      </div>

      {/* ── Renovación ── */}
      {!terminado && hasCDT && (
        <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-4">
          <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5] flex items-center justify-between gap-3">
            <div>
              <p className="font-bold text-[15px] text-[#2A3036]">Renovación</p>
              <p className="text-[12px] text-gray-400 mt-0.5">Instrucción al vencimiento de tu CDT</p>
            </div>
            <span className="text-[11px] font-semibold text-gray-400 flex-shrink-0">Modifica hasta el 29 SEP 2026</span>
          </div>
          <div className="p-5">
            <CDTRenovacion
              cdt={{ id: cdt.id, montoInvertido: cdt.montoInvertido, rendimientos: cdt.rendimientos, fechaVencimiento: cdt.fechaVencimiento, tasa: cdt.tasa }}
              onToast={msg => setToast(msg)}
            />
          </div>
        </div>
      )}

      {/* ── Certificados ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden">
        <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5]">
          <p className="font-bold text-[15px] text-[#2A3036]">Documentos y certificados</p>
          <p className="text-[12px] text-gray-400 mt-0.5">Documentos oficiales de tu CDT</p>
        </div>
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {certs.map(cert => (
            <div key={cert.id} className="rounded-2xl border border-[#E8ECF2] overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-0.5">
              <div className="h-1.5" style={{ background: cert.band }} />
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${cert.band}22` }}>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8} style={{ color: cert.iconColor }}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-[13px] text-[#2A3036] leading-tight">{cert.nombre}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{cert.desc}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(cert.id)}
                  disabled={downloading === cert.id}
                  className="w-full flex items-center justify-center gap-1.5 text-white text-[12px] font-bold px-3 py-2 rounded-xl cursor-pointer hover:opacity-90 active:scale-[0.98] transition-all duration-150"
                  style={{ background: cert.band }}
                >
                  {downloading === cert.id ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <DownloadIcon />
                  )}
                  Descargar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dialogs */}
      {infoProposito && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setInfoProposito(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
            <p className="font-bold text-[16px] text-[#2A3036]">¿Qué es el propósito de inversión?</p>
            <p className="text-[13px] text-gray-600 leading-relaxed">El propósito es una descripción corta del objetivo de ahorro para este CDT. Es un campo informativo que te ayuda a organizar tus inversiones, como "Fondo de emergencia", "Viaje 2027" o "Educación".</p>
            <p className="text-[13px] text-gray-600 leading-relaxed">Este campo no afecta los términos del CDT ni genera obligaciones adicionales.</p>
            <Btn variant="primary" size="md" className="w-full" onClick={() => setInfoProposito(false)}>Entendido</Btn>
          </div>
        </div>
      )}

      {editProposito && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setEditProposito(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 space-y-4">
            <p className="font-bold text-[16px] text-[#2A3036]">Editar propósito</p>
            <div>
              <label className="block text-[12px] font-semibold text-gray-500 mb-1">Propósito (máx. 50 caracteres)</label>
              <input
                type="text"
                maxLength={50}
                value={propositoTemp}
                onChange={e => setPropositoTemp(e.target.value)}
                className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] outline-none focus:border-[#3B82F6]"
                autoFocus
              />
              <p className="text-[11px] text-gray-400 mt-1 text-right">{propositoTemp.length}/50</p>
            </div>
            <div className="flex gap-2">
              <Btn variant="secondary" size="md" className="flex-1" onClick={() => setEditProposito(false)}>Cancelar</Btn>
              <Btn variant="primary" size="md" className="flex-1" disabled={!propositoTemp.trim()} onClick={handleGuardarProposito}>Guardar</Btn>
            </div>
          </div>
        </div>
      )}

      <FirmaElectronica
        open={firmaProposito}
        operacion="editar-proposito"
        onSuccess={handleFirmaPropositoSuccess}
        onClose={() => setFirmaProposito(false)}
      />

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  )
}
