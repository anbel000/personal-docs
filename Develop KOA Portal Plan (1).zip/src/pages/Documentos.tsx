import { useState, useEffect } from 'react'
import SectionHeader from '../components/SectionHeader'
import LoadingSkeleton from '../components/LoadingSkeleton'
import FilterChips from '../components/FilterChips'
import EmptyState from '../components/EmptyState'
import StatusPill from '../components/StatusPill'
import { documentos, documentosEnProceso } from '../data/mockData'

const estadoOpts = [
  { label: 'Todos', value: 'todos' },
  { label: 'Disponibles', value: 'disponible' },
  { label: 'En proceso', value: 'en-proceso' },
]
const productoOpts = [
  { label: 'Todos', value: 'todos' },
  { label: 'Libranza', value: 'Libranza' },
  { label: 'CDT', value: 'CDT' },
]

function iconForTipo(tipo: string) {
  switch (tipo) {
    case 'extracto': return (
      <svg className="w-5 h-5 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
    )
    case 'certificacion': return (
      <svg className="w-5 h-5 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
    )
    case 'paz-salvo': return (
      <svg className="w-5 h-5 text-[#10B981]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" /></svg>
    )
    default: return (
      <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
    )
  }
}

function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  useState(() => {
    const t = setTimeout(onDone, 3000)
    return () => clearTimeout(t)
  })
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#0A1F44] text-white px-5 py-3 rounded-xl shadow-lg text-[14px] font-medium z-50 flex items-center gap-2">
      <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
      {msg}
    </div>
  )
}

function DownloadIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
}

export default function Documentos() {
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700)
    return () => clearTimeout(t)
  }, [])

  const [estadoFiltro, setEstadoFiltro] = useState('todos')
  const [productoFiltro, setProductoFiltro] = useState('todos')
  const [busqueda, setBusqueda] = useState('')
  const [toast, setToast] = useState<string | null>(null)
  const [downloading, setDownloading] = useState<string | null>(null)

  const handleDownload = (id: string) => {
    setDownloading(id)
    setTimeout(() => {
      setDownloading(null)
      setToast('Documento descargado')
    }, 800)
  }

  // Filter logic
  const filteredDisponibles = documentos.filter(d => {
    if (estadoFiltro === 'en-proceso') return false
    if (estadoFiltro === 'disponible' || estadoFiltro === 'todos') {
      if (productoFiltro !== 'todos' && d.producto !== productoFiltro) return false
      if (busqueda && !d.nombre.toLowerCase().includes(busqueda.toLowerCase())) return false
      return true
    }
    return false
  })

  const filteredEnProceso = documentosEnProceso.filter(d => {
    if (estadoFiltro === 'disponible') return false
    if (productoFiltro !== 'todos' && d.producto !== productoFiltro) return false
    if (busqueda && !d.nombre.toLowerCase().includes(busqueda.toLowerCase())) return false
    return true
  })

  // Group disponibles by month
  const groups: { mes: string; items: typeof documentos }[] = []
  for (const d of filteredDisponibles) {
    const mesLabel = d.fecha.split(' ').slice(1).join(' ') // "AGO 2026"
    const last = groups[groups.length - 1]
    if (!last || last.mes !== mesLabel) groups.push({ mes: mesLabel, items: [d] })
    else last.items.push(d)
  }

  const total = filteredDisponibles.length + filteredEnProceso.length

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-5">
        <SectionHeader title="Documentos" subtitle="Todos tus certificados y solicitudes" />
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-4 space-y-3">
          <div className="flex gap-2">{[0,1,2].map(i => <LoadingSkeleton key={i} className="h-8 w-24 rounded-xl" />)}</div>
          <div className="flex gap-2">{[0,1,2].map(i => <LoadingSkeleton key={i} className="h-8 w-24 rounded-xl" />)}</div>
        </div>
        <div className="bg-white rounded-2xl border border-[#E5E7EB] divide-y divide-[#E5E7EB]">
          {[0,1,2,3,4].map(i => (
            <div key={i} className="flex gap-3 px-4 py-3">
              <LoadingSkeleton className="w-9 h-9 rounded-xl flex-shrink-0" />
              <div className="flex-1 space-y-1.5">
                <LoadingSkeleton className="h-4 w-48" />
                <LoadingSkeleton className="h-3 w-32" />
              </div>
              <LoadingSkeleton className="h-4 w-20 flex-shrink-0" />
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <SectionHeader title="Documentos" subtitle="Todos tus certificados y solicitudes" />

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-[#E5E7EB] p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <FilterChips options={estadoOpts} value={estadoFiltro} onChange={setEstadoFiltro} />
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            <input
              type="text"
              placeholder="Buscar por nombre"
              value={busqueda}
              onChange={e => setBusqueda(e.target.value)}
              className="pl-9 pr-3 py-2 border border-[#E5E7EB] rounded-xl text-[13px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white w-full sm:w-48"
            />
          </div>
        </div>
        <FilterChips options={productoOpts} value={productoFiltro} onChange={setProductoFiltro} />
      </div>

      {total === 0 ? (
        <EmptyState
          icon={
            <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          }
          title="Aún no tienes documentos"
          description="Los certificados que descargues o solicites quedarán guardados aquí."
        />
      ) : (
        <>
          {/* En proceso — always first */}
          {filteredEnProceso.length > 0 && (
            <div className="space-y-2">
              <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400">En proceso</p>
              {filteredEnProceso.map((d) => (
                <div key={d.id} className="bg-[#FFFBEB] border border-[#F59E0B]/30 rounded-xl p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="w-5 h-5 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                      </div>
                      <div>
                        <p className="font-semibold text-[14px] text-[#2A3036]">{d.nombre}</p>
                        <p className="text-[12px] text-gray-500">{d.producto} · {d.origen}</p>
                        <p className="font-figures text-[12px] text-gray-500">Solicitada el {d.fechaSolicitud} · {d.radicado}</p>
                        <p className="text-[12px] text-gray-400 mt-0.5">Te llegará a tu correo en máximo X días hábiles</p>
                      </div>
                    </div>
                    <StatusPill variant="en-proceso" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Disponibles — grouped by month */}
          {groups.length > 0 && (
            <div className="space-y-4">
              {groups.map((group) => (
                <div key={group.mes}>
                  <p className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-2">{group.mes}</p>
                  <div className="bg-white rounded-2xl border border-[#E5E7EB] divide-y divide-[#E5E7EB] overflow-hidden">
                    {group.items.map((d) => (
                      <div key={d.id} className="flex items-center gap-3 px-4 py-3">
                        <div className="w-9 h-9 rounded-xl bg-gray-50 border border-[#E5E7EB] flex items-center justify-center flex-shrink-0">
                          {iconForTipo(d.tipo)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-[14px] text-[#2A3036] truncate">{d.nombre}</p>
                          <p className="text-[12px] text-gray-500">{d.producto} · {d.origen}</p>
                        </div>
                        <span className="font-figures text-[12px] text-gray-400 flex-shrink-0 hidden sm:block">{d.fecha}</span>
                        <button
                          onClick={() => handleDownload(d.id)}
                          disabled={downloading === d.id}
                          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-gray-100 transition-colors cursor-pointer text-gray-500 disabled:opacity-50 flex-shrink-0"
                        >
                          {downloading === d.id ? (
                            <span className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <DownloadIcon />
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  )
}
