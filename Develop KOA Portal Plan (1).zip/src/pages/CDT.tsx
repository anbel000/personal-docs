import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import EmptyState from '../components/EmptyState'
import Btn from '../components/Btn'
import LoadingSkeleton from '../components/LoadingSkeleton'
import CDTGraficas from '../cdt/CDTGraficas'
import AsesorReferidos from '../cdt/AsesorReferidos'
import { cdts, cdtsTerminados, kpiCDT, type CDT, formatPesos } from '../data/mockData'

/* ─── Floating particles ─────────────────────────────────── */
const PARTICLES = [
  { size: 4, top: '12%', left: '7%', dur: '3.2s', delay: '0s', op: 0.3 },
  { size: 6, top: '65%', left: '12%', dur: '4.1s', delay: '0.9s', op: 0.2 },
  { size: 3, top: '22%', right: '9%', dur: '3.7s', delay: '1.5s', op: 0.35 },
  { size: 5, top: '75%', right: '18%', dur: '2.9s', delay: '0.3s', op: 0.22 },
  { size: 3, top: '48%', left: '38%', dur: '5.2s', delay: '2.1s', op: 0.15 },
]
function Particles() {
  return (
    <>
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            width: p.size, height: p.size,
            top: p.top, left: p.left, right: p.right,
            background: i % 2 === 0 ? '#3B82F6' : '#00DB8E',
            opacity: p.op,
            ['--dur' as string]: p.dur,
            ['--delay' as string]: p.delay,
            ['--op' as string]: p.op,
            ['--fy' as string]: `${-10 - i * 3}px`,
          }}
        />
      ))}
    </>
  )
}

/* ─── Empty — invite to open first CDT ──────────────────── */
function CDTAperturaEmpty() {
  return (
    <div className="relative overflow-hidden rounded-3xl card-enter" style={{ background: '#06005A', minHeight: 340 }}>
      <Particles />
      <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-[#3B82F6]/[0.06] pointer-events-none" />
      <div className="absolute -left-8 bottom-0 w-32 h-32 rounded-full bg-[#00DB8E]/[0.04] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-52 h-40 opacity-[0.1] pointer-events-none overflow-hidden">
        <svg viewBox="0 0 200 130" fill="none" className="w-full h-full">
          {[0, 1, 2, 3, 4].map(i => {
            const h = 30 + i * 20
            return <rect key={i} x={20 + i * 36} y={130 - h} width="24" height={h} rx="6" fill="#3B82F6" fillOpacity={0.5 + i * 0.1} />
          })}
          <polyline points="32,100 68,78 104,60 140,42 176,22" stroke="#00DB8E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-8 py-14 gap-5">
        <div className="w-16 h-16 rounded-2xl bg-[#3B82F6]/20 border border-[#3B82F6]/20 flex items-center justify-center animate-number-pop" style={{ ['--delay' as string]: '0.1s' }}>
          <svg className="w-7 h-7 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
        </div>
        <div className="space-y-2 animate-number-pop" style={{ ['--delay' as string]: '0.18s' }}>
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-[#3B82F6]/70">CDT Digital · KOA</p>
          <h2 className="text-white font-bold text-[26px] tracking-tight">Abre tu primer CDT</h2>
          <p className="text-white/45 text-[14px] max-w-xs">
            Empieza a generar rendimientos desde el primer día. Tasas desde{' '}
            <span className="text-[#00DB8E] font-semibold">11,50 % E.A.</span>
          </p>
        </div>
        <div className="flex gap-6 border-t border-white/[0.08] pt-5 animate-number-pop" style={{ ['--delay' as string]: '0.26s' }}>
          {[{ label: 'Tasa desde', value: '11,50 %' }, { label: 'Plazos', value: '60–360 d' }, { label: 'Proceso', value: '100 % online' }].map(s => (
            <div key={s.label} className="text-center">
              <p className="font-figures text-white font-bold text-[15px]">{s.value}</p>
              <p className="text-white/35 text-[10px] mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="animate-number-pop" style={{ ['--delay' as string]: '0.34s' }}>
          <Btn variant="mint" size="lg" onClick={() => window.open('https://ebtcd-staging.quolab.biz/simulacion', '_blank', 'noopener')}>
            Comenzar apertura
          </Btn>
        </div>
      </div>
    </div>
  )
}

function CDTNoData() {
  return (
    <div className="border-2 border-dashed border-[#E5E7EB] rounded-2xl p-8 card-enter">
      <EmptyState
        icon={<svg className="w-8 h-8 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>}
        iconBg="bg-[#3B82F6]/12"
        title="No tienes CDTs aperturados"
        description="Abre tu primer CDT Digital KOA y empieza a generar rendimientos desde el primer día."
        action={<Btn variant="mint" onClick={() => window.open('https://ebtcd-staging.quolab.biz/simulacion', '_blank', 'noopener')}>Abrir mi primer CDT</Btn>}
      />
    </div>
  )
}

/* ─── Skeleton ───────────────────────────────────────────── */
function CDTSkeleton() {
  return (
    <div className="space-y-5">
      <div className="rounded-3xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}>
        <div className="px-8 py-7 flex flex-wrap gap-6 items-end justify-between">
          <div className="space-y-2">
            <LoadingSkeleton className="h-2.5 w-20 rounded-full opacity-30" />
            <LoadingSkeleton className="h-10 w-48 rounded-2xl opacity-40" />
          </div>
          <div className="flex gap-8 flex-wrap">
            {[0, 1, 2].map(i => (
              <div key={i} className="space-y-2">
                <LoadingSkeleton className="h-2.5 w-20 rounded-full opacity-20" />
                <LoadingSkeleton className="h-7 w-28 rounded-xl opacity-35" />
              </div>
            ))}
          </div>
        </div>
      </div>
      {[0, 1, 2].map(i => (
        <div key={i} className="card-flat flex items-center gap-4 px-5 py-4 rounded-2xl">
          <LoadingSkeleton className="w-2 h-2 rounded-full" />
          <LoadingSkeleton className="w-[100px] h-4 rounded-full" />
          <LoadingSkeleton className="flex-1 h-7 rounded-xl" />
          <LoadingSkeleton className="w-[72px] h-4 rounded-full hidden sm:block" />
          <LoadingSkeleton className="w-[120px] h-4 rounded-full hidden md:block" />
          <LoadingSkeleton className="w-[120px] h-4 rounded-full" />
          <LoadingSkeleton className="w-4 h-4 rounded" />
        </div>
      ))}
    </div>
  )
}

/* ─── CDT row ─── desktop table + mobile card ────────────── */
function CDTRow({ cdt, delay = 0 }: { cdt: CDT; delay?: number }) {
  const navigate = useNavigate()
  const terminado = cdt.estado === 'terminado'
  const displayName = cdt.nombre || cdt.numeroMascarado

  return (
    <div
      className={`card-flat card-enter transition-all duration-200 ${
        !terminado ? 'cursor-pointer hover:shadow-md hover:-translate-y-px' : 'opacity-55'
      }`}
      style={{ animationDelay: `${delay}s` }}
      onClick={() => !terminado && navigate(`/cdt/${cdt.id}`)}
    >
      {/* Mobile */}
      <div className="sm:hidden px-4 py-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-2 h-2 rounded-full flex-shrink-0 mt-0.5 ${terminado ? 'bg-gray-300' : 'bg-[#3B82F6] mint-pulse'}`} />
            <div>
              {cdt.proposito ? (
                <>
                  <p className="text-[13px] font-bold text-[#2A3036]">{cdt.proposito}</p>
                  <p className="font-figures text-[10px] text-gray-400">{cdt.numeroMascarado}</p>
                </>
              ) : (
                <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.numeroMascarado}</p>
              )}
              {!terminado && cdt.renovacionAutomatica && (
                <p className="text-[9px] text-[#005E3C] font-bold">↻ Auto</p>
              )}
              {terminado && <p className="text-[9px] text-gray-400">Terminado</p>}
            </div>
          </div>
          <div className="text-right">
            <p className="font-figures text-[11px] font-bold text-[#3B82F6]">{cdt.tasa} % E.A.</p>
            {!terminado && cdt.diasRestantes !== undefined && <p className="text-[10px] text-gray-400">{cdt.diasRestantes} días rest.</p>}
          </div>
        </div>
        <p className="font-figures text-[22px] font-black text-[#2A3036] leading-none mb-1.5">{formatPesos(cdt.montoInvertido)}</p>
        <div className="flex items-center justify-between">
          <p className="font-figures text-[13px] font-bold text-[#10B981]">+{formatPesos(cdt.rendimientos)}</p>
          <p className="font-figures text-[12px] text-gray-400">{cdt.fechaVencimiento}</p>
        </div>
        {!terminado && (
          <div className="mt-3">
            <div className="h-1.5 bg-[#F7F7F7] rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${cdt.progresoPct}%`, background: 'linear-gradient(90deg, #3B82F6, #00DB8E)' }} />
            </div>
            <p className="text-[10px] text-gray-400 mt-1">{cdt.progresoPct}% transcurrido</p>
          </div>
        )}
      </div>

      {/* Desktop */}
      <div className="hidden sm:flex items-center gap-3 px-5 py-4 group">
        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${terminado ? 'bg-gray-300' : 'bg-[#3B82F6] mint-pulse'}`} />
        <div className="w-[130px] flex-shrink-0">
          {cdt.proposito ? (
            <>
              <p className="text-[13px] font-bold text-[#2A3036] leading-tight line-clamp-1">{cdt.proposito}</p>
              <p className="font-figures text-[10px] text-gray-400">{cdt.numeroMascarado}</p>
            </>
          ) : (
            <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.numeroMascarado}</p>
          )}
          {!terminado && cdt.renovacionAutomatica && <p className="text-[9px] text-[#005E3C] font-bold">↻ Auto</p>}
          {terminado && <p className="text-[9px] text-gray-400">Terminado</p>}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-figures text-[20px] font-black text-[#2A3036] leading-none">{formatPesos(cdt.montoInvertido)}</p>
          <p className="text-[10px] text-gray-400 mt-0.5">monto invertido</p>
        </div>
        <div className="w-[72px] flex-shrink-0 text-right">
          <p className="font-figures text-[14px] font-bold text-[#3B82F6]">{cdt.tasa} %</p>
          <p className="text-[10px] text-gray-400">E.A.</p>
        </div>
        <div className="w-[120px] flex-shrink-0 hidden md:block text-right">
          <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.fechaVencimiento}</p>
          {cdt.diasRestantes !== undefined && !terminado
            ? <p className="text-[10px] text-[#3B82F6] font-semibold">{cdt.diasRestantes} d. restantes</p>
            : <p className="text-[10px] text-gray-400">vencimiento</p>
          }
        </div>
        <div className="w-[72px] flex-shrink-0 hidden lg:block">
          {!terminado && (
            <>
              <div className="h-1.5 bg-[#F7F7F7] rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${cdt.progresoPct}%`, background: 'linear-gradient(90deg, #3B82F6, #00DB8E)' }} />
              </div>
              <p className="text-[10px] text-gray-400 mt-0.5 text-center">{cdt.progresoPct} %</p>
            </>
          )}
        </div>
        <div className="w-[120px] flex-shrink-0 text-right">
          <p className="font-figures text-[14px] font-bold text-[#10B981]">+{formatPesos(cdt.rendimientos)}</p>
          <p className="text-[10px] text-gray-400">rendimientos</p>
        </div>
        <svg className={`w-4 h-4 flex-shrink-0 transition-colors ${!terminado ? 'text-gray-300 group-hover:text-[#2A3036]' : 'text-transparent'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </div>
  )
}

function ListHeaders() {
  return (
    <div className="hidden sm:flex items-center gap-3 px-5 pb-1">
      <div className="w-2 flex-shrink-0" />
      <div className="w-[130px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400">CDT</div>
      <div className="flex-1 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400">Monto</div>
      <div className="w-[72px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Tasa</div>
      <div className="w-[120px] flex-shrink-0 hidden md:block text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Vencimiento</div>
      <div className="w-[72px] flex-shrink-0 hidden lg:block text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-center">Plazo</div>
      <div className="w-[120px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Rendimientos</div>
      <div className="w-4 flex-shrink-0" />
    </div>
  )
}

/* ─── Single CDT featured view ───────────────────────────── */
function SingleCDTView({ cdt }: { cdt: CDT }) {
  const navigate = useNavigate()
  const terminado = cdt.estado === 'terminado'

  return (
    <div className="space-y-5">
      {/* Featured card */}
      <div
        className="relative rounded-3xl overflow-hidden card-enter"
        style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}
      >
        <Particles color="#3B82F6" />
        <div className="absolute -top-14 -right-14 w-48 h-48 rounded-full bg-[#3B82F6]/[0.07] pointer-events-none" />
        <div className="absolute -bottom-10 -left-8 w-36 h-36 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />

        <div className="relative z-10 px-6 sm:px-8 pt-7 pb-6">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div>
              <p className="text-white/35 text-[10px] font-bold tracking-[0.2em] uppercase mb-2">CDT Digital · KOA</p>
              {cdt.proposito ? (
                <>
                  <h2 className="text-white font-black text-[22px] leading-tight">{cdt.proposito}</h2>
                  <p className="font-figures text-white/40 text-[13px] mt-0.5">{cdt.numeroCompleto}</p>
                </>
              ) : (
                <h2 className="font-figures text-white font-black text-[20px]">{cdt.numeroCompleto}</h2>
              )}
            </div>
            <span className="flex-shrink-0 flex items-center gap-1.5 text-[11px] font-bold px-3 py-1.5 rounded-full bg-[#3B82F6]/20 text-[#93C5FD] border border-[#3B82F6]/30">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3B82F6] animate-pulse" />
              Activo
            </span>
          </div>

          <div className="mb-5">
            <p className="text-white/40 text-[11px] font-bold tracking-[0.16em] uppercase mb-1">Monto invertido</p>
            <p className="font-figures text-white font-black leading-none" style={{ fontSize: 'clamp(30px, 7vw, 46px)' }}>
              {formatPesos(cdt.montoInvertido)}
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 mb-6">
            {[
              { label: 'Tasa E.A.', value: `${cdt.tasa} %` },
              { label: 'Rendimientos', value: `+${formatPesos(cdt.rendimientos)}`, accent: true },
              { label: 'Vencimiento', value: cdt.fechaVencimiento },
              { label: 'Periodicidad', value: cdt.periodicidad },
            ].map(chip => (
              <div key={chip.label} className="bg-white/[0.07] border border-white/10 rounded-xl px-3 py-2">
                <p className="text-white/35 text-[9px] font-bold tracking-[0.12em] uppercase mb-0.5">{chip.label}</p>
                <p className={`font-figures font-black text-[13px] ${chip.accent ? 'text-[#00DB8E]' : 'text-white'}`}>{chip.value}</p>
              </div>
            ))}
          </div>

          {!terminado && (
            <div className="mb-5">
              <div className="h-2 rounded-full overflow-hidden bg-white/10">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${cdt.progresoPct}%`,
                    background: 'linear-gradient(90deg, #3B82F6 0%, #00B4D8 60%, #00DB8E 100%)',
                    boxShadow: '0 0 10px rgba(59,130,246,0.5)',
                  }}
                />
              </div>
              <div className="flex justify-between mt-1.5">
                <span className="text-white/30 text-[10px]">{cdt.progresoPct}% del plazo transcurrido</span>
                {cdt.diasRestantes !== undefined && (
                  <span className="font-figures text-[#93C5FD] text-[11px] font-bold">Faltan {cdt.diasRestantes} días</span>
                )}
              </div>
            </div>
          )}

          <div className="border-t border-white/[0.06] pt-4 flex items-center justify-between">
            <p className="text-white/30 text-[11px]">
              {cdt.renovacionAutomatica ? '↻ Renovación automática activa' : 'Sin renovación automática'}
            </p>
            <button
              onClick={() => navigate(`/cdt/${cdt.id}`)}
              className="flex items-center gap-2 bg-[#00DB8E] text-[#06005A] text-[13px] font-bold px-4 py-2 rounded-xl hover:bg-[#00C57E] transition-colors cursor-pointer btn-mint-glow"
            >
              Ver detalle completo
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
            </button>
          </div>
        </div>
      </div>

      {/* Analytics */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-3 px-1">Análisis de tu inversión</p>
        <CDTGraficas showKPIs={false} />
      </div>

      {/* Referidos */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-3 px-1">Plan de referidos</p>
        <AsesorReferidos mode="referidos" />
      </div>

      {/* Open another CDT nudge */}
      <div
        className="rounded-2xl border border-dashed border-[#3B82F6]/30 bg-[#EFF6FF]/60 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 card-enter stagger-3 cursor-pointer hover:border-[#3B82F6]/60 transition-colors"
        onClick={() => navigate('/cdt/abrir')}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#3B82F6]/15 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div>
            <p className="font-bold text-[14px] text-[#1E40AF]">Diversifica tu portafolio</p>
            <p className="text-[12px] text-[#3B82F6]/70 mt-0.5">Abre un segundo CDT con diferentes plazos o tasas</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 text-[12px] font-bold text-[#3B82F6] whitespace-nowrap">
          Abrir otro CDT
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
        </span>
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function CDT() {
  const { personType, productos } = useDemoContext()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'activos' | 'terminados'>('activos')

  const hasCDT = productos === 'ambos' || productos === 'solo-cdt'
  const activeCdts = productos === 'solo-cdt' ? cdts.slice(0, 1) : cdts
  const terminadosCdts = productos === 'solo-cdt' ? [] : cdtsTerminados

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <CDTSkeleton />
  if (!hasCDT) return <CDTAperturaEmpty />
  if (activeCdts.length === 0) return <CDTNoData />

  /* Single CDT — featured view */
  if (activeCdts.length === 1 && terminadosCdts.length === 0) {
    return <SingleCDTView cdt={activeCdts[0]} />
  }

  return (
    <div className="space-y-6">

      {/* 1 ── Portfolio hero ───────────────────────────────── */}
      <div
        className="rounded-3xl overflow-hidden card-enter relative gradient-border"
        style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}
      >
        <Particles />
        <div className="absolute -right-10 -top-10 w-52 h-52 rounded-full bg-white/[0.025] pointer-events-none" />
        <div className="absolute right-16 bottom-0 w-28 h-28 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />

        <div className="relative z-10 px-6 sm:px-8 py-7 flex flex-col sm:flex-row sm:items-end gap-6 sm:justify-between">
          <div>
            <p className="text-white/35 text-[10px] font-bold tracking-[0.2em] uppercase mb-2">CDT Digital KOA · Portafolio</p>
            <p className="text-white/50 text-[13px] mb-1">Inversión total</p>
            <p className="font-figures text-white text-[36px] sm:text-[42px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.1s' }}>
              {formatPesos(kpiCDT.inversionTotal)}
            </p>
          </div>
          <div className="flex flex-wrap gap-6 sm:gap-8">
            <div>
              <p className="text-white/35 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">Rendimientos totales</p>
              <p className="font-figures text-[#00DB8E] text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.16s' }}>
                +{formatPesos(kpiCDT.rendimientos)}
              </p>
            </div>
            <div>
              <p className="text-white/35 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">Tasa ponderada</p>
              <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.22s' }}>
                {kpiCDT.tasaPonderada} %<span className="text-[13px] text-white/40 font-normal ml-1">E.A.</span>
              </p>
            </div>
            <div>
              <p className="text-white/35 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">CDTs activos</p>
              <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.28s' }}>
                {activeCdts.length}
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 px-6 sm:px-8 pb-5 flex items-center justify-between gap-4 border-t border-white/[0.06] pt-4">
          <p className="text-white/25 text-[11px]">Portafolio activo · {activeCdts.length + terminadosCdts.length} CDTs en total</p>
          <button
            onClick={() => navigate('/cdt/abrir')}
            className="flex items-center gap-2 bg-[#00DB8E] text-[#06005A] text-[12px] font-bold px-4 py-2 rounded-xl hover:bg-[#00C57E] transition-colors cursor-pointer btn-mint-glow whitespace-nowrap"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
            Abrir nuevo CDT
          </button>
        </div>
      </div>

      {/* 2 ── Analytics (no KPIs — hero already covers them) ── */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-3 px-1">Análisis del portafolio</p>
        <CDTGraficas showKPIs={false} />
      </div>

      {/* 3 ── Asesor / Referidos ─────────────────────────── */}
      <div>
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-3 px-1">
          {productos === 'solo-cdt' ? 'Plan de referidos' : 'Mi asesor'}
        </p>
        <AsesorReferidos mode={productos === 'ambos' ? 'asesor' : 'referidos'} />
      </div>

      {/* 4 ── CDT list — last ──────────────────────────────── */}
      <div>
        <div className="flex items-center gap-1 border-b border-[#E8ECF2] mb-3">
          {(['activos', 'terminados'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex items-center gap-2 px-5 py-3 text-[13px] font-semibold transition-colors cursor-pointer ${
                activeTab === tab
                  ? 'text-[#2A3036] border-b-2 border-[#3B82F6] -mb-px'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {tab === 'activos' ? 'Activos' : 'Terminados'}
              <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${
                activeTab === tab ? 'bg-[#0A1F44] text-white' : 'bg-gray-100 text-gray-500'
              }`}>
                {tab === 'activos' ? activeCdts.length : terminadosCdts.length}
              </span>
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {activeTab === 'activos' ? (
            activeCdts.length > 0 ? (
              <>
                <ListHeaders />
                {activeCdts.map((c, i) => <CDTRow key={c.id} cdt={c} delay={i * 0.04} />)}
              </>
            ) : <CDTNoData />
          ) : (
            terminadosCdts.length > 0 ? (
              <>
                <ListHeaders />
                {terminadosCdts.map((c, i) => <CDTRow key={c.id} cdt={c} delay={i * 0.04} />)}
              </>
            ) : (
              <EmptyState
                icon={
                  <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                }
                title="Sin CDTs terminados"
                description="Cuando un CDT llegue a su fecha de vencimiento sin renovarse, aparecerá aquí."
              />
            )
          )}
        </div>
      </div>

    </div>
  )
}
