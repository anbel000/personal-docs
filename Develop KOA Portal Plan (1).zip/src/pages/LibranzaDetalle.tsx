import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import LoadingSkeleton from '../components/LoadingSkeleton'
import TabPagos from '../libranza/TabPagos'
import CertificadosInmediatos from '../libranza/CertificadosInmediatos'
import CertificacionDeSaldo from '../libranza/CertificacionDeSaldo'
import { creditos, formatPesos } from '../data/mockData'

function useCountUp(target: number, duration = 950, active = true) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    if (!active) return
    setValue(0)
    let raf: number
    const start = performance.now()
    const tick = (time: number) => {
      const p = Math.min((time - start) / duration, 1)
      setValue(Math.round(target * (1 - Math.pow(1 - p, 4))))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, active])
  return value
}

function CopyIcon() {
  return (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  )
}

function CheckMini() {
  return (
    <svg className="w-3.5 h-3.5 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
  )
}

function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 3000)
    return () => clearTimeout(t)
  }, [])
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#0A1F44] text-white px-5 py-3 rounded-xl shadow-lg text-[14px] font-medium z-50 flex items-center gap-2">
      <svg className="w-4 h-4 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
      </svg>
      {msg}
    </div>
  )
}

function HeroSkeleton() {
  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <LoadingSkeleton className="h-5 w-40" />
      <div className="bg-[#06005A] rounded-3xl p-6 space-y-5">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <LoadingSkeleton className="h-3 w-24" style={{ background: 'rgba(255,255,255,0.12)' }} />
            <LoadingSkeleton className="h-5 w-36" style={{ background: 'rgba(255,255,255,0.12)' }} />
            <LoadingSkeleton className="h-3.5 w-28" style={{ background: 'rgba(255,255,255,0.08)' }} />
          </div>
          <LoadingSkeleton className="h-6 w-16 rounded-full" style={{ background: 'rgba(255,255,255,0.1)' }} />
        </div>
        <div className="space-y-2">
          <LoadingSkeleton className="h-3 w-20" style={{ background: 'rgba(255,255,255,0.08)' }} />
          <LoadingSkeleton className="h-12 w-56" style={{ background: 'rgba(255,255,255,0.12)' }} />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[0,1,2].map(i => <LoadingSkeleton key={i} className="h-[62px] rounded-xl" style={{ background: 'rgba(255,255,255,0.07)' }} />)}
        </div>
        <LoadingSkeleton className="h-12 rounded-xl" style={{ background: 'rgba(255,255,255,0.06)' }} />
      </div>
      <div className="bg-white rounded-3xl border border-[#E8ECF2] p-5 space-y-3">
        <LoadingSkeleton className="h-4 w-40" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {[0,1,2,3,4,5,6,7].map(i => <LoadingSkeleton key={i} className="h-[62px] rounded-xl" />)}
        </div>
      </div>
    </div>
  )
}

export default function LibranzaDetalle() {
  const { id } = useParams()
  const navigate = useNavigate()
  const credito = creditos.find(c => c.id === id) ?? creditos[0]
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 800)
    return () => clearTimeout(t)
  }, [id])

  const pct = Math.round((credito.cuotaActual / credito.totalCuotas) * 100)
  const enMora = credito.estado === 'en-mora'
  const animatedSaldo = useCountUp(credito.saldo, 950, !loading)

  if (loading) return <HeroSkeleton />

  const copyNumero = () => {
    navigator.clipboard.writeText(credito.numeroCompleto).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    setToast('Número copiado')
  }

  const statsChips = [
    { label: 'Cuota mensual', value: formatPesos(credito.cuotaMensual) },
    { label: 'Tasa E.A.', value: `${credito.tasa}%` },
    { label: 'Plazo', value: `${credito.plazoMeses} meses` },
  ]

  const condiciones = [
    { label: 'Monto desembolsado', value: formatPesos(credito.montoDesembolsado), figures: true },
    { label: 'Fecha desembolso', value: credito.fechaDesembolso, figures: true },
    { label: 'Plazo', value: `${credito.plazoMeses} meses`, figures: true },
    { label: 'Tasa', value: `${credito.tasa}% E.A.`, figures: true },
    { label: 'Cuotas pagadas', value: `${credito.cuotasPagadas} / ${credito.totalCuotas}`, figures: true },
    { label: 'Pendientes', value: String(credito.cuotasPendientes), figures: true },
    { label: 'Última cuota', value: credito.fechaUltimaCuota, figures: true },
    { label: 'Pagaduría', value: credito.pagaduria, figures: false },
  ]

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Back */}
      <button
        onClick={() => navigate('/libranza')}
        className="flex items-center gap-1.5 text-[13px] font-semibold text-[#065F46] hover:underline cursor-pointer"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
        Volver a mis créditos
      </button>

      {/* ── Hero card ─────────────────────────────────── */}
      <div className="relative bg-[#06005A] rounded-3xl overflow-hidden card-enter">
        {/* Decorative orbs */}
        <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-[#059669]/[0.08] pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-white/[0.025] pointer-events-none" />
        <div className="absolute top-1/2 -translate-y-1/2 right-6 w-32 h-32 rounded-full bg-[#3B2FA8]/[0.2] pointer-events-none" />

        <div className="relative px-6 pt-6 pb-6">

          {/* Identity row */}
          <div className="flex items-start justify-between gap-3 mb-6">
            <div>
              <p className="text-white/40 text-[10px] font-bold tracking-[0.18em] uppercase mb-1.5">
                Crédito de Libranza
              </p>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-white font-figures font-bold text-[18px] tracking-tight">
                  {credito.numeroCompleto}
                </span>
                <button
                  onClick={copyNumero}
                  className="w-7 h-7 rounded-lg bg-white/[0.1] hover:bg-white/[0.18] flex items-center justify-center transition-colors cursor-pointer text-white/55"
                  title="Copiar número"
                >
                  {copied ? <CheckMini /> : <CopyIcon />}
                </button>
              </div>
              <p className="text-white/45 text-[13px] font-medium">{credito.pagaduria}</p>
            </div>
            {/* Status badge — custom for dark bg contrast */}
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold flex-shrink-0 mt-1 border ${
              enMora
                ? 'bg-[#EF4444]/20 text-[#FF7070] border-[#EF4444]/35'
                : 'bg-[#059669]/15 text-[#059669] border-[#059669]/30'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 animate-pulse ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669]'}`} />
              {enMora ? 'En mora' : 'Al día'}
            </div>
          </div>

          {/* Mora alert */}
          {enMora && (
            <div className="mb-5 bg-[#EF4444]/[0.15] border border-[#EF4444]/25 rounded-xl px-4 py-3 flex items-center gap-2.5">
              <svg className="w-4 h-4 text-[#EF4444] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <p className="text-[13px] font-semibold text-[#EF4444]">
                Saldo en mora — comunícate con nosotros para regularizarlo.
              </p>
            </div>
          )}

          {/* Balance */}
          <div className="mb-5">
            <p className="text-white/35 text-[9px] font-bold tracking-[0.22em] uppercase mb-2">
              Saldo total
            </p>
            <p className="text-white font-figures font-black text-[44px] sm:text-[52px] leading-none tracking-tight">
              {formatPesos(animatedSaldo)}
            </p>
          </div>

          {/* Stats chips */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {statsChips.map(s => (
              <div
                key={s.label}
                className="bg-white/[0.07] rounded-xl px-3 py-2.5 border border-white/[0.05] transition-colors hover:bg-white/[0.1]"
              >
                <p className="text-white/35 text-[9px] font-bold tracking-widest uppercase mb-1 leading-none">
                  {s.label}
                </p>
                <p className="text-white font-figures font-bold text-[13px] leading-snug">{s.value}</p>
              </div>
            ))}
          </div>

          {/* Progress */}
          <div className="bg-white/[0.05] rounded-2xl px-4 py-3.5 border border-white/[0.04]">
            <div className="flex justify-between items-baseline mb-2.5">
              <span className="text-white/45 text-[11px]">
                Cuota{' '}
                <span className="font-figures font-semibold text-white/70">{credito.cuotaActual}</span>
                {' '}de{' '}
                <span className="font-figures text-white/60">{credito.totalCuotas}</span>
              </span>
              <span className="font-figures text-[12px] font-bold text-[#059669]">{pct}% pagado</span>
            </div>
            <div className="h-2.5 bg-white/[0.1] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000 ease-out"
                style={{
                  width: `${pct}%`,
                  background: 'linear-gradient(90deg, #00A676 0%, #059669 60%, #34D399 100% 100%)',
                  boxShadow: '0 0 14px rgba(0,219,142,0.55)',
                }}
              />
            </div>
          </div>

        </div>
      </div>

      {/* ── Condiciones del crédito ─────────────────── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] p-5 card-enter stagger-1">
        <p className="font-bold text-[15px] text-[#2A3036] mb-4">Condiciones del crédito</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {condiciones.map(d => (
            <div
              key={d.label}
              className="bg-[#F7F8FA] hover:bg-[#F0F2F5] transition-colors rounded-xl px-3.5 py-3"
            >
              <p className="text-[9px] font-bold text-gray-400 tracking-widest uppercase mb-1.5 leading-none">
                {d.label}
              </p>
              <p className={`font-semibold text-[#2A3036] text-[13px] leading-tight ${d.figures ? 'font-figures' : ''}`}>
                {d.value}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Historial de pagos ──────────────────────── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-2">
        <div className="px-5 pt-5 pb-4 flex items-center justify-between">
          <div>
            <p className="font-bold text-[15px] text-[#2A3036]">Historial de pagos</p>
            <p className="text-[12px] text-gray-400 mt-0.5">{credito.cuotasPagadas} cuotas aplicadas</p>
          </div>
          <div className="w-9 h-9 rounded-xl bg-[#ECFDF5] flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-[#065F46]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
          </div>
        </div>
        <div className="border-t border-[#F0F2F5] px-5 pt-4 pb-5">
          <TabPagos />
        </div>
      </div>

      {/* ── Documentos ─────────────────────────────── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] p-5 card-enter stagger-3">
        <div className="flex items-center justify-between mb-5">
          <p className="font-bold text-[15px] text-[#2A3036]">Documentos</p>
          <div className="w-9 h-9 rounded-xl bg-[#F0F0FF] flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
        </div>
        <CertificadosInmediatos onToast={msg => setToast(msg)} />
        <div className="mt-5 pt-5 border-t border-[#F0F2F5]">
          <CertificacionDeSaldo
            creditoId={credito.id}
            numeroMascarado={credito.numeroMascarado}
            pagaduria={credito.pagaduria}
            onToast={msg => setToast(msg)}
          />
        </div>
      </div>

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  )
}
