import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import LoadingSkeleton from '../components/LoadingSkeleton'
import Btn from '../components/Btn'
import { kpiLibranza, kpiCDT, cdts, pendientes, formatPesos } from '../data/mockData'

/* ─── Floating particles (shared) ─────────────────────────── */
const HOME_PARTICLES = [
  { size: 4, top: '12%', left: '7%', dur: '3.2s', delay: '0s', op: 0.28, fy: '-14px' },
  { size: 5, top: '68%', left: '11%', dur: '4s', delay: '0.9s', op: 0.18, fy: '-20px' },
  { size: 3, top: '22%', right: '8%', dur: '3.8s', delay: '1.5s', op: 0.32, fy: '-10px' },
  { size: 4, top: '77%', right: '16%', dur: '2.9s', delay: '0.3s', op: 0.22, fy: '-16px' },
  { size: 3, top: '46%', left: '40%', dur: '5.1s', delay: '2s', op: 0.14, fy: '-12px' },
]
function CardParticles({ color = '#00DB8E' }: { color?: string }) {
  return (
    <>
      {HOME_PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            width: p.size, height: p.size,
            top: p.top, left: p.left, right: p.right,
            background: i % 2 === 0 ? color : '#3B82F6',
            opacity: p.op,
            ['--dur' as string]: p.dur,
            ['--delay' as string]: p.delay,
            ['--fy' as string]: p.fy,
            ['--op' as string]: p.op,
          }}
        />
      ))}
    </>
  )
}


/* ─── CDT vigent rates ────────────────────────────────────── */
const TASAS_CDT = [
  { plazo: '60 días',  tasa: '10,50' },
  { plazo: '90 días',  tasa: '11,00' },
  { plazo: '180 días', tasa: '11,50' },
  { plazo: '360 días', tasa: '12,20' },
]

/* ─── CDT product card (dark, large) ─────────────────────── */
function CDTCard({ navigate }: { navigate: (p: string) => void }) {
  return (
    <div
      onClick={() => navigate('/cdt')}
      className="relative overflow-hidden rounded-3xl cursor-pointer group card-enter"
      style={{ background: '#06005A', minHeight: '300px' }}
    >
      <div className="absolute -right-14 -top-14 w-52 h-52 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />
      <div className="absolute right-10 bottom-0 w-28 h-28 rounded-full bg-[#3B82F6]/[0.06] pointer-events-none" />
      <div className="absolute -left-8 top-1/2 w-24 h-24 rounded-full bg-white/[0.018] pointer-events-none" />
      <svg className="absolute inset-0 w-full h-full opacity-[0.035] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="dots-cdt" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots-cdt)" />
      </svg>
      <CardParticles color="#00DB8E" />

      <div className="relative z-10 p-7 flex flex-col h-full">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00DB8E]/20 border border-[#00DB8E]/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            </div>
            <div>
              <p className="text-white font-bold text-[15px] leading-none">CDT Digital</p>
              <p className="text-white/55 text-[9px] font-bold tracking-[0.18em] uppercase mt-0.5">KOA</p>
            </div>
          </div>
          <span className="bg-[#00DB8E]/20 border border-[#00DB8E]/20 text-[#00DB8E] text-[10px] font-bold tracking-wide px-2.5 py-1 rounded-full">
            {cdts.length} activos
          </span>
        </div>

        <div className="flex-1 flex flex-col justify-center mb-6">
          <p className="text-white/60 text-[11px] font-semibold mb-1.5 tracking-wide">Inversión total</p>
          <p className="font-figures text-white font-black leading-none mb-3" style={{ fontSize: 'clamp(28px, 5vw, 44px)' }}>
            {formatPesos(kpiCDT.inversionTotal)}
          </p>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] flex-shrink-0" />
            <p className="font-figures text-[#00DB8E] text-[16px] font-black">
              +{formatPesos(kpiCDT.rendimientos)} en rendimientos
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-white/[0.1]">
          <div>
            <p className="text-white/55 text-[9px] font-bold tracking-[0.12em] uppercase">Tasa ponderada</p>
            <p className="font-figures text-white text-[16px] font-bold mt-0.5">
              {kpiCDT.tasaPonderada} % <span className="text-[12px] font-normal text-white/60">E.A.</span>
            </p>
          </div>
          <div className="flex items-center gap-2 bg-white/[0.1] group-hover:bg-white/[0.18] transition-all rounded-xl px-4 py-2.5">
            <span className="text-white text-[12px] font-semibold">Ver mis CDTs</span>
            <svg className="w-3.5 h-3.5 text-white/70 group-hover:translate-x-0.5 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Libranza main card (dark green, large) ─────────────── */
function LibranzaMainCard({ navigate }: { navigate: (p: string) => void }) {
  return (
    <div
      onClick={() => navigate('/libranza')}
      className="relative overflow-hidden rounded-3xl cursor-pointer group card-enter"
      style={{ background: '#06005A', minHeight: '300px' }}
    >
      <div className="absolute -right-14 -top-14 w-52 h-52 rounded-full bg-[#00DB8E]/[0.08] pointer-events-none" />
      <div className="absolute right-8 bottom-0 w-32 h-32 rounded-full bg-white/[0.025] pointer-events-none" />
      <div className="absolute -left-10 bottom-8 w-28 h-28 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />
      <svg className="absolute inset-0 w-full h-full opacity-[0.035] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="dots-lib" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots-lib)" />
      </svg>
      <CardParticles color="#00DB8E" />

      <div className="relative z-10 p-7 flex flex-col h-full">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#00DB8E]/25 border border-[#00DB8E]/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-white font-bold text-[15px] leading-none">Libranza</p>
              <p className="text-white/55 text-[9px] font-bold tracking-[0.18em] uppercase mt-0.5">Créditos KOA</p>
            </div>
          </div>
          <span className="bg-[#00DB8E]/20 border border-[#00DB8E]/20 text-[#00DB8E] text-[10px] font-bold tracking-wide px-2.5 py-1 rounded-full">
            {kpiLibranza.creditosActivos} activos
          </span>
        </div>

        <div className="flex-1 flex flex-col justify-center mb-6">
          <p className="text-white/60 text-[11px] font-semibold mb-1.5 tracking-wide">Saldo total</p>
          <p className="font-figures text-white font-black leading-none mb-3" style={{ fontSize: 'clamp(28px, 5vw, 44px)' }}>
            {formatPesos(kpiLibranza.deudaTotal)}
          </p>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] flex-shrink-0 mint-pulse" />
            <p className="font-figures text-[#00DB8E] text-[14px] font-semibold">
              {kpiLibranza.creditosActivos} créditos activos
            </p>
          </div>
        </div>

        <div className="flex items-center justify-end pt-4 border-t border-white/[0.1]">
          <div className="flex items-center gap-2 bg-white/[0.1] group-hover:bg-white/[0.18] transition-all rounded-xl px-4 py-2.5">
            <span className="text-white text-[12px] font-semibold">Ver créditos</span>
            <svg className="w-3.5 h-3.5 text-white/70 group-hover:translate-x-0.5 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Libranza compact card (right column) ───────────────── */
function LibranzaCompactCard({ navigate }: { navigate: (p: string) => void }) {
  return (
    <div
      onClick={() => navigate('/libranza')}
      className="relative overflow-hidden rounded-3xl cursor-pointer group card-enter flex flex-col h-full"
      style={{
        background: '#06005A',
        animationDelay: '0.06s',
        minHeight: '140px',
      }}
    >
      {/* Dot grid */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.04] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="dots-lib-c" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.2" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots-lib-c)" />
      </svg>
      <CardParticles color="#00DB8E" />
      <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />

      <div className="relative z-10 p-6 flex flex-col h-full">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#00DB8E]/20 border border-[#00DB8E]/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="font-bold text-white text-[13px] leading-none">Libranza</p>
              <p className="text-white/55 text-[9px] font-bold tracking-[0.14em] uppercase mt-0.5">KOA</p>
            </div>
          </div>
          <svg className="w-3.5 h-3.5 text-white/50 group-hover:text-white group-hover:translate-x-0.5 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>

        <div className="flex-1 flex flex-col justify-center">
          <p className="text-white/60 text-[10px] mb-0.5">Saldo total</p>
          <p className="font-figures font-bold text-white text-[22px] leading-none mb-1">
            {formatPesos(kpiLibranza.deudaTotal)}
          </p>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] flex-shrink-0 mint-pulse" />
            <p className="font-figures text-[#00DB8E] text-[11px] font-semibold">
              {kpiLibranza.creditosActivos} créditos activos
            </p>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-white/[0.1] flex items-center justify-between">
          <p className="text-[10px] text-white/55">{kpiLibranza.creditosActivos} créditos activos</p>
          <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse flex-shrink-0" />
        </div>
      </div>
    </div>
  )
}



/* ─── Recomendación: Amplía tu Libranza ───────────────────── */
function RecoAmpliaLibranza({ navigate }: { navigate: (p: string) => void }) {
  return (
    <div className="relative overflow-hidden rounded-3xl cursor-pointer group" onClick={() => navigate('/contactanos')} style={{ background: '#06005A' }}>
      {/* Decorative elements */}
      <div className="absolute -right-14 -top-14 w-56 h-56 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none animate-float" style={{'--dur': '6s', '--fy': '-18px', '--op': 0.07} as React.CSSProperties} />
      <div className="absolute left-1/2 bottom-0 w-40 h-40 rounded-full bg-white/[0.02] pointer-events-none" />
      <svg className="absolute inset-0 w-full h-full opacity-[0.03] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="dots-amplia" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.2" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots-amplia)" />
      </svg>
      <CardParticles color="#00DB8E" />

      <div className="relative z-10 px-7 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center gap-5">

          {/* Content */}
          <div className="flex-1 min-w-0">
            <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/60 mb-2">Libranza · Más capital</p>
            <p className="text-white font-black leading-tight mb-4" style={{ fontSize: 'clamp(18px, 3vw, 22px)' }}>
              Tienes cupo disponible para ampliar tu crédito
            </p>
            <div className="flex items-center gap-5 flex-wrap">
              <div>
                <p className="text-white/60 text-[10px] font-semibold uppercase tracking-wider mb-1">Monto disponible</p>
                <p className="font-figures font-black text-[#00DB8E] leading-none" style={{ fontSize: 'clamp(22px, 3.5vw, 28px)' }}>
                  Hasta $100M
                </p>
              </div>
              <div className="w-px h-10 bg-white/10 hidden sm:block" />
              <div className="flex flex-col gap-1.5">
                {[
                  { icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z', label: 'Mismo empleador · sin fiador' },
                  { icon: 'M13 10V3L4 14h7v7l9-11h-7z', label: 'Aprobación en 48 horas' },
                  { icon: 'M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 11h.01M12 11h.01M15 11h.01M4 19h16a2 2 0 002-2V7a2 2 0 00-2-2H4a2 2 0 00-2 2v10a2 2 0 002 2z', label: '100 % digital · sin papeleos' },
                ].map(b => (
                  <div key={b.label} className="flex items-center gap-1.5">
                    <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d={b.icon} />
                    </svg>
                    <p className="text-white/70 text-[11px] font-medium">{b.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex-shrink-0">
            <button
              onClick={() => navigate('/contactanos')}
              className="w-full sm:w-auto bg-[#00DB8E] text-[#06005A] font-black text-[14px] px-7 py-3.5 rounded-2xl btn-mint-glow hover:bg-[#00C57E] cursor-pointer transition-colors group-hover:scale-[1.02] transition-transform"
            >
              Iniciar proceso
            </button>
          </div>

        </div>
      </div>
    </div>
  )
}

/* ─── Tasas CDT card (reutilizable) ──────────────────────── */
function TasasCDTCard({ navigate, showCDT, delay = '0.1s' }: { navigate: (p: string) => void; showCDT: boolean; delay?: string }) {
  return (
    <div
      className="relative overflow-hidden rounded-3xl card-enter h-full"
      style={{ background: '#06005A', animationDelay: delay }}
    >
      <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none animate-float" style={{'--dur': '7s', '--fy': '-22px', '--op': 0.07} as React.CSSProperties} />
      <div className="absolute -left-10 bottom-0 w-44 h-44 rounded-full bg-white/[0.025] pointer-events-none animate-float" style={{'--dur': '9s', '--fy': '-14px', '--op': 0.025, '--delay': '1.5s'} as React.CSSProperties} />
      <div className="absolute right-1/3 top-0 w-px h-full bg-white/[0.04] pointer-events-none" />
      <svg className="absolute inset-0 w-full h-full opacity-[0.03] pointer-events-none" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="dots-tasas" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.2" fill="white" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots-tasas)" />
      </svg>
      <CardParticles color="#00DB8E" />
      <div className="relative z-10 px-7 py-7">
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse" />
              <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/55">KOA · Vigente 2026</p>
            </div>
            <p className="text-white font-black leading-tight" style={{ fontSize: 'clamp(18px, 3vw, 24px)' }}>
              {showCDT ? 'Tasas CDT vigentes' : 'CDT Digital KOA'}
            </p>
            {!showCDT && (
              <p className="text-white/60 text-[12px] mt-1 font-medium">Plazos de 60 a 360 días · 100 % digital</p>
            )}
          </div>
          <button
            onClick={() => navigate(showCDT ? '/cdt/abrir' : '/cdt')}
            className="flex-shrink-0 bg-[#00DB8E] text-[#06005A] text-[12px] font-bold px-5 py-2.5 rounded-xl hover:bg-[#00C57E] transition-colors cursor-pointer btn-mint-glow"
          >
            {showCDT ? 'Nueva apertura' : 'Abrir mi CDT'}
          </button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {TASAS_CDT.map((t, i) => {
            const isBest = i === TASAS_CDT.length - 1
            return (
              <div
                key={t.plazo}
                className="relative rounded-2xl px-4 py-4 card-enter"
                style={{
                  background: isBest ? 'rgba(0,219,142,0.13)' : 'rgba(255,255,255,0.06)',
                  border: isBest ? '1px solid rgba(0,219,142,0.28)' : '1px solid rgba(255,255,255,0.06)',
                  animationDelay: `${0.12 + i * 0.07}s`,
                }}
              >
                {isBest && (
                  <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-[#00DB8E] text-[#06005A] text-[8px] font-black px-2.5 py-[3px] rounded-full tracking-[0.12em] uppercase whitespace-nowrap">
                    Mejor tasa
                  </span>
                )}
                <p className="text-white/60 text-[10px] font-semibold mb-2">{t.plazo}</p>
                <p
                  className="font-figures text-[#00DB8E] font-black leading-none animate-number-pop"
                  style={{ fontSize: isBest ? '28px' : '22px', '--delay': `${0.22 + i * 0.07}s` } as React.CSSProperties}
                >
                  {t.tasa} %
                </p>
                <p className="text-white/50 text-[9px] font-semibold mt-1.5 tracking-[0.1em]">E.A.</p>
              </div>
            )
          })}
        </div>
        <p className="text-white/40 text-[10px] font-medium mt-4">Tasas efectivas anuales · Sujetas a cambio sin previo aviso</p>
      </div>
    </div>
  )
}

/* ─── Skeleton ────────────────────────────────────────────── */
function HomeSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-2.5 pt-1">
        <LoadingSkeleton className="h-3 w-16 rounded-full" />
        <LoadingSkeleton className="h-10 w-52 rounded-2xl" />
        <LoadingSkeleton className="h-3 w-44 rounded-full" />
      </div>
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="sm:flex-[2] rounded-3xl" style={{ background: '#06005A', minHeight: 300 }}>
          <div className="p-7 flex flex-col gap-5 h-full">
            <div className="flex justify-between">
              <LoadingSkeleton className="h-9 w-32 rounded-xl opacity-30" />
              <LoadingSkeleton className="h-6 w-20 rounded-full opacity-20" />
            </div>
            <div className="flex-1 space-y-2.5">
              <LoadingSkeleton className="h-3 w-20 rounded-full opacity-20" />
              <LoadingSkeleton className="h-12 w-56 rounded-2xl opacity-35" />
              <LoadingSkeleton className="h-4 w-40 rounded-full opacity-22" />
            </div>
          </div>
        </div>
        <div className="sm:flex-1">
          <div className="card-flat rounded-3xl" style={{ minHeight: 140 }} />
        </div>
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function Home() {
  const { personType, productos } = useDemoContext()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 700)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <HomeSkeleton />

  const showCDT = productos === 'ambos' || productos === 'solo-cdt'
  // Juridica cannot have libranza
  const showLibranza = (productos === 'ambos' || productos === 'solo-libranza') && personType === 'natural'
  const emptyState = productos === 'ninguno'
  const hasProducts = showCDT || showLibranza

  // Compute dynamic pending items
  const cdtBankPendientes = showCDT
    ? cdts
        .filter(c => c.estado === 'activo' && !c.cuentaInscrita)
        .map(c => ({
          id: `bank-${c.id}`,
          texto: `Inscribe tu cuenta bancaria para CDT ${c.numeroMascarado}`,
          href: `/cdt/${c.id}`,
          icono: 'banco' as const,
        }))
    : []
  const allPendientes = [...pendientes, ...cdtBankPendientes]

  const today = new Intl.DateTimeFormat('es-CO', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  }).format(new Date(2026, 7, 14))

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Buenos días' : hour < 18 ? 'Buenas tardes' : 'Buenas noches'

  return (
    <div className="space-y-8">

      {/* ── Hero ───────────────────────────────────────────────── */}
      <div className="card-enter flex items-start justify-between gap-4 pt-1">
        {/* Left: greeting + name */}
        <div>
          <p className="text-[10px] font-bold tracking-[0.22em] uppercase text-[#00DB8E] mb-2">{greeting}</p>
          <h1 className="text-[30px] sm:text-[36px] font-black text-[#2A3036] tracking-tight leading-none">
            {personType === 'juridica' ? 'Constructora' : 'Andrés'}
          </h1>
        </div>

        {/* Right: date + pendientes status */}
        <div className="flex-shrink-0 text-right pt-0.5">
          <p className="font-figures text-[12px] text-gray-400 capitalize leading-snug">{today}</p>
          <div className="flex items-center justify-end gap-1.5 mt-2">
            {hasProducts && allPendientes.length > 0 ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] flex-shrink-0" style={{ boxShadow: '0 0 0 3px rgba(245,158,11,0.18)' }} />
                <p className="text-[11px] font-semibold text-[#92400E]">
                  {allPendientes.length} pendiente{allPendientes.length !== 1 ? 's' : ''}
                </p>
              </>
            ) : (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse flex-shrink-0" />
                <p className="text-[11px] font-semibold text-[#005E3C]">Al día ✓</p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ── Mis productos ──────────────────────────────────────── */}
      {emptyState ? (
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="sm:flex-[3]" style={{ minHeight: 240 }}>
            <TasasCDTCard navigate={navigate} showCDT={false} delay="0s" />
          </div>
          {personType === 'natural' && (
            <button
              onClick={() => navigate('/contactanos')}
              className="sm:flex-[2] relative overflow-hidden rounded-3xl text-left group cursor-pointer card-enter flex flex-col"
              style={{ background: '#06005A', minHeight: 200, animationDelay: '0.07s' }}
            >
              <CardParticles color="#00DB8E" />
              <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />
              <div className="relative z-10 p-7 flex flex-col h-full">
                <div className="w-10 h-10 rounded-xl bg-[#00DB8E]/20 border border-[#00DB8E]/20 flex items-center justify-center mb-5">
                  <svg className="w-5 h-5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="text-white/60 text-[9px] font-bold tracking-[0.18em] uppercase mb-1">Crédito · KOA</p>
                <p className="text-white font-bold text-[20px] tracking-tight leading-tight mb-2">Libranza</p>
                <p className="text-white/65 text-[12px] leading-snug">Descuento directo de nómina o pensión. Sin trámites en caja.</p>
                <div className="mt-auto pt-5 flex items-center gap-2 text-white/65 group-hover:text-white transition-colors text-[12px] font-semibold">
                  <span>Hablar con un asesor</span>
                  <svg className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </button>
          )}
        </div>
      ) : hasProducts ? (
        <div className="flex flex-col sm:flex-row gap-4">
          <div className={showCDT && showLibranza ? 'sm:flex-[2]' : 'flex-1'}>
            {showCDT ? <CDTCard navigate={navigate} /> : <LibranzaMainCard navigate={navigate} />}
          </div>
          {showCDT && showLibranza && (
            <div className="sm:flex-1">
              <LibranzaCompactCard navigate={navigate} />
            </div>
          )}
        </div>
      ) : null}

      {/* ── Mis pendientes ─────────────────────────────────────── */}
      {hasProducts && allPendientes.length > 0 && (
        <div className="space-y-2.5 card-enter" style={{ animationDelay: '0.08s' }}>
          <div className="flex items-center gap-2 px-0.5">
            <div className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
            <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">Pendientes</p>
            <span className="ml-auto text-[10px] font-black text-[#F59E0B] bg-[#F59E0B]/12 px-2 py-0.5 rounded-full leading-none">
              {allPendientes.length}
            </span>
          </div>
          <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden divide-y divide-[#F4F4F4]">
            {allPendientes.map(p => (
              <button
                key={p.id}
                onClick={() => navigate(p.href)}
                className="w-full flex items-center gap-3.5 px-5 py-4 hover:bg-[#EFFFF7] transition-colors cursor-pointer group text-left"
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  p.icono === 'perfil' ? 'bg-[#3B82F6]/10' :
                  p.icono === 'banco' ? 'bg-[#8B5CF6]/10' : 'bg-[#EFFFF7]'
                }`}>
                  {p.icono === 'perfil' && (
                    <svg className="w-4 h-4 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  )}
                  {p.icono === 'banco' && (
                    <svg className="w-4 h-4 text-[#8B5CF6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-[#2A3036] text-[13px] leading-none">{p.texto}</p>
                  {'badge' in p && p.badge && (
                    <span className="inline-block text-[10px] font-bold text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-0.5 rounded-full mt-1">
                      {(p as { badge: string }).badge}
                    </span>
                  )}
                </div>
                <svg className="w-4 h-4 text-gray-300 group-hover:text-[#2A3036] group-hover:translate-x-0.5 transition-all flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── KOA recomienda ─────────────────────────────────────── */}
      {!emptyState && (
        <div className="space-y-4 card-enter" style={{ animationDelay: '0.12s' }}>
          <div className="flex items-center gap-2 px-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse" />
            <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">KOA recomienda</p>
          </div>

          {/* Libranza cross-sell banner — solo CDT, persona natural */}
          {showCDT && !showLibranza && personType === 'natural' && (
            <div className="relative overflow-hidden rounded-3xl" style={{ background: '#06005A' }}>
              <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />
              <div className="absolute right-20 bottom-0 w-28 h-28 rounded-full bg-white/[0.02] pointer-events-none" />
              <CardParticles color="#00DB8E" />
              <div className="px-7 py-6 flex items-center justify-between gap-6 relative z-10">
                <div>
                  <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/60 mb-2">Crédito · KOA</p>
                  <p className="text-white font-black text-[20px] tracking-tight leading-none">Libranza KOA</p>
                  <p className="font-figures text-[#00DB8E] text-[16px] mt-1.5 font-black leading-none">Descuento directo nómina o pensión</p>
                  <p className="text-white/65 text-[12px] mt-1">Sin trámites en caja · Tasas preferenciales</p>
                </div>
                <Btn variant="mint" size="lg" onClick={() => navigate('/contactanos')}>Hablar con asesor</Btn>
              </div>
            </div>
          )}

          {/* Amplía tu Libranza — solo para usuarios con Libranza */}
          {showLibranza && <RecoAmpliaLibranza navigate={navigate} />}

          {/* Tasas CDT — siempre al final */}
          <TasasCDTCard navigate={navigate} showCDT={showCDT} delay="0s" />
        </div>
      )}

    </div>
  )
}
