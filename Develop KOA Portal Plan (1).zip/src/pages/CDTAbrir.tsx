import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import FirmaElectronica from '../cdt/FirmaElectronica'
import MediosDePago from './MediosDePago'
import { formatPesos, clienteNatural } from '../data/mockData'

type Paso = 1 | 2 | 3 | 4

/* ─── Constants ──────────────────────────────────── */
const TASAS: Record<string, string> = {
  '30': '7,80', '60': '8,50', '90': '9,00', '120': '9,50',
  '180': '10,50', '270': '10,90', '360': '11,80', '540': '12,00', '720': '12,20',
}
const PLAZOS = [
  { label: '30 días', value: '30' },
  { label: '60 días', value: '60' },
  { label: '90 días', value: '90' },
  { label: '120 días', value: '120' },
  { label: '180 días', value: '180' },
  { label: '270 días', value: '270' },
  { label: '1 año', value: '360', popular: true },
  { label: '18 meses', value: '540' },
  { label: '2 años', value: '720' },
]
const PERIODICIDADES = [
  { value: 'Al vencimiento', desc: 'Cobras todo al final' },
  { value: 'Mensual', desc: 'Cobras cada mes' },
  { value: 'Trimestral', desc: 'Cada 3 meses' },
  { value: 'Semestral', desc: 'Cada 6 meses' },
]
const REGLAMENTOS = [
  { id: 'r1', titulo: 'Condiciones generales del CDT Digital KOA', desc: 'Términos, plazos, tasas y condiciones de renovación.', color: '#06005A' },
  { id: 'r2', titulo: 'Política de retención en la fuente', desc: 'Descripción del cobro del 4% sobre rendimientos.', color: '#0E4D8A' },
  { id: 'r3', titulo: 'Reglamento de inversión colectiva', desc: 'Normativa Superintendencia Financiera para CDT.', color: '#5B21B6' },
  { id: 'r4', titulo: 'Política de protección de datos', desc: 'Tratamiento de información personal KOA.', color: '#0D4A30' },
]
const CODIGO_VALIDO = 'AB4589R'

/* ─── Helpers ────────────────────────────────────── */
function addDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}
function formatFecha(date: Date): string {
  const M = ['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC']
  return `${String(date.getDate()).padStart(2,'0')} ${M[date.getMonth()]} ${date.getFullYear()}`
}

/* ─── Count-up hook ──────────────────────────────── */
function useCountUp(target: number, active: boolean, duration = 650) {
  const [value, setValue] = useState(0)
  const raf = useRef(0)
  const from = useRef(0)
  useEffect(() => {
    if (!active || target === 0) { setValue(0); from.current = 0; return }
    cancelAnimationFrame(raf.current)
    const start = performance.now()
    const prev = from.current
    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)
      setValue(Math.round(prev + (target - prev) * ease))
      if (t < 1) raf.current = requestAnimationFrame(tick)
      else from.current = target
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [target, active, duration])
  return value
}

/* ─── Step indicator ─────────────────────────────── */
function StepIndicator({ paso }: { paso: Paso }) {
  const steps = ['Simulación', 'Reglamento', 'Pago', '¡Listo!']
  return (
    <div className="flex items-start">
      {steps.map((s, i) => {
        const n = i + 1
        const done = n < paso
        const active = n === paso
        return (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-bold transition-all duration-300 ${
                done ? 'bg-[#00DB8E] text-[#005E3C] shadow-sm'
                : active ? 'bg-[#0A1F44] text-white shadow-md ring-4 ring-[#0A1F44]/12'
                : 'bg-white border-2 border-[#E8ECF2] text-gray-300'
              }`}>
                {done
                  ? <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  : n}
              </div>
              <span className={`text-[10px] font-bold whitespace-nowrap transition-colors ${active ? 'text-[#2A3036]' : done ? 'text-[#005E3C]' : 'text-gray-400'}`}>{s}</span>
            </div>
            {i < steps.length - 1 && (
              <div className="flex-1 h-0.5 mx-1.5 mb-5 relative overflow-hidden rounded-full bg-[#F0F2F5]">
                <div
                  className="absolute inset-y-0 left-0 rounded-full transition-all duration-700 ease-in-out"
                  style={{ width: done ? '100%' : '0%', background: 'linear-gradient(90deg, #0A1F44, #3B82F6, #00DB8E)' }}
                />
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ─── Main ───────────────────────────────────────── */
export default function CDTAbrir() {
  const navigate = useNavigate()

  const [paso, setPaso] = useState<Paso>(1)
  const [monto, setMonto] = useState('')
  const [plazo, setPlazo] = useState('360')
  const [periodicidad, setPeriodicidad] = useState('Al vencimiento')
  const [renovacion, setRenovacion] = useState(true)
  const [errMonto, setErrMonto] = useState('')
  const [codigoOpen, setCodigoOpen] = useState(false)
  const [codigoRef, setCodigoRef] = useState('')
  const [codigoAplicado, setCodigoAplicado] = useState(false)
  const [codigoErr, setCodigoErr] = useState('')
  const [descargados, setDescargados] = useState<Set<string>>(new Set())
  const [descargando, setDescargando] = useState<string | null>(null)
  const [aceptoReglamento, setAceptoReglamento] = useState(false)
  const [firmaOpen, setFirmaOpen] = useState(false)

  /* Derived */
  const montoNum = parseInt(monto.replace(/\D/g, '')) || 0
  const tasa = TASAS[plazo] || '11,80'
  const tasaBase = parseFloat(tasa.replace(',', '.'))
  const tasaEfectiva = codigoAplicado ? tasaBase + 0.30 : tasaBase
  const tasaDisplay = tasaEfectiva.toFixed(2).replace('.', ',')
  const rendimientos = Math.round(montoNum * tasaBase / 100 * parseInt(plazo) / 365)
  const bonoCodigo = codigoAplicado ? Math.round(montoNum * 0.003 * parseInt(plazo) / 365) : 0
  const rendimientosBrutos = rendimientos + bonoCodigo
  const retencion = Math.round(rendimientosBrutos * 0.04)
  const rendimientosNetos = rendimientosBrutos - retencion
  const totalARecibir = montoNum + rendimientosNetos
  const activo = montoNum >= 1_000_000

  /* Count-ups */
  const animBrutos = useCountUp(rendimientosBrutos, activo)
  const animNetos = useCountUp(rendimientosNetos, activo)
  const animTotal = useCountUp(totalARecibir, activo)

  /* Dates */
  const today = new Date()
  const fechaApertura = formatFecha(today)
  const fechaVencimiento = formatFecha(addDays(today, parseInt(plazo)))

  /* CDT number for certificate */
  const cdtNumero = `000${3000 + Math.min(Math.floor(montoNum / 1_000_000), 999)}`

  /* Handlers */
  const handleMontoChange = (val: string) => {
    const digits = val.replace(/\D/g, '')
    setMonto(digits ? parseInt(digits).toLocaleString('es-CO') : '')
    setErrMonto('')
  }
  const validarMonto = () => {
    if (montoNum < 1_000_000) { setErrMonto('El monto mínimo es $ 1.000.000.'); return false }
    if (montoNum > 2_000_000_000) { setErrMonto('El monto máximo es $ 2.000.000.000.'); return false }
    return true
  }
  const handleDescargar = (id: string) => {
    setDescargando(id)
    setTimeout(() => { setDescargando(null); setDescargados(prev => new Set([...prev, id])) }, 900)
  }
  const handleFirmaSuccess = () => { setFirmaOpen(false); setPaso(3) }
  const handleAplicarCodigo = () => {
    const clean = codigoRef.trim().toUpperCase()
    if (clean === CODIGO_VALIDO) {
      setCodigoAplicado(true)
      setCodigoErr('')
    } else {
      setCodigoErr('Código no válido o ya utilizado.')
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-5 pb-12">

      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => paso === 1 ? navigate('/cdt') : setPaso(p => (p - 1) as Paso)}
          className="w-9 h-9 rounded-xl bg-white border border-[#E8ECF2] flex items-center justify-center hover:bg-gray-50 text-gray-500 cursor-pointer flex-shrink-0 shadow-sm"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
        </button>
        <div>
          <h1 className="font-bold text-[18px] text-[#2A3036] leading-tight">Abrir CDT Digital KOA</h1>
          <p className="text-[12px] text-gray-400 mt-0.5">Paso {paso} de 4 · {['Simulación','Reglamento','Medio de pago','Confirmación'][paso-1]}</p>
        </div>
      </div>

      {/* Step indicator */}
      <StepIndicator paso={paso} />

      {/* Summary bar — visible on steps 2–4 */}
      {paso > 1 && activo && (
        <div className="flex items-center justify-between gap-3 bg-[#0A1F44]/[0.04] border border-[#0A1F44]/10 rounded-2xl px-4 py-3">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="font-figures font-black text-[15px] text-[#2A3036]">{formatPesos(montoNum)}</span>
            <span className="text-gray-300">·</span>
            <span className="text-[13px] text-gray-500">{PLAZOS.find(p => p.value === plazo)?.label}</span>
            <span className="text-gray-300">·</span>
            <span className="font-figures font-bold text-[13px] text-[#3B82F6]">{tasaDisplay} % E.A.</span>
            {codigoAplicado && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#00DB8E]/15 text-[#005E3C] border border-[#00DB8E]/25">
                +0,30 % referido
              </span>
            )}
          </div>
          {paso === 2 && (
            <button onClick={() => setPaso(1)} className="text-[11px] font-semibold text-[#3B82F6] hover:underline cursor-pointer flex-shrink-0">
              Modificar
            </button>
          )}
        </div>
      )}

      {/* ── Paso 1 — Simulador ── */}
      {paso === 1 && (
        <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden">
          <div className="px-6 pt-6 pb-5 space-y-6">

            {/* Monto */}
            <div>
              <label className="block text-[11px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Monto a invertir</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-[15px] font-figures font-bold select-none">$</span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={monto}
                  onChange={e => handleMontoChange(e.target.value)}
                  placeholder="0"
                  className={`w-full border-2 rounded-2xl pl-9 pr-4 py-3.5 text-[22px] font-figures font-black text-[#2A3036] outline-none transition-colors ${
                    errMonto ? 'border-[#EF4444] bg-[#FEF2F2]' : activo ? 'border-[#0A1F44]/30 focus:border-[#0A1F44]' : 'border-[#E8ECF2] focus:border-[#0A1F44]'
                  }`}
                />
              </div>
              {errMonto
                ? <p className="text-[12px] text-red-500 mt-1.5">{errMonto}</p>
                : <p className="text-[11px] text-gray-400 mt-1.5">Mínimo $ 1.000.000 · Máximo $ 2.000.000.000</p>
              }
            </div>

            {/* Plazo — rate-forward grid */}
            <div>
              <label className="block text-[11px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2.5">Plazo e interés anual</label>
              <div className="grid grid-cols-3 gap-2">
                {PLAZOS.map(p => (
                  <button
                    key={p.value}
                    onClick={() => setPlazo(p.value)}
                    className={`relative flex flex-col items-center py-3 px-2 rounded-xl border-2 transition-all duration-150 cursor-pointer overflow-hidden ${
                      plazo === p.value
                        ? 'bg-[#0A1F44] border-[#0A1F44] text-white shadow-md'
                        : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0A1F44]/30'
                    }`}
                  >
                    {(p as { popular?: boolean }).popular && (
                      <span className={`absolute top-1 right-1 text-[8px] font-black px-1.5 py-0.5 rounded-full ${plazo === p.value ? 'bg-[#00DB8E]/25 text-[#00DB8E]' : 'bg-[#3B82F6]/15 text-[#3B82F6]'}`}>
                        Popular
                      </span>
                    )}
                    <span className="text-[11px] font-semibold leading-none mb-1.5">{p.label}</span>
                    <span className={`font-figures font-black text-[15px] leading-none ${plazo === p.value ? 'text-[#00DB8E]' : 'text-[#3B82F6]'}`}>
                      {TASAS[p.value]} %
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Periodicidad */}
            <div>
              <label className="block text-[11px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2.5">Cobro de rendimientos</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {PERIODICIDADES.map(p => (
                  <button
                    key={p.value}
                    onClick={() => setPeriodicidad(p.value)}
                    className={`flex flex-col items-center py-2.5 px-2 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
                      periodicidad === p.value
                        ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                        : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0A1F44]/30'
                    }`}
                  >
                    <span className="text-[12px] font-semibold leading-none">{p.value}</span>
                    <span className={`text-[9px] mt-1 ${periodicidad === p.value ? 'text-white/55' : 'text-gray-400'}`}>{p.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Renovación */}
            <div className="flex items-center gap-4 bg-[#F9FAFB] border border-[#F0F2F5] rounded-xl px-4 py-3">
              <div className="flex-1">
                <p className="text-[13px] font-semibold text-[#2A3036]">Renovación automática</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Al vencer, renueva por el mismo plazo con la tasa vigente</p>
              </div>
              <button
                onClick={() => setRenovacion(!renovacion)}
                className={`w-11 h-6 rounded-full transition-all duration-200 cursor-pointer flex-shrink-0 relative ${renovacion ? 'bg-[#00DB8E]' : 'bg-[#E8ECF2]'}`}
              >
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${renovacion ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {/* Código de referido */}
            <div>
              {!codigoAplicado ? (
                <>
                  <button
                    onClick={() => setCodigoOpen(!codigoOpen)}
                    className="flex items-center gap-1.5 text-[12px] font-semibold text-[#3B82F6] hover:underline cursor-pointer"
                  >
                    <svg className={`w-3.5 h-3.5 transition-transform ${codigoOpen ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                    {codigoOpen ? 'Cancelar' : '¿Tienes código de referido?'}
                  </button>
                  {codigoOpen && (
                    <div className="mt-3 flex gap-2">
                      <input
                        type="text"
                        value={codigoRef}
                        onChange={e => { setCodigoRef(e.target.value.toUpperCase()); setCodigoErr('') }}
                        placeholder="Ej. AB4589R"
                        maxLength={8}
                        className={`flex-1 border-2 rounded-xl px-3 py-2.5 font-figures font-bold text-[14px] text-[#2A3036] outline-none tracking-widest transition-colors ${codigoErr ? 'border-[#EF4444] bg-[#FEF2F2]' : 'border-[#E8ECF2] focus:border-[#3B82F6]'}`}
                      />
                      <button
                        onClick={handleAplicarCodigo}
                        disabled={!codigoRef.trim()}
                        className="bg-[#0A1F44] text-white text-[12px] font-bold px-4 py-2.5 rounded-xl hover:bg-[#06005A] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        Aplicar
                      </button>
                    </div>
                  )}
                  {codigoErr && <p className="text-[11px] text-red-500 mt-1.5">{codigoErr}</p>}
                </>
              ) : (
                <div className="flex items-center gap-2.5 bg-[#EFFFF7] border border-[#00DB8E]/30 rounded-xl px-4 py-2.5">
                  <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                    <svg className="w-3 h-3 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-[12px] font-bold text-[#005E3C]">Código de referido aplicado: <span className="font-figures tracking-widest">{codigoRef}</span></p>
                    <p className="text-[11px] text-[#005E3C]/70">+0,30 % E.A. adicional incluido en tu simulación</p>
                  </div>
                  <button onClick={() => { setCodigoAplicado(false); setCodigoRef(''); setCodigoOpen(false) }} className="text-[#005E3C]/50 hover:text-[#EF4444] cursor-pointer">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Result card */}
          {activo && (
            <div className="relative overflow-hidden" style={{ background: 'linear-gradient(145deg, #06005A 0%, #0A1F44 100%)' }}>
              {/* Decorations */}
              <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-[#3B82F6]/[0.08] pointer-events-none" />
              <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-[#00DB8E]/[0.06] pointer-events-none" />
              <div className="absolute bottom-0 right-0 w-52 h-28 opacity-[0.06] pointer-events-none overflow-hidden">
                <svg viewBox="0 0 200 100" fill="none" className="w-full h-full">
                  <polyline points="0,85 50,62 100,44 150,28 200,14" stroke="#00DB8E" strokeWidth="2" strokeLinecap="round" />
                  <polyline points="0,95 50,82 100,72 150,60 200,46" stroke="#3B82F6" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="4 3" />
                </svg>
              </div>

              <div className="relative z-10 px-6 pt-5 pb-6 space-y-4">
                {/* Rate header */}
                <div className="flex items-center justify-between">
                  <p className="text-white/40 text-[10px] font-bold tracking-[0.2em] uppercase">Simulación estimada</p>
                  <div className="flex items-center gap-2">
                    {codigoAplicado && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/10 text-white/60 font-figures line-through">{tasa} %</span>
                    )}
                    <span className="bg-[#00DB8E] text-[#005E3C] text-[13px] font-black px-3 py-1 rounded-full font-figures shadow-sm">
                      {tasaDisplay} % E.A.
                    </span>
                  </div>
                </div>

                {/* Capital + Rendimientos brutos */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-white/40 text-[10px] uppercase tracking-wide mb-1">Capital</p>
                    <p className="font-figures font-black text-white leading-none" style={{ fontSize: 'clamp(18px, 4vw, 24px)' }}>{formatPesos(montoNum)}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-[10px] uppercase tracking-wide mb-1">Rendimientos brutos</p>
                    <p className="font-figures font-black text-[#00D09C] leading-none" style={{ fontSize: 'clamp(18px, 4vw, 24px)' }}>
                      {formatPesos(animBrutos)}
                    </p>
                  </div>
                </div>

                {/* Breakdown */}
                <div className="bg-white/[0.06] border border-white/10 rounded-2xl px-4 py-3 space-y-2">
                  {codigoAplicado && (
                    <div className="flex justify-between text-[12px]">
                      <span className="text-white/50">Bono código referido</span>
                      <span className="font-figures text-[#00DB8E] font-semibold">+{formatPesos(bonoCodigo)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-[12px]">
                    <span className="text-white/50">Retención en la fuente (4 %)</span>
                    <span className="font-figures text-red-300 font-semibold">— {formatPesos(retencion)}</span>
                  </div>
                  <div className="flex justify-between text-[13px] font-semibold pt-1 border-t border-white/10">
                    <span className="text-white/75">Rendimientos netos</span>
                    <span className="font-figures text-[#00D09C]">{formatPesos(animNetos)}</span>
                  </div>
                  <div className="flex justify-between text-[15px] font-bold pt-2 border-t border-white/10">
                    <span className="text-white">Total a recibir</span>
                    <span className="font-figures text-white">{formatPesos(animTotal)}</span>
                  </div>
                </div>

                {/* Dates */}
                <div className="flex items-center justify-between text-[11px]">
                  <div>
                    <p className="text-white/30 uppercase tracking-wide text-[9px]">Inicio</p>
                    <p className="font-figures text-white/60 font-semibold mt-0.5">{fechaApertura}</p>
                  </div>
                  <div className="flex-1 mx-3">
                    <div className="h-px bg-gradient-to-r from-white/15 via-[#00DB8E]/40 to-white/15" />
                    <p className="text-center text-white/25 text-[9px] mt-1">{PLAZOS.find(p => p.value === plazo)?.label}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/30 uppercase tracking-wide text-[9px]">Vencimiento</p>
                    <p className="font-figures text-white/60 font-semibold mt-0.5">{fechaVencimiento}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CTA */}
          <div className="px-6 py-5">
            <button
              disabled={!activo}
              onClick={() => { if (validarMonto()) setPaso(2) }}
              className="w-full flex items-center justify-center gap-2 bg-[#00DB8E] text-[#06005A] font-black text-[15px] py-3.5 rounded-2xl hover:bg-[#00c47f] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
            >
              Continuar
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
            </button>
          </div>
        </div>
      )}

      {/* ── Paso 2 — Reglamento ── */}
      {paso === 2 && (
        <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden">
          <div className="px-6 pt-6 pb-5 space-y-5">
            <div>
              <p className="font-bold text-[17px] text-[#2A3036]">Información legal</p>
              <p className="text-[13px] text-gray-500 mt-0.5">Descarga y lee los documentos antes de firmar tu CDT.</p>
            </div>

            <div className="space-y-2.5">
              {REGLAMENTOS.map(r => (
                <div key={r.id} className="flex items-center gap-3 rounded-2xl border border-[#E8ECF2] overflow-hidden transition-all hover:shadow-sm">
                  <div className="w-1.5 self-stretch flex-shrink-0" style={{ background: r.color }} />
                  <div className="flex items-center gap-3 flex-1 py-3 pr-3">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${r.color}18` }}>
                      {descargados.has(r.id)
                        ? <svg className="w-4 h-4 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                        : <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8} style={{ color: r.color }}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[13px] text-[#2A3036] leading-tight">{r.titulo}</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">{r.desc}</p>
                    </div>
                    <button
                      onClick={() => handleDescargar(r.id)}
                      disabled={descargando === r.id}
                      className={`flex items-center gap-1.5 text-[12px] font-bold px-3 py-1.5 rounded-xl transition-colors cursor-pointer flex-shrink-0 ${
                        descargados.has(r.id)
                          ? 'text-[#005E3C] bg-[#EFFFF7]'
                          : 'text-white hover:opacity-90'
                      }`}
                      style={descargados.has(r.id) ? {} : { background: r.color }}
                    >
                      {descargando === r.id
                        ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        : descargados.has(r.id)
                          ? <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>Listo</>
                          : <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>PDF</>
                      }
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <label className="flex items-start gap-3 cursor-pointer bg-[#F9FAFB] border border-[#F0F2F5] rounded-xl px-4 py-3">
              <input
                type="checkbox"
                checked={aceptoReglamento}
                onChange={e => setAceptoReglamento(e.target.checked)}
                className="mt-0.5 accent-[#00DB8E] w-4 h-4 cursor-pointer flex-shrink-0"
              />
              <span className="text-[13px] text-gray-600 leading-snug">
                He leído y acepto el reglamento, las condiciones del CDT y la política de retención en la fuente.
              </span>
            </label>

            <button
              disabled={!aceptoReglamento}
              onClick={() => setFirmaOpen(true)}
              className="w-full flex items-center justify-center gap-2 bg-[#0A1F44] text-white font-bold text-[14px] py-3.5 rounded-2xl hover:bg-[#06005A] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
              Firmar y continuar
            </button>
          </div>
        </div>
      )}

      {/* ── Paso 3 — Pago ── */}
      {paso === 3 && (
        <div className="bg-white rounded-3xl border border-[#E8ECF2] p-6">
          <MediosDePago
            modo="apertura"
            monto={montoNum}
            onExito={() => setPaso(4)}
            onVolver={() => setPaso(2)}
          />
        </div>
      )}

      {/* ── Paso 4 — Confirmación / Certificado ── */}
      {paso === 4 && (
        <div className="space-y-5">
          {/* Celebration header */}
          <div className="bg-white rounded-3xl border border-[#E8ECF2] px-6 py-8 text-center space-y-3">
            <div className="relative inline-flex items-center justify-center">
              <div className="w-20 h-20 rounded-full bg-[#EFFFF7] flex items-center justify-center">
                <svg className="w-10 h-10 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-[#00DB8E] flex items-center justify-center">
                <svg className="w-3 h-3 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
            </div>
            <div>
              <p className="font-black text-[22px] text-[#2A3036]">¡Tu CDT está activo!</p>
              <p className="text-[14px] text-gray-500 mt-1.5 leading-relaxed">
                Recibirás la confirmación en <span className="font-semibold text-[#2A3036]">{clienteNatural.correoMascarado}</span> con todos los detalles.
              </p>
            </div>
          </div>

          {/* CDT Certificate */}
          <div className="relative rounded-3xl overflow-hidden shadow-xl" style={{ background: 'linear-gradient(145deg, #0A1F44 0%, #06005A 100%)' }}>
            <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-[#3B82F6]/[0.07] pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-[#00DB8E]/[0.05] pointer-events-none" />
            <div className="absolute top-1/2 right-1/3 w-24 h-24 rounded-full bg-[#3B82F6]/[0.04] pointer-events-none" />
            {/* Grid watermark */}
            <div className="absolute inset-0 opacity-[0.025] pointer-events-none"
              style={{ backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

            {/* Header */}
            <div className="relative px-6 pt-6 pb-5 border-b border-white/10">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-white/30 text-[9px] font-bold tracking-[0.28em] uppercase">Certificado de Depósito a Término</p>
                  <p className="text-white font-black text-[20px] mt-0.5 leading-tight">CDT Digital KOA</p>
                </div>
                <div className="text-right">
                  <p className="text-white/25 text-[9px] tracking-widest uppercase">N° Certificado</p>
                  <p className="font-figures text-[#00DB8E]/80 font-black text-[13px] tracking-widest mt-0.5">{cdtNumero}</p>
                </div>
              </div>
            </div>

            {/* Titular */}
            <div className="relative px-6 pt-4 pb-3 border-b border-white/08">
              <p className="text-white/25 text-[9px] tracking-widest uppercase mb-1">Titular</p>
              <p className="text-white font-bold text-[16px]">{clienteNatural.nombre}</p>
            </div>

            {/* Key terms */}
            <div className="relative px-6 py-5">
              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Capital invertido</p>
                  <p className="font-figures font-black text-white leading-none" style={{ fontSize: 'clamp(18px, 4vw, 22px)' }}>{formatPesos(montoNum)}</p>
                </div>
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Tasa efectiva anual</p>
                  <p className="font-figures font-black text-[#00DB8E] leading-none" style={{ fontSize: 'clamp(18px, 4vw, 22px)' }}>{tasaDisplay} %</p>
                </div>
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Fecha de apertura</p>
                  <p className="font-figures font-bold text-white text-[14px]">{fechaApertura}</p>
                </div>
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Fecha de vencimiento</p>
                  <p className="font-figures font-bold text-white text-[14px]">{fechaVencimiento}</p>
                </div>
                <div>
                  <p className="text-white/30 text-[9px] tracking-widests uppercase mb-1">Periodicidad</p>
                  <p className="font-semibold text-white/80 text-[13px]">{periodicidad}</p>
                </div>
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Renovación</p>
                  <p className="font-semibold text-white/80 text-[13px]">{renovacion ? 'Automática' : 'Manual'}</p>
                </div>
              </div>
            </div>

            {/* Footer — rendimientos */}
            <div className="relative px-6 py-4 bg-[#00DB8E]/[0.08] border-t border-white/10">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Rendimientos netos estimados</p>
                  <p className="font-figures font-black text-[#00DB8E] text-[20px] leading-none">+{formatPesos(rendimientosNetos)}</p>
                </div>
                <div className="text-right">
                  <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Total a recibir</p>
                  <p className="font-figures font-bold text-white text-[15px] leading-none">{formatPesos(totalARecibir)}</p>
                </div>
              </div>
              <p className="text-white/20 text-[9px] mt-3 leading-snug">
                Rendimientos estimados con tasa vigente hoy. Sujetos a cambios en la tasa al momento del pago. Retención en la fuente aplicada (4%).
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/cdt')}
              className="flex-1 flex items-center justify-center gap-2 bg-[#00DB8E] text-[#06005A] font-black text-[14px] py-3.5 rounded-2xl hover:bg-[#00c47f] transition-colors cursor-pointer"
            >
              Ver mis CDT
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
            </button>
            <button
              onClick={() => {}}
              className="flex items-center justify-center gap-1.5 bg-white border-2 border-[#E8ECF2] text-[#2A3036] font-semibold text-[13px] px-4 py-3.5 rounded-2xl hover:border-[#0A1F44]/30 transition-colors cursor-pointer"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
              Descargar
            </button>
          </div>
        </div>
      )}

      <FirmaElectronica
        open={firmaOpen}
        operacion="abrir-cdt"
        subtitulo={`${formatPesos(montoNum)} · ${PLAZOS.find(p => p.value === plazo)?.label} · ${tasaDisplay} % E.A.`}
        onSuccess={handleFirmaSuccess}
        onClose={() => setFirmaOpen(false)}
      />
    </div>
  )
}
