import { useState, useEffect } from 'react'
import { useDemoContext } from '../context/DemoContext'
import SectionHeader from '../components/SectionHeader'
import Btn from '../components/Btn'
import LoadingSkeleton from '../components/LoadingSkeleton'

function CheckIcon() {
  return <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
}
function DotAmberIcon() {
  return <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#F59E0B] flex-shrink-0 mt-0.5" />
}
function ChevronDown({ open }: { open: boolean }) {
  return (
    <svg className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
    </svg>
  )
}

interface AcordeonProps {
  title: string
  complete: boolean
  id: string
  defaultOpen?: boolean
  children: React.ReactNode
}

function Acordeon({ title, complete, id, defaultOpen = false, children }: AcordeonProps) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div id={id} className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-gray-50 transition-colors cursor-pointer"
        onClick={() => setOpen(!open)}
      >
        <div className="flex items-center gap-2">
          <span className="font-semibold text-[15px] text-[#2A3036]">{title}</span>
        </div>
        <div className="flex items-center gap-2">
          {complete ? <CheckIcon /> : <DotAmberIcon />}
          <ChevronDown open={open} />
        </div>
      </button>
      {open && (
        <div className="border-t border-[#E5E7EB] px-5 py-5">
          {children}
        </div>
      )}
    </div>
  )
}

function Field({ label, value, readonly = false, onChange }: {
  label: string; value: string; readonly?: boolean; onChange?: (v: string) => void
}) {
  return (
    <div>
      <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">{label}</label>
      {readonly ? (
        <div className="bg-gray-100 border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-gray-500 select-none cursor-not-allowed">
          {value}
        </div>
      ) : (
        <input
          type="text"
          value={value}
          onChange={e => onChange?.(e.target.value)}
          className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] focus:ring-1 focus:ring-[#00DB8E]/30 transition-colors bg-white"
        />
      )}
    </div>
  )
}

function Toggle({ label, checked, locked, onChange }: {
  label: string; checked: boolean; locked?: boolean; onChange?: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className={`text-[14px] ${locked ? 'text-gray-400' : 'text-[#2A3036]'}`}>{label}</span>
      <button
        disabled={locked}
        onClick={() => onChange?.(!checked)}
        className={`relative w-10 h-6 rounded-full transition-colors duration-200 flex-shrink-0 ${checked ? 'bg-[#00DB8E]' : 'bg-gray-200'} ${locked ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
      >
        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${checked ? 'translate-x-4' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}

function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  useState(() => {
    const t = setTimeout(onDone, 3000)
    return () => clearTimeout(t)
  })
  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#0A1F44] text-white px-5 py-3 rounded-xl shadow-lg text-[14px] font-medium z-50 flex items-center gap-2">
      <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
      {msg}
    </div>
  )
}

export default function MisDatos() {
  const { personType } = useDemoContext()

  // Editable state
  const [correo, setCorreo] = useState('andres@correo.com')
  const [celular, setCelular] = useState('315 456 7890')
  const [ciudad, setCiudad] = useState('Bogotá D.C.')
  const [barrio, setBarrio] = useState('Chapinero')
  const [ingresos, setIngresos] = useState('4.500.000')
  const [declaraRenta, setDeclaraRenta] = useState(false)
  const [pepFuncionario, setPepFuncionario] = useState(false)
  const [pepRecursos, setPepRecursos] = useState(false)
  const [pepExpuesto, setPepExpuesto] = useState(false)
  const [pepFamiliar, setPepFamiliar] = useState(false)
  const [smsComercial, setSmsComercial] = useState(true)
  const [correoComercial, setCorreoComercial] = useState(true)
  const [waComercial, setWaComercial] = useState(false)
  const [estrato, setEstrato] = useState<number>(3)

  // Dirty tracking
  const [dirty, setDirty] = useState(false)
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const markDirty = (setter: (v: any) => void) => (v: any) => {
    setter(v)
    setDirty(true)
  }

  const [loading, setLoading] = useState(true)
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700)
    return () => clearTimeout(t)
  }, [])

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="space-y-1"><LoadingSkeleton className="h-8 w-36" /><LoadingSkeleton className="h-4 w-56" /></div>
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5 space-y-2">
          <LoadingSkeleton className="h-4 w-48" />
          <LoadingSkeleton className="h-3 w-full rounded-full" />
        </div>
        {[0,1,2,3].map(i => (
          <div key={i} className="bg-white rounded-2xl border border-[#E5E7EB] p-5">
            <div className="flex justify-between"><LoadingSkeleton className="h-5 w-40" /><LoadingSkeleton className="h-5 w-5 rounded-full" /></div>
          </div>
        ))}
      </div>
    )
  }

  const completeness: number = 80
  const completeColor = completeness >= 100 ? 'bg-[#00DB8E]' : 'bg-[#0A1F44]'

  const scrollToBlock = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5 pb-24">
      <SectionHeader title="Mis datos" subtitle="Mantén tu información actualizada" />

      {/* Completeness bar */}
      <div className="bg-white rounded-2xl border border-[#E5E7EB] px-5 py-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[14px] font-semibold text-[#2A3036]">
            {completeness >= 100 ? 'Perfil al día' : `Perfil completo al ${completeness} %`}
          </p>
          {completeness < 100 && (
            <button
              onClick={() => scrollToBlock('bloque-financiera')}
              className="text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer"
            >
              Completar información financiera
            </button>
          )}
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${completeColor}`}
            style={{ width: `${completeness}%` }}
          />
        </div>
      </div>

      {personType === 'natural' ? (
        <div className="grid grid-cols-1 gap-4">
          {/* Datos de perfil */}
          <Acordeon title="Datos de perfil" complete={true} id="bloque-perfil" defaultOpen={true}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Nombres" value="Andrés Ricardo" readonly />
              <Field label="Apellidos" value="Beltrán Sarta" readonly />
              <Field label="Tipo de documento" value="Cédula de ciudadanía" readonly />
              <Field label="Número de documento" value="1.030.456.789" readonly />
              <Field label="Correo electrónico" value={correo} onChange={markDirty(setCorreo)} />
              <Field label="Celular" value={celular} onChange={markDirty(setCelular)} />
            </div>
          </Acordeon>

          {/* Datos de residencia */}
          <Acordeon title="Datos de residencia" complete={true} id="bloque-residencia">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Departamento" value="Cundinamarca" readonly />
              <Field label="Ciudad" value={ciudad} onChange={markDirty(setCiudad)} />
              <Field label="Barrio" value={barrio} onChange={markDirty(setBarrio)} />
            </div>
            <div className="mt-4">
              <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-2">Estrato</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5, 6].map(e => (
                  <button
                    key={e}
                    onClick={() => { setEstrato(e); setDirty(true) }}
                    className={`w-10 h-10 rounded-xl border text-[14px] font-bold transition-colors cursor-pointer ${
                      estrato === e
                        ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                        : 'bg-white border-[#E5E7EB] text-gray-600 hover:border-[#0A1F44]/40'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          </Acordeon>

          {/* Información financiera */}
          <Acordeon title="Información financiera" complete={false} id="bloque-financiera">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Origen de fondos" value="Salario" onChange={markDirty(() => {})} />
              <Field label="Ingresos mensuales" value={ingresos} onChange={markDirty(setIngresos)} />
              <Field label="Egresos mensuales" value="2.200.000" onChange={markDirty(() => {})} />
              <Field label="Activos totales" value="85.000.000" onChange={markDirty(() => {})} />
              <Field label="Pasivos totales" value="22.000.000" onChange={markDirty(() => {})} />
            </div>
            <div className="mt-4">
              <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-2">¿Declaras renta?</p>
              <div className="flex gap-3">
                {[true, false].map((val) => (
                  <button
                    key={String(val)}
                    onClick={() => { setDeclaraRenta(val); setDirty(true) }}
                    className={`px-4 py-2 rounded-xl border text-[14px] font-semibold transition-colors cursor-pointer ${
                      declaraRenta === val
                        ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                        : 'bg-white border-[#E5E7EB] text-gray-600 hover:border-[#0A1F44]/40'
                    }`}
                  >
                    {val ? 'Sí' : 'No'}
                  </button>
                ))}
              </div>
            </div>
          </Acordeon>

          {/* Datos profesionales */}
          <Acordeon title="Datos profesionales" complete={true} id="bloque-profesional">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Nivel educativo</label>
                <select className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Universitario</option>
                  <option>Posgrado</option>
                  <option>Técnico</option>
                  <option>Bachillerato</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Ocupación</label>
                <select className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Empleado</option>
                  <option>Independiente</option>
                  <option>Pensionado</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Actividad económica</label>
                <select className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Educación</option>
                  <option>Salud</option>
                  <option>Comercio</option>
                  <option>Servicios</option>
                </select>
              </div>
            </div>
          </Acordeon>

          {/* Exposición política PEP */}
          <Acordeon title="Exposición política (PEP)" complete={true} id="bloque-pep">
            <div className="space-y-3">
              {[
                { label: '¿Eres funcionario público?', val: pepFuncionario, set: setPepFuncionario },
                { label: '¿Administras recursos públicos?', val: pepRecursos, set: setPepRecursos },
                { label: '¿Eres una persona expuesta políticamente?', val: pepExpuesto, set: setPepExpuesto },
              ].map(({ label, val, set }) => (
                <div key={label} className="flex items-center justify-between py-1">
                  <span className="text-[14px] text-[#2A3036]">{label}</span>
                  <div className="flex gap-3">
                    {[true, false].map(v => (
                      <button
                        key={String(v)}
                        onClick={() => { set(v); setDirty(true) }}
                        className={`px-3 py-1.5 rounded-xl border text-[13px] font-semibold transition-colors cursor-pointer ${
                          val === v
                            ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                            : 'bg-white border-[#E5E7EB] text-gray-500 hover:border-[#0A1F44]/40'
                        }`}
                      >
                        {v ? 'Sí' : 'No'}
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div>
                <div className="flex items-center justify-between py-1">
                  <span className="text-[14px] text-[#2A3036]">¿Tienes familiares PEP?</span>
                  <div className="flex gap-3">
                    {[true, false].map(v => (
                      <button
                        key={String(v)}
                        onClick={() => { setPepFamiliar(v); setDirty(true) }}
                        className={`px-3 py-1.5 rounded-xl border text-[13px] font-semibold transition-colors cursor-pointer ${
                          pepFamiliar === v
                            ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                            : 'bg-white border-[#E5E7EB] text-gray-500 hover:border-[#0A1F44]/40'
                        }`}
                      >
                        {v ? 'Sí' : 'No'}
                      </button>
                    ))}
                  </div>
                </div>
                {pepFamiliar && (
                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3 pl-2 border-l-2 border-[#F59E0B]/40">
                    <Field label="Vínculo" value="" onChange={() => setDirty(true)} />
                    <Field label="Nombre" value="" onChange={() => setDirty(true)} />
                    <Field label="Apellido" value="" onChange={() => setDirty(true)} />
                  </div>
                )}
              </div>
            </div>
          </Acordeon>

          {/* Notificaciones */}
          <Acordeon title="Notificaciones y alertas" complete={true} id="bloque-notificaciones">
            <div className="space-y-4">
              <div>
                <p className="text-[13px] font-semibold text-[#2A3036] mb-1">Seguridad y alertas</p>
                <p className="text-[12px] text-gray-400 mb-3">Obligatorias para la seguridad de tus productos</p>
                <Toggle label="SMS" checked={true} locked />
                <Toggle label="Correo electrónico" checked={true} locked />
                <Toggle label="WhatsApp" checked={true} locked />
              </div>
              <div className="border-t border-[#E5E7EB] pt-4">
                <p className="text-[13px] font-semibold text-[#2A3036] mb-3">Comerciales</p>
                <Toggle label="SMS" checked={smsComercial} onChange={v => { setSmsComercial(v); setDirty(true) }} />
                <Toggle label="Correo electrónico" checked={correoComercial} onChange={v => { setCorreoComercial(v); setDirty(true) }} />
                <Toggle label="WhatsApp" checked={waComercial} onChange={v => { setWaComercial(v); setDirty(true) }} />
              </div>
            </div>
          </Acordeon>
        </div>
      ) : (
        /* Jurídica */
        <div className="grid grid-cols-1 gap-4">
          <Acordeon title="Datos del representante legal" complete={true} id="bloque-rep" defaultOpen>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Nombres" value="Carlos Alberto" onChange={markDirty(() => {})} />
              <Field label="Apellidos" value="Sánchez Rojas" onChange={markDirty(() => {})} />
              <Field label="Tipo de documento" value="Cédula de ciudadanía" readonly />
              <Field label="Número de documento" value="79.456.123" readonly />
            </div>
          </Acordeon>
          <Acordeon title="Información de la empresa" complete={true} id="bloque-empresa">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Razón social" value="Comercializadora Andina S.A.S." readonly />
              <Field label="NIT" value="900.123.456-7" readonly />
              <Field label="Correo electrónico" value="contacto@andina.com" readonly />
              <Field label="Celular" value="601 456 7890" readonly />
            </div>
          </Acordeon>
          <Acordeon title="Notificaciones y alertas" complete={true} id="bloque-notif-jur">
            <Toggle label="Correo electrónico" checked={correoComercial} onChange={v => { setCorreoComercial(v); setDirty(true) }} />
            <Toggle label="SMS" checked={smsComercial} onChange={v => { setSmsComercial(v); setDirty(true) }} />
          </Acordeon>
        </div>
      )}

      {/* Save bar */}
      {dirty && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#E5E7EB] px-6 py-4 z-40 flex items-center justify-between gap-4 shadow-lg">
          <p className="text-[14px] text-gray-600 font-medium">Tienes cambios sin guardar</p>
          <div className="flex gap-3">
            <Btn variant="ghost" size="md" onClick={() => setDirty(false)}>Descartar</Btn>
            <Btn variant="primary" size="md" onClick={() => setConfirmOpen(true)}>Guardar cambios</Btn>
          </div>
        </div>
      )}

      {/* Confirm dialog */}
      {confirmOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h3 className="font-bold text-[18px] text-[#2A3036] mb-4">Confirma tus cambios</h3>
            <div className="bg-gray-50 rounded-xl divide-y divide-[#E5E7EB] mb-4">
              <div className="flex justify-between px-4 py-3 text-[13px]">
                <span className="text-gray-500">Correo electrónico</span>
                <span className="text-gray-400 font-figures">andres@correo.com <span className="text-[#00DB8E]">→</span> {correo}</span>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <Btn variant="ghost" size="md" onClick={() => setConfirmOpen(false)}>Volver</Btn>
              <Btn variant="primary" size="md" onClick={() => {
                setConfirmOpen(false)
                setDirty(false)
                setToast('Tu información fue actualizada')
              }}>
                Confirmar
              </Btn>
            </div>
          </div>
        </div>
      )}

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  )
}
