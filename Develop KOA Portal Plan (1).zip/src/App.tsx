import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { DemoProvider, useDemoContext, type PersonType } from './context/DemoContext'
import { AuthProvider } from './context/AuthContext'
import TopNav from './components/TopNav'
import BottomNav from './components/BottomNav'
import DemoSelector from './components/DemoSelector'
import Home from './pages/Home'
import Libranza from './pages/Libranza'
import LibranzaDetalle from './pages/LibranzaDetalle'
import MisDatos from './pages/MisDatos'
import CDT from './pages/CDT'
import CDTDetalle from './pages/CDTDetalle'
import CDTAbrir from './pages/CDTAbrir'
import MediosDePago from './pages/MediosDePago'
import LibranzaGuard from './components/LibranzaGuard'
import Seguridad from './pages/Seguridad'
import Contactanos from './pages/Contactanos'
import EducacionFinanciera from './pages/EducacionFinanciera'
import Login from './pages/Login'

function TrustFooter() {
  return (
    <div className="border-t border-[#E8ECF2] mt-10" style={{ background: 'rgba(255,255,255,0.8)' }}>
      <div className="max-w-5xl mx-auto px-5 sm:px-6 py-6 sm:py-8">

        {/* 2-col grid on mobile → flex row on desktop */}
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-x-4 gap-y-0 sm:gap-0">

          {/* SFC */}
          <div className="flex flex-row items-center gap-3 sm:gap-5 sm:pr-12 sm:border-r sm:border-[#E8ECF2] sm:mr-12 py-3 sm:py-0">
            <img
              src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/SFC_Color.png"
              alt="Vigilado Superintendencia Financiera de Colombia"
              className="w-auto object-contain flex-shrink-0 h-12 sm:h-20"
            />
            <div>
              <p className="text-[11px] font-bold text-[#2A3036] leading-tight">Vigilado</p>
              <p className="text-[10px] text-gray-500 leading-snug mt-0.5">
                Superintendencia Financiera de Colombia
              </p>
            </div>
          </div>

          {/* Fogafin */}
          <div className="flex flex-row items-center gap-3 sm:gap-5 border-l sm:border-l-0 border-[#E8ECF2] pl-4 sm:pl-0 py-3 sm:py-0">
            <img
              src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-fogafin.png"
              alt="Fogafin — Seguridad para tu dinero"
              className="w-auto object-contain flex-shrink-0 h-9 sm:h-14"
            />
            <div className="hidden sm:block">
              <p className="text-[11px] font-bold text-[#2A3036] leading-tight">Respaldado por</p>
              <p className="text-[10px] text-gray-500 leading-snug mt-0.5">
                Fondo de Garantías de Instituciones Financieras
              </p>
            </div>
          </div>

          {/* Copyright — full-width below on mobile, right-aligned on desktop */}
          <div className="col-span-2 sm:col-auto sm:flex-1 sm:flex sm:items-center sm:justify-end border-t sm:border-t-0 border-[#E8ECF2] pt-4 sm:pt-0 text-center sm:text-right">
            <p className="text-[10px] text-gray-400 leading-relaxed">
              © 2026 KOA C.F. Compañía de Financiamiento S.A.<br />
              Todos los derechos reservados · Colombia
            </p>
          </div>

        </div>
      </div>
    </div>
  )
}

function Layout() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F7F7F7]">
      <TopNav />
      <main className="flex-1 overflow-y-auto scrollable pb-20 md:pb-0">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-7">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/libranza" element={<LibranzaGuard><Libranza /></LibranzaGuard>} />
            <Route path="/libranza/credito/:id" element={<LibranzaGuard><LibranzaDetalle /></LibranzaGuard>} />
            <Route path="/cdt" element={<CDT />} />
            <Route path="/cdt/abrir" element={<CDTAbrir />} />
            <Route path="/cdt/:id" element={<CDTDetalle />} />
            <Route path="/cdt/:id/medios-de-pago" element={<MediosDePago modo="apertura" monto={5000000} />} />
            <Route path="/mis-datos" element={<MisDatos />} />
            <Route path="/seguridad" element={<Seguridad />} />
            <Route path="/contactanos" element={<Contactanos />} />
            <Route path="/educacion-financiera" element={<EducacionFinanciera />} />
          </Routes>
        </div>
        <TrustFooter />
      </main>
      <BottomNav />
      <DemoSelector />
    </div>
  )
}

function AppContent() {
  const { setPersonType } = useDemoContext()
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  function handleLogin(pt: PersonType) {
    setPersonType(pt)
    setIsLoggedIn(true)
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <AuthProvider onLogout={() => setIsLoggedIn(false)}>
      <Layout />
    </AuthProvider>
  )
}

export default function App() {
  return (
    <DemoProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </DemoProvider>
  )
}
