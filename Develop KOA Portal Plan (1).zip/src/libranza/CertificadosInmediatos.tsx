import { useState } from 'react'

const certificados = [
  {
    id: 'carta',
    nombre: 'Carta de condiciones',
    descripcion: 'Condiciones financieras vigentes de tu crédito',
    iconBg: '#06005A',
    iconAccent: '#00DB8E',
  },
  {
    id: 'plan',
    nombre: 'Plan de pagos',
    descripcion: 'Detalle de todas tus cuotas programadas',
    iconBg: '#0E4D8A',
    iconAccent: '#60B8FF',
  },
  {
    id: 'amort',
    nombre: 'Amortización',
    descripcion: 'Distribución de capital e intereses por cuota',
    iconBg: '#0D4A30',
    iconAccent: '#00DB8E',
  },
]

function DocIcon({ color = '#00DB8E' }) {
  return (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={color} strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  )
}

function DownloadIcon({ className = 'w-3.5 h-3.5' }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
  )
}

function Spinner() {
  return (
    <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin" />
  )
}

function getCurrentMonths() {
  const meses = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC']
  const now = new Date(2026, 7, 1)
  const result = []
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    result.push({ mes: meses[d.getMonth()], año: d.getFullYear(), key: `${meses[d.getMonth()]}-${d.getFullYear()}` })
  }
  return result
}

interface CertificadosInmediatosProps {
  onToast: (msg: string) => void
}

export default function CertificadosInmediatos({ onToast }: CertificadosInmediatosProps) {
  const [loadingId, setLoadingId] = useState<string | null>(null)
  const [selectedMes, setSelectedMes] = useState<string | null>(null)
  const [loadingExtracto, setLoadingExtracto] = useState(false)

  const meses = getCurrentMonths()

  const handleDownload = (id: string) => {
    setLoadingId(id)
    setTimeout(() => {
      setLoadingId(null)
      onToast('Certificado descargado')
    }, 1100)
  }

  const handleExtracto = () => {
    setLoadingExtracto(true)
    setTimeout(() => {
      setLoadingExtracto(false)
      onToast('Extracto descargado')
    }, 1100)
  }

  return (
    <div className="space-y-6">

      {/* ── Descarga inmediata ── */}
      <div>
        <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-3">
          Descarga inmediata
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {certificados.map((cert) => {
            const isLoading = loadingId === cert.id
            return (
              <div
                key={cert.id}
                className="rounded-2xl border border-[#E8ECF2] overflow-hidden flex flex-col hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 bg-white"
              >
                {/* Colored top band */}
                <div
                  className="px-4 pt-4 pb-3.5 flex items-center gap-3"
                  style={{ background: cert.iconBg }}
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(255,255,255,0.12)' }}
                  >
                    <DocIcon color={cert.iconAccent} />
                  </div>
                  {/* Mini doc lines decoration */}
                  <div className="flex-1 space-y-1.5 opacity-25">
                    <div className="h-1.5 rounded-full bg-white w-full" />
                    <div className="h-1.5 rounded-full bg-white w-3/4" />
                    <div className="h-1.5 rounded-full bg-white w-1/2" />
                  </div>
                </div>

                {/* Body */}
                <div className="flex-1 px-4 pt-3.5 pb-2">
                  <p className="font-bold text-[#2A3036] text-[14px] leading-tight mb-1">{cert.nombre}</p>
                  <p className="text-[12px] text-gray-400 leading-snug">{cert.descripcion}</p>
                </div>

                {/* Download button */}
                <div className="px-4 pb-4">
                  <button
                    onClick={() => handleDownload(cert.id)}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] font-bold transition-all cursor-pointer"
                    style={{
                      background: isLoading ? '#F0F0F0' : cert.iconBg,
                      color: isLoading ? '#9CA3AF' : 'white',
                    }}
                  >
                    {isLoading ? <><Spinner /> Descargando…</> : <><DownloadIcon /> Descargar</>}
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* ── Extracto mensual ── */}
      <div>
        <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-3">
          Extracto mensual
        </p>
        <div className="bg-[#F7F8FA] rounded-2xl p-4">
          <p className="text-[13px] text-gray-500 mb-3 leading-snug">
            Selecciona el mes y descarga el movimiento detallado de tu crédito.
          </p>

          {/* Month pills — horizontal scroll on mobile */}
          <div className="flex gap-2 overflow-x-auto pb-1 mb-4 scrollable -mx-1 px-1">
            {meses.map((m) => {
              const sel = selectedMes === m.key
              return (
                <button
                  key={m.key}
                  onClick={() => setSelectedMes(m.key)}
                  className={`flex-shrink-0 flex flex-col items-center px-3.5 py-2.5 rounded-xl border-2 transition-all duration-150 cursor-pointer min-w-[60px] ${
                    sel
                      ? 'bg-[#06005A] border-[#06005A] shadow-md shadow-[#06005A]/20'
                      : 'bg-white border-[#E8ECF2] hover:border-[#06005A]/40'
                  }`}
                >
                  <span className={`text-[10px] font-black tracking-widest uppercase leading-none ${sel ? 'text-[#00DB8E]' : 'text-gray-500'}`}>
                    {m.mes}
                  </span>
                  <span className={`font-figures text-[11px] font-semibold mt-1 leading-none ${sel ? 'text-white/70' : 'text-gray-400'}`}>
                    {m.año}
                  </span>
                </button>
              )
            })}
          </div>

          <button
            onClick={handleExtracto}
            disabled={!selectedMes || loadingExtracto}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[13px] font-bold transition-all cursor-pointer ${
              !selectedMes
                ? 'bg-[#F0F0F0] text-gray-400 cursor-not-allowed'
                : loadingExtracto
                  ? 'bg-[#06005A]/80 text-white cursor-wait'
                  : 'bg-[#06005A] text-white hover:bg-[#08007A] shadow-md shadow-[#06005A]/20'
            }`}
          >
            {loadingExtracto ? <><Spinner /> Descargando…</> : <><DownloadIcon className="w-4 h-4" /> Descargar extracto</>}
          </button>
        </div>
      </div>

    </div>
  )
}
