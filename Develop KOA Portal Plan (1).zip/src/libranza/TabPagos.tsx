import { useState } from 'react'
import { pagosCredito4821, formatPesos } from '../data/mockData'

const PAGE = 8

export default function TabPagos() {
  const [visible, setVisible] = useState(PAGE)
  const pagos = pagosCredito4821
  const shown = pagos.slice(0, visible)
  const exhausted = visible >= pagos.length

  // Group by year for section headers
  const groups: { year: number; items: typeof pagos }[] = []
  for (const p of shown) {
    const last = groups[groups.length - 1]
    if (!last || last.year !== p.año) groups.push({ year: p.año, items: [p] })
    else last.items.push(p)
  }

  return (
    <div>
      {groups.map((group) => (
        <div key={group.year}>
          {/* Year separator */}
          <div className="flex items-center gap-2.5 mb-2 mt-1 first:mt-0">
            <span className="text-[9px] font-black tracking-[0.2em] uppercase text-gray-300">{group.year}</span>
            <div className="flex-1 h-px bg-[#F0F2F5]" />
          </div>

          {/* Payment rows */}
          <div className="mb-3">
            {group.items.map((p, i) => (
              <div
                key={p.id}
                className="flex items-center gap-3 py-2.5 border-b border-[#F5F6F8] last:border-0 fade-in"
                style={{ animationDelay: `${i * 0.04}s` }}
              >
                {/* Green dot */}
                <div className="w-2 h-2 rounded-full bg-[#00DB8E] flex-shrink-0" />

                {/* Date */}
                <span className="font-figures text-[13px] text-gray-500 flex-1 min-w-0 truncate">
                  {p.fecha}
                </span>

                {/* Amount */}
                <span className="font-figures text-[14px] font-bold text-[#2A3036] flex-shrink-0">
                  {formatPesos(p.valor)}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Load more / end */}
      <div className="flex justify-center pt-1">
        {!exhausted ? (
          <button
            onClick={() => setVisible(v => v + PAGE)}
            className="text-[12px] font-bold text-[#005E3C] hover:underline cursor-pointer py-1.5"
          >
            Ver más pagos
          </button>
        ) : (
          <p className="text-[11px] text-gray-300 py-1.5 tracking-wide">Primer pago registrado</p>
        )}
      </div>
    </div>
  )
}
