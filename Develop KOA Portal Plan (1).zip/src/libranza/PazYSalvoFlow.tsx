import { useState, useEffect } from 'react'
import VerificacionStep from './VerificacionStep'
import { creditosTerminados, formatPesos } from '../data/mockData'

interface PazYSalvoFlowProps {
  onClose: () => void
}

type Paso = 1 | 2 | 'generando' | 3

const STEPS = ['Verificación', 'Selección', 'Certificado']

/* ── Generating animation ──────────────────────────────────── */
const GEN_STEPS = [
  'Validando crédito seleccionado…',
  'Consultando estado de obligaciones…',
  'Emitiendo certificado oficial…',
]

function GenerandoScreen() {
  const [phase, setPhase] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 900)
    const t2 = setTimeout(() => setPhase(2), 1900)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [])

  return (
    <div className="flex flex-col items-center justify-center gap-10 py-16">
      <div className="relative flex items-center justify-center">
        <div className="absolute w-28 h-28 rounded-full border-2 border-[#00DB8E]/20 animate-spin"
          style={{ animationDuration: '3s', borderTopColor: '#00DB8E' }} />
        <div className="absolute w-20 h-20 rounded-full border-2 border-white/10 animate-spin"
          style={{ animationDuration: '2s', animationDirection: 'reverse', borderBottomColor: 'rgba(255,255,255,0.2)' }} />
        <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-xl shadow-black/10">
          <img
            src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg"
            alt="KOA"
            className="h-7 w-auto"
            style={{ filter: 'invert(1) sepia(1) saturate(5) hue-rotate(185deg)' }}
          />
        </div>
      </div>

      <div className="space-y-3 w-full max-w-[240px]">
        {GEN_STEPS.map((s, i) => (
          <div key={i} className={`flex items-center gap-3 transition-all duration-500 ${i <= phase ? 'opacity-100' : 'opacity-25'}`}>
            <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
              i < phase ? 'bg-[#00DB8E]' : i === phase ? 'border-2 border-white/60 bg-white/10' : 'bg-white/10'
            }`}>
              {i < phase ? (
                <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              ) : i === phase ? (
                <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
              ) : null}
            </div>
            <p className={`text-[13px] transition-colors duration-300 ${
              i < phase ? 'text-[#00DB8E] font-semibold' : i === phase ? 'text-white font-bold' : 'text-white/30'
            }`}>{s}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── Certificate document ──────────────────────────────────── */
function Certificado({ creditoId }: { creditoId: string }) {
  const credito = creditosTerminados.find(c => c.id === creditoId)
  const today = new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'long', year: 'numeric' })
    .format(new Date(2026, 7, 14))

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden shadow-lg max-w-md mx-auto">
      {/* Header */}
      <div className="bg-[#06005A] px-7 py-5">
        <div className="flex items-center gap-3 mb-4">
          <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg" alt="KOA" className="h-8 w-auto" />
        </div>
        <p className="text-white/50 text-[10px] mb-3">Vigilado Superintendencia Financiera de Colombia</p>
        <div className="border-t border-white/[0.12] pt-3">
          <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-white/45 mb-1">Documento oficial</p>
          <p className="text-[#00DB8E] font-black text-[18px] tracking-tight leading-none">Certificado de Paz y Salvo</p>
        </div>
      </div>

      {/* Body */}
      <div className="px-7 py-5 space-y-4">
        <div className="bg-[#F7F7F7] rounded-xl p-4 space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-0.5">Crédito</p>
              <p className="font-figures font-black text-[#2A3036] text-[16px]">{credito?.numeroMascarado}</p>
            </div>
            <span className="bg-[#EFFFF7] text-[#005E3C] text-[10px] font-bold px-2.5 py-1 rounded-full">Cancelado</span>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2.5 border-t border-[#EBEBEB]">
            <div>
              <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Pagaduría</p>
              <p className="text-[12px] font-semibold text-[#2A3036] leading-tight">{credito?.pagaduria}</p>
            </div>
            <div>
              <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Monto original</p>
              <p className="font-figures text-[12px] font-semibold text-[#2A3036]">{credito ? formatPesos(credito.montoDesembolsado) : '—'}</p>
            </div>
            <div>
              <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Inicio</p>
              <p className="font-figures text-[12px] font-semibold text-[#2A3036]">{credito?.periodoInicio}</p>
            </div>
            <div>
              <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Cancelado</p>
              <p className="font-figures text-[12px] font-semibold text-[#2A3036]">{credito?.periodoFin}</p>
            </div>
          </div>
        </div>

        <p className="text-[12px] text-gray-500 leading-relaxed text-center">
          KOA Compañía de Financiamiento certifica que el crédito indicado se encuentra{' '}
          <span className="font-bold text-[#2A3036]">completamente cancelado</span>, sin saldo ni
          obligación pendiente a la fecha de expedición de este certificado.
        </p>

        <div className="flex items-center justify-between pt-3 border-t border-[#F0F0F0]">
          <div>
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Fecha de expedición</p>
            <p className="font-figures text-[12px] font-semibold text-[#2A3036] capitalize">{today}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── Main flow ─────────────────────────────────────────────── */
export default function PazYSalvoFlow({ onClose }: PazYSalvoFlowProps) {
  const [paso, setPaso] = useState<Paso>(1)
  const [selected, setSelected] = useState<string | null>(null)
  const [downloading, setDownloading] = useState(false)
  const [revealed, setRevealed] = useState(false)

  const multiplePagedurias = new Set(creditosTerminados.map(c => c.pagaduria)).size > 1
  const pasoNum = paso === 'generando' ? 3 : (paso as number)

  function handleSeleccion() {
    setPaso('generando')
    setTimeout(() => {
      setPaso(3)
      setTimeout(() => setRevealed(true), 80)
    }, 2900)
  }

  function resetFlow() {
    setPaso(1)
    setSelected(null)
    setRevealed(false)
  }

  function handleDownload() {
    setDownloading(true)
    setTimeout(() => setDownloading(false), 1200)
  }

  const isDark = paso === 'generando'

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col overflow-y-auto transition-colors duration-500"
      style={{ background: isDark ? '#06005A' : '#F4F6F9' }}
    >

      {/* ── Stepper header ──────────────────────────────── */}
      <div className="bg-[#06005A] px-5 pt-4 pb-0 sticky top-0 z-10 flex-shrink-0 relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-5 w-8 h-8 rounded-lg bg-white/[0.1] hover:bg-white/[0.18] flex items-center justify-center transition-colors cursor-pointer z-20"
        >
          <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Stepper */}
        <div className="flex max-w-xs mx-auto pb-5 pt-2">
          {STEPS.map((label, i) => {
            const p = i + 1
            const done = pasoNum > p
            const active = pasoNum === p || (paso === 'generando' && p === 3)
            return (
              <div key={p} className="flex-1 flex flex-col items-center relative">
                {/* Connector line left — gap for circle (radius 16px) */}
                {i > 0 && (
                  <div className={`absolute top-4 right-[calc(50%+16px)] left-0 h-px transition-all duration-500 ${
                    done ? 'bg-[#00DB8E]' : 'bg-white/20'
                  }`} />
                )}
                {/* Connector line right */}
                {i < STEPS.length - 1 && (
                  <div className={`absolute top-4 left-[calc(50%+16px)] right-0 h-px transition-all duration-500 ${
                    pasoNum > p ? 'bg-[#00DB8E]' : 'bg-white/20'
                  }`} />
                )}
                {/* Circle */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-black relative z-10 transition-all duration-300 ${
                  done
                    ? 'bg-[#00DB8E] text-[#06005A] shadow-sm shadow-[#00DB8E]/40'
                    : active
                      ? 'bg-white text-[#06005A] shadow-md ring-2 ring-white/20 ring-offset-2 ring-offset-[#06005A]'
                      : 'bg-white/[0.12] text-white/35 border border-white/10'
                }`}>
                  {done ? (
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  ) : p}
                </div>
                {/* Label */}
                <p className={`text-[10px] font-semibold tracking-wide mt-2 transition-colors text-center leading-tight ${
                  active ? 'text-white' : done ? 'text-[#00DB8E]' : 'text-white/30'
                }`}>
                  {label}
                </p>
                {/* Active underline */}
                {active && (
                  <div className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-white/60 rounded-full" />
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* ── Content ─────────────────────────────────────────── */}
      <div className="flex-1 px-5 py-8 max-w-lg mx-auto w-full">

        {/* Step 1 — Verificación */}
        {paso === 1 && (
          <VerificacionStep onContinuar={() => setPaso(2)} />
        )}

        {/* Step 2 — Selección */}
        {paso === 2 && (
          <div className="space-y-5">
            <div className="bg-[#06005A] rounded-2xl px-5 py-4 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#00DB8E]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-white font-bold text-[13px] leading-tight mb-0.5">Solo créditos terminados</p>
                <p className="text-white/55 text-[12px] leading-snug">
                  El paz y salvo certifica que tu crédito fue pagado en su totalidad y no tienes obligaciones pendientes con KOA.
                </p>
              </div>
            </div>

            <div>
              <h2 className="font-black text-[19px] text-[#2A3036]">Selecciona el crédito</h2>
            </div>

            {creditosTerminados.length === 0 ? (
              <div className="bg-white rounded-2xl border border-[#E8ECF2] p-8 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-[#F7F7F7] flex items-center justify-center mx-auto">
                  <svg className="w-7 h-7 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <p className="font-bold text-[#2A3036]">Sin créditos terminados</p>
                <p className="text-[13px] text-gray-400 leading-snug max-w-xs mx-auto">
                  Cuando finalices de pagar un crédito de libranza, aparecerá aquí para generar su paz y salvo.
                </p>
                <button onClick={onClose} className="text-[13px] font-bold text-[#06005A] hover:underline cursor-pointer mt-1">
                  Volver a mis créditos
                </button>
              </div>
            ) : (
              <>
                {/* Scrollable list — handles many credits */}
                <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1 -mr-1">
                  {creditosTerminados.map((c) => {
                    const isSelected = selected === c.id
                    return (
                      <button
                        key={c.id}
                        onClick={() => setSelected(c.id)}
                        className={`w-full text-left rounded-2xl border-2 px-4 py-3.5 transition-all duration-150 cursor-pointer flex items-center gap-4 ${
                          isSelected
                            ? 'border-[#06005A] bg-[#06005A]/04 shadow-sm'
                            : 'border-[#E8ECF2] bg-white hover:border-[#06005A]/30'
                        }`}
                      >
                        {/* Radio */}
                        <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all duration-150 ${
                          isSelected ? 'border-[#06005A] bg-[#06005A]' : 'border-[#D0D5DD]'
                        }`}>
                          {isSelected && (
                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-bold text-[#2A3036] text-[14px] truncate">{c.pagaduria}</p>
                            <span className="text-[9px] font-bold text-[#005E3C] bg-[#EFFFF7] px-2 py-0.5 rounded-full flex-shrink-0">Cancelado</span>
                          </div>
                          <div className="flex items-center gap-3 mt-1 flex-wrap">
                            <p className="font-figures text-[12px] text-gray-400">{c.numeroMascarado}</p>
                            <span className="w-1 h-1 rounded-full bg-gray-300" />
                            <p className="font-figures text-[12px] text-gray-400">{formatPesos(c.montoDesembolsado)}</p>
                            <span className="w-1 h-1 rounded-full bg-gray-300" />
                            <p className="font-figures text-[12px] text-gray-400">{c.periodoInicio} – {c.periodoFin}</p>
                          </div>
                          {multiplePagedurias && (
                            <p className="text-[11px] text-gray-400 mt-0.5 truncate">{c.pagaduria}</p>
                          )}
                        </div>
                      </button>
                    )
                  })}
                </div>

                {creditosTerminados.length > 3 && (
                  <p className="text-center text-[11px] text-gray-400">
                    {creditosTerminados.length} créditos · desplázate para ver todos
                  </p>
                )}

                <button
                  disabled={!selected}
                  onClick={handleSeleccion}
                  className={`w-full py-4 rounded-2xl font-black text-[15px] transition-all duration-200 ${
                    selected
                      ? 'bg-[#06005A] text-white hover:bg-[#08007A] shadow-lg shadow-[#06005A]/25 cursor-pointer'
                      : 'bg-[#F0F0F0] text-gray-400 cursor-not-allowed'
                  }`}
                >
                  Generar certificado
                </button>
              </>
            )}
          </div>
        )}

        {/* Generating */}
        {paso === 'generando' && <GenerandoScreen />}

        {/* Step 3 — Certificate */}
        {paso === 3 && selected && (
          <div className={`space-y-5 transition-all duration-500 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            <div className="flex items-center gap-3 bg-[#EFFFF7] border border-[#00DB8E]/30 rounded-2xl px-4 py-3">
              <div className="w-8 h-8 rounded-xl bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <p className="font-bold text-[#005E3C] text-[13px]">Certificado generado</p>
                <p className="text-[11px] text-[#005E3C]/70">Tu paz y salvo fue emitido exitosamente</p>
              </div>
            </div>

            <Certificado creditoId={selected} />

            <div className="flex flex-col sm:flex-row gap-3 pb-4">
              <button
                onClick={handleDownload}
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl font-black text-[14px] transition-all cursor-pointer ${
                  downloading
                    ? 'bg-[#00DB8E]/90 text-[#06005A]'
                    : 'bg-[#06005A] text-white hover:bg-[#08007A] shadow-lg shadow-[#06005A]/25'
                }`}
              >
                {downloading ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-[#06005A]/30 border-t-[#06005A] animate-spin" />
                    Descargando…
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Descargar PDF
                  </>
                )}
              </button>
              <button
                onClick={resetFlow}
                className="flex-1 py-4 rounded-2xl font-bold text-[14px] text-[#06005A] bg-white border-2 border-[#E8ECF2] hover:border-[#06005A]/30 transition-all cursor-pointer"
              >
                Consultar otro
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  )
}
