import { useState, useEffect, useRef } from 'react'

interface VerificacionStepProps {
  onContinuar: () => void
}

const CODE_LENGTH = 6
const DEMO_CODE = '248731'

type OtpState = 'idle' | 'validating' | 'success' | 'error'

export default function VerificacionStep({ onContinuar }: VerificacionStepProps) {
  const [digits, setDigits] = useState<string[]>(Array(CODE_LENGTH).fill(''))
  const [seconds, setSeconds] = useState(180)
  const [resent, setResent] = useState(false)
  const [otpState, setOtpState] = useState<OtpState>('idle')
  const [validPhase, setValidPhase] = useState(0)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])
  const isCorrectRef = useRef(false)

  const code = digits.join('')

  // Countdown
  useEffect(() => {
    if (seconds <= 0 || otpState !== 'idle') return
    const t = setInterval(() => setSeconds(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [seconds, otpState])

  const mins = String(Math.floor(seconds / 60)).padStart(2, '0')
  const secs = String(seconds % 60).padStart(2, '0')

  // Auto-validate when 6 digits entered — always run animation
  useEffect(() => {
    if (code.length === CODE_LENGTH && otpState === 'idle') {
      isCorrectRef.current = code === DEMO_CODE
      runValidation()
    }
  }, [code])

  function runValidation() {
    setOtpState('validating')
    setValidPhase(0)
    const t1 = setTimeout(() => setValidPhase(1), 700)
    const t2 = setTimeout(() => setValidPhase(2), 1400)
    const t3 = setTimeout(() => {
      if (isCorrectRef.current) {
        setOtpState('success')
        setTimeout(onContinuar, 700)
      } else {
        setOtpState('error')
        setTimeout(() => {
          setOtpState('idle')
          setDigits(Array(CODE_LENGTH).fill(''))
          inputRefs.current[0]?.focus()
        }, 1500)
      }
    }, 2000)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
  }

  function handleDigit(i: number, val: string) {
    if (otpState !== 'idle') return
    const ch = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]
    next[i] = ch
    setDigits(next)
    if (ch && i < CODE_LENGTH - 1) inputRefs.current[i + 1]?.focus()
  }

  function handleKeyDown(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (otpState !== 'idle') return
    if (e.key === 'Backspace' && !digits[i] && i > 0) inputRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowLeft' && i > 0) inputRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < CODE_LENGTH - 1) inputRefs.current[i + 1]?.focus()
  }

  function handlePaste(e: React.ClipboardEvent) {
    if (otpState !== 'idle') return
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, CODE_LENGTH)
    const next = [...digits]
    pasted.split('').forEach((ch, i) => { next[i] = ch })
    setDigits(next)
    inputRefs.current[Math.min(pasted.length, CODE_LENGTH - 1)]?.focus()
  }

  function handleResend() {
    setSeconds(180)
    setDigits(Array(CODE_LENGTH).fill(''))
    setOtpState('idle')
    setResent(true)
    setTimeout(() => setResent(false), 3000)
    inputRefs.current[0]?.focus()
  }

  // ── Validating / success / error overlay ──
  if (otpState !== 'idle') {
    const isError = otpState === 'error'
    const isSuccess = otpState === 'success'
    const stepLabels = [
      'Verificando código…',
      'Confirmando identidad…',
      isError ? 'Código incorrecto' : 'Acceso autorizado',
    ]

    return (
      <div className="flex flex-col items-center justify-center gap-8 py-12">
        <div className="relative flex items-center justify-center">
          <div
            className="absolute w-24 h-24 rounded-full border-2 animate-spin"
            style={{
              animationDuration: '2.5s',
              borderColor: 'transparent',
              borderTopColor: isError ? '#EF4444' : '#00DB8E',
            }}
          />
          <div
            className="absolute w-16 h-16 rounded-full border-2 animate-spin"
            style={{
              animationDuration: '1.8s',
              animationDirection: 'reverse',
              borderColor: 'transparent',
              borderBottomColor: isError ? '#EF4444' : '#06005A',
              opacity: 0.25,
            }}
          />
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
            isSuccess ? 'bg-[#00DB8E]' : isError ? 'bg-[#EF4444]' : 'bg-[#06005A]'
          }`}>
            {isSuccess ? (
              <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            ) : isError ? (
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <img src="https://s3.us-east-1.amazonaws.com/abacusfront.koa/Koa/logo-white.svg" alt="KOA" className="h-5 w-auto" />
            )}
          </div>
        </div>

        <div className="space-y-2.5 w-full max-w-[220px]">
          {stepLabels.map((s, i) => {
            const stepDone = i < validPhase || isSuccess
            const stepActive = i === validPhase && !isSuccess
            const stepError = isError && i === validPhase
            return (
              <div
                key={i}
                className={`flex items-center gap-3 transition-all duration-400 ${
                  i <= validPhase ? 'opacity-100' : 'opacity-25'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
                  stepDone
                    ? 'bg-[#00DB8E]'
                    : stepError
                      ? 'bg-[#EF4444]'
                      : stepActive
                        ? 'border-2 border-[#06005A] bg-[#06005A]/08'
                        : 'bg-[#F0F0F0]'
                }`}>
                  {stepDone ? (
                    <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  ) : stepError ? (
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  ) : stepActive ? (
                    <div className="w-2 h-2 rounded-full bg-[#06005A] animate-pulse" />
                  ) : null}
                </div>
                <p className={`text-[13px] transition-colors duration-300 ${
                  stepError
                    ? 'text-[#DC2626] font-bold'
                    : stepDone
                      ? 'text-[#005E3C] font-semibold'
                      : stepActive
                        ? 'text-[#2A3036] font-bold'
                        : 'text-gray-300'
                }`}>{s}</p>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-sm mx-auto flex flex-col gap-6">
      <div className="flex flex-col items-center text-center gap-3">
        <div className="w-14 h-14 rounded-2xl bg-[#06005A] flex items-center justify-center relative">
          <svg className="w-7 h-7 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#00DB8E] flex items-center justify-center">
            <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </span>
        </div>
        <div>
          <h2 className="font-black text-[19px] text-[#2A3036] leading-tight">Verifica tu identidad</h2>
          <p className="text-[13px] text-gray-400 mt-1 leading-snug">
            Enviamos un código a <span className="font-semibold text-[#2A3036]">a****s@correo.com</span>
          </p>
        </div>
      </div>

      {/* OTP */}
      <div
        className="flex gap-2 justify-center"
        onPaste={handlePaste}
      >
        {digits.map((d, i) => (
          <input
            key={i}
            ref={el => { inputRefs.current[i] = el }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={d}
            autoFocus={i === 0}
            onChange={e => handleDigit(i, e.target.value)}
            onKeyDown={e => handleKeyDown(i, e)}
            className={`w-11 h-14 text-center font-figures font-black text-[22px] rounded-xl border-2 outline-none transition-all duration-150 ${
              otpState === 'error'
                ? 'border-[#EF4444] bg-[#FEF2F2] text-[#DC2626] animate-[shake_0.3s_ease-in-out]'
                : d
                  ? 'border-[#06005A] bg-[#06005A]/05 text-[#06005A]'
                  : 'border-[#E8ECF2] bg-white text-[#2A3036] focus:border-[#06005A]'
            }`}
          />
        ))}
      </div>

      {/* Timer */}
      <div className="text-center">
        {seconds > 0 ? (
          <p className="text-[12px] text-gray-400">
            Vence en <span className="font-figures font-bold text-[#2A3036]">{mins}:{secs}</span>
          </p>
        ) : (
          <p className="text-[12px] text-[#EF4444] font-semibold">El código expiró</p>
        )}
        <button onClick={handleResend} className="text-[12px] font-bold text-[#06005A] hover:underline mt-1 cursor-pointer">
          {resent ? '✓ Código reenviado' : 'Reenviar código'}
        </button>
      </div>

      {/* Demo hint */}
      <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-4 py-3 flex items-start gap-2.5">
        <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-[11px] text-[#005E3C] leading-snug">
          <span className="font-bold">Demo:</span> el código es{' '}
          <button
            onClick={() => {
              setDigits(DEMO_CODE.split(''))
              setTimeout(() => inputRefs.current[5]?.focus(), 0)
            }}
            className="font-figures font-black underline cursor-pointer"
          >
            {DEMO_CODE}
          </button>
        </p>
      </div>
    </div>
  )
}
