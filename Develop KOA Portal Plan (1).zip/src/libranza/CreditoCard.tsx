import { useNavigate } from 'react-router-dom'
import { formatPesos, type Credito } from '../data/mockData'

interface CreditoCardProps {
  credito: Credito
  delay?: number
}

export default function CreditoCard({ credito, delay = 0 }: CreditoCardProps) {
  const navigate = useNavigate()
  const pct = Math.round((credito.cuotaActual / credito.totalCuotas) * 100)
  const enMora = credito.estado === 'en-mora'
  const cuotasRestantes = credito.totalCuotas - credito.cuotaActual

  return (
    <div
      className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden cursor-pointer group card-enter hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
      style={{ animationDelay: `${delay}s` }}
      onClick={() => navigate(`/libranza/credito/${credito.id}`)}
    >
      <div className={`h-1 w-full ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669]'}`} />

      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="min-w-0">
            <p className="font-bold text-[#2A3036] text-[15px] leading-tight truncate">{credito.pagaduria}</p>
            <p className="font-figures text-[12px] text-gray-400 mt-0.5">{credito.numeroMascarado}</p>
          </div>
          <div className="flex-shrink-0 flex items-center gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669] animate-pulse'}`} />
            <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
              enMora ? 'bg-[#FEF2F2] text-[#DC2626]' : 'bg-[#ECFDF5] text-[#065F46]'
            }`}>
              {enMora ? 'En mora' : 'Al día'}
            </span>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Saldo pendiente</p>
          <p className="font-figures text-[28px] font-black text-[#2A3036] leading-none">{formatPesos(credito.saldo)}</p>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Cuota</p>
            <p className="font-figures text-[12px] font-black text-[#2A3036] leading-tight">{formatPesos(credito.cuotaMensual)}</p>
          </div>
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Tasa</p>
            <p className="font-figures text-[12px] font-black text-[#2A3036] leading-tight">{credito.tasa} %</p>
          </div>
          <div className="bg-[#F7F7F7] rounded-xl px-3 py-2.5">
            <p className="text-[9px] font-bold tracking-[0.1em] uppercase text-gray-400 mb-0.5">Restantes</p>
            <p className="font-figures text-[12px] font-black text-[#2A3036] leading-tight">{cuotasRestantes} cuotas</p>
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] text-gray-400">Cuota {credito.cuotaActual} de {credito.totalCuotas}</span>
            <span className="font-figures text-[11px] font-bold text-[#2A3036]">{pct} % pagado</span>
          </div>
          <div className="h-1.5 bg-[#F0F0F0] rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${enMora ? 'bg-[#EF4444]' : 'bg-[#059669]'}`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>

      <div className="px-5 pb-4 flex justify-end">
        <div className="flex items-center gap-1 text-[12px] font-bold text-[#06005A] group-hover:gap-2 transition-all">
          <span>Ver detalle</span>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  )
}
