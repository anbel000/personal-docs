import { useState, useEffect, useRef } from 'react'
import Btn from '../components/Btn'
import StatusPill from '../components/StatusPill'

const DEMO_OTP = '248731'
const D = 6

type EstadoSolicitud = 'libre' | 'en-proceso' | 'con-costo'
type ModalStep = 'closed' | 'otp' | 'validating' | 'otp-error' | 'confirm'

interface CertificacionDeSaldoProps {
  creditoId: string
  numeroMascarado: string
  pagaduria: string
  onToast: (msg: string) => void
}

/* ── OTP digit row ──────────────────────────────────── */
interface DigitRowProps {
  digits: string[]
  inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>
  onChange: (i: number, v: string) => void
  onKeyDown: (i: number, e: React.KeyboardEvent<HTMLInputElement>) => void
  onPaste?: (e: React.ClipboardEvent) => void
  autoFocus?: boolean
}

function DigitRow({ digits, inputRefs, onChange, onKeyDown, onPaste, autoFocus }: DigitRowProps) {
  return (
    <div className="flex gap-2 justify-center" onPaste={onPaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { inputRefs.current[i] = el }}
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={d}
          autoFocus={autoFocus && i === 0}
          onChange={e => onChange(i, e.target.value)}
          onKeyDown={e => onKeyDown(i, e)}
          className={`w-10 h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all duration-150 ${
            d
              ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
              : 'border-[#E8ECF2] bg-white focus:border-[#06005A] text-[#2A3036]'
          }`}
        />
      ))}
    </div>
  )
}

/* ── Validation animation ───────────────────────────── */
function ValidatingOverlay({ phase, isError }: { phase: number; isError: boolean }) {
  const steps = ['Verificando código…', 'Confirmando identidad…', isError ? 'Código incorrecto' : 'Acceso autorizado']
  return (
    <div className="flex flex-col items-center gap-7 py-6">
      <div className="relative flex items-center justify-center">
        <div
          className="absolute w-20 h-20 rounded-full border-2 animate-spin"
          style={{ animationDuration: '2.5s', borderColor: 'transparent', borderTopColor: isError ? '#EF4444' : '#00DB8E' }}
        />
        <div
          className="absolute w-14 h-14 rounded-full border-2 animate-spin"
          style={{ animationDuration: '1.8s', animationDirection: 'reverse', borderColor: 'transparent', borderBottomColor: isError ? '#EF4444' : '#06005A', opacity: 0.2 }}
        />
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg transition-all duration-500 ${isError ? 'bg-[#EF4444]' : 'bg-[#06005A]'}`}>
          {isError ? (
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          )}
        </div>
      </div>

      <div className="space-y-2.5 w-full">
        {steps.map((s, i) => {
          const done = i < phase
          const active = i === phase
          const err = isError && i === 2 && phase === 2
          return (
            <div key={i} className={`flex items-center gap-3 transition-all duration-400 ${i <= phase ? 'opacity-100' : 'opacity-20'}`}>
              <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
                done ? 'bg-[#00DB8E]' : err ? 'bg-[#EF4444]' : active ? 'border-2 border-[#06005A]' : 'bg-[#F0F0F0]'
              }`}>
                {done ? (
                  <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                ) : err ? (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                ) : active ? (
                  <div className="w-2 h-2 rounded-full bg-[#06005A] animate-pulse" />
                ) : null}
              </div>
              <p className={`text-[13px] transition-colors duration-300 ${
                err ? 'text-[#DC2626] font-bold' : done ? 'text-[#005E3C] font-semibold' : active ? 'text-[#2A3036] font-bold' : 'text-gray-300'
              }`}>{s}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ── Main component ─────────────────────────────────── */
export default function CertificacionDeSaldo({ creditoId, numeroMascarado, pagaduria, onToast }: CertificacionDeSaldoProps) {
  const initialState: EstadoSolicitud =
    creditoId === '7350' ? 'en-proceso' : creditoId === '2893' ? 'con-costo' : 'libre'
  const [estado] = useState<EstadoSolicitud>(initialState)

  /* Modal flow */
  const [modalStep, setModalStep] = useState<ModalStep>('closed')
  const [successOpen, setSuccessOpen] = useState(false)
  const [checkAccepted, setCheckAccepted] = useState(false)
  const [sending, setSending] = useState(false)

  /* OTP state */
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(D).fill(''))
  const [otpSeconds, setOtpSeconds] = useState(180)
  const [otpResent, setOtpResent] = useState(false)
  const [validPhase, setValidPhase] = useState(0)
  const isCorrectRef = useRef(false)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  const hasCosto = estado === 'con-costo'
  const mesActual = 'AGO 2026'

  /* Countdown */
  useEffect(() => {
    if (modalStep !== 'otp' || otpSeconds <= 0) return
    const t = setInterval(() => setOtpSeconds(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [modalStep, otpSeconds])

  /* Auto-validate when 6 digits entered */
  const otpCode = otpDigits.join('')
  useEffect(() => {
    if (otpCode.length === D && modalStep === 'otp') {
      isCorrectRef.current = otpCode === DEMO_OTP
      runValidation()
    }
  }, [otpCode])

  function runValidation() {
    setModalStep('validating')
    setValidPhase(0)
    const t1 = setTimeout(() => setValidPhase(1), 700)
    const t2 = setTimeout(() => setValidPhase(2), 1400)
    setTimeout(() => {
      if (isCorrectRef.current) {
        setModalStep('confirm')
        setOtpDigits(Array(D).fill(''))
      } else {
        setModalStep('otp-error')
        setTimeout(() => {
          setModalStep('otp')
          setOtpDigits(Array(D).fill(''))
          setTimeout(() => otpRefs.current[0]?.focus(), 30)
        }, 1400)
      }
    }, 2000)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }

  function handleOtpDigit(i: number, v: string) {
    if (modalStep !== 'otp') return
    const ch = v.replace(/\D/g, '').slice(-1)
    const next = [...otpDigits]; next[i] = ch; setOtpDigits(next)
    if (ch && i < D - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpKey(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !otpDigits[i] && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowLeft' && i > 0) otpRefs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < D - 1) otpRefs.current[i + 1]?.focus()
  }
  function handleOtpPaste(e: React.ClipboardEvent) {
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, D)
    const next = Array(D).fill(''); pasted.split('').forEach((ch, i) => { next[i] = ch }); setOtpDigits(next)
    otpRefs.current[Math.min(pasted.length, D - 1)]?.focus()
  }

  function openModal() {
    setModalStep('otp')
    setOtpDigits(Array(D).fill(''))
    setOtpSeconds(180)
    setCheckAccepted(false)
  }
  function closeModal() {
    setModalStep('closed')
    setOtpDigits(Array(D).fill(''))
    setValidPhase(0)
  }

  function handleConfirm() {
    setSending(true)
    setTimeout(() => {
      setSending(false)
      closeModal()
      setSuccessOpen(true)
    }, 1000)
  }

  function resendOtp() {
    setOtpDigits(Array(D).fill(''))
    setOtpSeconds(180)
    setOtpResent(true)
    setTimeout(() => setOtpResent(false), 3000)
    setTimeout(() => otpRefs.current[0]?.focus(), 30)
  }

  const mins = String(Math.floor(otpSeconds / 60)).padStart(2, '0')
  const secs = String(otpSeconds % 60).padStart(2, '0')

  /* ── En proceso state ── */
  if (estado === 'en-proceso') {
    return (
      <div className="bg-[#FFFBEB] border border-[#F59E0B]/40 rounded-xl p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-[#F59E0B] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            <p className="font-semibold text-[#2A3036] text-[15px]">Certificación de saldo</p>
          </div>
          <StatusPill variant="en-proceso" />
        </div>
        <p className="text-[13px] text-gray-600 mb-1">Solicitada el <span className="font-figures font-semibold">11 AGO 2026</span></p>
        <p className="text-[14px] font-semibold text-[#2A3036] mb-1">Te llegará a tu correo en máximo X días hábiles</p>
        <p className="text-[13px] text-gray-500">La enviaremos a a****s@correo.com</p>
      </div>
    )
  }

  return (
    <>
      {/* ── Card ── */}
      <div className={`rounded-xl border p-4 ${hasCosto ? 'border-[#F59E0B]/40 bg-[#FFFBEB]' : 'border-[#E5E7EB] bg-white'}`}>
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-[#EFFFF7] flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-[#2A3036] text-[15px]">Certificación de saldo</p>
            <p className="text-[13px] text-gray-500 mt-0.5">Certificado oficial del saldo vigente de tu crédito, enviado a tu correo registrado.</p>
          </div>
        </div>

        {!hasCosto && (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#005E3C] bg-[#EFFFF7] px-2.5 py-1 rounded-full mb-3">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
            Primera del mes sin costo
          </span>
        )}
        {hasCosto && (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#92400E] bg-[#F59E0B]/20 px-2.5 py-1 rounded-full mb-3">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            Segunda solicitud del mes · tiene costo de $ XX.XXX
          </span>
        )}

        <div>
          <Btn variant="primary" size="md" onClick={openModal}>
            Solicitar certificación
          </Btn>
        </div>
      </div>

      {/* ── Multi-step modal ── */}
      {modalStep !== 'closed' && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">

            {/* Modal header */}
            <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-[#F0F2F5]">
              <div className="flex items-center gap-3">
                {/* Step indicator */}
                <div className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full transition-all duration-300 ${modalStep === 'otp' || modalStep === 'validating' || modalStep === 'otp-error' ? 'bg-[#06005A] w-4' : 'bg-[#E8ECF2]'}`} />
                  <div className={`w-2 h-2 rounded-full transition-all duration-300 ${modalStep === 'confirm' ? 'bg-[#06005A] w-4' : 'bg-[#E8ECF2]'}`} />
                </div>
                <p className="font-bold text-[16px] text-[#2A3036]">
                  {modalStep === 'confirm' ? 'Confirma tu solicitud' : 'Verifica tu identidad'}
                </p>
              </div>
              <button onClick={closeModal} className="w-8 h-8 rounded-full hover:bg-[#F0F2F5] flex items-center justify-center transition-colors cursor-pointer">
                <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            {/* ── Step 1: OTP ── */}
            {(modalStep === 'otp') && (
              <div className="px-6 py-6 flex flex-col items-center gap-5">
                <div className="flex flex-col items-center gap-2 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-[#06005A] flex items-center justify-center relative">
                    <svg className="w-6 h-6 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#00DB8E] flex items-center justify-center">
                      <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    </span>
                  </div>
                  <p className="text-[13px] text-gray-500">
                    Enviamos un código a <span className="font-semibold text-[#2A3036]">a****s@correo.com</span>
                  </p>
                </div>

                <DigitRow
                  digits={otpDigits}
                  inputRefs={otpRefs}
                  onChange={handleOtpDigit}
                  onKeyDown={handleOtpKey}
                  onPaste={handleOtpPaste}
                  autoFocus
                />

                <div className="text-center">
                  {otpSeconds > 0 ? (
                    <p className="text-[12px] text-gray-400">
                      Vence en <span className="font-figures font-bold text-[#2A3036]">{mins}:{secs}</span>
                    </p>
                  ) : (
                    <p className="text-[12px] text-[#EF4444] font-semibold">El código expiró</p>
                  )}
                  <button onClick={resendOtp} className="text-[12px] font-bold text-[#06005A] hover:underline cursor-pointer mt-1">
                    {otpResent ? '✓ Código reenviado' : 'Reenviar código'}
                  </button>
                </div>

                {/* Demo hint */}
                <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-4 py-2.5 flex items-center gap-2 w-full">
                  <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  <p className="text-[11px] text-[#005E3C]">
                    <span className="font-bold">Demo:</span> el código es{' '}
                    <button
                      onClick={() => { setOtpDigits(DEMO_OTP.split('')); setTimeout(() => otpRefs.current[D - 1]?.focus(), 0) }}
                      className="font-figures font-black underline cursor-pointer"
                    >
                      {DEMO_OTP}
                    </button>
                  </p>
                </div>
              </div>
            )}

            {/* ── Validating animation ── */}
            {(modalStep === 'validating' || modalStep === 'otp-error') && (
              <div className="px-6">
                <ValidatingOverlay phase={validPhase} isError={modalStep === 'otp-error'} />
              </div>
            )}

            {/* ── Step 2: Confirm ── */}
            {modalStep === 'confirm' && (
              <div className="px-6 py-5">
                <div className="bg-gray-50 rounded-xl divide-y divide-[#E5E7EB] mb-4">
                  <div className="flex justify-between px-4 py-3">
                    <span className="text-[13px] text-gray-500">Crédito</span>
                    <span className="font-figures text-[13px] font-semibold text-[#2A3036]">{numeroMascarado} · {pagaduria}</span>
                  </div>
                  <div className="flex justify-between px-4 py-3">
                    <span className="text-[13px] text-gray-500">Solicitudes en {mesActual}</span>
                    <span className="text-[13px] font-semibold text-[#2A3036]">{hasCosto ? '1 ya utilizada este mes' : '0 utilizadas'}</span>
                  </div>
                  <div className="flex justify-between px-4 py-3">
                    <span className="text-[13px] text-gray-500">Costo de esta solicitud</span>
                    <span className={`font-figures text-[13px] font-semibold ${hasCosto ? 'text-[#F59E0B]' : 'text-[#005E3C]'}`}>
                      {hasCosto ? '$ XX.XXX' : 'Sin costo'}
                    </span>
                  </div>
                </div>

                <p className="text-[13px] text-gray-500 mb-4">
                  Te llegará a <span className="font-figures font-semibold">a****s@correo.com</span> en máximo X días hábiles.
                </p>

                {hasCosto && (
                  <label className="flex items-start gap-3 mb-4 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={checkAccepted}
                      onChange={e => setCheckAccepted(e.target.checked)}
                      className="mt-0.5 w-4 h-4 accent-[#0A1F44] cursor-pointer"
                    />
                    <span className="text-[13px] text-gray-700">Acepto el cobro de $ XX.XXX por esta solicitud adicional</span>
                  </label>
                )}

                <div className="flex gap-3 justify-end">
                  <Btn variant="ghost" size="md" onClick={closeModal}>Cancelar</Btn>
                  <Btn
                    variant="primary"
                    size="md"
                    loading={sending}
                    disabled={hasCosto && !checkAccepted}
                    onClick={handleConfirm}
                  >
                    Confirmar solicitud
                  </Btn>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* ── Success dialog ── */}
      {successOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 text-center">
            <div className="w-14 h-14 rounded-full bg-[#00DB8E]/20 flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
            </div>
            <h3 className="font-bold text-[18px] text-[#2A3036] mb-1">Solicitud radicada</h3>
            <p className="font-figures text-[20px] font-bold text-[#2A3036] mb-2">SOL-2026-004821</p>
            <p className="text-[13px] text-gray-500 mb-6">
              Te llegará en máximo X días hábiles a tu correo registrado.
            </p>
            <div className="flex justify-center">
              <Btn variant="primary" size="md" onClick={() => setSuccessOpen(false)}>Cerrar</Btn>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
