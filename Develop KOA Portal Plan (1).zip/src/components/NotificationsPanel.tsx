import { useState } from 'react'
import SidePanel from './SidePanel'
import { notificaciones } from '../data/mockData'
import { useNavigate } from 'react-router-dom'

interface NotificationsPanelProps {
  open: boolean
  onClose: () => void
}

function iconForType(tipo: string) {
  switch (tipo) {
    case 'proceso': return (
      <svg className="w-5 h-5 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
    case 'pago': return (
      <svg className="w-5 h-5 text-[#10B981]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
    case 'documento': return (
      <svg className="w-5 h-5 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    )
    default: return (
      <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
  }
}

export default function NotificationsPanel({ open, onClose }: NotificationsPanelProps) {
  const navigate = useNavigate()
  const [items, setItems] = useState(notificaciones)

  const markAllRead = () => setItems(items.map(n => ({ ...n, leida: true })))

  const hasUnread = items.some(n => !n.leida)

  return (
    <SidePanel open={open} onClose={onClose} title="Notificaciones">
      <div className="px-4 py-3 border-b border-[#E5E7EB] flex items-center justify-between">
        {hasUnread ? (
          <button onClick={markAllRead} className="text-[13px] text-[#005E3C] font-semibold hover:underline cursor-pointer">
            Marcar todas como leídas
          </button>
        ) : (
          <span className="text-[13px] text-gray-400">Todas leídas</span>
        )}
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center text-center py-12 px-6 gap-3">
          <svg className="w-12 h-12 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          <p className="text-[14px] text-gray-500">Estás al día. No tienes notificaciones nuevas.</p>
        </div>
      ) : (
        <ul>
          {items.map((n) => (
            <li
              key={n.id}
              className={`px-5 py-4 border-b border-[#E5E7EB] flex gap-3 transition-colors duration-150 ${n.leida ? 'bg-white' : 'bg-[#F0FDF9]'}`}
            >
              <div className="flex-shrink-0 mt-0.5">
                {!n.leida && (
                  <span className="block w-2 h-2 rounded-full bg-[#00DB8E] mb-1 mt-1" />
                )}
                {n.leida && <span className="block w-2 h-2" />}
              </div>
              <div className="flex-shrink-0 mt-0.5">{iconForType(n.tipo)}</div>
              <div className="flex-1 min-w-0">
                <p className={`text-[14px] leading-snug ${n.leida ? 'text-gray-700' : 'font-semibold text-[#2A3036]'}`}>{n.titulo}</p>
                <p className="text-[12px] text-gray-500 mt-0.5">{n.detalle}</p>
                <p className="text-[11px] text-gray-400 mt-1">{n.tiempo}</p>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div className="px-5 py-4 border-t border-[#E5E7EB]">
        <button
          onClick={() => { onClose(); navigate('/') }}
          className="text-[13px] text-[#005E3C] font-semibold hover:underline cursor-pointer"
        >
          Cerrar
        </button>
      </div>
    </SidePanel>
  )
}
