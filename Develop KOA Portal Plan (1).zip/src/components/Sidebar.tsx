import { useState, useEffect } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'

interface NavItem {
  label: string
  href?: string
  icon: React.ReactNode
  pronto?: boolean
}

interface NavGroup {
  title: string
  items: NavItem[]
}

function HomeIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
}
function LibranzaIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
}
function CDTIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
}
function AhorrosIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
}
function PhoneIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
}
function BookIcon() {
  return <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
}

interface SidebarProps {
  mobileOpen: boolean
  onMobileClose: () => void
}

export default function Sidebar({ mobileOpen, onMobileClose }: SidebarProps) {
  const { personType, productos } = useDemoContext()
  const location = useLocation()

  const [collapsed, setCollapsed] = useState(() => {
    return localStorage.getItem('sidebarCollapsed') === 'true'
  })

  const toggleCollapsed = () => {
    const next = !collapsed
    setCollapsed(next)
    localStorage.setItem('sidebarCollapsed', String(next))
  }

  useEffect(() => {
    onMobileClose()
  }, [location.pathname])

  const showLibranza = personType !== 'juridica'

  const groups: NavGroup[] = [
    {
      title: 'Principal',
      items: [
        { label: 'Inicio', href: '/', icon: <HomeIcon /> },
      ],
    },
    {
      title: 'Mis productos',
      items: [
        ...(showLibranza ? [{ label: 'Libranza', href: '/libranza', icon: <LibranzaIcon /> }] : []),
        { label: 'CDT', href: '/cdt', icon: <CDTIcon /> },
        { label: 'Cuenta de Ahorros', icon: <AhorrosIcon />, pronto: true },
      ],
    },
    {
      title: 'Ayuda',
      items: [
        { label: 'Contáctanos', href: '/contactanos', icon: <PhoneIcon /> },
        { label: 'Educación financiera', href: '/educacion-financiera', icon: <BookIcon /> },
      ],
    },
  ]

  const isActive = (href?: string) => {
    if (!href) return false
    if (href === '/') return location.pathname === '/'
    return location.pathname.startsWith(href)
  }

  const productColor = (href: string) => {
    if (href.startsWith('/libranza')) return '#059669'
    if (href.startsWith('/cdt')) return '#3B82F6'
    return '#00DB8E'
  }

  const w = collapsed ? 64 : 240

  const SidebarContent = (
    <div className="sidebar-gradient h-full flex flex-col" style={{ width: w }}>
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-5 min-h-[68px]">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
              <svg className="w-4 h-4 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
            </div>
            <span className="text-white font-bold text-[18px] tracking-tight">KOA</span>
          </div>
        )}
        <button
          onClick={toggleCollapsed}
          className={`w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 transition-colors cursor-pointer text-white/50 hover:text-white ${collapsed ? 'mx-auto' : 'ml-auto'}`}
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            {collapsed
              ? <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              : <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            }
          </svg>
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto scrollable px-3 pb-4 space-y-5">
        {groups.map(group => (
          <div key={group.title}>
            {!collapsed && (
              <p className="text-white/30 text-[9px] font-bold tracking-[0.2em] uppercase px-2 mb-1.5">
                {group.title}
              </p>
            )}
            <div className="space-y-0.5">
              {group.items.map(item => {
                if (item.pronto) {
                  return (
                    <div
                      key={item.label}
                      title={collapsed ? item.label : undefined}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-2xl text-white/25 cursor-default"
                    >
                      <span className="flex-shrink-0">{item.icon}</span>
                      {!collapsed && (
                        <>
                          <span className="text-[13px] font-medium flex-1 truncate">{item.label}</span>
                          <span className="text-[8px] font-bold tracking-widest uppercase bg-white/10 text-white/35 px-2 py-0.5 rounded-full">
                            Pronto
                          </span>
                        </>
                      )}
                    </div>
                  )
                }
                if (!item.href) return null
                const active = isActive(item.href)
                return (
                  <NavLink
                    key={item.label}
                    to={item.href}
                    title={collapsed ? item.label : undefined}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl transition-all duration-150 relative group ${
                      active
                        ? 'nav-active text-white'
                        : 'text-white/55 hover:text-white hover:bg-white/8'
                    }`}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full" style={{ background: productColor(item.href!) }} />
                    )}
                    <span className="flex-shrink-0 relative z-10 transition-transform duration-150" style={active ? { color: productColor(item.href!) } : {}}>
                      {item.icon}
                    </span>
                    {!collapsed && (
                      <span className="text-[13px] font-medium flex-1 truncate relative z-10">{item.label}</span>
                    )}
                    {!collapsed && active && (
                      <svg className="w-3.5 h-3.5 text-white/40 relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                      </svg>
                    )}
                  </NavLink>
                )
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div className="px-5 py-4 border-t border-white/8 space-y-0.5">
          <p className="text-white/20 text-[9px] leading-tight">Vigilado Superintendencia Financiera</p>
          <p className="text-white/20 text-[9px]">Fogafin · Colombia</p>
        </div>
      )}
    </div>
  )

  return (
    <>
      {/* Desktop */}
      <div className="hidden lg:flex flex-shrink-0 h-full transition-all duration-300" style={{ width: w }}>
        {SidebarContent}
      </div>

      {/* Mobile drawer */}
      <>
        <div
          className={`fixed inset-0 bg-black/50 z-40 lg:hidden transition-opacity duration-300 ${mobileOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          onClick={onMobileClose}
        />
        <div
          className="fixed top-0 left-0 h-full z-50 lg:hidden transition-transform duration-300 ease-out"
          style={{ width: 240, transform: mobileOpen ? 'translateX(0)' : 'translateX(-100%)' }}
        >
          <div className="sidebar-gradient h-full flex flex-col" style={{ width: 240 }}>
            <div className="flex items-center justify-between px-5 py-5 min-h-[68px]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-[#00DB8E] flex items-center justify-center">
                  <svg className="w-4 h-4 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                </div>
                <span className="text-white font-bold text-[18px] tracking-tight">KOA</span>
              </div>
              <button onClick={onMobileClose} className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/10 text-white/50 hover:text-white transition-colors cursor-pointer">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto scrollable px-3 pb-4 space-y-5">
              {groups.map(group => (
                <div key={group.title}>
                  <p className="text-white/30 text-[9px] font-bold tracking-[0.2em] uppercase px-2 mb-1.5">{group.title}</p>
                  <div className="space-y-0.5">
                    {group.items.map(item => {
                      if (item.pronto) {
                        return (
                          <div key={item.label} className="flex items-center gap-3 px-3 py-2.5 rounded-2xl text-white/25 cursor-default">
                            <span className="flex-shrink-0">{item.icon}</span>
                            <span className="text-[13px] font-medium flex-1 truncate">{item.label}</span>
                            <span className="text-[8px] font-bold tracking-widest uppercase bg-white/10 text-white/35 px-2 py-0.5 rounded-full">Pronto</span>
                          </div>
                        )
                      }
                      if (!item.href) return null
                      const active = isActive(item.href)
                      return (
                        <NavLink
                          key={item.label}
                          to={item.href}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-2xl transition-all duration-150 relative ${active ? 'nav-active text-white' : 'text-white/55 hover:text-white hover:bg-white/8'}`}
                        >
                          {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full" style={{ background: productColor(item.href!) }} />}
                          <span className="flex-shrink-0 z-10" style={active ? { color: productColor(item.href!) } : {}}>{item.icon}</span>
                          <span className="text-[13px] font-medium flex-1 truncate z-10">{item.label}</span>
                        </NavLink>
                      )
                    })}
                  </div>
                </div>
              ))}
            </nav>
            <div className="px-5 py-4 border-t border-white/8 space-y-0.5">
              <p className="text-white/20 text-[9px] leading-tight">Vigilado Superintendencia Financiera</p>
              <p className="text-white/20 text-[9px]">Fogafin · Colombia</p>
            </div>
          </div>
        </div>
      </>
    </>
  )
}
