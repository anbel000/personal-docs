import { NavLink, useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'

const TABS = [
  {
    label: 'Inicio',
    href: '/',
    exact: true,
    color: '#00DB8E',
    icon: (active: boolean) => (
      <svg className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} fill={active ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 0 : 1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    ),
  },
  {
    label: 'CDT',
    href: '/cdt',
    color: '#3B82F6',
    icon: (active: boolean) => (
      <svg className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.2 : 1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
  },
  {
    label: 'Libranza',
    href: '/libranza',
    libranzaOnly: true,
    color: '#059669',
    icon: (active: boolean) => (
      <svg className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.2 : 1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    label: 'Ayuda',
    href: '/contactanos',
    color: '#00DB8E',
    icon: (active: boolean) => (
      <svg className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 2.2 : 1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    label: 'Perfil',
    href: '/mis-datos',
    color: '#00DB8E',
    icon: (active: boolean) => (
      <svg className={`w-5 h-5 transition-all ${active ? 'scale-110' : ''}`} fill={active ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={active ? 0 : 1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
]

export default function BottomNav() {
  const { personType } = useDemoContext()

  const tabs = personType === 'juridica'
    ? TABS.filter(t => !t.libranzaOnly)
    : TABS

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#E8ECF2]"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="flex items-stretch h-16">
        {tabs.map(tab => (
          <NavLink
            key={tab.href}
            to={tab.href}
            end={tab.exact}
            className="flex-1 flex flex-col items-center justify-center gap-0.5 relative"
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-b-full" style={{ background: tab.color ?? '#00DB8E' }} />
                )}
                <span className={`transition-colors duration-150 ${isActive ? 'text-[#2A3036]' : 'text-gray-400'}`}>
                  {tab.icon(isActive)}
                </span>
                <span className={`text-[10px] font-semibold transition-colors duration-150 leading-tight ${isActive ? 'text-[#2A3036]' : 'text-gray-400'}`}>
                  {tab.label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
