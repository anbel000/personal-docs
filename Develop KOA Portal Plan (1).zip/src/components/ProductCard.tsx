import type { ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'

interface Stat {
  label: string
  value: string
}

interface ProductCardProps {
  icon: ReactNode
  iconBg?: string
  name: string
  stats: Stat[]
  href?: string
  locked?: boolean
  delay?: number
  accent?: string
}

export default function ProductCard({ icon, iconBg = 'bg-[#EFFFF7]', name, stats, href, locked = false, delay = 0, accent }: ProductCardProps) {
  const navigate = useNavigate()

  if (locked) {
    return (
      <div className="card-flat card-enter p-5 relative overflow-hidden" style={{ animationDelay: `${delay}s` }}>
        <div className="filter blur-sm select-none pointer-events-none">
          <div className="flex items-center gap-3 mb-5">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${iconBg}`}>{icon}</div>
            <p className="font-semibold text-[#2A3036] text-[15px]">{name}</p>
          </div>
          <div className="space-y-2.5">
            {stats.map(s => (
              <div key={s.label} className="flex justify-between">
                <span className="text-[13px] text-gray-400">{s.label}</span>
                <span className="font-figures text-[13px] font-semibold text-[#2A3036]">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center bg-white/70 rounded-[20px]">
          <span className="bg-[#0A1F44] text-white text-[10px] font-bold tracking-widest px-3.5 py-1.5 rounded-full uppercase">
            Pronto
          </span>
        </div>
      </div>
    )
  }

  return (
    <div
      className="card card-enter p-5 cursor-pointer relative overflow-hidden"
      style={{ animationDelay: `${delay}s` }}
      onClick={() => href && navigate(href)}
    >
      {accent && (
        <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px]" style={{ background: accent }} />
      )}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${iconBg}`}>{icon}</div>
          <p className="font-semibold text-[#2A3036] text-[16px]">{name}</p>
        </div>
        <div className="w-8 h-8 rounded-xl bg-[#F7F7F7] flex items-center justify-center">
          <svg className="w-4 h-4 text-[#2A3036]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
      <div className="space-y-2.5">
        {stats.map(s => (
          <div key={s.label} className="flex justify-between items-baseline">
            <span className="text-[13px] text-gray-400">{s.label}</span>
            <span className="font-figures text-[13px] font-semibold text-[#2A3036]">{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
