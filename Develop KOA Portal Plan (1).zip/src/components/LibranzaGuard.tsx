import type { ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import Btn from './Btn'

interface LibranzaGuardProps {
  children: ReactNode
}

export default function LibranzaGuard({ children }: LibranzaGuardProps) {
  const { personType } = useDemoContext()
  const navigate = useNavigate()

  if (personType === 'juridica') {
    return (
      <div className="max-w-2xl mx-auto py-8">
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-8 text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-[#3B82F6]/10 flex items-center justify-center mx-auto">
            <svg className="w-8 h-8 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <div>
            <h2 className="font-bold text-[20px] text-[#2A3036] mb-2">
              El crédito por libranza es un producto para personas naturales
            </h2>
            <p className="text-[14px] text-gray-500 leading-relaxed max-w-md mx-auto">
              La libranza descuenta la cuota de la nómina de una persona, por eso no aplica a empresas. Si te interesa un producto de financiación para tu empresa, tu asesor comercial puede ayudarte.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Btn variant="primary" size="md" onClick={() => navigate('/contactanos')}>
              Contactar a mi asesor
            </Btn>
            <Btn variant="secondary" size="md" onClick={() => navigate('/')}>
              Volver al inicio
            </Btn>
          </div>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
