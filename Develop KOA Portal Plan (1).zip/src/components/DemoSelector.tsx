import { useDemoContext, type Productos } from '../context/DemoContext'
import { useState } from 'react'

type Scenario = { id: Productos; label: string; sub: string; icon: React.ReactNode }

const SCENARIOS: Scenario[] = [
  {
    id: 'ambos',
    label: 'CDT + Libranza',
    sub: 'Ambos productos',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
      </svg>
    ),
  },
  {
    id: 'solo-cdt',
    label: 'Solo CDT',
    sub: 'Sin libranza',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
  },
  {
    id: 'solo-libranza',
    label: 'Solo Libranza',
    sub: 'Sin CDT',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    id: 'ninguno',
    label: 'Sin productos',
    sub: 'Cliente nuevo',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
]

export default function DemoSelector() {
  const { personType, productos, setPersonType, setProductos } = useDemoContext()
  const [open, setOpen] = useState(false)

  const current = SCENARIOS.find(s => s.id === productos) ?? SCENARIOS[0]
  const isDisabled = (id: Productos) =>
    personType === 'juridica' && (id === 'ambos' || id === 'solo-libranza')

  return (
    <div className="fixed bottom-20 right-3 sm:bottom-5 sm:right-5 z-50">
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 bg-white border border-[#E5E7EB] rounded-2xl shadow-lg px-3.5 py-2.5 cursor-pointer hover:shadow-xl transition-all"
        >
          <span className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#EF4444] bg-[#EF4444]/10 px-2 py-0.5 rounded-full">
            DEMO
          </span>
          <span className="text-[12px] font-semibold text-[#2A3036]">{current.label}</span>
          <svg className="w-3.5 h-3.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
          </svg>
        </button>
      )}

      {open && (
        <div className="bg-white border border-[#E5E7EB] rounded-2xl shadow-2xl w-[244px] overflow-hidden scale-in">
          <div
            className="flex items-center justify-between px-4 py-3 border-b border-[#E8ECF2]"
            style={{ background: '#06005A' }}
          >
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#EF4444] bg-[#EF4444]/20 px-2 py-0.5 rounded-full">
                DEMO
              </span>
              <span className="text-white text-[12px] font-semibold">Modo demo</span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer"
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>

          <div className="p-3 space-y-3.5">
            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2 px-0.5">Productos en Home</p>
              <div className="grid grid-cols-2 gap-1.5">
                {SCENARIOS.map(s => {
                  const disabled = isDisabled(s.id)
                  const active = productos === s.id
                  return (
                    <button
                      key={s.id}
                      onClick={() => !disabled && setProductos(s.id)}
                      disabled={disabled}
                      className={`flex flex-col items-start gap-1 px-3 py-2.5 rounded-xl border text-left transition-all ${
                        disabled
                          ? 'border-[#E8ECF2] bg-[#F9FAFB] opacity-40 cursor-not-allowed'
                          : active
                          ? 'border-[#0A1F44] bg-[#0A1F44] text-white cursor-pointer'
                          : 'border-[#E8ECF2] bg-white text-gray-600 hover:border-gray-300 cursor-pointer'
                      }`}
                    >
                      <span className={active ? 'text-[#00DB8E]' : 'text-gray-400'}>{s.icon}</span>
                      <span className="text-[11px] font-bold leading-none">{s.label}</span>
                      <span className={`text-[9px] leading-none ${active ? 'text-white/50' : 'text-gray-400'}`}>
                        {disabled ? 'Solo natural' : s.sub}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>

            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1.5 px-0.5">Persona</p>
              <div className="flex rounded-xl overflow-hidden border border-[#E8ECF2]">
                {(['natural', 'juridica'] as const).map(p => (
                  <button
                    key={p}
                    onClick={() => setPersonType(p)}
                    className={`flex-1 py-2 text-[11px] font-semibold transition-colors cursor-pointer ${
                      personType === p ? 'bg-[#0A1F44] text-white' : 'bg-white text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {p === 'natural' ? 'Natural' : 'Jurídica'}
                  </button>
                ))}
              </div>
              {personType === 'juridica' && (
                <p className="text-[9px] text-[#F59E0B] mt-1.5 px-0.5">
                  Jurídica solo puede tener CDT
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
