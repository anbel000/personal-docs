import type { ButtonHTMLAttributes, ReactNode } from 'react'

type Variant = 'primary' | 'mint' | 'secondary' | 'ghost' | 'danger'
type Size = 'sm' | 'md' | 'lg'

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  children: ReactNode
  loading?: boolean
}

const variantClasses: Record<Variant, string> = {
  primary:   'bg-gradient-to-br from-[#06005A] to-[#06005A] text-white hover:opacity-90 shadow-sm disabled:opacity-40',
  mint:      'bg-[#00DB8E] text-[#06005A] font-semibold hover:bg-[#00B572] btn-mint-glow disabled:opacity-40',
  secondary: 'bg-white text-[#2A3036] border border-[#E8ECF2] hover:bg-[#F7F7F7] shadow-sm disabled:opacity-40',
  ghost:     'bg-transparent text-[#2A3036] hover:bg-[#F7F7F7] disabled:opacity-40',
  danger:    'bg-[#EF4444] text-white hover:bg-red-600 shadow-sm disabled:opacity-40',
}

const sizeClasses: Record<Size, string> = {
  sm: 'text-[12px] px-3.5 py-2 rounded-xl gap-1.5',
  md: 'text-[13px] px-4.5 py-2.5 rounded-xl gap-2',
  lg: 'text-[14px] px-6 py-3 rounded-2xl gap-2',
}

export default function Btn({ variant = 'primary', size = 'md', children, loading, className = '', ...props }: BtnProps) {
  return (
    <button
      className={`inline-flex items-center justify-center font-semibold transition-all duration-150 cursor-pointer ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading && (
        <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      )}
      {children}
    </button>
  )
}
