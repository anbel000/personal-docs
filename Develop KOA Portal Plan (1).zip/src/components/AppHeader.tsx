import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import { clienteNatural, clienteJuridico } from '../data/mockData'
import NotificationsPanel from './NotificationsPanel'
import { notificaciones } from '../data/mockData'

interface AppHeaderProps {
  onMenuClick: () => void
}

export default function AppHeader({ onMenuClick }: AppHeaderProps) {
  const { personType } = useDemoContext()
  const navigate = useNavigate()
  const [avatarMenuOpen, setAvatarMenuOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)

  const cliente = personType === 'juridica' ? clienteJuridico : clienteNatural
  const nombre = personType === 'juridica' ? (clienteJuridico as typeof clienteJuridico).razonSocial.split(' ')[0] : 'Andrés'
  const iniciales = personType === 'juridica' ? 'CA' : 'AB'
  const correo = cliente.correoMascarado
  const hasUnread = notificaciones.some(n => !n.leida)
  const unreadCount = notificaciones.filter(n => !n.leida).length

  return (
    <>
      <header className="h-16 glass border-b border-white/60 flex items-center px-5 gap-4 flex-shrink-0 z-30 sticky top-0">
        {/* Mobile hamburger */}
        <button
          onClick={onMenuClick}
          className="lg:hidden w-9 h-9 rounded-xl flex items-center justify-center hover:bg-black/6 transition-colors cursor-pointer text-[#2A3036]"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Actions */}
        <div className="flex items-center gap-1.5">
          {/* Notifications */}
          <button
            onClick={() => setNotifOpen(true)}
            className="relative w-9 h-9 rounded-xl flex items-center justify-center hover:bg-black/6 transition-colors cursor-pointer text-gray-500 hover:text-[#2A3036]"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            {hasUnread && (
              <span className="absolute top-1 right-1 min-w-[16px] h-4 bg-[#EF4444] rounded-full text-[9px] font-bold text-white flex items-center justify-center px-0.5 border-2 border-white">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Divider */}
          <div className="w-px h-5 bg-gray-200 mx-1" />

          {/* Avatar + dropdown */}
          <div className="relative">
            <button
              onClick={() => setAvatarMenuOpen(!avatarMenuOpen)}
              className="flex items-center gap-2.5 pl-1 pr-3 py-1.5 rounded-2xl hover:bg-black/5 transition-colors cursor-pointer"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#06005A] to-[#06005A] flex items-center justify-center text-[#00DB8E] font-bold text-[12px]">
                {iniciales}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-[13px] font-semibold text-[#2A3036] leading-tight">{nombre}</p>
                <p className="text-[11px] text-gray-400 leading-tight font-figures">{correo}</p>
              </div>
              <svg className={`w-3.5 h-3.5 text-gray-400 transition-transform duration-200 ${avatarMenuOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {avatarMenuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setAvatarMenuOpen(false)} />
                <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-[#E8ECF2] z-50 overflow-hidden scale-in">
                  {/* User info */}
                  <div className="px-4 py-3.5 bg-gradient-to-br from-[#06005A] to-[#06005A]">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-[#00DB8E] font-bold text-[14px]">
                        {iniciales}
                      </div>
                      <div>
                        <p className="text-white font-semibold text-[13px] leading-tight">{nombre}</p>
                        <p className="text-white/50 text-[11px] font-figures leading-tight">{correo}</p>
                      </div>
                    </div>
                  </div>

                  <div className="py-1.5">
                    <button
                      onClick={() => { setAvatarMenuOpen(false); navigate('/mis-datos') }}
                      className="w-full text-left px-4 py-2.5 text-[13px] text-gray-700 hover:bg-[#F7F7F7] transition-colors cursor-pointer flex items-center gap-2.5"
                    >
                      <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                      Mi perfil
                    </button>
                    <button
                      onClick={() => { setAvatarMenuOpen(false); navigate('/seguridad') }}
                      className="w-full text-left px-4 py-2.5 text-[13px] text-gray-700 hover:bg-[#F7F7F7] transition-colors cursor-pointer flex items-center gap-2.5"
                    >
                      <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                      Seguridad
                    </button>
                  </div>

                  <div className="border-t border-[#E8ECF2] py-1.5">
                    <button
                      className="w-full text-left px-4 py-2.5 text-[13px] text-[#EF4444] hover:bg-red-50 transition-colors cursor-pointer flex items-center gap-2.5"
                      onClick={() => setAvatarMenuOpen(false)}
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                      Cerrar sesión
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      <NotificationsPanel open={notifOpen} onClose={() => setNotifOpen(false)} />
    </>
  )
}
