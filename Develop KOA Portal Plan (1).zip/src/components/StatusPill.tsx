type Variant =
  | 'activo'
  | 'en-mora'
  | 'al-dia'
  | 'pendiente'
  | 'en-proceso'
  | 'resuelto'
  | 'terminado'
  | 'proximo'
  | 'error'

interface StatusPillProps {
  variant: Variant
  label?: string
}

const config: Record<Variant, { dot: string; bg: string; text: string; defaultLabel: string; pulse?: boolean }> = {
  'activo':     { dot: 'bg-[#00DB8E]', bg: 'bg-[#EFFFF7]', text: 'text-[#005E3C]', defaultLabel: 'Activo', pulse: true },
  'en-mora':    { dot: 'bg-[#EF4444]', bg: 'bg-[#EF4444]/12', text: 'text-[#DC2626]', defaultLabel: 'En mora' },
  'al-dia':     { dot: 'bg-[#10B981]', bg: 'bg-[#10B981]/12', text: 'text-[#065F46]', defaultLabel: 'Al día', pulse: true },
  'pendiente':  { dot: 'bg-[#F59E0B]', bg: 'bg-[#F59E0B]/12', text: 'text-[#92400E]', defaultLabel: 'Pendiente' },
  'en-proceso': { dot: 'bg-[#F59E0B]', bg: 'bg-[#F59E0B]/12', text: 'text-[#92400E]', defaultLabel: 'En proceso' },
  'resuelto':   { dot: 'bg-[#3B82F6]', bg: 'bg-[#3B82F6]/12', text: 'text-[#1E40AF]', defaultLabel: 'Resuelto' },
  'terminado':  { dot: 'bg-[#9CA3AF]', bg: 'bg-gray-100',      text: 'text-gray-500',  defaultLabel: 'Terminado' },
  'proximo':    { dot: 'bg-[#3B82F6]', bg: 'bg-[#3B82F6]/12', text: 'text-[#1E40AF]', defaultLabel: 'Próximo' },
  'error':      { dot: 'bg-[#EF4444]', bg: 'bg-[#EF4444]/12', text: 'text-[#DC2626]', defaultLabel: 'Error' },
}

export default function StatusPill({ variant, label }: StatusPillProps) {
  const c = config[variant]
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c.dot} ${c.pulse ? 'mint-pulse' : ''}`} />
      {label ?? c.defaultLabel}
    </span>
  )
}
