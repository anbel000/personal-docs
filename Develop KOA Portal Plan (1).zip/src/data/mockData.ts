export const clienteNatural = {
  nombre: 'Andrés Beltrán',
  iniciales: 'AB',
  ultimaConexion: '12/08/2026 4:32 p. m.',
  correoMascarado: 'a****s@correo.com',
}

export const clienteJuridico = {
  razonSocial: 'Comercializadora Andina S.A.S.',
  nit: '900.123.456-7',
  iniciales: 'CA',
  ultimaConexion: '12/08/2026 4:32 p. m.',
  correoMascarado: 'c****a@empresa.com',
}

export interface Credito {
  id: string
  numeroCompleto: string
  numeroMascarado: string
  pagaduria: string
  estado: 'al-dia' | 'en-mora' | 'activo'
  saldo: number
  cuotaMensual: number
  cuotaActual: number
  totalCuotas: number
  montoDesembolsado: number
  fechaDesembolso: string
  plazoMeses: number
  tasa: string
  cuotasPagadas: number
  cuotasPendientes: number
  fechaUltimaCuota: string
}

export const creditos: Credito[] = [
  {
    id: '4821',
    numeroCompleto: '0034821',
    numeroMascarado: '···· 4821',
    pagaduria: 'Secretaría de Educación',
    estado: 'al-dia',
    saldo: 9480200,
    cuotaMensual: 742500,
    cuotaActual: 14,
    totalCuotas: 60,
    montoDesembolsado: 18000000,
    fechaDesembolso: '15 MAR 2021',
    plazoMeses: 60,
    tasa: '18,45',
    cuotasPagadas: 14,
    cuotasPendientes: 46,
    fechaUltimaCuota: '15 FEB 2031',
  },
  {
    id: '7350',
    numeroCompleto: '0037350',
    numeroMascarado: '···· 7350',
    pagaduria: 'Alcaldía de Medellín',
    estado: 'al-dia',
    saldo: 4200200,
    cuotaMensual: 542400,
    cuotaActual: 31,
    totalCuotas: 48,
    montoDesembolsado: 8000000,
    fechaDesembolso: '10 JUN 2023',
    plazoMeses: 48,
    tasa: '16,80',
    cuotasPagadas: 31,
    cuotasPendientes: 17,
    fechaUltimaCuota: '10 MAY 2027',
  },
  {
    id: '2893',
    numeroCompleto: '0032893',
    numeroMascarado: '···· 2893',
    pagaduria: 'Gobernación de Antioquia',
    estado: 'al-dia',
    saldo: 12500000,
    cuotaMensual: 980000,
    cuotaActual: 8,
    totalCuotas: 72,
    montoDesembolsado: 20000000,
    fechaDesembolso: '01 ENE 2026',
    plazoMeses: 72,
    tasa: '17,20',
    cuotasPagadas: 8,
    cuotasPendientes: 64,
    fechaUltimaCuota: '01 DIC 2031',
  },
]

export const creditosTerminados = [
  {
    id: 'term-4821',
    numeroMascarado: '···· 4821',
    montoDesembolsado: 18000000,
    periodoInicio: 'MAR 2021',
    periodoFin: 'ENE 2024',
    pagaduria: 'Secretaría de Educación',
  },
  {
    id: 'term-7350',
    numeroMascarado: '···· 7350',
    montoDesembolsado: 4200000,
    periodoInicio: 'ENE 2019',
    periodoFin: 'FEB 2022',
    pagaduria: 'Alcaldía de Medellín',
  },
]

function generarPagos() {
  const pagos = []
  const meses = [
    'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC',
    'ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL',
  ]
  const años = [2025, 2025, 2025, 2025, 2025, 2025, 2025, 2026, 2026, 2026, 2026, 2026, 2026, 2026]
  const dias = [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]
  let saldo = 11200000
  for (let i = 13; i >= 0; i--) {
    const valor = 700000 + Math.floor(Math.random() * 80000)
    const capital = Math.floor(valor * 0.65)
    const intereses = Math.floor(valor * 0.30)
    const otros = valor - capital - intereses
    pagos.push({
      id: `pago-${i}`,
      fecha: `${dias[i]} ${meses[i]} ${años[i]}`,
      año: años[i],
      valor,
      capital,
      intereses,
      otros,
      saldoDespues: saldo,
    })
    saldo += Math.floor(capital * 1.1)
  }
  return pagos
}

export const pagosCredito4821 = generarPagos()

function generarPlanCuotas() {
  const cuotas = []
  const meses = ['MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC','ENE','FEB']
  let saldo = 18000000
  let año = 2021
  let mesIdx = 0
  for (let i = 1; i <= 60; i++) {
    const cuotaTotal = 742500
    const intereses = Math.round(saldo * 0.01537)
    const capital = cuotaTotal - intereses
    saldo = Math.max(0, saldo - capital)
    cuotas.push({
      numero: i,
      fecha: `15 ${meses[mesIdx]} ${año}`,
      capital,
      intereses,
      cuotaTotal,
      saldo,
    })
    mesIdx++
    if (mesIdx >= 12) { mesIdx = 0; año++ }
  }
  return cuotas
}

export const planCuotasCredito4821 = generarPlanCuotas()

export const documentos = [
  { id: 'd1', nombre: 'Extracto mensual', producto: 'Libranza', origen: 'Crédito ···· 4821', fecha: '05 AGO 2026', tipo: 'extracto', estado: 'disponible' },
  { id: 'd2', nombre: 'Plan de pagos', producto: 'Libranza', origen: 'Crédito ···· 4821', fecha: '02 AGO 2026', tipo: 'plan', estado: 'disponible' },
  { id: 'd3', nombre: 'Certificación de saldo', producto: 'Libranza', origen: 'Crédito ···· 4821', fecha: '28 JUL 2026', tipo: 'certificacion', estado: 'disponible' },
  { id: 'd4', nombre: 'Carta de condiciones', producto: 'Libranza', origen: 'Crédito ···· 7350', fecha: '21 JUL 2026', tipo: 'carta', estado: 'disponible' },
  { id: 'd5', nombre: 'Certificado CDT', producto: 'CDT', origen: 'CDT ···· 9012', fecha: '15 JUL 2026', tipo: 'certificado', estado: 'disponible' },
  { id: 'd6', nombre: 'Amortización', producto: 'Libranza', origen: 'Crédito ···· 4821', fecha: '10 JUL 2026', tipo: 'amortizacion', estado: 'disponible' },
  { id: 'd7', nombre: 'Extracto mensual', producto: 'Libranza', origen: 'Crédito ···· 4821', fecha: '05 JUL 2026', tipo: 'extracto', estado: 'disponible' },
  { id: 'd8', nombre: 'Paz y salvo', producto: 'Libranza', origen: 'Crédito ···· 3344', fecha: '30 JUN 2026', tipo: 'paz-salvo', estado: 'disponible' },
]

export const documentosEnProceso = [
  {
    id: 'ep1',
    nombre: 'Certificación de saldo',
    producto: 'Libranza',
    origen: 'Crédito ···· 7350',
    fechaSolicitud: '11 AGO 2026',
    radicado: 'SOL-2026-004821',
    estado: 'en-proceso',
  },
]

export const notificaciones = [
  { id: 'n1', titulo: 'Tu certificación de saldo está en proceso', detalle: 'Crédito ···· 7350 · Libranza', tiempo: 'Hace 2 horas', leida: false, tipo: 'proceso' },
  { id: 'n2', titulo: 'Descuento aplicado por $ 742.500', detalle: 'Crédito ···· 4821 · Libranza', tiempo: 'Ayer', leida: false, tipo: 'pago' },
  { id: 'n3', titulo: 'Completa tu información financiera', detalle: 'Tu perfil está al 80 %', tiempo: 'Hace 3 días', leida: true, tipo: 'aviso' },
  { id: 'n4', titulo: 'Tu extracto de julio está disponible', detalle: 'Crédito ···· 4821 · Libranza', tiempo: 'Hace 6 días', leida: true, tipo: 'documento' },
  { id: 'n5', titulo: 'Actualizamos nuestros términos y condiciones', detalle: 'KOA Compañía de Financiamiento', tiempo: 'Hace 12 días', leida: true, tipo: 'info' },
]

export const pendientes = [
  { id: 'p1', texto: 'Completa tu información financiera', href: '/mis-datos', icono: 'perfil' },
]

export const kpiLibranza = {
  deudaTotal: 26180600,
  creditosActivos: 3,
}

export const kpiCDT = {
  inversionTotal: 59000000,
  rendimientos: 4607900,
  tasaPonderada: '11,68',
  proximoVencimiento: { numeroMascarado: '···· 9012', dias: 47, fecha: '30 SEP 2026' },
}

export interface CDT {
  id: string
  numeroCompleto: string
  numeroMascarado: string
  proposito?: string
  estado: 'activo' | 'terminado'
  renovacionAutomatica: boolean
  montoInvertido: number
  rendimientos: number
  fechaVencimiento: string
  progresoPct: number
  diasRestantes?: number
  fechaApertura: string
  tasa: string
  periodicidad: string
  cuentaBanco: string
  cuentaTipo: string
  cuentaNumeroMascarado: string
  cuentaInscrita: boolean
  cuentaEstado: 'sin-inscribir' | 'en-validacion' | 'validada' | 'rechazada'
}

export const cdts: CDT[] = [
  {
    id: '9012',
    numeroCompleto: '00039012',
    numeroMascarado: '···· 9012',
    proposito: 'Fondo de emergencia',
    estado: 'activo',
    renovacionAutomatica: true,
    montoInvertido: 25000000,
    rendimientos: 1940300,
    fechaVencimiento: '30 SEP 2026',
    progresoPct: 72,
    diasRestantes: 47,
    fechaApertura: '01 OCT 2025',
    tasa: '11,80',
    periodicidad: 'Al vencimiento',
    cuentaBanco: 'Bancolombia',
    cuentaTipo: 'Cuenta de ahorros',
    cuentaNumeroMascarado: '**** **** 4821',
    cuentaInscrita: true,
    cuentaEstado: 'validada',
  },
  {
    id: '5567',
    numeroCompleto: '00035567',
    numeroMascarado: '···· 5567',
    estado: 'activo',
    renovacionAutomatica: false,
    montoInvertido: 17000000,
    rendimientos: 1244200,
    fechaVencimiento: '12 DIC 2026',
    progresoPct: 41,
    diasRestantes: 120,
    fechaApertura: '12 ABR 2026',
    tasa: '11,80',
    periodicidad: 'Mensual',
    cuentaBanco: 'Bancolombia',
    cuentaTipo: 'Cuenta de ahorros',
    cuentaNumeroMascarado: '**** **** 4821',
    cuentaInscrita: true,
    cuentaEstado: 'en-validacion',
  },
  {
    id: '3421',
    numeroCompleto: '00033421',
    numeroMascarado: '···· 3421',
    proposito: 'Educación 2027',
    estado: 'activo',
    renovacionAutomatica: true,
    montoInvertido: 10000000,
    rendimientos: 412300,
    fechaVencimiento: '28 FEB 2027',
    progresoPct: 25,
    diasRestantes: 198,
    fechaApertura: '28 AGO 2026',
    tasa: '12,20',
    periodicidad: 'Al vencimiento',
    cuentaBanco: 'Davivienda',
    cuentaTipo: 'Cuenta de ahorros',
    cuentaNumeroMascarado: '**** **** 2290',
    cuentaInscrita: false,
    cuentaEstado: 'rechazada',
  },
  {
    id: '7108',
    numeroCompleto: '00037108',
    numeroMascarado: '···· 7108',
    estado: 'activo',
    renovacionAutomatica: false,
    montoInvertido: 7000000,
    rendimientos: 310800,
    fechaVencimiento: '15 NOV 2026',
    progresoPct: 55,
    diasRestantes: 93,
    fechaApertura: '15 MAY 2026',
    tasa: '11,50',
    periodicidad: 'Mensual',
    cuentaBanco: 'Bancolombia',
    cuentaTipo: 'Cuenta de ahorros',
    cuentaNumeroMascarado: '**** **** 4821',
    cuentaInscrita: false,
    cuentaEstado: 'sin-inscribir',
  },
]

export const cdtsTerminados: CDT[] = [
  {
    id: '2231',
    numeroCompleto: '00032231',
    numeroMascarado: '···· 2231',
    estado: 'terminado',
    renovacionAutomatica: false,
    montoInvertido: 8000000,
    rendimientos: 612400,
    fechaVencimiento: '15 FEB 2026',
    progresoPct: 100,
    fechaApertura: '15 AGO 2025',
    tasa: '10,50',
    periodicidad: 'Al vencimiento',
    cuentaBanco: 'Bancolombia',
    cuentaTipo: 'Cuenta de ahorros',
    cuentaNumeroMascarado: '**** **** 4821',
    cuentaInscrita: true,
    cuentaEstado: 'validada',
  },
]

export function formatPesos(valor: number): string {
  return '$ ' + valor.toLocaleString('es-CO').replace(/,/g, '.')
}
