---
title: Prompt 00 — Guidelines del archivo de Figma Make
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 00 · Guidelines

**No es un prompt.** Se pega en el panel **Guidelines** del archivo de Figma Make, antes de ejecutar el prompt `01`. Son las reglas que Make aplica a todo lo que genere en ese archivo.

---

```markdown
# Portal KOA — Reglas del sistema

Portal transaccional de clientes de KOA Compañía de Financiamiento, entidad
financiera colombiana vigilada por la Superintendencia Financiera. Todo el
contenido va en español de Colombia.

## Color

- Azul de marca: #0A1F44 (inicio) y #06005A (fin). Solo en degradado vertical
  sobre la barra lateral, y como color de títulos.
- Menta de acento: #00D18C. Estado activo, foco, indicadores.
- Verde de texto sobre fondo menta claro: #007A54. Nunca poner texto menta
  sobre blanco.
- Fondo de aplicación: #F9FAFB. Tarjetas blancas con borde #E5E7EB.
- Semánticos: éxito #10B981, advertencia #F59E0B, error #EF4444, info #3B82F6.
- La barra lateral es la única superficie oscura. Todo lo demás es claro.

## Tipografía

- Montserrat para todo el texto. Pesos 400, 500, 600, 700.
- Space Grotesk exclusivamente para cifras y códigos: montos, saldos, tasas,
  porcentajes, números de obligación, fechas en formato numérico.
- Un monto va en Space Grotesk; su etiqueta va en Montserrat. Sin excepciones.
- Tamaño mínimo de texto corriente: 13px. Cuerpo principal 15px. Cifras
  destacadas entre 28 y 36px. Etiquetas en versalitas: 10 u 11px.

## Forma

- Tarjetas y contenedores: radio 16px. Botones, campos y píldoras de
  navegación: radio 12px. Píldoras de estado: radio completo.
- Tarjetas sin sombra en reposo. En hover: sombra suave y desplazamiento
  de 1px hacia arriba.
- Cabezote de 64px. Barra lateral de 256px expandida y 60px colapsada.
- Relleno del área de contenido: 24px.

## Movimiento

- Entradas: opacidad 0 a 1 y desplazamiento vertical de 14px a 0, en 0.35s,
  con curva [0.22, 1, 0.36, 1]. Escalonar 0.05s entre tarjetas hermanas.
- Transiciones de color: 150ms.
- Solo el punto de estado en vivo pulsa de forma continua. Nada más pulsa.

## Moneda, fechas y cifras

- Pesos colombianos con separador de miles de punto y sin decimales:
  $ 9.480.200. Los porcentajes con dos decimales: 18,45 %.
- Fechas largas: 15 AGO 2026. Fechas cortas: 15/08/2026.
- Meses en versalitas de tres letras: ENE FEB MAR ABR MAY JUN JUL AGO SEP
  OCT NOV DIC.

## Redacción

- Tuteo colombiano. Cercano y claro, nunca informal en exceso.
- Prohibido el voseo rioplatense: nunca "ingresá", "cambiá", "personalizá".
  Se escribe "ingresa", "cambia", "personaliza".
- Nada de emojis en la interfaz.
- Los estados vacíos explican por qué está vacío y qué puede hacer el cliente.
  Nunca solo "Sin resultados".
- Los montos de deuda no se acompañan de lenguaje celebratorio.

## Estructura

- Layout responsive con flexbox y grid. Posicionamiento absoluto solo cuando
  no haya alternativa.
- Un componente por archivo. Los datos simulados en archivos aparte.
- Todo dato mostrado es simulado. No inventar cifras nuevas si el prompt ya
  las trae: usar exactamente las del prompt.

## Reglas de producto

- Libranza es un producto exclusivo de personas naturales. Nunca aparece en
  la interfaz de una persona jurídica.
- Una deuda y una inversión no se suman jamás en una misma cifra.
- El estado de mora siempre es visible cuando existe. No se atenúa ni se
  esconde.
- Los sellos "Vigilado Superintendencia Financiera de Colombia" y "Fogafin"
  van en el pie de la barra lateral y son permanentes.
```

---

## Por qué estas reglas y no otras

- **El reparto tipográfico** es la firma del sistema heredado de K Dash. Sin la regla explícita, Make mezcla las dos familias.
- **La prohibición del voseo** viene de un defecto real del portal CDT actual, que tiene textos en voseo rioplatense mezclados con tuteo colombiano.
- **La prohibición de sumar deuda con inversión** evita el error de diseño más caro de un portal multiproducto.
- **El límite de un solo elemento que pulsa** evita que la interfaz se lea como un tablero de alertas.
