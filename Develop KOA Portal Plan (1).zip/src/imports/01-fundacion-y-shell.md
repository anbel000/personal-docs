---
title: Prompt 01 — Fundación y shell
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 01 · Fundación y shell

Se ejecuta en un archivo **vacío**, con las Guidelines ya pegadas. Es el único prompt largo: fija la estructura de todo el proyecto.

---

## Prompt

```
TAREA
Construye la base de Portal KOA: el sistema de diseño, el armazón de la
aplicación, la navegación, el enrutamiento y los datos simulados. No
construyas todavía el contenido de ninguna pantalla: cada ruta muestra un
marcador de posición con su nombre.

CONTEXTO
Portal KOA es el canal digital de autogestión de KOA Compañía de
Financiamiento, entidad financiera colombiana. Sus usuarios son clientes,
no operadores: entran pocas veces al mes, desde el celular o el computador,
a consultar sus productos y descargar documentos. El portal aloja varios
productos financieros y debe poder recibir productos nuevos sin rehacerse.
El cliente ya inició sesión: el prototipo arranca dentro del portal.

ELEMENTOS

1. Sistema de diseño en un archivo de tokens
   - Colores: navy #0A1F44 y #06005A, menta #00D18C, verde texto #007A54,
     fondo #F9FAFB, borde #E5E7EB, éxito #10B981, advertencia #F59E0B,
     error #EF4444, info #3B82F6.
   - Tipografías Montserrat (texto) y Space Grotesk (cifras) desde Google Fonts.
   - Radios: 16px contenedores, 12px controles, completo en píldoras.

2. Componentes base reutilizables, uno por archivo
   - StatusPill: píldora con punto de color. Variantes: activo, en mora,
     al día, pendiente, en proceso, resuelto, terminado, próximo, error.
   - KpiCard: icono en cuadro de color, cifra grande en Space Grotesk,
     etiqueta debajo, chip opcional.
   - ProductCard: tarjeta de producto con nombre, icono, dos o tres cifras
     clave y flecha de entrada. Estado bloqueado con el contenido
     desenfocado detrás y etiqueta PRONTO.
   - EmptyState: icono en cuadro redondeado, título, descripción y acción.
   - SectionHeader: título de 24px, subtítulo y acciones a la derecha.
   - Btn: variantes primary (navy), mint, secondary, ghost. Tamaños sm, md, lg.
   - FilterChips: grupo de píldoras, la activa en navy sólido.
   - LoadingSkeleton y SidePanel deslizante desde la derecha.

3. Armazón de la aplicación
   - Barra lateral izquierda de 256px con degradado vertical #0A1F44 a
     #06005A, colapsable a 60px con el estado recordado. Bajo 1024px se
     convierte en cajón lateral.
   - Cabezote blanco de 64px, fijo: botón de menú en móvil, saludo "Hola,
     Andrés" con la última conexión "Última conexión 12/08/2026 4:32 p. m.",
     campana de notificaciones con punto rojo, icono de ayuda, y avatar
     cuadrado redondeado navy con las iniciales en menta más menú de cuenta
     con Mi perfil, Seguridad y Cerrar sesión.
   - Barra de miga de pan blanca bajo el cabezote.
   - Área de contenido con fondo #F9FAFB y relleno de 24px.
   - Pie de la barra lateral con los sellos "Vigilado Superintendencia
     Financiera de Colombia" y "Fogafin", en texto discreto.

4. Navegación de la barra lateral, agrupada con títulos en versalitas
   de 9px con letter-spacing amplio
   - PRINCIPAL: Inicio
   - MIS PRODUCTOS: Libranza, CDT, Cuenta de Ahorros
   - MI CUENTA: Mis datos, Documentos, Seguridad
   - AYUDA: Contáctanos, Educación financiera
   El ítem activo lleva fondo menta al 12% y una barra vertical menta de 2px
   pegada al borde izquierdo. Un ítem marcado como próximo va al 35% de
   opacidad, sin acción, con la etiqueta PRONTO.

5. Rutas, todas con marcador de posición
   /  /libranza  /libranza/credito/:id  /cdt  /cdt/:id
   /mis-datos  /documentos  /seguridad  /contactanos  /educacion-financiera

6. Selector de demostración
   Control flotante fijo abajo a la derecha, compacto, con la etiqueta DEMO
   y dos interruptores: "Fase 1 / Fase 2" y "Natural / Jurídica".
   Vive en un único archivo y se monta en un único punto del layout.

7. Datos simulados en un archivo aparte
   Cliente natural: Andrés Beltrán, dos créditos de libranza y dos CDT.
   Cliente jurídico: Comercializadora Andina S.A.S., un CDT.

COMPORTAMIENTO
- El selector de demostración controla qué productos existen:
  Fase 1 + Natural  -> Libranza disponible. CDT en estado PRONTO.
  Fase 2 + Natural  -> Libranza y CDT disponibles.
  Fase 1 + Jurídica -> ningún producto disponible.
  Fase 2 + Jurídica -> solo CDT. Libranza NO aparece en la navegación.
- Cuenta de Ahorros siempre está en estado PRONTO.
- Al cambiar de tipo de persona cambian el nombre del cabezote y el avatar.
- La barra lateral recuerda si quedó colapsada.
- Las tarjetas entran con opacidad y desplazamiento vertical escalonados.

RESTRICCIONES
- Español de Colombia. Tuteo. Sin voseo rioplatense. Sin emojis.
- Montserrat para texto, Space Grotesk para toda cifra.
- Responsive real: móvil desde 360px, tableta y escritorio.
- El selector de demostración no debe filtrarse a ninguna pantalla: las
  pantallas leen el estado, nunca dibujan el control.
- Un componente por archivo. Datos simulados fuera de los componentes.
- No construyas contenido de pantallas todavía.
```

---

## Cómo verificar

- [ ] La barra lateral tiene el degradado navy y colapsa a 60 px conservando el estado al recargar.
- [ ] `Cuenta de Ahorros` aparece atenuada con la etiqueta `PRONTO` y no navega.
- [ ] Con **Fase 2 + Jurídica**, `Libranza` **desaparece** de la navegación — no queda deshabilitada.
- [ ] Con **Fase 1 + Natural**, `CDT` aparece en estado `PRONTO`.
- [ ] Toda cifra visible está en Space Grotesk y toda etiqueta en Montserrat.
- [ ] Los sellos regulatorios están en el pie de la barra lateral.
- [ ] El selector `DEMO` está en un solo archivo.
- [ ] En 360 px de ancho la barra lateral es un cajón y el cabezote tiene botón de menú.

## Si algo falla

| Síntoma | Ajuste |
|---|---|
| Mezcla las tipografías | *"Todas las cifras, montos, tasas y fechas numéricas deben usar Space Grotesk. Solo el texto usa Montserrat."* |
| Deja `Libranza` deshabilitada en jurídica | *"Con persona jurídica, Libranza no debe existir en la navegación. Elimínala del arreglo, no la deshabilites."* |
| El selector `DEMO` aparece dentro de las pantallas | *"El selector DEMO se monta una sola vez en el layout raíz."* |
