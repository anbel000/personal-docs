import { useState } from 'react'
import {
  PieChart, Pie, Cell, Tooltip as ReTooltip, ResponsiveContainer,
  XAxis, YAxis, CartesianGrid, Area, AreaChart,
} from 'recharts'
import { formatPesos } from '../data/mockData'

const PALETTE = ['#06005A', '#3D8BF2', '#00D09C', '#F59E0B', '#EF4444']

const dataDonut = [
  { nombre: 'Fondo de emergencia', valor: 25000000 },
  { nombre: 'CDT ···· 5567', valor: 17000000 },
  { nombre: 'Viaje Europa 2027', valor: 10000000 },
  { nombre: 'CDT ···· 7108', valor: 7000000 },
]

const dataMensual = [
  { mes: 'Oct', rendimiento: 241000 },
  { mes: 'Nov', rendimiento: 245800 },
  { mes: 'Dic', rendimiento: 252100 },
  { mes: 'Ene', rendimiento: 258400 },
  { mes: 'Feb', rendimiento: 261700 },
  { mes: 'Mar', rendimiento: 268000 },
  { mes: 'Abr', rendimiento: 275300 },
  { mes: 'May', rendimiento: 280100 },
  { mes: 'Jun', rendimiento: 287500 },
  { mes: 'Jul', rendimiento: 293800 },
  { mes: 'Ago', rendimiento: 301200 },
]

const dataAnual = [
  { mes: '2022', rendimiento: 1840000 },
  { mes: '2023', rendimiento: 2210000 },
  { mes: '2024', rendimiento: 2780000 },
  { mes: '2025', rendimiento: 3050000 },
  { mes: '2026', rendimiento: 3184500 },
]

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0A1F44] text-white rounded-xl px-3 py-2 text-[12px] shadow-lg">
      <p className="font-semibold">{label}</p>
      <p className="font-figures">{formatPesos(payload[0].value)}</p>
    </div>
  )
}

function DonutTooltip({ active, payload }: { active?: boolean; payload?: { name: string; value: number }[] }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0A1F44] text-white rounded-xl px-3 py-2 text-[12px] shadow-lg">
      <p className="font-semibold">{payload[0].name}</p>
      <p className="font-figures">{formatPesos(payload[0].value)}</p>
    </div>
  )
}

export default function CDTGraficas({ showKPIs = false }: { showKPIs?: boolean }) {
  const [filtro, setFiltro] = useState<'mensual' | 'anual'>('mensual')
  const [infoOpen, setInfoOpen] = useState(false)
  const data = filtro === 'mensual' ? dataMensual : dataAnual
  const total = dataDonut.reduce((s, d) => s + d.valor, 0)

  return (
    <div className="space-y-4">
      {showKPIs && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl p-4 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}>
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#3B82F6]/10 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-white/40 mb-1">Capital invertido</p>
            <p className="font-figures text-[24px] font-black text-white leading-none">$ 59.000.000</p>
            <p className="text-[11px] text-white/40 mt-1.5">4 CDT activos</p>
          </div>
          <div className="rounded-2xl p-4 relative overflow-hidden bg-[#EFFFF7] border border-[#00DB8E]/25">
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#00DB8E]/15 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#005E3C]/60 mb-1">Rendimientos acumulados</p>
            <p className="font-figures text-[24px] font-black text-[#005E3C] leading-none">$ 4.607.900</p>
            <p className="text-[11px] text-[#005E3C]/60 mt-1.5">Desde apertura</p>
          </div>
          <div className="rounded-2xl p-4 relative overflow-hidden bg-[#EFF6FF] border border-[#3B82F6]/20">
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#3B82F6]/10 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#3B82F6]/60 mb-1">Tasa ponderada</p>
            <p className="font-figures text-[24px] font-black text-[#1E40AF] leading-none">11,68 %</p>
            <p className="text-[11px] text-[#3B82F6]/60 mt-1.5">E.A. promedio</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Donut */}
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="font-semibold text-[15px] text-[#2A3036]">Composición</p>
              <p className="text-[11px] text-gray-400 mt-0.5">Distribución del capital</p>
            </div>
            <button
              onClick={() => setInfoOpen(!infoOpen)}
              className="w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center text-gray-400 hover:bg-gray-200 cursor-pointer"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 16v-4m0-4h.01" /></svg>
            </button>
          </div>

          {infoOpen && (
            <div className="bg-[#0A1F44]/5 rounded-xl p-3 mb-4 text-[12px] text-gray-600 leading-relaxed">
              Muestra cómo está distribuido tu capital entre los CDTs activos, sin incluir rendimientos.
            </div>
          )}

          <div className="relative h-40">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={dataDonut} dataKey="valor" nameKey="nombre" innerRadius="58%" outerRadius="80%" paddingAngle={3}>
                  {dataDonut.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
                </Pie>
                <ReTooltip content={<DonutTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <p className="text-[10px] text-gray-400">Total</p>
              <p className="font-figures font-bold text-[13px] text-[#2A3036]">{formatPesos(total)}</p>
            </div>
          </div>

          <div className="space-y-2 mt-3">
            {dataDonut.map((d, i) => (
              <div key={d.nombre} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: PALETTE[i % PALETTE.length] }} />
                <span className="text-[12px] text-gray-500 flex-1 truncate">{d.nombre}</span>
                <span className="font-figures text-[12px] font-semibold text-[#2A3036] flex-shrink-0">{Math.round(d.valor / total * 100)} %</span>
              </div>
            ))}
          </div>
        </div>

        {/* Area chart */}
        <div className="bg-white rounded-2xl border border-[#E5E7EB] p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold text-[15px] text-[#2A3036]">Rendimientos</p>
            <div className="flex rounded-xl border border-[#E5E7EB] overflow-hidden">
              {(['mensual', 'anual'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setFiltro(f)}
                  className={`px-3 py-1.5 text-[11px] font-semibold capitalize transition-colors cursor-pointer ${
                    filtro === f ? 'bg-[#0A1F44] text-white' : 'bg-white text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  {f === 'mensual' ? 'Mensual' : 'Anual'}
                </button>
              ))}
            </div>
          </div>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="gradRend" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D09C" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#00D09C" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="mes" tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <ReTooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="rendimiento" stroke="#00D09C" strokeWidth={2.5} fill="url(#gradRend)" dot={false} activeDot={{ r: 5, fill: '#00D09C' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  )
}
