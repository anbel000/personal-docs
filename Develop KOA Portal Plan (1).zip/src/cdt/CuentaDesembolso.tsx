import { useState } from 'react'
import Btn from '../components/Btn'
import StatusPill from '../components/StatusPill'
import FirmaElectronica from './FirmaElectronica'

export type EstadoCuenta = 'sin-inscribir' | 'en-validacion' | 'validada' | 'rechazada'

interface CuentaDesembolsoProps {
  estadoInicial?: EstadoCuenta
  onToast?: (msg: string) => void
}

const BANCOS = ['Bancolombia', 'Davivienda', 'Banco de Bogotá', 'BBVA', 'Nequi', 'Daviplata', 'Banco Popular', 'Otro']
const TIPOS = ['Cuenta de ahorros', 'Cuenta corriente']

export default function CuentaDesembolso({ estadoInicial = 'sin-inscribir', onToast }: CuentaDesembolsoProps) {
  const [estado, setEstado] = useState<EstadoCuenta>(estadoInicial)
  const [firmaOpen, setFirmaOpen] = useState(false)
  const [editando, setEditando] = useState(false)
  const [banco, setBanco] = useState('Bancolombia')
  const [tipo, setTipo] = useState('Cuenta de ahorros')
  const [numero, setNumero] = useState('')
  const [numeroConf, setNumeroConf] = useState('')
  const [errNum, setErrNum] = useState('')
  const [guardando, setGuardando] = useState(false)

  const cuenta = {
    banco: 'Bancolombia',
    tipo: 'Cuenta de ahorros',
    numeroMask: '**** **** 4821',
  }

  const validar = () => {
    if (!/^\d{8,18}$/.test(numero)) {
      setErrNum('Ingresa un número de cuenta válido (8-18 dígitos).')
      return false
    }
    if (numero !== numeroConf) {
      setErrNum('Los números de cuenta no coinciden.')
      return false
    }
    setErrNum('')
    return true
  }

  const handleGuardar = () => {
    if (!validar()) return
    setFirmaOpen(true)
  }

  const handleFirmaSuccess = () => {
    setFirmaOpen(false)
    setGuardando(true)
    setTimeout(() => {
      setGuardando(false)
      setEstado('en-validacion')
      setEditando(false)
      onToast?.('Cuenta enviada a validación')
    }, 1200)
  }

  const handleCambiar = () => {
    setNumero('')
    setNumeroConf('')
    setErrNum('')
    setEditando(true)
  }

  if (estado === 'sin-inscribir' || editando) {
    return (
      <>
        <div className="space-y-4">
          {editando && (
            <span className="text-[11px] font-semibold text-[#005E3C] bg-[#EFFFF7] px-2 py-0.5 rounded-full inline-block">Editando</span>
          )}

          {estado === 'sin-inscribir' && !editando && (
            <p className="text-[13px] text-gray-500 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2.5">
              Aún no tienes una cuenta inscrita. Debes inscribir una cuenta para recibir tus rendimientos y capital al vencimiento.
            </p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[12px] font-semibold text-gray-500 mb-1">Banco</label>
              <select
                value={banco}
                onChange={e => setBanco(e.target.value)}
                className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] bg-white outline-none focus:border-[#0A1F44] cursor-pointer"
              >
                {BANCOS.map(b => <option key={b}>{b}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[12px] font-semibold text-gray-500 mb-1">Tipo de cuenta</label>
              <select
                value={tipo}
                onChange={e => setTipo(e.target.value)}
                className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] bg-white outline-none focus:border-[#0A1F44] cursor-pointer"
              >
                {TIPOS.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[12px] font-semibold text-gray-500 mb-1">Número de cuenta</label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="Ej. 12345678901"
              value={numero}
              onChange={e => { setNumero(e.target.value.replace(/\D/g, '')); setErrNum('') }}
              className="w-full border border-[#E5E7EB] rounded-xl px-3 py-2.5 text-[14px] font-figures text-[#2A3036] outline-none focus:border-[#0A1F44]"
            />
          </div>

          <div>
            <label className="block text-[12px] font-semibold text-gray-500 mb-1">Confirmar número de cuenta</label>
            <input
              type="text"
              inputMode="numeric"
              placeholder="Repite el número"
              value={numeroConf}
              onChange={e => { setNumeroConf(e.target.value.replace(/\D/g, '')); setErrNum('') }}
              className={`w-full border rounded-xl px-3 py-2.5 text-[14px] font-figures text-[#2A3036] outline-none focus:border-[#0A1F44] ${errNum ? 'border-red-400 bg-red-50' : 'border-[#E5E7EB]'}`}
            />
            {errNum && <p className="text-[12px] text-red-500 mt-1">{errNum}</p>}
          </div>

          <div className="flex gap-2 pt-1">
            {editando && (
              <Btn variant="secondary" size="md" onClick={() => setEditando(false)}>Cancelar</Btn>
            )}
            <Btn variant="primary" size="md" loading={guardando} onClick={handleGuardar} className="flex-1">
              {editando ? 'Actualizar cuenta' : 'Inscribir cuenta'}
            </Btn>
          </div>
        </div>

        <FirmaElectronica
          open={firmaOpen}
          operacion="cambiar-cuenta"
          subtitulo={`${banco} · ${tipo}`}
          onSuccess={handleFirmaSuccess}
          onClose={() => setFirmaOpen(false)}
        />
      </>
    )
  }

  if (estado === 'en-validacion') {
    return (
      <div className="space-y-3">
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-3">
          <span className="w-5 h-5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-[13px] font-semibold text-amber-800">Cuenta en validación</p>
            <p className="text-[12px] text-amber-700 mt-0.5">Estamos verificando tu cuenta bancaria. Este proceso puede tomar hasta 2 días hábiles.</p>
          </div>
        </div>
        <div className="bg-gray-50 rounded-xl px-4 py-3 flex items-center justify-between">
          <div>
            <p className="font-semibold text-[14px] text-[#2A3036]">{banco || cuenta.banco}</p>
            <p className="text-[12px] text-gray-500">{tipo || cuenta.tipo}</p>
          </div>
          <StatusPill variant="en-proceso" label="En validación" />
        </div>
        <Btn variant="ghost" size="sm" onClick={handleCambiar}>Cambiar cuenta</Btn>
      </div>
    )
  }

  if (estado === 'rechazada') {
    return (
      <>
        <div className="space-y-3">
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3">
            <p className="text-[13px] font-semibold text-red-700">Cuenta rechazada</p>
            <p className="text-[12px] text-red-600 mt-0.5">No pudimos validar tu cuenta. Verifica los datos e intenta con otra cuenta.</p>
          </div>
          <Btn variant="primary" size="md" onClick={handleCambiar} className="w-full">Inscribir nueva cuenta</Btn>
        </div>
        <FirmaElectronica open={firmaOpen} operacion="cambiar-cuenta" onSuccess={handleFirmaSuccess} onClose={() => setFirmaOpen(false)} />
      </>
    )
  }

  // validada
  return (
    <>
      <div className="space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <p className="font-semibold text-[14px] text-[#2A3036]">{cuenta.banco}</p>
            <p className="text-[13px] text-gray-500">{cuenta.tipo}</p>
            <p className="font-figures text-[13px] text-gray-500 mt-0.5">{cuenta.numeroMask}</p>
          </div>
          <StatusPill variant="activo" label="Validada" />
        </div>
        <p className="text-[12px] text-gray-400 bg-gray-50 rounded-xl px-3 py-2.5">
          Es la cuenta donde recibirás tus rendimientos y tu capital al vencimiento.
        </p>
        <Btn variant="ghost" size="sm" onClick={handleCambiar}>Cambiar cuenta</Btn>
      </div>
      <FirmaElectronica open={firmaOpen} operacion="cambiar-cuenta" onSuccess={handleFirmaSuccess} onClose={() => setFirmaOpen(false)} />
    </>
  )
}
