import { useNavigate } from 'react-router-dom'
import StatusPill from '../components/StatusPill'
import { type CDT, formatPesos } from '../data/mockData'

interface CDTCardProps {
  cdt: CDT
  delay?: number
}

export default function CDTCard({ cdt, delay = 0 }: CDTCardProps) {
  const navigate = useNavigate()
  const terminado = cdt.estado === 'terminado'

  return (
    <div
      className={`card card-enter p-5 relative overflow-hidden ${!terminado ? 'cursor-pointer' : ''}`}
      style={{ animationDelay: `${delay}s` }}
      onClick={() => !terminado && navigate(`/cdt/${cdt.id}`)}
    >
      {/* Accent line */}
      <div className={`absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] ${terminado ? 'bg-gray-300' : 'bg-gradient-to-r from-[#3B82F6] to-[#00DB8E]'}`} />

      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${terminado ? 'bg-gray-100' : 'bg-[#3B82F6]/12'}`}>
            <svg className={`w-4.5 h-4.5 ${terminado ? 'text-gray-400' : 'text-[#3B82F6]'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
          </div>
          <div>
            <p className="font-semibold text-[#2A3036] text-[15px] leading-tight">CDT</p>
            <p className="font-figures text-[12px] text-gray-400">{cdt.numeroMascarado}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {!terminado && (
            <span className={`text-[9px] font-bold tracking-wide px-2 py-1 rounded-full ${
              cdt.renovacionAutomatica ? 'bg-[#EFFFF7] text-[#005E3C]' : 'bg-gray-100 text-gray-500'
            }`}>
              {cdt.renovacionAutomatica ? '↻ Renovación auto' : 'Sin renovación'}
            </span>
          )}
          <StatusPill variant={terminado ? 'terminado' : 'activo'} label={terminado ? 'Terminado' : 'Activo'} />
        </div>
      </div>

      {/* Monto */}
      <div className="mb-4">
        <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Monto invertido</p>
        <p className="font-figures text-[30px] font-bold text-[#2A3036] leading-none">{formatPesos(cdt.montoInvertido)}</p>
      </div>

      {/* Datos */}
      <div className="grid grid-cols-2 gap-y-2 mb-4">
        <span className="text-[12px] text-gray-400">Rendimientos</span>
        <span className="font-figures text-[12px] font-semibold text-[#10B981] text-right">+{formatPesos(cdt.rendimientos)}</span>
        <span className="text-[12px] text-gray-400">{terminado ? 'Venció' : 'Vencimiento'}</span>
        <span className="font-figures text-[12px] font-semibold text-[#2A3036] text-right">{cdt.fechaVencimiento}</span>
        {!terminado && (
          <>
            <span className="text-[12px] text-gray-400">Tasa</span>
            <span className="font-figures text-[12px] font-semibold text-[#2A3036] text-right">{cdt.tasa} % E.A.</span>
          </>
        )}
      </div>

      {/* Progreso */}
      {!terminado && (
        <div>
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] text-gray-400">Plazo transcurrido</span>
            <span className="font-figures text-[11px] font-semibold text-[#3B82F6]">
              {cdt.diasRestantes !== undefined ? `Faltan ${cdt.diasRestantes} días` : `${cdt.progresoPct} %`}
            </span>
          </div>
          <div className="h-1.5 bg-[#F7F7F7] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full progress-glow transition-all duration-500"
              style={{ width: `${cdt.progresoPct}%`, background: 'linear-gradient(90deg, #3B82F6, #00DB8E)' }}
            />
          </div>
        </div>
      )}

      {/* Arrow */}
      {!terminado && (
        <div className="flex justify-end mt-3">
          <div className="w-7 h-7 rounded-xl bg-[#F7F7F7] flex items-center justify-center">
            <svg className="w-3.5 h-3.5 text-[#2A3036]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
