import { useState } from 'react'
import FirmaElectronica from './FirmaElectronica'
import { formatPesos } from '../data/mockData'

/* ─── Types & constants ──────────────────────────── */
type Opcion = 'automatica' | 'modificar' | 'no-renovar'
type MontoMode = 'capital' | 'capital-rend' | 'personalizado'
type Periodicidad = 'AL VENCIMIENTO' | 'MENSUAL' | 'TRIMESTRAL' | 'SEMESTRAL' | 'ANUAL'

const PLAZOS = [6, 12, 18, 24, 36]
const MONTO_MIN = 1_000_000
const MONTO_MAX = 500_000_000

const PERIOD_META: Record<Periodicidad, { short: string; desc: string }> = {
  'AL VENCIMIENTO': { short: 'Al vencer', desc: 'Cobras todo al final del plazo' },
  'MENSUAL': { short: 'Mensual', desc: 'Un pago cada mes' },
  'TRIMESTRAL': { short: 'Trimestral', desc: 'Cada 3 meses' },
  'SEMESTRAL': { short: 'Semestral', desc: 'Cada 6 meses' },
  'ANUAL': { short: 'Anual', desc: 'Una vez al año' },
}

function parseMonto(s: string): number {
  return parseInt(s.replace(/\D/g, ''), 10) || 0
}

function formatMontoInput(s: string): string {
  const n = parseMonto(s)
  if (!n) return ''
  return n.toLocaleString('es-CO').replace(/,/g, '.')
}

function simular(monto: number, plazo: number, tasa: number) {
  const rend = Math.round(monto * (Math.pow(1 + tasa / 100, plazo / 12) - 1))
  return { monto, tasa, rend, total: monto + rend }
}

/* ─── Props ──────────────────────────────────────── */
interface Props {
  cdt: {
    id: string
    montoInvertido: number
    rendimientos: number
    fechaVencimiento: string
    tasa: string
  }
  onToast: (msg: string) => void
}

/* ─── Step badge ─────────────────────────────────── */
function StepBadge({ n, done, locked }: { n: number; done?: boolean; locked?: boolean }) {
  if (done) return (
    <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
      <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
    </div>
  )
  return (
    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${locked ? 'bg-[#E8ECF2]' : 'bg-[#0A1F44]'}`}>
      <span className={`text-[10px] font-black ${locked ? 'text-gray-400' : 'text-white'}`}>{n}</span>
    </div>
  )
}

/* ─── Main component ─────────────────────────────── */
export default function CDTRenovacion({ cdt, onToast }: Props) {
  const tasaNum = parseFloat((cdt.tasa ?? '11.80').replace(',', '.'))

  const [opcion, setOpcion] = useState<Opcion>('automatica')
  const [montoMode, setMontoMode] = useState<MontoMode>('capital-rend')
  const [montoPersonalizado, setMontoPersonalizado] = useState('')
  const [plazo, setPlazo] = useState<number | null>(null)
  const [periodicidad, setPeriodicidad] = useState<Periodicidad | null>(null)
  const [firmaOpen, setFirmaOpen] = useState(false)
  const [firmaOp, setFirmaOp] = useState<'renovar-cdt' | 'cancelar-renovacion'>('renovar-cdt')
  const [saved, setSaved] = useState<{ opcion: Opcion; resumen: string } | null>(null)

  /* Derived monto */
  const montoBase =
    montoMode === 'capital' ? cdt.montoInvertido
    : montoMode === 'capital-rend' ? cdt.montoInvertido + cdt.rendimientos
    : parseMonto(montoPersonalizado)

  const montoFueraDeRango =
    montoMode === 'personalizado' && montoPersonalizado !== '' &&
    (montoBase < MONTO_MIN || montoBase > MONTO_MAX)

  const montoValido = montoBase >= MONTO_MIN && montoBase <= MONTO_MAX && !montoFueraDeRango
  const condicionesCompletas = montoValido && plazo !== null && periodicidad !== null

  /* Live simulation */
  const simResult = condicionesCompletas ? simular(montoBase, plazo!, tasaNum) : null
  const simActual = simular(cdt.montoInvertido, 12, tasaNum)

  const abrirFirma = (op: 'renovar-cdt' | 'cancelar-renovacion') => {
    setFirmaOp(op)
    setFirmaOpen(true)
  }

  const handleFirmaSuccess = () => {
    setFirmaOpen(false)
    const resumen =
      opcion === 'automatica' ? 'Renovación automática por las mismas condiciones.'
      : opcion === 'modificar' && simResult
        ? `${formatPesos(simResult.monto)} · ${plazo} meses · ${periodicidad}`
        : 'Tu CDT no se renovará al vencer.'
    setSaved({ opcion, resumen })
    onToast('Tu instrucción de renovación fue guardada.')
  }

  const cambiarOpcion = (op: Opcion) => {
    setOpcion(op)
    setSaved(null)
  }

  /* ── Success state ── */
  if (saved) {
    return (
      <div className="space-y-4">
        <div className="rounded-2xl border border-[#00DB8E]/35 bg-[#EFFFF7] px-5 py-4 flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#00DB8E]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
            <svg className="w-4 h-4 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-[14px] text-[#005E3C]">Instrucción guardada</p>
            <p className="text-[13px] text-[#005E3C]/80 mt-0.5 leading-snug">{saved.resumen}</p>
            <p className="text-[11px] text-[#005E3C]/60 mt-1.5">Se aplicará al vencer el {cdt.fechaVencimiento}.</p>
          </div>
        </div>
        <button
          onClick={() => setSaved(null)}
          className="flex items-center gap-1.5 text-[12px] font-semibold text-[#3B82F6] hover:underline cursor-pointer"
        >
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
          Modificar instrucción
        </button>
      </div>
    )
  }

  /* ── Main ── */
  return (
    <div className="space-y-4">
      {/* Option tabs */}
      <div className="grid grid-cols-3 gap-2">
        {([
          { id: 'automatica' as Opcion, label: 'Automática', icon: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15' },
          { id: 'modificar' as Opcion, label: 'Modificar', icon: 'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4' },
          { id: 'no-renovar' as Opcion, label: 'No renovar', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
        ] as const).map(opt => (
          <button
            key={opt.id}
            onClick={() => cambiarOpcion(opt.id)}
            className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
              opcion === opt.id
                ? 'bg-[#0A1F44] border-[#0A1F44] text-white shadow-md'
                : 'bg-white border-[#E8ECF2] text-gray-500 hover:border-[#0A1F44]/30 hover:text-[#0A1F44]'
            }`}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d={opt.icon} />
            </svg>
            <span className="text-[11px] font-bold leading-none">{opt.label}</span>
          </button>
        ))}
      </div>

      {/* ── Panel: Automática ── */}
      {opcion === 'automatica' && (
        <div className="space-y-4">
          <p className="text-[13px] text-gray-500 leading-relaxed">
            Al vencer, tu capital y los rendimientos ganados se reinvierten automáticamente por el mismo plazo, con la tasa vigente ese día.
          </p>

          <div className="grid grid-cols-2 gap-2">
            {[
              { label: 'NUEVO MONTO', value: formatPesos(cdt.montoInvertido + cdt.rendimientos), sub: 'Capital + rendimientos' },
              { label: 'PLAZO', value: '12 meses', sub: 'Igual al actual' },
              { label: 'TASA HOY', value: `${cdt.tasa} % E.A.`, sub: 'Sujeta a cambios' },
              { label: 'RENDIMIENTOS EST.', value: formatPesos(simActual.rend), sub: 'Primer año' },
            ].map(item => (
              <div key={item.label} className="bg-[#F9FAFB] border border-[#F0F2F5] rounded-xl px-3 py-3">
                <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-1">{item.label}</p>
                <p className="font-figures font-bold text-[14px] text-[#2A3036]">{item.value}</p>
                <p className="text-[10px] text-gray-400 mt-0.5">{item.sub}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => abrirFirma('renovar-cdt')}
            className="w-full flex items-center justify-center gap-2 bg-[#0A1F44] text-white text-[14px] font-bold px-4 py-3 rounded-xl hover:bg-[#06005A] transition-colors cursor-pointer"
          >
            Guardar renovación automática
          </button>
        </div>
      )}

      {/* ── Panel: Modificar ── */}
      {opcion === 'modificar' && (
        <div className="space-y-5">

          {/* Step 1: Monto */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <StepBadge n={1} done={montoValido} />
              <p className="font-bold text-[13px] text-[#2A3036]">¿Cuánto vas a reinvertir?</p>
            </div>

            <div className="space-y-2">
              {([
                {
                  mode: 'capital' as MontoMode,
                  label: 'Solo el capital',
                  desc: 'Sin incluir rendimientos',
                  amount: cdt.montoInvertido,
                  amountColor: 'text-[#2A3036]',
                },
                {
                  mode: 'capital-rend' as MontoMode,
                  label: 'Capital + rendimientos',
                  desc: `Incluye ${formatPesos(cdt.rendimientos)} ganados`,
                  amount: cdt.montoInvertido + cdt.rendimientos,
                  amountColor: 'text-[#005E3C]',
                },
                {
                  mode: 'personalizado' as MontoMode,
                  label: 'Monto personalizado',
                  desc: 'Elige un monto diferente',
                  amount: null,
                  amountColor: '',
                },
              ]).map(opt => (
                <button
                  key={opt.mode}
                  onClick={() => { setMontoMode(opt.mode); if (opt.mode !== 'personalizado') setMontoPersonalizado('') }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all duration-150 cursor-pointer text-left ${
                    montoMode === opt.mode
                      ? 'border-[#0A1F44] bg-[#0A1F44]/[0.03]'
                      : 'border-[#E8ECF2] bg-white hover:border-[#0A1F44]/30'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${montoMode === opt.mode ? 'border-[#0A1F44]' : 'border-[#CBD5E1]'}`}>
                    {montoMode === opt.mode && <div className="w-2 h-2 rounded-full bg-[#0A1F44]" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-[13px] font-semibold ${montoMode === opt.mode ? 'text-[#0A1F44]' : 'text-[#2A3036]'}`}>{opt.label}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{opt.desc}</p>
                  </div>
                  {opt.amount !== null && (
                    <span className={`font-figures font-black text-[14px] flex-shrink-0 ${opt.amountColor}`}>
                      {formatPesos(opt.amount)}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {montoMode === 'personalizado' && (
              <div className="mt-3">
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-[14px] font-semibold select-none">$</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={montoPersonalizado}
                    onChange={e => setMontoPersonalizado(formatMontoInput(e.target.value))}
                    placeholder="Ej. 30.000.000"
                    autoFocus
                    className={`w-full pl-8 pr-4 py-3 border-2 rounded-xl text-[15px] font-figures font-bold text-[#2A3036] focus:outline-none transition-colors ${
                      montoFueraDeRango
                        ? 'border-[#EF4444] bg-[#FEF2F2]'
                        : 'border-[#E8ECF2] focus:border-[#0A1F44]'
                    }`}
                  />
                </div>
                <p className={`text-[11px] mt-1.5 ${montoFueraDeRango ? 'text-[#EF4444]' : 'text-gray-400'}`}>
                  {montoFueraDeRango
                    ? `Monto fuera de rango. Entre ${formatPesos(MONTO_MIN)} y ${formatPesos(MONTO_MAX)}.`
                    : `Entre ${formatPesos(MONTO_MIN)} y ${formatPesos(MONTO_MAX)}`}
                </p>
              </div>
            )}
          </div>

          {/* Step 2: Plazo & Periodicidad */}
          <div className={`space-y-4 transition-opacity duration-300 ${montoValido ? '' : 'opacity-35 pointer-events-none'}`}>
            <div className="flex items-center gap-2">
              <StepBadge n={2} done={condicionesCompletas} locked={!montoValido} />
              <p className="font-bold text-[13px] text-[#2A3036]">Plazo y cobro de rendimientos</p>
            </div>

            {/* Plazo pills */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Plazo</p>
              <div className="flex gap-2 flex-wrap">
                {PLAZOS.map(p => {
                  const sub = p === 12 ? '1 año' : p === 24 ? '2 años' : p === 36 ? '3 años' : null
                  return (
                    <button
                      key={p}
                      onClick={() => { setPlazo(p); setPeriodicidad(null) }}
                      className={`flex flex-col items-center min-w-[58px] py-2.5 px-3 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
                        plazo === p
                          ? 'bg-[#0A1F44] border-[#0A1F44] text-white'
                          : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0A1F44]/35'
                      }`}
                    >
                      <span className="font-figures font-black text-[19px] leading-none">{p}</span>
                      <span className="text-[8px] font-bold tracking-[0.15em] uppercase mt-0.5 opacity-60">meses</span>
                      {sub && <span className={`text-[9px] mt-0.5 ${plazo === p ? 'text-white/55' : 'text-gray-400'}`}>{sub}</span>}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Periodicidad */}
            <div className={`transition-opacity duration-200 ${plazo !== null ? '' : 'opacity-40 pointer-events-none'}`}>
              <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Cobro de rendimientos</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(Object.entries(PERIOD_META) as [Periodicidad, typeof PERIOD_META[keyof typeof PERIOD_META]][]).map(([key, meta]) => (
                  <button
                    key={key}
                    onClick={() => setPeriodicidad(key)}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all duration-150 cursor-pointer text-left gap-3 ${
                      periodicidad === key
                        ? 'bg-[#0A1F44] border-[#0A1F44]'
                        : 'bg-white border-[#E8ECF2] hover:border-[#0A1F44]/35'
                    }`}
                  >
                    <div>
                      <p className={`text-[13px] font-semibold ${periodicidad === key ? 'text-white' : 'text-[#2A3036]'}`}>{meta.short}</p>
                      <p className={`text-[11px] mt-0.5 ${periodicidad === key ? 'text-white/55' : 'text-gray-400'}`}>{meta.desc}</p>
                    </div>
                    {periodicidad === key && (
                      <svg className="w-4 h-4 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Step 3: Simulation & Confirm */}
          {simResult && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                  <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                </div>
                <p className="font-bold text-[13px] text-[#2A3036]">Tu nueva inversión</p>
              </div>

              {/* Before / After */}
              <div className="rounded-2xl overflow-hidden border border-[#E8ECF2]">
                <div className="grid grid-cols-2">
                  {/* Antes */}
                  <div className="bg-[#F9FAFB] px-4 py-4 border-r border-[#E8ECF2] space-y-3">
                    <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-gray-400">CDT actual</p>
                    {[
                      { label: 'Monto', val: formatPesos(cdt.montoInvertido) },
                      { label: 'Plazo', val: '12 meses' },
                      { label: 'Tasa', val: `${cdt.tasa} % E.A.` },
                      { label: 'Rendimientos', val: formatPesos(cdt.rendimientos) },
                    ].map(r => (
                      <div key={r.label}>
                        <p className="text-[9px] text-gray-400 uppercase tracking-wide">{r.label}</p>
                        <p className="font-figures font-bold text-[#2A3036] text-[13px] mt-0.5">{r.val}</p>
                      </div>
                    ))}
                  </div>

                  {/* Después */}
                  <div className="px-4 py-4 space-y-3" style={{ background: 'linear-gradient(145deg, #0A1F44 0%, #06005A 100%)' }}>
                    <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-white/40">Al renovar</p>
                    {[
                      { label: 'Monto', val: formatPesos(simResult.monto), color: 'text-white' },
                      { label: 'Plazo', val: `${plazo} meses`, color: 'text-white' },
                      { label: 'Tasa', val: `${cdt.tasa} % E.A.`, color: 'text-[#93C5FD]' },
                      { label: 'Rendimientos est.', val: formatPesos(simResult.rend), color: 'text-[#00DB8E]' },
                    ].map(r => (
                      <div key={r.label}>
                        <p className="text-[9px] text-white/35 uppercase tracking-wide">{r.label}</p>
                        <p className={`font-figures font-bold text-[13px] mt-0.5 ${r.color}`}>{r.val}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Total bar */}
                <div className="bg-[#EFFFF7] border-t border-[#00DB8E]/20 px-4 py-3 flex items-center justify-between">
                  <p className="text-[12px] font-semibold text-[#005E3C]">Total al vencimiento</p>
                  <p className="font-figures font-black text-[17px] text-[#005E3C]">{formatPesos(simResult.total)}</p>
                </div>
              </div>

              <p className="text-[11px] text-gray-400 leading-snug">
                Los rendimientos son estimados y se calculan con la tasa vigente hoy. Al renovar se aplica la tasa del día.
              </p>

              <button
                onClick={() => abrirFirma('renovar-cdt')}
                className="w-full flex items-center justify-center gap-2 bg-[#00DB8E] text-[#06005A] text-[14px] font-black px-4 py-3 rounded-xl hover:bg-[#00c47f] transition-colors cursor-pointer"
              >
                Confirmar esta renovación
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── Panel: No renovar ── */}
      {opcion === 'no-renovar' && (
        <div className="space-y-4">
          <div className="rounded-xl border border-[#F59E0B]/30 bg-[#FFFBEB] px-4 py-3 flex items-start gap-2.5">
            <svg className="w-4 h-4 text-[#D97706] flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            <p className="text-[12px] text-[#92400E] font-medium leading-snug">
              Al vencer el {cdt.fechaVencimiento}, tu capital y los rendimientos se depositarán en tu cuenta bancaria inscrita.
            </p>
          </div>

          <div className="bg-[#F9FAFB] rounded-xl border border-[#E8ECF2] px-4 py-3.5">
            <p className="text-[9px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Cuenta de desembolso</p>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#0A1F44]/08 flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-[#0A1F44]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>
              </div>
              <div>
                <p className="font-semibold text-[14px] text-[#2A3036]">Bancolombia · Cuenta de ahorros</p>
                <p className="font-figures text-[13px] text-gray-500 mt-0.5">**** **** 4821</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => abrirFirma('cancelar-renovacion')}
            className="w-full flex items-center justify-center gap-2 bg-white border-2 border-[#E8ECF2] text-[#2A3036] text-[13px] font-bold px-4 py-3 rounded-xl hover:border-[#0A1F44]/30 transition-colors cursor-pointer"
          >
            Confirmar que no deseo renovar
          </button>
        </div>
      )}

      <FirmaElectronica
        open={firmaOpen}
        operacion={firmaOp}
        onSuccess={handleFirmaSuccess}
        onClose={() => setFirmaOpen(false)}
      />
    </div>
  )
}
