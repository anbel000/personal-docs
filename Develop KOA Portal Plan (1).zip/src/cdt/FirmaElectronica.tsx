import { useState, useEffect, useRef } from 'react'
import Btn from '../components/Btn'

export type OperacionFirma =
  | 'abrir-cdt'
  | 'renovar-cdt'
  | 'cancelar-renovacion'
  | 'cambiar-cuenta'
  | 'activar-referido'
  | 'editar-proposito'
  | 'desbloqueo'
  | 'otro'

interface FirmaElectronicaProps {
  open: boolean
  operacion: OperacionFirma
  subtitulo?: string
  onSuccess: () => void
  onClose: () => void
}

const TEXTOS: Record<OperacionFirma, { titulo: string; desc: string }> = {
  'abrir-cdt': {
    titulo: 'Confirmar apertura de CDT',
    desc: 'Ingresa el código OTP enviado a tu correo para autorizar la apertura del Certificado de Depósito a Término.',
  },
  'renovar-cdt': {
    titulo: 'Confirmar renovación de CDT',
    desc: 'Ingresa el código OTP enviado a tu correo para autorizar la renovación automática de tu CDT.',
  },
  'cancelar-renovacion': {
    titulo: 'Cancelar renovación automática',
    desc: 'Ingresa el código OTP enviado a tu correo para desactivar la renovación automática de tu CDT.',
  },
  'cambiar-cuenta': {
    titulo: 'Inscripción de cuenta de desembolso',
    desc: 'Ingresa el código OTP enviado a tu correo para autorizar la inscripción de la nueva cuenta.',
  },
  'activar-referido': {
    titulo: 'Activar programa de referidos',
    desc: 'Ingresa el código OTP enviado a tu correo para activar tu código de referidos KOA.',
  },
  'editar-proposito': {
    titulo: 'Editar propósito del CDT',
    desc: 'Ingresa el código OTP enviado a tu correo para actualizar el propósito de inversión.',
  },
  'desbloqueo': {
    titulo: 'Verificación de identidad',
    desc: 'Ingresa el código OTP enviado a tu correo para continuar con el proceso de desbloqueo.',
  },
  'otro': {
    titulo: 'Firma electrónica',
    desc: 'Ingresa el código OTP enviado a tu correo para autorizar esta operación.',
  },
}

const CODIGO_CORRECTO = '123456'
const INTENTOS_MAX = 3
const VIGENCIA_SEG = 600
const REENVIO_SEG = 60
const D = 6

const VAL_STEPS = ['Verificando código…', 'Confirmando autorización…', '']

/* ─── ValidatingOverlay ─────────────────────────────── */
function ValidatingOverlay({ phase, isSuccess, isError }: { phase: number; isSuccess: boolean; isError: boolean }) {
  const steps = [VAL_STEPS[0], VAL_STEPS[1], isError ? 'Código incorrecto' : 'Operación autorizada']
  return (
    <div className="flex flex-col items-center justify-center gap-7 py-8">
      <div className="relative flex items-center justify-center">
        <div
          className="absolute w-20 h-20 rounded-full border-2 animate-spin"
          style={{ animationDuration: '2.5s', borderTopColor: isError ? '#EF4444' : '#00DB8E', borderRightColor: 'transparent', borderBottomColor: 'transparent', borderLeftColor: 'transparent' }}
        />
        <div
          className="absolute w-14 h-14 rounded-full border-2 animate-spin"
          style={{ animationDuration: '1.8s', animationDirection: 'reverse', borderTopColor: 'transparent', borderRightColor: 'transparent', borderBottomColor: isError ? '#EF4444' : '#06005A', borderLeftColor: 'transparent', opacity: 0.2 }}
        />
        <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${isSuccess ? 'bg-[#00DB8E]' : isError ? 'bg-[#EF4444]' : 'bg-[#06005A]'}`}>
          {isSuccess ? (
            <svg className="w-5 h-5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          ) : isError ? (
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
          )}
        </div>
      </div>
      <div className="space-y-2.5 w-full max-w-[190px]">
        {steps.map((s, i) => {
          const done = i < phase || isSuccess
          const active = i === phase && !isSuccess && !isError
          const err = isError && i === phase
          return (
            <div key={i} className={`flex items-center gap-2.5 transition-all duration-400 ${i <= phase ? 'opacity-100' : 'opacity-20'}`}>
              <div className={`w-4.5 h-4.5 w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${done ? 'bg-[#00DB8E]' : err ? 'bg-[#EF4444]' : active ? 'border-2 border-[#06005A] bg-[#06005A]/08' : 'bg-[#F0F0F0]'}`}>
                {done
                  ? <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  : err
                    ? <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                    : active
                      ? <div className="w-1.5 h-1.5 rounded-full bg-[#06005A] animate-pulse" />
                      : null}
              </div>
              <p className={`text-[12px] transition-colors duration-300 ${err ? 'text-[#DC2626] font-bold' : done ? 'text-[#005E3C] font-semibold' : active ? 'text-[#2A3036] font-bold' : 'text-gray-300'}`}>{s}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default function FirmaElectronica({ open, operacion, subtitulo, onSuccess, onClose }: FirmaElectronicaProps) {
  const [digits, setDigits] = useState<string[]>(Array(D).fill(''))
  const [intentos, setIntentos] = useState(0)
  const [errMsg, setErrMsg] = useState('')
  const [shake, setShake] = useState(false)
  const [bloqueado, setBloqueado] = useState(false)
  const [validando, setValidando] = useState(false)
  const [validPhase, setValidPhase] = useState(0)
  const [isSuccess, setIsSuccess] = useState(false)
  const [isError, setIsError] = useState(false)
  const [vigencia, setVigencia] = useState(VIGENCIA_SEG)
  const [reenvio, setReenvio] = useState(REENVIO_SEG)
  const [reenviando, setReenviando] = useState(false)
  const inputsRef = useRef<(HTMLInputElement | null)[]>([])
  const isCorrectRef = useRef(false)

  useEffect(() => {
    if (!open) return
    setDigits(Array(D).fill(''))
    setIntentos(0)
    setErrMsg('')
    setShake(false)
    setBloqueado(false)
    setValidando(false)
    setValidPhase(0)
    setIsSuccess(false)
    setIsError(false)
    setVigencia(VIGENCIA_SEG)
    setReenvio(REENVIO_SEG)
    setTimeout(() => inputsRef.current[0]?.focus(), 100)
  }, [open])

  useEffect(() => {
    if (!open || bloqueado || validando) return
    const t = setInterval(() => setVigencia(v => Math.max(0, v - 1)), 1000)
    return () => clearInterval(t)
  }, [open, bloqueado, validando])

  useEffect(() => {
    if (!open || reenvio <= 0) return
    const t = setInterval(() => setReenvio(r => Math.max(0, r - 1)), 1000)
    return () => clearInterval(t)
  }, [open, reenvio])

  const otpCode = digits.join('')
  useEffect(() => {
    if (otpCode.length === D && open && !validando && !bloqueado) {
      runValidation(otpCode)
    }
  }, [otpCode])

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`

  function runValidation(code: string) {
    isCorrectRef.current = code === CODIGO_CORRECTO
    setValidando(true)
    setValidPhase(0)
    setIsSuccess(false)
    setIsError(false)

    const t1 = setTimeout(() => setValidPhase(1), 700)
    const t2 = setTimeout(() => setValidPhase(2), 1400)
    const t3 = setTimeout(() => {
      if (isCorrectRef.current) {
        setIsSuccess(true)
        setTimeout(() => onSuccess(), 500)
      } else {
        setIsError(true)
        const nuevoIntentos = intentos + 1
        setIntentos(nuevoIntentos)
        setTimeout(() => {
          setValidando(false)
          setIsError(false)
          setValidPhase(0)
          setDigits(Array(D).fill(''))
          if (nuevoIntentos >= INTENTOS_MAX) {
            setBloqueado(true)
          } else {
            setErrMsg(`Código incorrecto. Te quedan ${INTENTOS_MAX - nuevoIntentos} intento${INTENTOS_MAX - nuevoIntentos === 1 ? '' : 's'}.`)
            setShake(true)
            setTimeout(() => setShake(false), 400)
            setTimeout(() => inputsRef.current[0]?.focus(), 60)
          }
        }, 1200)
      }
    }, 2000)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
  }

  const handleChange = (i: number, val: string) => {
    if (bloqueado || validando) return
    const clean = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]
    next[i] = clean
    setDigits(next)
    setErrMsg('')
    if (clean && i < D - 1) inputsRef.current[i + 1]?.focus()
  }

  const handleKeyDown = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      e.preventDefault()
      if (digits[i]) {
        const next = [...digits]; next[i] = ''; setDigits(next)
      } else if (i > 0) {
        inputsRef.current[i - 1]?.focus()
      }
    }
  }

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault()
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, D)
    const next = Array(D).fill('')
    text.split('').forEach((c, i) => { next[i] = c })
    setDigits(next)
    inputsRef.current[Math.min(text.length, D - 1)]?.focus()
  }

  const handleReenviar = () => {
    setReenviando(true)
    setTimeout(() => {
      setReenviando(false)
      setReenvio(REENVIO_SEG)
      setVigencia(VIGENCIA_SEG)
      setDigits(Array(D).fill(''))
      setErrMsg('')
      inputsRef.current[0]?.focus()
    }, 1200)
  }

  if (!open) return null

  const texto = TEXTOS[operacion]
  const vigenciaPct = (vigencia / VIGENCIA_SEG) * 100

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={!bloqueado && !validando ? onClose : undefined} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 px-6 pt-6 pb-4 border-b border-[#F0F2F5]">
          <div>
            <div className="flex gap-1.5 mb-2">
              <div className="w-6 h-2 rounded-full bg-[#0A1F44]" />
              <div className="w-2 h-2 rounded-full bg-[#0A1F44]" />
            </div>
            <p className="font-bold text-[16px] text-[#2A3036] leading-snug">{texto.titulo}</p>
            {subtitulo && <p className="text-[12px] text-gray-500 mt-0.5">{subtitulo}</p>}
          </div>
          {!bloqueado && !validando && (
            <button onClick={onClose} className="w-7 h-7 rounded-lg flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-500 cursor-pointer flex-shrink-0 mt-0.5">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          )}
        </div>

        {/* Body */}
        <div className="px-6 pb-6">
          {bloqueado ? (
            <div className="text-center space-y-4 py-6">
              <div className="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mx-auto">
                <svg className="w-7 h-7 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
              </div>
              <div>
                <p className="font-bold text-[16px] text-[#2A3036]">Operación bloqueada</p>
                <p className="text-[13px] text-gray-500 mt-1">Superaste los 3 intentos permitidos. Por seguridad, esta operación quedará bloqueada durante 24 horas.</p>
              </div>
              <Btn variant="secondary" size="md" className="w-full" onClick={onClose}>Entendido</Btn>
            </div>
          ) : validando ? (
            <ValidatingOverlay phase={validPhase} isSuccess={isSuccess} isError={isError} />
          ) : (
            <div className="space-y-5 pt-4">
              <p className="text-[13px] text-gray-500 leading-relaxed">{texto.desc}</p>

              {/* Vigencia bar */}
              <div>
                <div className="flex justify-between text-[11px] text-gray-400 mb-1">
                  <span>Vigencia del código</span>
                  <span className={`font-figures font-semibold ${vigencia < 120 ? 'text-red-500' : 'text-gray-500'}`}>{formatTime(vigencia)}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ${vigencia < 120 ? 'bg-red-400' : 'bg-[#00DB8E]'}`}
                    style={{ width: `${vigenciaPct}%` }}
                  />
                </div>
              </div>

              {/* OTP inputs — app-wide pattern */}
              <div className={`flex gap-2 justify-center ${shake ? 'animate-[shake_0.35s_ease-in-out]' : ''}`} onPaste={handlePaste}>
                {digits.map((d, i) => (
                  <input
                    key={i}
                    ref={el => { inputsRef.current[i] = el }}
                    type="password"
                    inputMode="numeric"
                    maxLength={1}
                    value={d}
                    onChange={e => handleChange(i, e.target.value)}
                    onKeyDown={e => handleKeyDown(i, e)}
                    disabled={bloqueado || validando}
                    className={`w-11 h-[52px] text-center text-[22px] font-figures font-black rounded-xl border-2 outline-none transition-all duration-150 ${
                      shake || errMsg
                        ? 'border-[#EF4444] bg-[#FEF2F2] text-[#DC2626]'
                        : d
                          ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
                          : 'border-[#E8ECF2] bg-white focus:border-[#06005A]'
                    } disabled:opacity-50`}
                  />
                ))}
              </div>

              {errMsg && (
                <p className="text-[12px] text-red-500 text-center font-medium">{errMsg}</p>
              )}

              {/* Reenviar */}
              <div className="text-center">
                {reenvio > 0 ? (
                  <p className="text-[12px] text-gray-400">
                    Reenviar en <span className="font-figures font-semibold">{reenvio}s</span>
                  </p>
                ) : (
                  <button
                    onClick={handleReenviar}
                    disabled={reenviando}
                    className="text-[12px] font-semibold text-[#3B82F6] hover:underline cursor-pointer disabled:opacity-50"
                  >
                    {reenviando ? 'Reenviando...' : 'Reenviar código'}
                  </button>
                )}
              </div>

              <p className="text-[11px] text-gray-400 text-center">
                Código de prueba: <span className="font-figures font-bold text-[#2A3036]">123456</span>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
