import { useState, useEffect, useRef } from 'react'
import { clienteNatural } from '../data/mockData'

/* ─── OTP constants & types ───────────────────────────── */
const DEMO_OTP = '248731'
const D = 6
const OTP_STEPS = ['Verificando código…', 'Confirmando identidad…', '']

/* ─── DigitRow — matches app-wide pattern ─────────────── */
function DigitRow({
  digits, inputRefs, onChange, onKeyDown, onPaste, shake, autoFocus,
}: {
  digits: string[]
  inputRefs: React.MutableRefObject<(HTMLInputElement | null)[]>
  onChange: (i: number, v: string) => void
  onKeyDown: (i: number, e: React.KeyboardEvent<HTMLInputElement>) => void
  onPaste?: (e: React.ClipboardEvent) => void
  shake?: boolean
  autoFocus?: boolean
}) {
  return (
    <div className={`flex gap-2 justify-center ${shake ? 'animate-[shake_0.35s_ease-in-out]' : ''}`} onPaste={onPaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { inputRefs.current[i] = el }}
          type="password"
          inputMode="numeric"
          maxLength={1}
          value={d}
          autoFocus={autoFocus && i === 0}
          onChange={e => onChange(i, e.target.value)}
          onKeyDown={e => onKeyDown(i, e)}
          className={`w-11 h-[52px] text-center font-figures font-black text-[22px] rounded-xl border-2 outline-none transition-all duration-150 ${
            shake
              ? 'border-[#EF4444] bg-[#FEF2F2] text-[#DC2626]'
              : d
                ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
                : 'border-[#E8ECF2] bg-white focus:border-[#06005A]'
          }`}
        />
      ))}
    </div>
  )
}

/* ─── ValidatingOverlay — matches Seguridad pattern ──── */
function ValidatingOverlay({ phase, isSuccess, isError }: { phase: number; isSuccess: boolean; isError: boolean }) {
  const steps = [OTP_STEPS[0], OTP_STEPS[1], isError ? 'Código incorrecto' : 'Acceso autorizado']
  return (
    <div className="flex flex-col items-center justify-center gap-8 py-10">
      <div className="relative flex items-center justify-center">
        <div className="absolute w-24 h-24 rounded-full border-2 animate-spin"
          style={{ animationDuration: '2.5s', borderTopColor: isError ? '#EF4444' : '#00DB8E', borderRightColor: 'transparent', borderBottomColor: 'transparent', borderLeftColor: 'transparent' }} />
        <div className="absolute w-16 h-16 rounded-full border-2 animate-spin"
          style={{ animationDuration: '1.8s', animationDirection: 'reverse', borderTopColor: 'transparent', borderRightColor: 'transparent', borderBottomColor: isError ? '#EF4444' : '#06005A', borderLeftColor: 'transparent', opacity: 0.2 }} />
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${
          isSuccess ? 'bg-[#00DB8E]' : isError ? 'bg-[#EF4444]' : 'bg-[#06005A]'
        }`}>
          {isSuccess ? (
            <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          ) : isError ? (
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
          )}
        </div>
      </div>
      <div className="space-y-3 w-full max-w-[200px]">
        {steps.map((s, i) => {
          const done = i < phase || isSuccess
          const active = i === phase && !isSuccess
          const err = isError && i === phase
          return (
            <div key={i} className={`flex items-center gap-3 transition-all duration-400 ${i <= phase ? 'opacity-100' : 'opacity-20'}`}>
              <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
                done ? 'bg-[#00DB8E]' : err ? 'bg-[#EF4444]' : active ? 'border-2 border-[#06005A] bg-[#06005A]/08' : 'bg-[#F0F0F0]'
              }`}>
                {done ? <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  : err ? <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                  : active ? <div className="w-2 h-2 rounded-full bg-[#06005A] animate-pulse" /> : null}
              </div>
              <p className={`text-[13px] transition-colors duration-300 ${
                err ? 'text-[#DC2626] font-bold' : done ? 'text-[#005E3C] font-semibold' : active ? 'text-[#2A3036] font-bold' : 'text-gray-300'
              }`}>{s}</p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ─── Referidos ─────────────────────────────────────── */
type RefStep = 'idle' | 'terms' | 'otp' | 'validating' | 'otp-error' | 'activo'

const CODIGO = 'AB4589R'
const T_AND_C_URL = 'https://koa.co/wp-content/uploads/2026/02/terminos-y-condiciones-programa-de-plan-de-referidos-koa-30012026-vf.pdf'

function ProgramaReferidos() {
  const [step, setStep] = useState<RefStep>('idle')
  const [accepted, setAccepted] = useState(false)
  const [copiado, setCopiado] = useState(false)

  /* OTP state — array pattern matching Seguridad */
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(D).fill(''))
  const [otpSeconds, setOtpSeconds] = useState(90)
  const [validPhase, setValidPhase] = useState(0)
  const [shake, setShake] = useState(false)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])
  const isCorrectRef = useRef(false)

  useEffect(() => {
    if (step !== 'otp' || otpSeconds <= 0) return
    const t = setInterval(() => setOtpSeconds(s => s - 1), 1000)
    return () => clearInterval(t)
  }, [step, otpSeconds])

  const otpCode = otpDigits.join('')
  useEffect(() => {
    if (otpCode.length === D && step === 'otp') {
      isCorrectRef.current = otpCode === DEMO_OTP
      runOtpValidation()
    }
  }, [otpCode])

  function runOtpValidation() {
    setStep('validating')
    setValidPhase(0)
    const t1 = setTimeout(() => setValidPhase(1), 700)
    const t2 = setTimeout(() => setValidPhase(2), 1400)
    const t3 = setTimeout(() => {
      if (isCorrectRef.current) {
        setStep('activo')
      } else {
        setStep('otp-error')
        setTimeout(() => {
          setStep('otp')
          setOtpDigits(Array(D).fill(''))
          setShake(true)
          setTimeout(() => setShake(false), 400)
          setTimeout(() => otpRefs.current[0]?.focus(), 60)
        }, 1200)
      }
    }, 2000)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
  }

  function handleOtpChange(i: number, v: string) {
    const clean = v.replace(/\D/g, '').slice(0, 1)
    const next = [...otpDigits]
    next[i] = clean
    setOtpDigits(next)
    if (clean && i < D - 1) otpRefs.current[i + 1]?.focus()
  }

  function handleOtpKeyDown(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace') {
      e.preventDefault()
      if (otpDigits[i]) {
        const next = [...otpDigits]; next[i] = ''; setOtpDigits(next)
      } else if (i > 0) {
        otpRefs.current[i - 1]?.focus()
      }
    }
  }

  function handleOtpPaste(e: React.ClipboardEvent) {
    const raw = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, D)
    if (raw) {
      const arr = Array(D).fill('')
      raw.split('').forEach((c, i) => { arr[i] = c })
      setOtpDigits(arr)
      otpRefs.current[Math.min(raw.length, D - 1)]?.focus()
    }
    e.preventDefault()
  }

  const copiarCodigo = () => {
    navigator.clipboard.writeText(CODIGO).catch(() => {})
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2200)
  }

  const waText = encodeURIComponent(
    `¡Hola! 👋\nTe comparto un dato buenísimo. Me uní al Plan de Referidos KOA y tengo un beneficio para ti.\n\nSi abres tu CDT Digital usando mi código: ${CODIGO}, KOA te regala un +0.30% E.A adicional en tu tasa. 💰📈\n\nSolo tienes que:\n1️⃣ Ingresa a www.koa.co\n2️⃣ Ve a la sección CDTs\n3️⃣ Simular tu CDT e ingresar mi código.\n\n¡Es una forma fácil de hacer crecer tus ahorros! Si tienes dudas, avísame. 😉`
  )
  const waUrl = `https://wa.me/?text=${waText}`

  /* ── Active: compact code card ── */
  if (step === 'activo') {
    return (
      <div
        className="relative rounded-2xl overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}
      >
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-[#00DB8E]/[0.07] pointer-events-none" />
        <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-[#3B82F6]/[0.05] pointer-events-none" />
        <div className="relative z-10 px-5 py-5">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-[#00DB8E]/20 flex items-center justify-center flex-shrink-0">
                <svg className="w-3.5 h-3.5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <div>
                <p className="text-white/35 text-[9px] font-bold tracking-[0.16em] uppercase">Plan de Referidos · KOA</p>
                <p className="text-white font-bold text-[13px] leading-tight">Tu código exclusivo</p>
              </div>
            </div>
            <span className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-full bg-[#00DB8E]/20 text-[#00DB8E] border border-[#00DB8E]/25 flex-shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] animate-pulse" />
              Activo
            </span>
          </div>

          {/* Code */}
          <div className="bg-white/[0.06] border border-white/10 rounded-xl px-4 py-4 mb-3">
            <p className="text-white/30 text-[9px] font-bold tracking-[0.2em] uppercase text-center mb-2">Código de referido</p>
            <div className="flex items-center justify-center gap-1.5">
              {CODIGO.split('').map((ch, i) => (
                <span
                  key={i}
                  className="font-figures text-white font-black text-[28px] sm:text-[32px] leading-none animate-number-pop"
                  style={{ ['--delay' as string]: `${i * 0.07}s` }}
                >
                  {ch}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1.5 flex-1">
              <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              <p className="text-white/45 text-[11px]">Gana de <span className="text-[#00DB8E] font-bold">$25.000</span> a <span className="text-[#00DB8E] font-bold">$1.200.000</span> por referido</p>
            </div>
          </div>

          <div className="flex gap-2.5">
            <button
              onClick={copiarCodigo}
              className="flex-1 flex items-center justify-center gap-1.5 bg-white/10 border border-white/15 text-white text-[12px] font-bold px-3 py-2.5 rounded-xl hover:bg-white/20 transition-colors cursor-pointer"
            >
              {copiado
                ? <><svg className="w-3.5 h-3.5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg><span className="text-[#00DB8E]">Copiado</span></>
                : <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>Copiar</>
              }
            </button>
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-[#25D366] text-white text-[12px] font-bold px-3 py-2.5 rounded-xl hover:bg-[#1ebe59] transition-colors cursor-pointer"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              WhatsApp
            </a>
          </div>
        </div>
      </div>
    )
  }

  /* ── Inactive: compact invitation card ── */
  return (
    <>
      <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
        <div className="px-5 py-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #0A1F44 0%, #06005A 100%)' }}>
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-[14px] text-[#2A3036]">Plan de Referidos KOA</p>
            <p className="text-[12px] text-gray-500 mt-0.5">Invita amigos y gana de <span className="text-[#005E3C] font-semibold">$25.000</span> a <span className="text-[#005E3C] font-semibold">$1.200.000</span> por referido</p>
          </div>
          <button
            onClick={() => setStep('terms')}
            className="flex-shrink-0 flex items-center gap-1.5 bg-[#0A1F44] text-white text-[12px] font-bold px-3.5 py-2 rounded-xl hover:bg-[#06005A] transition-colors cursor-pointer whitespace-nowrap"
          >
            Activar
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>
        <div className="border-t border-[#F0F2F5] px-5 py-2.5 flex items-center gap-4">
          {[
            { icon: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z', label: 'Actívate' },
            { icon: 'M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z', label: 'Comparte' },
            { icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z', label: 'Gana bonos' },
          ].map((s, i) => (
            <div key={s.label} className="flex items-center gap-1.5">
              {i > 0 && <span className="w-4 h-px bg-[#E8ECF2]" />}
              <div className="w-5 h-5 rounded-full bg-[#0A1F44]/08 flex items-center justify-center flex-shrink-0">
                <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d={s.icon} /></svg>
              </div>
              <span className="text-[11px] text-gray-500 whitespace-nowrap">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Terms modal */}
      {step === 'terms' && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setStep('idle')} />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl w-full max-w-md flex flex-col" style={{ maxHeight: '90vh' }}>
            <div className="flex items-center justify-between px-6 pt-5 pb-3">
              <div>
                <p className="text-[10px] font-bold tracking-[0.16em] uppercase text-gray-400">Plan de Referidos</p>
                <h3 className="font-black text-[18px] text-[#2A3036]">Términos y condiciones</h3>
              </div>
              <button onClick={() => setStep('idle')} className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 hover:bg-gray-200 cursor-pointer">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 text-[13px] text-gray-600 leading-relaxed border-t border-[#F0F2F5]">
              <p className="text-[#2A3036] font-semibold">Como cliente de KOA, ahora cuentas con un beneficio exclusivo. Invita a tus amigos y familiares a abrir su primer CDT y obtén <strong>Bonos Digitales Falabella</strong> por cada uno de ellos.</p>
              <div>
                <p className="font-bold text-[#2A3036] mb-2">Participar es muy fácil, solo sigue estos 3 pasos:</p>
                <div className="space-y-2">
                  {[
                    { n: '1', t: 'Actívate', d: 'Acepta los términos y condiciones en este portal para obtener tu código de referido único.' },
                    { n: '2', t: 'Comparte', d: 'Envía tu código a personas que aún no sean clientes de KOA para que lo utilicen al abrir su primer CDT.' },
                    { n: '3', t: 'Gana', d: 'Recibirás un bono por cada referido que complete la apertura de su inversión usando tu código.' },
                  ].map(s => (
                    <div key={s.n} className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-[#0A1F44] text-white text-[11px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{s.n}</span>
                      <p><strong className="text-[#2A3036]">{s.t}:</strong> {s.d}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl p-4">
                <p className="font-bold text-[#005E3C] mb-1">Tus Incentivos</p>
                <p>Recibirás un bono digital por el primer CDT que abra cada uno de tus referidos. El valor del premio dependerá del monto y plazo de la inversión realizada.</p>
                <p className="font-black text-[#005E3C] text-[15px] mt-2">¡Puedes ganar desde $25.000 hasta $1.200.000 por cada referido!</p>
                <p className="mt-2">Los bonos serán enviados directamente al correo electrónico que tienes registrado con nosotros.</p>
              </div>
              <div>
                <p className="font-bold text-[#2A3036] mb-2">Condiciones importantes:</p>
                <ul className="space-y-1.5 list-disc list-inside">
                  <li><strong className="text-[#2A3036]">Clientes nuevos:</strong> Los incentivos aplican únicamente por referidos que nunca hayan tenido un CDT en KOA C.F.</li>
                  <li><strong className="text-[#2A3036]">Beneficio para tu referido:</strong> Al usar tu código, ellos obtendrán una tasa adicional del 0.30% sobre la tasa de su simulación.</li>
                </ul>
              </div>
              <a href={T_AND_C_URL} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-[#3B82F6] font-semibold hover:underline">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                Ver términos y condiciones completos
              </a>
            </div>
            <div className="px-6 py-4 border-t border-[#E5E7EB] space-y-3">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} className="mt-0.5 accent-[#00DB8E] w-4 h-4 cursor-pointer" />
                <span className="text-[13px] text-gray-600">He leído y acepto los términos y condiciones del programa de referidos KOA.</span>
              </label>
              <div className="flex gap-2">
                <button onClick={() => setStep('idle')} className="flex-1 bg-gray-100 text-gray-700 text-[13px] font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-200 transition-colors cursor-pointer">Cancelar</button>
                <button
                  disabled={!accepted}
                  onClick={() => { setStep('otp'); setOtpSeconds(90); setOtpDigits(Array(D).fill('')) }}
                  className="flex-1 bg-[#0A1F44] text-white text-[13px] font-bold px-4 py-2.5 rounded-xl hover:bg-[#06005A] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Continuar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OTP / Validating modal */}
      {(step === 'otp' || step === 'validating' || step === 'otp-error') && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-[#F0F2F5]">
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <div className="w-6 h-2 rounded-full bg-[#0A1F44]" />
                  <div className="w-2 h-2 rounded-full bg-[#0A1F44]" />
                </div>
                <p className="font-bold text-[15px] text-[#2A3036]">
                  {step === 'otp' ? 'Verificación' : 'Validando…'}
                </p>
              </div>
              {step === 'otp' && (
                <button onClick={() => setStep('terms')} className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 hover:bg-gray-200 cursor-pointer">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              )}
            </div>

            {/* Body */}
            <div className="px-6 py-6">
              {step === 'validating' || step === 'otp-error' ? (
                <ValidatingOverlay
                  phase={validPhase}
                  isSuccess={false}
                  isError={step === 'otp-error'}
                />
              ) : (
                <div className="space-y-5">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-2xl bg-[#0A1F44]/08 flex items-center justify-center mx-auto mb-3">
                      <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
                    </div>
                    <p className="font-bold text-[16px] text-[#2A3036]">Confirma tu identidad</p>
                    <p className="text-[13px] text-gray-500 mt-1">Ingresa el código de 6 dígitos enviado a <strong>{clienteNatural.correoMascarado}</strong></p>
                  </div>

                  <DigitRow
                    digits={otpDigits}
                    inputRefs={otpRefs}
                    onChange={handleOtpChange}
                    onKeyDown={handleOtpKeyDown}
                    onPaste={handleOtpPaste}
                    shake={shake}
                    autoFocus
                  />

                  <div className="text-center">
                    {otpSeconds > 0 ? (
                      <p className="text-[12px] text-gray-400">Reenviar código en <span className="font-figures font-semibold text-[#2A3036]">{otpSeconds}s</span></p>
                    ) : (
                      <button onClick={() => setOtpSeconds(90)} className="text-[12px] text-[#3B82F6] font-semibold hover:underline cursor-pointer">Reenviar código</button>
                    )}
                  </div>

                  <div className="bg-[#F0F9FF] rounded-xl px-4 py-2.5 text-center">
                    <p className="text-[11px] text-[#3B82F6]/70">Demo: el código es{' '}
                      <button
                        onClick={() => { const arr = DEMO_OTP.split(''); setOtpDigits(arr.concat(Array(D - arr.length).fill(''))) }}
                        className="font-figures font-bold text-[#3B82F6] hover:underline cursor-pointer"
                      >{DEMO_OTP}</button>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}

/* ─── Asesor ─────────────────────────────────────────── */
function AsesorCard() {
  const ASESOR = { codigo: 'PCY4237', nombre: 'Camilo Yepes', iniciales: 'CY', rol: 'Asesor experto', tel: '3017077434', telDisplay: '301 707 7434' }

  const waText = encodeURIComponent(
    `¡Hola! 👋 Mi nombre es ${clienteNatural.nombre} (CC. 1030531401). Necesito asesoría con mis productos Koa.`
  )
  const waUrl = `https://wa.me/57${ASESOR.tel}?text=${waText}`

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
      <div className="px-5 py-4 flex items-center gap-4">
        {/* Avatar */}
        <div className="relative flex-shrink-0">
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-black text-[15px]"
            style={{ background: 'linear-gradient(135deg, #3B82F6 0%, #1E40AF 100%)' }}
          >
            {ASESOR.iniciales}
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#00DB8E] border-2 border-white flex items-center justify-center">
            <svg className="w-2 h-2 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-gray-400">{ASESOR.rol} · {ASESOR.codigo}</p>
          <p className="font-bold text-[15px] text-[#2A3036] leading-tight">{ASESOR.nombre}</p>
          <p className="font-figures text-[12px] text-gray-500">{ASESOR.telDisplay}</p>
        </div>

        {/* WhatsApp */}
        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-shrink-0 flex items-center gap-1.5 bg-[#25D366] text-white text-[12px] font-bold px-3.5 py-2 rounded-xl hover:bg-[#1ebe59] transition-colors cursor-pointer whitespace-nowrap"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          Contactar
        </a>
      </div>
    </div>
  )
}

/* ─── Export ─────────────────────────────────────────── */
export default function AsesorReferidos({ mode }: { mode: 'asesor' | 'referidos' }) {
  if (mode === 'asesor') return <AsesorCard />
  return <ProgramaReferidos />
}
