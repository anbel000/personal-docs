import { useState } from 'react'
import OtpModalKoa from './OtpModalKoa'
import { formatPesos } from '../data/mockData'
import type { EstadoCuenta } from './CuentaDesembolso'
import type { ToastPayload } from '../components/NotificationToast'

/* ─── Types & constants ──────────────────────────── */
type Opcion = 'automatica' | 'modificar' | 'no-renovar'
type MontoMode = 'capital' | 'capital-rend' | 'personalizado'
type Periodicidad = 'AL VENCIMIENTO' | 'MENSUAL' | 'TRIMESTRAL' | 'SEMESTRAL' | 'ANUAL'

const PLAZOS = [6, 12, 18, 24, 36]
const MONTO_MIN = 1_000_000
const MONTO_MAX = 500_000_000

const PERIOD_META: Record<Periodicidad, { short: string; desc: string }> = {
  'AL VENCIMIENTO': { short: 'Al vencer', desc: 'Cobras todo al final del plazo' },
  'MENSUAL': { short: 'Mensual', desc: 'Un pago cada mes' },
  'TRIMESTRAL': { short: 'Trimestral', desc: 'Cada 3 meses' },
  'SEMESTRAL': { short: 'Semestral', desc: 'Cada 6 meses' },
  'ANUAL': { short: 'Anual', desc: 'Una vez al año' },
}

function parseMonto(s: string): number {
  return parseInt(s.replace(/\D/g, ''), 10) || 0
}

function formatMontoInput(s: string): string {
  const n = parseMonto(s)
  if (!n) return ''
  return n.toLocaleString('es-CO').replace(/,/g, '.')
}

function simular(monto: number, plazo: number, tasa: number) {
  const rend = Math.round(monto * (Math.pow(1 + tasa / 100, plazo / 12) - 1))
  return { monto, tasa, rend, total: monto + rend }
}

/* ─── Props ──────────────────────────────────────── */
interface Props {
  cdt: {
    id: string
    montoInvertido: number
    rendimientos: number
    fechaVencimiento: string
    tasa: string
    cuentaEstado?: EstadoCuenta
    cuentaBanco?: string
    cuentaTipo?: string
    cuentaNumeroMascarado?: string
  }
  onToast: (t: ToastPayload) => void
}

/* ─── Step badge ─────────────────────────────────── */
function StepBadge({ n, done, locked }: { n: number; done?: boolean; locked?: boolean }) {
  if (done) return (
    <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0 scale-in">
      <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
    </div>
  )
  return (
    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${locked ? 'bg-[#E8ECF2]' : 'bg-[#0C1E4C]'}`}>
      <span className={`text-[10px] font-black ${locked ? 'text-gray-400' : 'text-white'}`}>{n}</span>
    </div>
  )
}

/* ─── Main component ─────────────────────────────── */
export default function CDTRenovacion({ cdt, onToast }: Props) {
  const tasaNum = parseFloat((cdt.tasa ?? '11.80').replace(',', '.'))

  const [opcion, setOpcion] = useState<Opcion>('automatica')
  const [montoMode, setMontoMode] = useState<MontoMode>('capital-rend')
  const [montoPersonalizado, setMontoPersonalizado] = useState('')
  const [plazo, setPlazo] = useState<number | null>(null)
  const [periodicidad, setPeriodicidad] = useState<Periodicidad | null>(null)
  const [firmaOpen, setFirmaOpen] = useState(false)
  const [saved, setSaved] = useState<{ opcion: Opcion; resumen: string } | null>(null)

  /* Cuenta de desembolso — solo mostramos datos si realmente existe */
  const cuentaInscrita = cdt.cuentaEstado === 'validada'
  const cuentaEnProceso = cdt.cuentaEstado === 'en-validacion'
  const cuentaDisponible = cuentaInscrita || cuentaEnProceso

  /* Derived monto */
  const montoBase =
    montoMode === 'capital' ? cdt.montoInvertido
    : montoMode === 'capital-rend' ? cdt.montoInvertido + cdt.rendimientos
    : parseMonto(montoPersonalizado)

  const montoFueraDeRango =
    montoMode === 'personalizado' && montoPersonalizado !== '' &&
    (montoBase < MONTO_MIN || montoBase > MONTO_MAX)

  const montoValido = montoBase >= MONTO_MIN && montoBase <= MONTO_MAX && !montoFueraDeRango
  const condicionesCompletas = montoValido && plazo !== null && periodicidad !== null

  /* Live simulation */
  const simResult = condicionesCompletas ? simular(montoBase, plazo!, tasaNum) : null
  const simActual = simular(cdt.montoInvertido, 12, tasaNum)

  const handleFirmaSuccess = () => {
    setFirmaOpen(false)
    const resumen =
      opcion === 'automatica' ? 'Renovación automática por las mismas condiciones.'
      : opcion === 'modificar' && simResult
        ? `${formatPesos(simResult.monto)} · ${plazo} meses · ${periodicidad}`
        : cuentaInscrita
          ? 'Tu CDT no se renovará. Depositaremos en tu cuenta inscrita.'
          : 'Tu CDT no se renovará. Recuerda inscribir una cuenta de desembolso.'
    setSaved({ opcion, resumen })
    onToast({ tone: 'success', title: 'Instrucción guardada', message: 'Aplicaremos tu preferencia de renovación cuando venza el CDT.' })
  }

  const cambiarOpcion = (op: Opcion) => {
    setOpcion(op)
    setSaved(null)
  }

  /* ── Success state ── */
  if (saved) {
    const okColor = saved.opcion === 'no-renovar' ? '#8A6D00' : '#005E3C'
    const noRenovarSinCuenta = saved.opcion === 'no-renovar' && !cuentaInscrita
    return (
      <div className="space-y-4 fade-in">
        <div className={`rounded-2xl border px-5 py-4 flex items-start gap-3 ${noRenovarSinCuenta ? 'border-[#FFD400]/45 bg-[#FFFBEB]' : 'border-[#00DB8E]/35 bg-[#EFFFF7]'}`}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: noRenovarSinCuenta ? '#FFD400' : '#00DB8E' }}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke={noRenovarSinCuenta ? '#FFFFFF' : '#06005A'} strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-[14px]" style={{ color: okColor }}>Instrucción guardada</p>
            <p className="text-[13px] mt-0.5 leading-snug" style={{ color: okColor, opacity: 0.85 }}>{saved.resumen}</p>
            <p className="text-[11px] mt-1.5" style={{ color: okColor, opacity: 0.6 }}>Se aplicará al vencer el {cdt.fechaVencimiento}.</p>
          </div>
        </div>
        <button
          onClick={() => setSaved(null)}
          className="flex items-center gap-1.5 text-[12px] font-semibold text-[#0098FF] hover:underline cursor-pointer"
        >
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
          Modificar instrucción
        </button>
      </div>
    )
  }

  /* ── Option selector ── */
  const opciones = [
    { id: 'automatica' as Opcion, label: 'Automática', hint: 'Reinvierte todo', icon: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15' },
    { id: 'modificar' as Opcion, label: 'Modificar', hint: 'Cambia condiciones', icon: 'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4' },
    { id: 'no-renovar' as Opcion, label: 'No renovar', hint: 'Recibe tu dinero', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
  ]

  /* ── Main ── */
  return (
    <div className="space-y-4">
      {/* Option selector — segmentado, mint-accent activo */}
      <div className="grid grid-cols-3 gap-2.5">
        {opciones.map(opt => {
          const active = opcion === opt.id
          return (
            <button
              key={opt.id}
              onClick={() => cambiarOpcion(opt.id)}
              aria-pressed={active}
              className={`relative flex flex-col items-center gap-2 py-3.5 px-2 rounded-2xl border-2 transition-all duration-200 cursor-pointer ${
                active
                  ? 'border-transparent text-white shadow-[0_10px_26px_-10px_rgba(6,0,90,0.6)] -translate-y-0.5'
                  : 'bg-white border-[#E8ECF2] text-gray-500 hover:border-[#0C1E4C]/25 hover:text-[#0C1E4C] hover:-translate-y-0.5'
              }`}
              style={active ? { background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' } : undefined}
            >
              {active && (
                <span className="absolute top-2 right-2 w-4 h-4 rounded-full bg-[#00DB8E] flex items-center justify-center scale-in">
                  <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                </span>
              )}
              <span className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${active ? 'bg-white/12' : 'bg-[#F5F7FA]'}`}>
                <svg className={`w-4 h-4 ${active && opt.id === 'automatica' ? 'icon-ring-loop' : ''} ${active ? 'text-[#00DB8E]' : 'text-[#0C1E4C]'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={opt.icon} />
                </svg>
              </span>
              <span className="text-[11px] font-bold leading-none">{opt.label}</span>
              <span className={`text-[9px] leading-none ${active ? 'text-white/55' : 'text-gray-400'}`}>{opt.hint}</span>
            </button>
          )
        })}
      </div>

      {/* ── Panel: Automática ── */}
      {opcion === 'automatica' && (
        <div className="space-y-4 fade-in">
          {/* Resumen hero — mint-forward */}
          <div className="relative overflow-hidden rounded-2xl border border-[#00DB8E]/25 bg-[#EFFFF7] px-5 py-4">
            <div className="absolute -top-10 -right-8 w-28 h-28 rounded-full bg-[#00DB8E]/[0.12] blur-2xl pointer-events-none" />
            <div className="relative flex items-center gap-3">
              <span className="w-10 h-10 rounded-xl bg-[#00DB8E] flex items-center justify-center flex-shrink-0 shadow-[0_6px_16px_-4px_rgba(0,219,142,0.6)]">
                <svg className="w-5 h-5 icon-ring-loop text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
              </span>
              <div className="min-w-0">
                <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-[#005E3C]/70">Se reinvertirá automáticamente</p>
                <p className="font-figures font-black text-[22px] text-[#005E3C] leading-tight mt-0.5">{formatPesos(cdt.montoInvertido + cdt.rendimientos)}</p>
                <p className="text-[11px] text-[#005E3C]/70">Capital + rendimientos, por el mismo plazo</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'PLAZO', value: '12 meses', sub: 'Igual al actual' },
              { label: 'TASA HOY', value: `${cdt.tasa} %`, sub: 'Sujeta a cambios' },
              { label: 'REND. EST.', value: formatPesos(simActual.rend), sub: 'Primer año' },
            ].map(item => (
              <div key={item.label} className="bg-[#F7F7F7] border border-[#F0F2F5] rounded-xl px-3 py-2.5">
                <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">{item.label}</p>
                <p className="font-figures font-bold text-[13px] text-[#2A3036] leading-none">{item.value}</p>
                <p className="text-[9px] text-gray-400 mt-1">{item.sub}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => setFirmaOpen(true)}
            className="w-full flex items-center justify-center gap-2 text-white text-[14px] font-bold px-4 py-3.5 rounded-xl transition-all cursor-pointer hover:brightness-110 active:scale-[0.99] shadow-[0_10px_26px_-10px_rgba(6,0,90,0.6)]"
            style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
          >
            Guardar renovación automática
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>
      )}

      {/* ── Panel: Modificar ── */}
      {opcion === 'modificar' && (
        <div className="space-y-5 fade-in">

          {/* Step 1: Monto */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <StepBadge n={1} done={montoValido} />
              <p className="font-bold text-[13px] text-[#2A3036]">¿Cuánto vas a reinvertir?</p>
            </div>

            <div className="space-y-2">
              {([
                { mode: 'capital' as MontoMode, label: 'Solo el capital', desc: 'Sin incluir rendimientos', amount: cdt.montoInvertido, amountColor: 'text-[#2A3036]' },
                { mode: 'capital-rend' as MontoMode, label: 'Capital + rendimientos', desc: `Incluye ${formatPesos(cdt.rendimientos)} ganados`, amount: cdt.montoInvertido + cdt.rendimientos, amountColor: 'text-[#005E3C]' },
                { mode: 'personalizado' as MontoMode, label: 'Monto personalizado', desc: 'Elige un monto diferente', amount: null, amountColor: '' },
              ]).map(opt => (
                <button
                  key={opt.mode}
                  onClick={() => { setMontoMode(opt.mode); if (opt.mode !== 'personalizado') setMontoPersonalizado('') }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all duration-150 cursor-pointer text-left ${
                    montoMode === opt.mode
                      ? 'border-[#0C1E4C] bg-[#0C1E4C]/[0.03]'
                      : 'border-[#E8ECF2] bg-white hover:border-[#0C1E4C]/30'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${montoMode === opt.mode ? 'border-[#0C1E4C]' : 'border-[#E8ECF2]'}`}>
                    {montoMode === opt.mode && <div className="w-2 h-2 rounded-full bg-[#0C1E4C] scale-in" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-[13px] font-semibold ${montoMode === opt.mode ? 'text-[#0C1E4C]' : 'text-[#2A3036]'}`}>{opt.label}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{opt.desc}</p>
                  </div>
                  {opt.amount !== null && (
                    <span className={`font-figures font-black text-[14px] flex-shrink-0 ${opt.amountColor}`}>
                      {formatPesos(opt.amount)}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {montoMode === 'personalizado' && (
              <div className="mt-3 fade-in">
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-[14px] font-semibold select-none">$</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={montoPersonalizado}
                    onChange={e => setMontoPersonalizado(formatMontoInput(e.target.value))}
                    placeholder="Ej. 30.000.000"
                    autoFocus
                    className={`w-full pl-8 pr-4 py-3 border-2 rounded-xl text-[15px] font-figures font-bold text-[#2A3036] focus:outline-none transition-colors ${
                      montoFueraDeRango ? 'border-[#FA467F] bg-[#FFF0F5]' : 'border-[#E8ECF2] focus:border-[#0C1E4C]'
                    }`}
                  />
                </div>
                <p className={`text-[11px] mt-1.5 ${montoFueraDeRango ? 'text-[#FA467F]' : 'text-gray-400'}`}>
                  {montoFueraDeRango
                    ? `Monto fuera de rango. Entre ${formatPesos(MONTO_MIN)} y ${formatPesos(MONTO_MAX)}.`
                    : `Entre ${formatPesos(MONTO_MIN)} y ${formatPesos(MONTO_MAX)}`}
                </p>
              </div>
            )}
          </div>

          {/* Step 2: Plazo & Periodicidad */}
          <div className={`space-y-4 transition-opacity duration-300 ${montoValido ? '' : 'opacity-35 pointer-events-none'}`}>
            <div className="flex items-center gap-2">
              <StepBadge n={2} done={condicionesCompletas} locked={!montoValido} />
              <p className="font-bold text-[13px] text-[#2A3036]">Plazo y cobro de rendimientos</p>
            </div>

            <div>
              <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Plazo</p>
              <div className="flex gap-2 flex-wrap">
                {PLAZOS.map(p => {
                  const sub = p === 12 ? '1 año' : p === 24 ? '2 años' : p === 36 ? '3 años' : null
                  return (
                    <button
                      key={p}
                      onClick={() => { setPlazo(p); setPeriodicidad(null) }}
                      className={`flex flex-col items-center min-w-[58px] py-2.5 px-3 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
                        plazo === p
                          ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white'
                          : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0C1E4C]/35'
                      }`}
                    >
                      <span className="font-figures font-black text-[19px] leading-none">{p}</span>
                      <span className="text-[8px] font-bold tracking-[0.15em] uppercase mt-0.5 opacity-60">meses</span>
                      {sub && <span className={`text-[9px] mt-0.5 ${plazo === p ? 'text-white/55' : 'text-gray-400'}`}>{sub}</span>}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className={`transition-opacity duration-200 ${plazo !== null ? '' : 'opacity-40 pointer-events-none'}`}>
              <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400 mb-2">Cobro de rendimientos</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(Object.entries(PERIOD_META) as [Periodicidad, typeof PERIOD_META[keyof typeof PERIOD_META]][]).map(([key, meta]) => (
                  <button
                    key={key}
                    onClick={() => setPeriodicidad(key)}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all duration-150 cursor-pointer text-left gap-3 ${
                      periodicidad === key ? 'bg-[#0C1E4C] border-[#0C1E4C]' : 'bg-white border-[#E8ECF2] hover:border-[#0C1E4C]/35'
                    }`}
                  >
                    <div>
                      <p className={`text-[13px] font-semibold ${periodicidad === key ? 'text-white' : 'text-[#2A3036]'}`}>{meta.short}</p>
                      <p className={`text-[11px] mt-0.5 ${periodicidad === key ? 'text-white/55' : 'text-gray-400'}`}>{meta.desc}</p>
                    </div>
                    {periodicidad === key && (
                      <svg className="w-4 h-4 text-[#00DB8E] flex-shrink-0 scale-in" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Step 3: Simulation & Confirm */}
          {simResult && (() => {
            const capitalPct = Math.round((simResult.monto / simResult.total) * 100)
            const rendPct = 100 - capitalPct
            return (
            <div key={simResult.total} className="space-y-4 fade-in">
              <style>{`@keyframes renovGrow{from{width:0}to{width:var(--w)}}.renov-bar-fill{animation:renovGrow .9s cubic-bezier(.22,1,.36,1) both}@media (prefers-reduced-motion: reduce){.renov-bar-fill{animation:none}}`}</style>

              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0 scale-in">
                  <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                </div>
                <p className="font-bold text-[13px] text-[#2A3036]">Tu nueva inversión</p>
              </div>

              {/* Projection hero — mint-forward, con crecimiento visual */}
              <div className="relative overflow-hidden rounded-2xl px-5 py-5 shadow-[0_16px_40px_-16px_rgba(6,0,90,0.55)]" style={{ background: 'linear-gradient(145deg, #0C1E4C 0%, #06005A 100%)' }}>
                <div className="absolute -top-14 -right-10 w-44 h-44 rounded-full bg-[#00DB8E]/[0.14] blur-2xl animate-float pointer-events-none" style={{ ['--dur' as string]: '9s' }} />
                <div className="absolute inset-0 opacity-[0.05] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '22px 22px' }} />

                <div className="relative">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-white/55 text-[10px] font-bold tracking-[0.18em] uppercase">Total estimado al vencimiento</p>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#0C1E4C] bg-white/90 rounded-full px-2 py-0.5">{plazo} meses · {cdt.tasa}%</span>
                  </div>
                  <p className="font-figures text-white font-black leading-none mt-2 animate-number-pop" style={{ fontSize: 'clamp(28px, 7vw, 38px)' }}>
                    {formatPesos(simResult.total)}
                  </p>
                  <p className="font-figures text-[#00DB8E] text-[12px] font-black mt-2.5 inline-flex items-center gap-1.5 bg-[#00DB8E]/12 border border-[#00DB8E]/25 px-2.5 py-1 rounded-lg animate-number-pop" style={{ ['--delay' as string]: '0.12s' }}>
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8m0 0h-5m5 0v5" /></svg>
                    +{formatPesos(simResult.rend)} de rendimientos
                  </p>

                  {/* Barra de composición — capital vs rendimientos */}
                  <div className="mt-5">
                    <div className="flex h-3 rounded-full overflow-hidden bg-white/10">
                      <div className="h-full bg-white/85 rounded-l-full" style={{ width: `${capitalPct}%` }} />
                      <div className="renov-bar-fill h-full rounded-r-full" style={{ ['--w' as string]: `${rendPct}%`, width: `${rendPct}%`, background: 'linear-gradient(90deg,#00DB8E,#00F0A0)', boxShadow: '0 0 12px rgba(0,219,142,0.55)' }} />
                    </div>
                    <div className="flex items-center justify-between mt-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-white/85" />
                        <span className="text-white/60 text-[10px]">Capital</span>
                        <span className="font-figures text-white text-[11px] font-bold ml-1">{formatPesos(simResult.monto)}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#00DB8E]" />
                        <span className="text-white/60 text-[10px]">Rendimientos</span>
                        <span className="font-figures text-[#00DB8E] text-[11px] font-bold ml-1">{formatPesos(simResult.rend)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Delta vs CDT actual */}
                  <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/10">
                    <svg className="w-3.5 h-3.5 text-white/40 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                    <p className="text-[11px] text-white/55">
                      Frente a tu CDT actual de <span className="font-figures font-semibold text-white/80">{formatPesos(cdt.montoInvertido)}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Disclaimer — énfasis alto: es información clave para el cliente */}
              <div className="rounded-2xl border border-[#FFD400]/45 bg-[#FFFBEB] px-4 py-3.5 flex items-start gap-3">
                <div className="w-7 h-7 rounded-lg bg-[#FFD400] flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <p className="text-[12px] text-[#7A5E00] leading-relaxed">
                  Los rendimientos son <span className="font-bold text-[#5C4700]">estimados</span> y se calculan con la tasa vigente hoy. <span className="font-bold text-[#5C4700]">Al renovar se aplica la tasa del día</span>, que puede ser diferente.
                </p>
              </div>

              <button
                onClick={() => setFirmaOpen(true)}
                className="w-full flex items-center justify-center gap-2 bg-[#00DB8E] text-[#06005A] text-[14px] font-black px-4 py-3.5 rounded-xl hover:brightness-105 active:scale-[0.99] transition-all cursor-pointer btn-mint-glow"
              >
                Confirmar esta renovación
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
              </button>
            </div>
            )
          })()}
        </div>
      )}

      {/* ── Panel: No renovar ── */}
      {opcion === 'no-renovar' && (
        <div className="space-y-4 fade-in">
          <div className="rounded-2xl border border-[#0098FF]/25 bg-[#EBF5FF] px-4 py-4 flex items-start gap-4">
            <div className="w-7 h-7 rounded-lg bg-[#0098FF] flex items-center justify-center flex-shrink-0">
              <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-[#2A3036] text-[13px]">Tu CDT no se renovará</p>
              <p className="text-[12px] text-gray-500 mt-0.5 leading-snug">
                Al vencer el {cdt.fechaVencimiento}, dejaremos de reinvertir. Tu capital y tus rendimientos se depositarán en tu cuenta de desembolso.
              </p>
            </div>
          </div>

          {/* Destino del dinero — solo si la cuenta realmente existe */}
          {cuentaDisponible ? (
            <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] px-4 py-3.5">
              <div className="flex items-center justify-between mb-2">
                <p className="text-[9px] font-bold tracking-[0.18em] uppercase text-gray-400">Cuenta de desembolso</p>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cuentaInscrita ? 'bg-[#EFFFF7] text-[#005E3C]' : 'bg-[#FFFBEB] text-[#8A6D00]'}`}>
                  {cuentaInscrita ? 'Validada' : 'En validación'}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#0C1E4C]/[0.06] flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-[#0C1E4C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>
                </div>
                <div className="min-w-0">
                  <p className="font-semibold text-[14px] text-[#2A3036] truncate">{cdt.cuentaBanco ?? 'Bancolombia'} · {cdt.cuentaTipo ?? 'Cuenta de ahorros'}</p>
                  <p className="font-figures text-[13px] text-gray-500 mt-0.5">{cdt.cuentaNumeroMascarado ?? '**** **** ****'}</p>
                </div>
              </div>
              {cuentaEnProceso && (
                <p className="text-[11px] text-[#8A6D00] mt-2.5 leading-snug">Estamos validando esta cuenta. Estará lista antes del vencimiento.</p>
              )}
            </div>
          ) : (
            <div className="rounded-2xl border border-[#FFD400]/45 bg-[#FFFBEB] px-4 py-4 flex items-start gap-4">
              <div className="w-7 h-7 rounded-lg bg-[#FFD400] flex items-center justify-center flex-shrink-0">
                <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M12 3a9 9 0 100 18 9 9 0 000-18z" /></svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-[#2A3036] text-[13px]">No tienes una cuenta inscrita</p>
                <p className="text-[12px] text-gray-500 mt-0.5 leading-snug">
                  Puedes guardar tu decisión de no renovar, pero necesitaremos una cuenta de desembolso para entregarte el dinero. Inscríbela en la sección <span className="font-semibold text-[#8A6D00]">Cuenta de desembolso</span> antes del vencimiento.
                </p>
              </div>
            </div>
          )}

          <button
            onClick={() => setFirmaOpen(true)}
            className="w-full flex items-center justify-center gap-2 bg-white border-2 border-[#E8ECF2] text-[#2A3036] text-[13px] font-bold px-4 py-3.5 rounded-xl hover:border-[#0C1E4C]/30 hover:bg-[#F7F7F7] active:scale-[0.99] transition-all cursor-pointer"
          >
            Confirmar que no deseo renovar
          </button>
        </div>
      )}

      <OtpModalKoa
        open={firmaOpen}
        kicker={opcion === 'automatica' ? 'Renovación automática' : opcion === 'modificar' ? 'Renovación de CDT' : 'Cancelar renovación'}
        onSuccess={handleFirmaSuccess}
        onClose={() => setFirmaOpen(false)}
      />
    </div>
  )
}
