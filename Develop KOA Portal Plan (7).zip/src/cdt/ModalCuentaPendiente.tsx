import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Modal, Button } from '../components/ui'

interface ModalCuentaPendienteProps {
  cdtId?: string
}

export default function ModalCuentaPendiente({ cdtId = '9012' }: ModalCuentaPendienteProps) {
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    const dismissed = sessionStorage.getItem('cuentaPendienteDismissed')
    if (dismissed) return
    const t = setTimeout(() => setOpen(true), 2000)
    return () => clearTimeout(t)
  }, [])

  const handleIr = () => {
    setOpen(false)
    sessionStorage.setItem('cuentaPendienteDismissed', '1')
    navigate(`/cdt/${cdtId}`)
  }

  const handleClose = () => {
    setOpen(false)
    sessionStorage.setItem('cuentaPendienteDismissed', '1')
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Inscribe tu cuenta de desembolso"
      description="Para recibir tus rendimientos y capital al vencimiento, necesitas inscribir una cuenta bancaria en tu CDT."
      icon={
        <div className="w-12 h-12 bg-[#FFFBEB] rounded-2xl flex items-center justify-center">
          <svg className="w-6 h-6 text-[#8A6D00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
          </svg>
        </div>
      }
      footer={
        <>
          <Button variant="secondary" size="md" onClick={handleClose} className="flex-1">Más tarde</Button>
          <Button variant="primary" size="md" onClick={handleIr} className="flex-1">Inscribir ahora</Button>
        </>
      }
    >
      <></>
    </Modal>
  )
}

export function FranjaAlertaCuenta({ cdtId }: { cdtId: string }) {
  const navigate = useNavigate()
  const [dismissed, setDismissed] = useState(false)
  if (dismissed) return null
  return (
    <div className="bg-[#FFFBEB] border border-[#FFD400]/30 rounded-xl px-4 py-2.5 flex items-center gap-2">
      <svg className="w-4 h-4 text-[#8A6D00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
      <span className="flex-1 text-[12px] text-[#8A6D00] font-medium">Sin cuenta de desembolso inscrita</span>
      <button
        onClick={() => navigate(`/cdt/${cdtId}`)}
        className="text-[12px] font-semibold text-[#8A6D00] hover:underline cursor-pointer"
      >
        Inscribir
      </button>
      <button onClick={() => setDismissed(true)} className="text-[#8A6D00] hover:text-[#8A6D00] cursor-pointer">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
  )
}
