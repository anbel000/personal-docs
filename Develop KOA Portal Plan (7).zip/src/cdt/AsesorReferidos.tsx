import { useState } from 'react'
import { clienteNatural } from '../data/mockData'
import { copyText } from '../lib/copy'
import OtpModalKoa from './OtpModalKoa'
import { KoaFlor } from '../components/koa'

/* ─── Referidos ─────────────────────────────────────── */
type RefStep = 'idle' | 'terms' | 'activo'

const CODIGO = 'AB4589R'
const T_AND_C_URL = 'https://koa.co/wp-content/uploads/2026/02/terminos-y-condiciones-programa-de-plan-de-referidos-koa-30012026-vf.pdf'

/* Iconos de los 3 pasos del programa */
const PASOS = [
  { icon: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z', label: 'Actívate', desc: 'Obtén tu código' },
  { icon: 'M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z', label: 'Comparte', desc: 'Invita amigos' },
  { icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z', label: 'Gana bonos', desc: 'Hasta $1.200.000' },
]

function ProgramaReferidos() {
  const [step, setStep] = useState<RefStep>('idle')
  const [accepted, setAccepted] = useState(false)
  const [copiado, setCopiado] = useState(false)
  const [otpOpen, setOtpOpen] = useState(false)

  const copiarCodigo = () => {
    copyText(CODIGO)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2200)
  }

  const waText = encodeURIComponent(
    `¡Hola! 👋\nTe comparto un dato buenísimo. Me uní al Plan de Referidos KOA y tengo un beneficio para ti.\n\nSi abres tu CDT Digital usando mi código: ${CODIGO}, KOA te regala un +0.30% E.A adicional en tu tasa. 💰📈\n\nSolo tienes que:\n1️⃣ Ingresa a www.koa.co\n2️⃣ Ve a la sección CDTs\n3️⃣ Simular tu CDT e ingresar mi código.\n\n¡Es una forma fácil de hacer crecer tus ahorros! Si tienes dudas, avísame. 😉`
  )
  const waUrl = `https://wa.me/?text=${waText}`

  /* ── Activo: código en superficie de marca ── */
  if (step === 'activo') {
    return (
      <div
        className="relative overflow-hidden rounded-3xl card-enter shadow-card"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        <div className="absolute -top-24 -right-16 w-72 h-72 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-22px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-24 -left-12 w-64 h-64 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '16px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

        <div className="relative z-10 p-6">
          <div className="flex items-start gap-3 mb-5">
            <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">Plan de Referidos · KOA</p>
              <p className="text-white font-black text-[16px] leading-tight mt-0.5">Tu plan está <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">activo</span></p>
            </div>
            <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
              <span className="w-1.5 h-1.5 rounded-full bg-brand/60 mint-pulse" />
              Activo
            </span>
          </div>

          {/* Código */}
          <div className="relative bg-white/[0.06] border border-white/10 rounded-2xl px-4 py-5 mb-4 overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-mint/40 to-transparent" />
            <p className="text-white/50 text-[9px] font-bold tracking-[0.24em] uppercase text-center mb-3">Tu código de referido</p>
            <div className="flex items-center justify-center gap-1.5 sm:gap-2">
              {CODIGO.split('').map((ch, i) => (
                <span
                  key={i}
                  className="w-8 sm:w-9 h-11 sm:h-12 rounded-lg bg-white/[0.06] border border-white/10 flex items-center justify-center font-figures text-white font-black text-[22px] sm:text-[26px] leading-none animate-number-pop"
                  style={{ ['--delay' as string]: `${i * 0.07}s` }}
                >
                  {ch}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5 mb-4">
            <svg className="w-3.5 h-3.5 text-mint flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <p className="text-white/60 text-[11px]">Gana de <span className="text-mint font-bold">$25.000</span> a <span className="text-mint font-bold">$1.200.000</span> por referido</p>
          </div>

          <div className="flex gap-2.5">
            <button
              onClick={copiarCodigo}
              className="flex-1 flex items-center justify-center gap-1.5 bg-white/10 border border-white/15 text-white text-[12px] font-bold px-3 py-3 rounded-xl hover:bg-white/[0.16] transition-colors cursor-pointer"
            >
              {copiado
                ? <><svg className="w-3.5 h-3.5 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg><span className="text-mint">Copiado</span></>
                : <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>Copiar código</>
              }
            </button>
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-mint text-brand text-[12px] font-bold px-3 py-3 rounded-xl hover:brightness-105 transition cursor-pointer btn-mint-glow"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Compartir
            </a>
          </div>
        </div>
      </div>
    )
  }

  /* ── Inactivo: invitación en superficie de marca ── */
  return (
    <>
      <div
        className="relative overflow-hidden rounded-3xl card-enter shadow-card"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        <div className="absolute -top-24 -right-16 w-72 h-72 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-22px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-20 -left-12 w-56 h-56 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '16px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

        <div className="relative z-10 p-6">
          <div className="flex items-start gap-3">
            <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">Plan de Referidos · KOA</p>
              <p className="text-white font-black text-[18px] leading-tight mt-0.5">Invita y gana <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">bonos</span></p>
            </div>
          </div>

          {/* Recompensa destacada */}
          <div className="mt-5 mb-6">
            <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Gana por cada referido</p>
            <p className="font-figures text-white font-black leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(28px, 6.5vw, 40px)', ['--delay' as string]: '0.1s' }}>
              $25.000 <span className="text-white/40 text-[18px] font-bold">a</span> $1.200.000
            </p>
            <p className="text-white/55 text-[12px] mt-2">En Bonos Digitales Falabella, más <span className="text-mint font-bold">+0.30% E.A.</span> para tu referido.</p>
          </div>

          {/* 3 pasos */}
          <div className="grid grid-cols-3 gap-2.5 mb-6">
            {PASOS.map((s, i) => (
              <div
                key={s.label}
                className="rounded-2xl bg-white/[0.06] border border-white/10 px-2.5 py-3 text-center fade-in"
                style={{ ['--delay' as string]: `${0.15 + i * 0.08}s` }}
              >
                <div className="w-8 h-8 rounded-xl bg-mint/15 border border-mint/25 flex items-center justify-center mx-auto mb-2">
                  <svg className="w-4 h-4 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.9}><path strokeLinecap="round" strokeLinejoin="round" d={s.icon} /></svg>
                </div>
                <p className="text-white font-bold text-[11.5px] leading-tight">{s.label}</p>
                <p className="text-white/40 text-[10px] mt-0.5 leading-tight">{s.desc}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => { setAccepted(false); setStep('terms') }}
            className="w-full flex items-center justify-center gap-2 bg-mint text-brand text-[13px] font-bold px-5 py-3 rounded-xl hover:brightness-105 transition cursor-pointer btn-mint-glow"
          >
            Activar mi plan de referidos
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>
      </div>

      {/* Terms modal — alineado con el header de marca del Modal OTP del DS */}
      {step === 'terms' && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setStep('idle')} />
          <div className="relative bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden scale-in" style={{ maxHeight: '92vh' }}>
            {/* Header navy con bloom mint */}
            <div className="relative overflow-hidden px-6 pt-6 pb-5 bg-[#06005A]">
              <div className="absolute -top-14 -right-10 w-44 h-44 rounded-full bg-[#00DB8E]/[0.18] blur-2xl pointer-events-none" />
              <button onClick={() => setStep('idle')} className="absolute top-4 right-4 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
              <div className="relative">
                <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">Plan de Referidos</p>
                <h3 className="font-black text-[20px] text-white mt-1 leading-tight">Términos y condiciones</h3>
                <p className="text-white/55 text-[12px] mt-1">Revisa cómo funciona y activa tu beneficio.</p>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 text-[13px] text-gray-600 leading-relaxed">
              <p className="text-[#2A3036] font-semibold">Como cliente de KOA, ahora cuentas con un beneficio exclusivo. Invita a tus amigos y familiares a abrir su primer CDT y obtén <strong>Bonos Digitales Falabella</strong> por cada uno de ellos.</p>
              <div>
                <p className="font-bold text-[#2A3036] mb-2">Participar es muy fácil, solo sigue estos 3 pasos:</p>
                <div className="space-y-2">
                  {[
                    { n: '1', t: 'Actívate', d: 'Acepta los términos y condiciones en este portal para obtener tu código de referido único.' },
                    { n: '2', t: 'Comparte', d: 'Envía tu código a personas que aún no sean clientes de KOA para que lo utilicen al abrir su primer CDT.' },
                    { n: '3', t: 'Gana', d: 'Recibirás un bono por cada referido que complete la apertura de su inversión usando tu código.' },
                  ].map(s => (
                    <div key={s.n} className="flex gap-3">
                      <span className="w-5 h-5 rounded-full bg-[#0C1E4C] text-white text-[11px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{s.n}</span>
                      <p><strong className="text-[#2A3036]">{s.t}:</strong> {s.d}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl p-4">
                <p className="font-bold text-[#005E3C] mb-1">Tus Incentivos</p>
                <p>Recibirás un bono digital por el primer CDT que abra cada uno de tus referidos. El valor del premio dependerá del monto y plazo de la inversión realizada.</p>
                <p className="font-black text-[#005E3C] text-[15px] mt-2">¡Puedes ganar desde $25.000 hasta $1.200.000 por cada referido!</p>
                <p className="mt-2">Los bonos serán enviados directamente al correo electrónico que tienes registrado con nosotros.</p>
              </div>
              <div>
                <p className="font-bold text-[#2A3036] mb-2">Condiciones importantes:</p>
                <ul className="space-y-1.5 list-disc list-inside">
                  <li><strong className="text-[#2A3036]">Clientes nuevos:</strong> Los incentivos aplican únicamente por referidos que nunca hayan tenido un CDT en KOA C.F.</li>
                  <li><strong className="text-[#2A3036]">Beneficio para tu referido:</strong> Al usar tu código, ellos obtendrán una tasa adicional del 0.30% sobre la tasa de su simulación.</li>
                </ul>
              </div>
              <a href={T_AND_C_URL} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-[#0098FF] font-semibold hover:underline">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                Ver términos y condiciones completos
              </a>
            </div>
            <div className="px-6 py-4 border-t border-[#E8ECF2] space-y-3">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} className="mt-0.5 accent-[#00DB8E] w-4 h-4 cursor-pointer" />
                <span className="text-[13px] text-gray-600">He leído y acepto los términos y condiciones del programa de referidos KOA.</span>
              </label>
              <div className="flex gap-2">
                <button onClick={() => setStep('idle')} className="flex-1 bg-gray-100 text-gray-700 text-[13px] font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-200 transition-colors cursor-pointer">Cancelar</button>
                <button
                  disabled={!accepted}
                  onClick={() => setOtpOpen(true)}
                  className="flex-1 bg-[#0C1E4C] text-white text-[13px] font-bold px-4 py-2.5 rounded-xl hover:bg-[#06005A] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Continuar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OTP — Modal del KOA DS */}
      <OtpModalKoa
        open={otpOpen}
        kicker="Activación plan de referidos"
        onSuccess={() => { setOtpOpen(false); setStep('activo') }}
        onClose={() => setOtpOpen(false)}
      />
    </>
  )
}

/* ─── Asesor ─────────────────────────────────────────── */
function AsesorCard() {
  const ASESOR = { codigo: 'PCY4237', nombre: 'Camilo Yepes', iniciales: 'CY', rol: 'Asesor experto', tel: '3017077434', telDisplay: '301 707 7434' }

  const waText = encodeURIComponent(
    `¡Hola! 👋 Mi nombre es ${clienteNatural.nombre} (CC. 1030531401). Necesito asesoría con mis productos Koa.`
  )
  const waUrl = `https://wa.me/57${ASESOR.tel}?text=${waText}`

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
      <div className="px-5 py-4 flex items-center gap-4">
        {/* Avatar */}
        <div className="relative flex-shrink-0">
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-black text-[15px]"
            style={{ background: 'linear-gradient(135deg, #0098FF 0%, #0068B3 100%)' }}
          >
            {ASESOR.iniciales}
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#00DB8E] border-2 border-white flex items-center justify-center">
            <svg className="w-2 h-2 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-gray-400">{ASESOR.rol} · {ASESOR.codigo}</p>
          <p className="font-bold text-[15px] text-[#2A3036] leading-tight">{ASESOR.nombre}</p>
          <p className="font-figures text-[12px] text-gray-500">{ASESOR.telDisplay}</p>
        </div>

        {/* WhatsApp */}
        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-shrink-0 flex items-center gap-1.5 bg-[#25D366] text-white text-[12px] font-bold px-3.5 py-2 rounded-xl hover:bg-[#1ebe59] transition-colors cursor-pointer whitespace-nowrap"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          Contactar
        </a>
      </div>
    </div>
  )
}

/* ─── Export ─────────────────────────────────────────── */
export default function AsesorReferidos({ mode }: { mode: 'asesor' | 'referidos' }) {
  if (mode === 'asesor') return <AsesorCard />
  return <ProgramaReferidos />
}
