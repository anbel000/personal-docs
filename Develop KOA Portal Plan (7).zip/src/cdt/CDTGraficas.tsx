import { useState } from 'react'
import {
  PieChart, Pie, Cell, Tooltip as ReTooltip, ResponsiveContainer,
  XAxis, YAxis, CartesianGrid, Area, AreaChart,
} from 'recharts'
import { cdts as cdtsDefault, formatPesos, type CDT } from '../data/mockData'

/* Colores de marca del KOA Design System — menta, blue e yellow.
   Vibrantes y bien separados (validado CVD). Corto → Mediano → Largo. */
const PALETTE = ['#00DB8E', '#0098FF', '#FFD400']

/* Moneda compacta para el centro del donut (evita apretujar la cifra):
   $ 89.000.000 → $ 89,0 M · $ 850.000 → $ 850 K */
function pesosCompacto(v: number): string {
  if (v >= 1_000_000) return `$ ${(v / 1_000_000).toFixed(1).replace('.', ',')} M`
  if (v >= 1_000) return `$ ${Math.round(v / 1_000)} K`
  return formatPesos(v)
}

/* Composición por tramo de plazo — categorías acotadas que NO crecen con
   la cantidad de CDTs (a diferencia de un item por CDT). */
const BUCKETS = [
  { nombre: 'Corto plazo', detalle: 'Hasta 120 días', max: 120 },
  { nombre: 'Mediano plazo', detalle: '121 – 240 días', max: 240 },
  { nombre: 'Largo plazo', detalle: 'Más de 240 días', max: Infinity },
]

function composicionPorPlazo(lista: CDT[]) {
  const acc = BUCKETS.map(b => ({ nombre: b.nombre, detalle: b.detalle, valor: 0, count: 0 }))
  for (const c of lista) {
    const dias = c.diasRestantes ?? 0
    const idx = dias <= 120 ? 0 : dias <= 240 ? 1 : 2
    acc[idx].valor += c.montoInvertido
    acc[idx].count += 1
  }
  return acc.filter(b => b.valor > 0)
}

const dataMensual = [
  { mes: 'Oct', rendimiento: 241000 },
  { mes: 'Nov', rendimiento: 245800 },
  { mes: 'Dic', rendimiento: 252100 },
  { mes: 'Ene', rendimiento: 258400 },
  { mes: 'Feb', rendimiento: 261700 },
  { mes: 'Mar', rendimiento: 268000 },
  { mes: 'Abr', rendimiento: 275300 },
  { mes: 'May', rendimiento: 280100 },
  { mes: 'Jun', rendimiento: 287500 },
  { mes: 'Jul', rendimiento: 293800 },
  { mes: 'Ago', rendimiento: 301200 },
]

const dataAnual = [
  { mes: '2022', rendimiento: 1840000 },
  { mes: '2023', rendimiento: 2210000 },
  { mes: '2024', rendimiento: 2780000 },
  { mes: '2025', rendimiento: 3050000 },
  { mes: '2026', rendimiento: 3184500 },
]

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0C1E4C] text-white rounded-xl px-3 py-2 text-[12px] shadow-lg">
      <p className="font-semibold">{label}</p>
      <p className="font-figures">{formatPesos(payload[0].value)}</p>
    </div>
  )
}

function DonutTooltip({ active, payload }: { active?: boolean; payload?: { name: string; value: number }[] }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0C1E4C] text-white rounded-xl px-3 py-2 text-[12px] shadow-lg">
      <p className="font-semibold">{payload[0].name}</p>
      <p className="font-figures">{formatPesos(payload[0].value)}</p>
    </div>
  )
}

export default function CDTGraficas({ showKPIs = false, cdts = cdtsDefault }: { showKPIs?: boolean; cdts?: CDT[] }) {
  const [filtro, setFiltro] = useState<'mensual' | 'anual'>('mensual')
  const [infoOpen, setInfoOpen] = useState(false)
  const data = filtro === 'mensual' ? dataMensual : dataAnual
  const dataDonut = composicionPorPlazo(cdts)
  const total = dataDonut.reduce((s, d) => s + d.valor, 0)

  const totalCount = dataDonut.reduce((s, d) => s + d.count, 0)

  return (
    <div className="space-y-4">
      <style>{`
        @keyframes koaSpin { to { transform: rotate(360deg) } }
        @keyframes koaSweep { 0% { transform: translateX(-140%) } 60%,100% { transform: translateX(160%) } }
        @keyframes koaGlow { 0%,100% { opacity: .3 } 50% { opacity: .7 } }
        .koa-ring { animation: koaSpin 18s linear infinite }
        .koa-glow { animation: koaGlow 3.4s ease-in-out infinite }
        .koa-sweep { animation: koaSweep 3.8s ease-in-out infinite }
        @media (prefers-reduced-motion: reduce) {
          .koa-ring, .koa-glow, .koa-sweep { animation: none }
          .koa-sweep { display: none }
        }
      `}</style>
      {showKPIs && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl p-4 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}>
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#0098FF]/10 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-white/40 mb-1">Capital invertido</p>
            <p className="font-figures text-[24px] font-black text-white leading-none">$ 59.000.000</p>
            <p className="text-[11px] text-white/40 mt-1.5">4 CDT activos</p>
          </div>
          <div className="rounded-2xl p-4 relative overflow-hidden bg-[#EFFFF7] border border-[#00DB8E]/25">
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#00DB8E]/15 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#005E3C]/60 mb-1">Rendimientos acumulados</p>
            <p className="font-figures text-[24px] font-black text-[#005E3C] leading-none">$ 4.607.900</p>
            <p className="text-[11px] text-[#005E3C]/60 mt-1.5">Desde apertura</p>
          </div>
          <div className="rounded-2xl p-4 relative overflow-hidden bg-[#EBF5FF] border border-[#0098FF]/20">
            <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-[#0098FF]/10 pointer-events-none" />
            <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#0098FF]/60 mb-1">Tasa ponderada</p>
            <p className="font-figures text-[24px] font-black text-[#0068B3] leading-none">11,68 %</p>
            <p className="text-[11px] text-[#0098FF]/60 mt-1.5">E.A. promedio</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Donut */}
        <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl flex items-center justify-center text-white flex-shrink-0 shadow-[0_4px_12px_-3px_rgba(0,152,255,0.55)]" style={{ background: 'linear-gradient(135deg, #0098FF 0%, #06005A 100%)' }}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" /><path strokeLinecap="round" strokeLinejoin="round" d="M20.488 9A9.004 9.004 0 0015 3.512V9h5.488z" /></svg>
              </span>
              <div>
                <p className="font-semibold text-[15px] text-[#2A3036]">Composición</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Capital por tramo de plazo</p>
              </div>
            </div>
            <button
              onClick={() => setInfoOpen(!infoOpen)}
              className="w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center text-gray-400 hover:bg-gray-200 cursor-pointer flex-shrink-0"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 16v-4m0-4h.01" /></svg>
            </button>
          </div>

          {infoOpen && (
            <div className="bg-[#0C1E4C]/5 rounded-xl p-3 mb-4 text-[12px] text-gray-600 leading-relaxed">
              Agrupa tu capital según cuánto falta para el vencimiento de cada CDT. Así ves la
              distribución por plazo sin importar cuántos CDTs tengas.
            </div>
          )}

          <div className="relative h-52">
            {/* anillo decorativo giratorio — por fuera del donut */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="koa-ring w-[206px] h-[206px] rounded-full border-2 border-dashed border-[#00DB8E]/25" />
            </div>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dataDonut}
                  dataKey="valor"
                  nameKey="nombre"
                  innerRadius="78%"
                  outerRadius="94%"
                  paddingAngle={4}
                  cornerRadius={6}
                  stroke="none"
                >
                  {dataDonut.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
                </Pie>
                <ReTooltip content={<DonutTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none px-10">
              <div className="koa-glow absolute w-24 h-24 rounded-full bg-[#00DB8E]/12 blur-xl" />
              <p className="relative text-[8px] font-bold uppercase tracking-[0.12em] text-gray-400">Total invertido</p>
              <p className="relative font-figures font-black text-[17px] text-[#2A3036] leading-none mt-1.5">{pesosCompacto(total)}</p>
              <p className="relative text-[10px] text-gray-400 mt-1.5">{totalCount} CDT{totalCount !== 1 ? 's' : ''}</p>
            </div>
          </div>

          <div className="space-y-2.5 mt-4">
            {dataDonut.map((d, i) => (
              <div key={d.nombre} className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: PALETTE[i % PALETTE.length] }} />
                <div className="flex-1 min-w-0">
                  <p className="text-[12.5px] font-semibold text-[#2A3036] leading-tight truncate">{d.nombre}</p>
                  <p className="text-[10.5px] text-gray-400 leading-tight">{d.detalle} · {d.count} CDT{d.count !== 1 ? 's' : ''}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-figures text-[12.5px] font-bold text-[#2A3036] leading-tight">{Math.round(d.valor / total * 100)} %</p>
                  <p className="font-figures text-[10.5px] text-gray-400 leading-tight">{formatPesos(d.valor)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Area chart */}
        <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl flex items-center justify-center text-white flex-shrink-0 shadow-[0_4px_12px_-3px_rgba(0,219,142,0.6)]" style={{ background: 'linear-gradient(135deg, #00DB8E 0%, #0098FF 100%)' }}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8m0 0h-5m5 0v5" /></svg>
              </span>
              <div>
                <p className="font-semibold text-[15px] text-[#2A3036]">Rendimientos</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Evolución acumulada</p>
              </div>
            </div>
            <div className="flex rounded-xl border border-[#E8ECF2] overflow-hidden flex-shrink-0">
              {(['mensual', 'anual'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setFiltro(f)}
                  className={`px-3 py-1.5 text-[11px] font-semibold capitalize transition-colors cursor-pointer ${
                    filtro === f ? 'bg-[#0C1E4C] text-white' : 'bg-white text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  {f === 'mensual' ? 'Mensual' : 'Anual'}
                </button>
              ))}
            </div>
          </div>
          <div className="relative flex-1 min-h-[200px] overflow-hidden rounded-xl">
            {/* barrido de luz — efecto constante */}
            <div className="koa-sweep absolute inset-y-0 -left-1/3 w-1/3 pointer-events-none z-10" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.55), transparent)' }} />
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="gradRend" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00DB8E" stopOpacity={0.35} />
                    <stop offset="60%" stopColor="#0098FF" stopOpacity={0.12} />
                    <stop offset="100%" stopColor="#0098FF" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="strokeRend" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#00DB8E" />
                    <stop offset="100%" stopColor="#0098FF" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F0F2F5" vertical={false} />
                <XAxis dataKey="mes" tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <ReTooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="rendimiento" stroke="url(#strokeRend)" strokeWidth={2.5} fill="url(#gradRend)" dot={false} activeDot={{ r: 5, fill: '#0098FF' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  )
}
