import { Link, useLocation } from 'react-router-dom'

const routeLabels: Record<string, string> = {
  '': 'Inicio',
  'libranza': 'Libranza',
  'credito': 'Detalle del crédito',
  'cdt': 'CDT',
  'abrir': 'Abrir CDT',
  'mis-datos': 'Mi perfil',
  'seguridad': 'Seguridad',
  'contactanos': 'Contáctanos',
  'educacion-financiera': 'Educación financiera',
}

export default function Breadcrumb() {
  const location = useLocation()
  const segments = location.pathname.split('/').filter(Boolean)

  if (segments.length === 0) return null

  const crumbs = [{ label: 'Inicio', href: '/' }]
  let path = ''
  for (const seg of segments) {
    path += '/' + seg
    const label = routeLabels[seg] ?? (seg.length > 6 ? `···· ${seg.slice(-4)}` : seg)
    crumbs.push({ label, href: path })
  }

  if (crumbs.length <= 1) return null

  return (
    <nav className="glass border-b border-white/50 px-6 py-2.5 flex items-center gap-1.5 text-[11px] flex-shrink-0">
      {crumbs.map((crumb, i) => (
        <span key={crumb.href} className="flex items-center gap-1.5">
          {i < crumbs.length - 1 ? (
            <Link to={crumb.href} className="text-[#005E3C] hover:text-[#00DB8E] transition-colors font-semibold">{crumb.label}</Link>
          ) : (
            <span className="text-gray-400 font-medium">{crumb.label}</span>
          )}
          {i < crumbs.length - 1 && (
            <svg className="w-3 h-3 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          )}
        </span>
      ))}
    </nav>
  )
}
