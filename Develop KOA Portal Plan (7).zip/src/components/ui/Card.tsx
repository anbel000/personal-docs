import type { HTMLAttributes, ReactNode, MouseEvent } from 'react'

/**
 * Card — neutral surface primitive with organic KOA surfaces.
 * variant: visual ground · interactive: hover elevation ·
 * spotlight: mint glow that tracks the cursor · sheen: light sweep on hover.
 */
type CardVariant = 'default' | 'flat' | 'glass' | 'navy' | 'bloom' | 'gradient'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: CardVariant
  interactive?: boolean
  spotlight?: boolean
  sheen?: boolean
  children?: ReactNode
}

const base: Record<CardVariant, string> = {
  default: 'card',
  flat: 'card-flat',
  glass: 'card-glass',
  navy: 'glass-navy rounded-[20px] text-white',
  bloom: 'rounded-[20px] bg-mint-bg border border-[#00DB90]/25',
  gradient: 'card gradient-border',
}

export default function Card({
  variant = 'default',
  interactive,
  spotlight,
  sheen,
  className = '',
  children,
  onMouseMove,
  ...props
}: CardProps) {
  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    if (spotlight) {
      const r = e.currentTarget.getBoundingClientRect()
      e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`)
      e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`)
    }
    onMouseMove?.(e)
  }

  return (
    <div
      onMouseMove={handleMove}
      className={`${base[variant]} ${spotlight ? 'card-spotlight' : ''} ${sheen ? 'sheen' : ''} ${interactive && !spotlight ? 'quick-link cursor-pointer' : ''} ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}
