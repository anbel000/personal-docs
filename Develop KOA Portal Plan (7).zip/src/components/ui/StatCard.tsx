import type { ReactNode } from 'react'
import Card from './Card'
import IconTile from './IconTile'
import type { IconTileTone } from './IconTile'

/**
 * StatCard — KPI surface. Big figures in Space Grotesk with a pop-in,
 * optional trend and icon. Neutral by API; brand look from tokens.
 */
interface StatCardProps {
  label: string
  value: string
  unit?: string
  icon?: ReactNode
  tone?: IconTileTone
  trend?: { value: string; direction: 'up' | 'down' | 'flat' }
  accent?: boolean // mint bloom surface
  className?: string
}

const trendColor = {
  up: 'text-success-strong bg-success/10',
  down: 'text-error-strong bg-error/10',
  flat: 'text-muted bg-app-bg',
}
const trendArrow = { up: '↑', down: '↓', flat: '→' }

export default function StatCard({
  label, value, unit, icon, tone = 'mint', trend, accent, className = '',
}: StatCardProps) {
  return (
    <Card variant={accent ? 'bloom' : 'default'} spotlight className={`p-5 ${className}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold tracking-wide uppercase text-muted">{label}</p>
          <p className="mt-2 flex items-baseline gap-1">
            <span className="font-figures text-[30px] font-bold text-ink leading-none animate-number-pop">{value}</span>
            {unit && <span className="font-figures text-[14px] font-semibold text-muted">{unit}</span>}
          </p>
        </div>
        {icon && <IconTile toneName={tone}>{icon}</IconTile>}
      </div>
      {trend && (
        <span className={`mt-3 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold ${trendColor[trend.direction]}`}>
          <span aria-hidden="true">{trendArrow[trend.direction]}</span>
          {trend.value}
        </span>
      )}
    </Card>
  )
}
