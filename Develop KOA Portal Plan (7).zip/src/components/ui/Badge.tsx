import type { ReactNode } from 'react'

/**
 * Badge — neutral status/label primitive driven by a semantic `tone`.
 * Domain badges (credit status, product state) should map their meaning
 * onto a tone here rather than re-styling from scratch.
 */
export type BadgeTone = 'neutral' | 'brand' | 'mint' | 'success' | 'warning' | 'error' | 'info'

interface BadgeProps {
  tone?: BadgeTone
  children: ReactNode
  icon?: ReactNode
  dot?: boolean
  className?: string
}

const toneClasses: Record<BadgeTone, string> = {
  neutral: 'bg-app-bg text-ink-soft',
  brand:   'bg-brand/10 text-brand',
  mint:    'bg-mint-bg text-mint-text',
  success: 'bg-success/12 text-success-strong',
  warning: 'bg-warning/15 text-[#92610A]',
  error:   'bg-error/12 text-error-strong',
  info:    'bg-info/12 text-info',
}

const dotColor: Record<BadgeTone, string> = {
  neutral: 'bg-muted-soft',
  brand:   'bg-brand',
  mint:    'bg-mint',
  success: 'bg-success',
  warning: 'bg-warning',
  error:   'bg-error',
  info:    'bg-info',
}

export default function Badge({ tone = 'neutral', children, icon, dot, className = '' }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ${toneClasses[tone]} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColor[tone]}`} aria-hidden="true" />}
      {icon}
      {children}
    </span>
  )
}
