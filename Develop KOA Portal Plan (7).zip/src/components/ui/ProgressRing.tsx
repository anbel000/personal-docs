/**
 * ProgressRing — circular progress with a mint→navy gradient stroke.
 * Neutral primitive; label/value are caller-supplied. The value sits
 * centered inside the ring with breathing room; the caption reads below
 * it so the interior never feels crowded.
 */
interface ProgressRingProps {
  value: number // 0–100
  size?: number
  stroke?: number
  label?: string
  caption?: string
  className?: string
}

export default function ProgressRing({
  value, size = 120, stroke = 9, label, caption, className = '',
}: ProgressRingProps) {
  const pct = Math.max(0, Math.min(100, value))
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const offset = c - (pct / 100) * c
  const valueSize = Math.round(size * 0.19)

  return (
    <div className={`flex flex-col items-center gap-3 ${className}`}>
      <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90" role="img" aria-label={label ? `${label}: ${pct}%` : `${pct}%`}>
          <defs>
            <linearGradient id="koa-ring" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#00DB90" />
              <stop offset="100%" stopColor="#0C1E4C" />
            </linearGradient>
          </defs>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--color-line, #EDEFF3)" strokeWidth={stroke} />
          <circle
            cx={size / 2} cy={size / 2} r={r} fill="none"
            stroke="url(#koa-ring)" strokeWidth={stroke} strokeLinecap="round"
            strokeDasharray={c} strokeDashoffset={offset}
            style={{
              transition: 'stroke-dashoffset 1s cubic-bezier(0.22,1,0.36,1)',
              filter: 'drop-shadow(0 1px 5px rgba(0,219,144,0.35))',
            }}
          />
        </svg>
        <div className="absolute inset-0 grid place-items-center px-3 text-center">
          <span className="font-figures font-bold text-ink leading-none" style={{ fontSize: valueSize }}>
            {label ?? `${pct}%`}
          </span>
        </div>
      </div>
      {caption && (
        <p className="text-[11px] font-semibold text-muted text-center leading-tight max-w-[120px]">{caption}</p>
      )}
    </div>
  )
}
