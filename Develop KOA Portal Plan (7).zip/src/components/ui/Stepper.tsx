/** Stepper — horizontal progress indicator for multi-step flows. */
interface StepperProps {
  steps: string[]
  current: number // 0-based index of the active step
}

export default function Stepper({ steps, current }: StepperProps) {
  return (
    <ol className="flex items-center w-full" aria-label="Progreso">
      {steps.map((label, i) => {
        const done = i < current
        const active = i === current
        const isLast = i === steps.length - 1
        return (
          <li key={label} className={`flex items-center ${isLast ? '' : 'flex-1'}`}>
            <div className="flex flex-col items-center gap-1.5">
              <span
                aria-current={active ? 'step' : undefined}
                className={`flex h-8 w-8 items-center justify-center rounded-full text-[12px] font-semibold transition-all duration-300 ${
                  done
                    ? 'bg-mint text-brand'
                    : active
                    ? 'bg-brand text-white ring-4 ring-brand/15'
                    : 'bg-app-bg text-muted-soft border border-line'
                }`}
              >
                {done ? (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : (
                  i + 1
                )}
              </span>
              <span className={`text-[11px] whitespace-nowrap ${active ? 'font-semibold text-ink' : 'text-muted'}`}>
                {label}
              </span>
            </div>
            {!isLast && (
              <span className="mx-2 mb-5 h-0.5 flex-1 rounded-full bg-line overflow-hidden">
                <span
                  className="block h-full bg-mint transition-all duration-500"
                  style={{ width: done ? '100%' : '0%' }}
                />
              </span>
            )}
          </li>
        )
      })}
    </ol>
  )
}
