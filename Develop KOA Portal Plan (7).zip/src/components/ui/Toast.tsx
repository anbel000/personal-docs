import type { ReactNode } from 'react'
import type { BadgeTone } from './Badge'

/**
 * Toast — transient notification primitive.
 * Announces politely via role=status + aria-live so screen readers
 * pick it up. Callers own show/hide timing.
 */
type ToastTone = Extract<BadgeTone, 'success' | 'error' | 'warning' | 'info'>

interface ToastProps {
  tone?: ToastTone
  title: string
  message?: string
  icon?: ReactNode
  onClose?: () => void
}

const accent: Record<ToastTone, string> = {
  success: 'border-l-success',
  error: 'border-l-error',
  warning: 'border-l-warning',
  info: 'border-l-info',
}

export default function Toast({ tone = 'info', title, message, icon, onClose }: ToastProps) {
  return (
    <div
      role="status"
      aria-live="polite"
      className={`card-flat flex items-start gap-3 border-l-4 ${accent[tone]} px-4 py-3 pr-3 min-w-[280px] max-w-sm scale-in`}
    >
      {icon && <span className="mt-0.5 shrink-0">{icon}</span>}
      <div className="flex-1">
        <p className="text-[13px] font-semibold text-ink">{title}</p>
        {message && <p className="mt-0.5 text-[12px] text-muted">{message}</p>}
      </div>
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Cerrar notificación"
          className="focus-ring rounded-lg p-1 text-muted hover:bg-app-bg"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      )}
    </div>
  )
}
