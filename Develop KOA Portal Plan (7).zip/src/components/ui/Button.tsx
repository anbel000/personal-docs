import type { ButtonHTMLAttributes, ReactNode } from 'react'

/**
 * Button — neutral primitive.
 * Brand look comes from tokens (bg-brand, bg-mint…), not hardcoded hex,
 * so a theme change flows through automatically. Domain buttons should
 * compose this, not fork it.
 */
export type ButtonVariant = 'primary' | 'mint' | 'secondary' | 'ghost' | 'danger'
export type ButtonSize = 'sm' | 'md' | 'lg'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  size?: ButtonSize
  loading?: boolean
  iconOnly?: boolean
  leadingIcon?: ReactNode
  trailingIcon?: ReactNode
  children?: ReactNode
}

const variantClasses: Record<ButtonVariant, string> = {
  primary:   'bg-brand text-white hover:bg-brand-hover shadow-sm disabled:opacity-40',
  mint:      'bg-mint text-brand font-semibold hover:bg-mint-hover btn-mint-glow disabled:opacity-40',
  secondary: 'bg-surface text-ink border border-line hover:bg-app-bg shadow-sm disabled:opacity-40',
  ghost:     'bg-transparent text-ink hover:bg-app-bg disabled:opacity-40',
  danger:    'bg-error text-white hover:bg-error-strong shadow-sm disabled:opacity-40',
}

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'text-[12px] px-3.5 py-2 rounded-xl gap-1.5',
  md: 'text-[13px] px-4.5 py-2.5 rounded-xl gap-2',
  lg: 'text-[14px] px-6 py-3 rounded-2xl gap-2',
}

const iconOnlySize: Record<ButtonSize, string> = {
  sm: 'p-2 rounded-xl',
  md: 'p-2.5 rounded-xl',
  lg: 'p-3 rounded-2xl',
}

export default function Button({
  variant = 'primary',
  size = 'md',
  loading,
  iconOnly,
  leadingIcon,
  trailingIcon,
  children,
  className = '',
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      className={`focus-ring inline-flex items-center justify-center font-semibold transition-all duration-150 cursor-pointer disabled:cursor-not-allowed ${variantClasses[variant]} ${iconOnly ? iconOnlySize[size] : sizeClasses[size]} ${className}`}
      disabled={loading || disabled}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading && (
        <span
          className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
          aria-hidden="true"
        />
      )}
      {!loading && leadingIcon}
      {children}
      {!loading && trailingIcon}
    </button>
  )
}
