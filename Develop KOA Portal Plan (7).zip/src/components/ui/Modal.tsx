import { useEffect, useRef } from 'react'
import type { ReactNode } from 'react'

/**
 * Modal — accessible dialog primitive.
 * role=dialog + aria-modal, focus trap, Escape to close, restores focus
 * to the trigger on close, and locks body scroll while open.
 */
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  description?: string
  children: ReactNode
  footer?: ReactNode
  /** Optional decorative header content (e.g. an icon or brand mark). */
  icon?: ReactNode
  /** Organic bloom entrance + mint glow band at the top. */
  bloom?: boolean
}

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'

export default function Modal({ open, onClose, title, description, children, footer, icon, bloom }: ModalProps) {
  const panelRef = useRef<HTMLDivElement>(null)
  const restoreRef = useRef<HTMLElement | null>(null)

  useEffect(() => {
    if (!open) return
    restoreRef.current = document.activeElement as HTMLElement
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const panel = panelRef.current
    const focusables = panel?.querySelectorAll<HTMLElement>(FOCUSABLE)
    focusables?.[0]?.focus()

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose()
        return
      }
      if (e.key === 'Tab' && focusables && focusables.length > 0) {
        const first = focusables[0]
        const last = focusables[focusables.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
      restoreRef.current?.focus?.()
    }
  }, [open, onClose])

  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 fade-in"
      style={{ background: 'rgba(6,0,90,0.28)' }}
      onClick={onClose}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        aria-describedby={description ? 'modal-desc' : undefined}
        className={`glass relative w-full max-w-md overflow-hidden rounded-3xl p-6 shadow-xl ${bloom ? 'bloom-in' : 'scale-in'}`}
        onClick={(e) => e.stopPropagation()}
      >
        {bloom && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full blur-3xl"
            style={{ background: 'radial-gradient(circle, rgba(0,219,144,0.35), transparent 70%)' }}
          />
        )}
        {icon && <div className="relative mb-4 flex justify-center">{icon}</div>}
        <h2 id="modal-title" className={`relative text-[18px] font-bold text-ink ${icon ? 'text-center' : ''}`}>
          {title}
        </h2>
        {description && (
          <p id="modal-desc" className={`relative mt-1 text-[13px] text-muted ${icon ? 'text-center' : ''}`}>
            {description}
          </p>
        )}
        <div className="relative mt-4">{children}</div>
        {footer && <div className="mt-6 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  )
}
