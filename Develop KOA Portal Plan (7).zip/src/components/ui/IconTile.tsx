import type { ReactNode } from 'react'

/** IconTile — rounded tinted container for an icon. Building block for cards. */
export type IconTileTone = 'mint' | 'navy' | 'success' | 'warning' | 'error' | 'info' | 'neutral'
type IconTileSize = 'sm' | 'md' | 'lg'

const tone: Record<IconTileTone, string> = {
  mint:    'bg-mint-bg text-mint-text',
  navy:    'bg-brand text-white',
  success: 'bg-success/12 text-success-strong',
  warning: 'bg-warning/15 text-[#92610A]',
  error:   'bg-error/12 text-error-strong',
  info:    'bg-info/12 text-info',
  neutral: 'bg-app-bg text-ink',
}
const size: Record<IconTileSize, string> = {
  sm: 'w-8 h-8 rounded-lg',
  md: 'w-11 h-11 rounded-xl',
  lg: 'w-14 h-14 rounded-2xl',
}

export default function IconTile({
  children,
  toneName = 'mint',
  sizeName = 'md',
  className = '',
}: {
  children: ReactNode
  toneName?: IconTileTone
  sizeName?: IconTileSize
  className?: string
}) {
  return (
    <span className={`inline-flex items-center justify-center shrink-0 ${tone[toneName]} ${size[sizeName]} ${className}`}>
      {children}
    </span>
  )
}
