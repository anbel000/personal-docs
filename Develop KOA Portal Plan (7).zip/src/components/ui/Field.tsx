import { useId } from 'react'
import type { InputHTMLAttributes, ReactNode } from 'react'

/**
 * Field — labelled text input primitive with built-in a11y wiring
 * (label htmlFor, aria-invalid, aria-describedby) and token-driven states.
 * Replaces the loose <input> JSX previously scattered across pages.
 */
type FieldState = 'default' | 'error' | 'success'

interface FieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label?: string
  state?: FieldState
  helperText?: string
  leadingIcon?: ReactNode
  trailingIcon?: ReactNode
}

const stateRing: Record<FieldState, string> = {
  default: 'border-line focus-within:border-mint focus-within:shadow-[0_0_0_3px_rgba(0,219,142,0.15)]',
  error: 'border-error focus-within:shadow-[0_0_0_3px_rgba(239,68,68,0.15)]',
  success: 'border-success focus-within:shadow-[0_0_0_3px_rgba(16,185,129,0.15)]',
}

const helperColor: Record<FieldState, string> = {
  default: 'text-muted',
  error: 'text-error',
  success: 'text-mint-text',
}

export default function Field({
  label,
  state = 'default',
  helperText,
  leadingIcon,
  trailingIcon,
  id,
  className = '',
  disabled,
  ...props
}: FieldProps) {
  const autoId = useId()
  const fieldId = id ?? autoId
  const helpId = helperText ? `${fieldId}-help` : undefined

  return (
    <div className={className}>
      {label && (
        <label htmlFor={fieldId} className="block text-[12px] font-semibold text-ink mb-1.5">
          {label}
        </label>
      )}
      <div
        className={`flex items-center gap-2 bg-surface border rounded-xl px-3.5 py-2.5 transition-all ${stateRing[state]} ${disabled ? 'opacity-50 bg-app-bg' : ''}`}
      >
        {leadingIcon && <span className="text-muted shrink-0">{leadingIcon}</span>}
        <input
          id={fieldId}
          disabled={disabled}
          aria-invalid={state === 'error' || undefined}
          aria-describedby={helpId}
          className="w-full bg-transparent text-[13px] text-ink placeholder:text-muted-soft outline-none"
          {...props}
        />
        {trailingIcon && <span className="text-muted shrink-0">{trailingIcon}</span>}
      </div>
      {helperText && (
        <p id={helpId} className={`mt-1.5 text-[11px] ${helperColor[state]}`}>
          {helperText}
        </p>
      )}
    </div>
  )
}
