import { useState } from 'react'
import type { ReactNode } from 'react'

/** Accordion — accessible disclosure list (aria-expanded + region wiring). */
export interface AccordionItem {
  id: string
  title: string
  content: ReactNode
}

interface AccordionProps {
  items: AccordionItem[]
  defaultOpen?: string
}

export default function Accordion({ items, defaultOpen }: AccordionProps) {
  const [open, setOpen] = useState<string | null>(defaultOpen ?? null)

  return (
    <div className="divide-y divide-line rounded-2xl border border-line bg-surface overflow-hidden">
      {items.map((item) => {
        const isOpen = open === item.id
        return (
          <div key={item.id}>
            <h3>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`acc-${item.id}`}
                onClick={() => setOpen(isOpen ? null : item.id)}
                className="focus-ring-inset flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left hover:bg-app-bg"
              >
                <span className="text-[13px] font-semibold text-ink">{item.title}</span>
                <svg
                  width="18" height="18" viewBox="0 0 24 24" fill="none"
                  className={`shrink-0 text-muted transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                  aria-hidden="true"
                >
                  <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </h3>
            {isOpen && (
              <div id={`acc-${item.id}`} className="px-4 pb-4 text-[13px] text-muted fade-in">
                {item.content}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
