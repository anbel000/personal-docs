import { useEffect, useRef } from 'react'
import React from 'react'

/**
 * OtpInput — a row of single-digit inputs for one-time codes.
 *
 * Neutral primitive that owns intra-field behavior (auto-advance, Backspace
 * to previous, Arrow navigation, and full-code paste) so every OTP/firma flow
 * shares one implementation. Controlled via `value` (the concatenated code)
 * and `onChange`. The parent keeps ownership of validation, timers, attempts
 * and lockout — this component is purely the input surface.
 */
export interface OtpInputProps {
  value: string
  onChange: (code: string) => void
  length?: number
  state?: 'default' | 'error'
  size?: 'sm' | 'md'
  masked?: boolean
  fluid?: boolean
  autoFocus?: boolean
  disabled?: boolean
  ariaLabel?: string
}

export default function OtpInput({
  value,
  onChange,
  length = 6,
  state = 'default',
  size = 'sm',
  masked = false,
  fluid = false,
  autoFocus = false,
  disabled = false,
  ariaLabel = 'Código de verificación',
}: OtpInputProps) {
  const refs = useRef<(HTMLInputElement | null)[]>([])
  const digits = Array.from({ length }, (_, i) => value[i] ?? '')

  // Focus the first box on mount and whenever the code is cleared (reset/retry).
  useEffect(() => {
    if (autoFocus && value.length === 0) {
      const t = setTimeout(() => refs.current[0]?.focus(), 30)
      return () => clearTimeout(t)
    }
  }, [autoFocus, value])

  function emit(next: string[]) {
    onChange(next.join(''))
  }

  function handleDigit(i: number, raw: string) {
    if (disabled) return
    const ch = raw.replace(/\D/g, '').slice(-1)
    const next = [...digits]
    next[i] = ch
    emit(next)
    if (ch && i < length - 1) refs.current[i + 1]?.focus()
  }

  function handleKey(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace' && !digits[i] && i > 0) refs.current[i - 1]?.focus()
    if (e.key === 'ArrowLeft' && i > 0) refs.current[i - 1]?.focus()
    if (e.key === 'ArrowRight' && i < length - 1) refs.current[i + 1]?.focus()
  }

  function handlePaste(e: React.ClipboardEvent) {
    if (disabled) return
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length)
    const next = Array<string>(length).fill('')
    pasted.split('').forEach((ch, i) => { next[i] = ch })
    emit(next)
    refs.current[Math.min(pasted.length, length - 1)]?.focus()
  }

  const box = fluid
    ? 'w-full h-[52px] text-[22px]'
    : size === 'md' ? 'w-12 h-14 text-[22px]' : 'w-10 h-12 text-[20px]'

  return (
    <div
      className={fluid ? 'grid gap-1.5 sm:gap-2' : 'flex gap-2 justify-center'}
      style={fluid ? { gridTemplateColumns: `repeat(${length}, minmax(0, 1fr))` } : undefined}
      onPaste={handlePaste}
      role="group"
      aria-label={ariaLabel}
    >
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { refs.current[i] = el }}
          type={masked ? 'password' : 'text'}
          inputMode="numeric"
          maxLength={1}
          value={d}
          disabled={disabled}
          aria-label={`Dígito ${i + 1} de ${length}`}
          onChange={e => handleDigit(i, e.target.value)}
          onKeyDown={e => handleKey(i, e)}
          className={`${box} text-center font-figures font-black rounded-xl border-2 outline-none transition-all duration-150 disabled:opacity-50 ${
            state === 'error'
              ? 'border-[#FA467F] bg-[#FFF0F5] text-[#F70C5B] animate-[shake_0.3s_ease-in-out]'
              : d
                ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]'
                : 'border-[#E8ECF2] bg-white focus:border-[#06005A] text-[#2A3036]'
          }`}
        />
      ))}
    </div>
  )
}
