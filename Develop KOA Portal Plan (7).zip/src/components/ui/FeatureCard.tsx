import type { ReactNode } from 'react'
import Card from './Card'
import IconTile from './IconTile'
import type { IconTileTone } from './IconTile'

/**
 * FeatureCard — icon + title + description surface with organic hover.
 * Uses spotlight glow by default; optional action row.
 */
interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
  tone?: IconTileTone
  action?: ReactNode
  className?: string
}

export default function FeatureCard({
  icon, title, description, tone = 'mint', action, className = '',
}: FeatureCardProps) {
  return (
    <Card spotlight className={`group p-6 ${className}`}>
      <IconTile toneName={tone} sizeName="lg" className="transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105">
        {icon}
      </IconTile>
      <h3 className="mt-4 text-[17px] font-bold text-ink">{title}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-muted">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </Card>
  )
}
