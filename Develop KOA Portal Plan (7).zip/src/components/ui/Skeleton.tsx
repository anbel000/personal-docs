/** Skeleton — shimmer placeholder. Honors prefers-reduced-motion via .shimmer. */
interface SkeletonProps {
  className?: string
  rounded?: string
}

export default function Skeleton({ className = 'h-4 w-full', rounded = 'rounded-lg' }: SkeletonProps) {
  return <div className={`shimmer ${rounded} ${className}`} aria-hidden="true" />
}
