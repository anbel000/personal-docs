import type { ReactNode } from 'react'

interface EmptyStateProps {
  icon: ReactNode
  iconBg?: string
  title: string
  description: string
  action?: ReactNode
}

export default function EmptyState({ icon, iconBg = 'bg-[#EFFFF7]', title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center text-center py-16 px-6 gap-4">
      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${iconBg}`}>
        {icon}
      </div>
      <div>
        <p className="font-semibold text-[#2A3036] text-[17px] mb-1">{title}</p>
        <p className="text-[14px] text-gray-500 max-w-sm">{description}</p>
      </div>
      {action && <div>{action}</div>}
    </div>
  )
}
