import { useState, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'

/**
 * OtpVerificationModal — modal de verificación OTP del Portal KOA.
 *
 * Replica el patrón canónico "FirmaElectronica · OTP Modal" del KOA Design
 * System (/componentes): cabecera navy con eyebrow + título, grid de 6 dígitos,
 * cuenta regresiva, reenvío con cooldown, overlay de validación de 3 pasos y
 * estados de éxito/error.
 *
 * Se renderiza vía `createPortal` a `document.body` para que la superposición
 * cubra TODO el portal y no quede atrapada dentro de contenedores con
 * `transform` (p. ej. tarjetas con animación `card-enter`).
 */
interface OtpVerificationModalProps {
  open: boolean
  onClose: () => void
  /** Se dispara cuando el código es correcto y la validación termina bien. */
  onVerified: () => void
  /** Eyebrow contextual (kicker) sobre el título. */
  kicker: string
  title?: string
  description?: string
  demoCode?: string
  /** Destino enmascarado que se muestra al usuario. */
  sentTo?: string
}

const STEPS = ['Verificando identidad', 'Validando operación', 'Generando resultados']

export default function OtpVerificationModal({
  open,
  onClose,
  onVerified,
  kicker,
  title = 'Autorizar operación',
  description = 'Ingresa el código enviado a tu correo y celular registrado para confirmar',
  demoCode = '248731',
}: OtpVerificationModalProps) {
  const [digits, setDigits] = useState(['', '', '', '', '', ''])
  const [phase, setPhase] = useState<'input' | 'validating' | 'success' | 'error'>('input')
  const [step, setStep] = useState(0)
  const [seconds, setSeconds] = useState(180)
  const [resendIn, setResendIn] = useState(30)
  const [resending, setResending] = useState(false)
  const [resentAt, setResentAt] = useState(0)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  /* Reset al abrir / cerrar */
  useEffect(() => {
    if (!open) {
      setDigits(['', '', '', '', '', ''])
      setPhase('input'); setStep(0); setSeconds(180); setResendIn(30); setResending(false); setResentAt(0)
    }
  }, [open])

  /* Bloqueo de scroll del fondo */
  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [open])

  /* Cierre con Escape */
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  /* Cuenta regresiva de vigencia */
  useEffect(() => {
    if (phase !== 'input' || !open) return
    const t = setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [phase, open])

  /* Cooldown de reenvío */
  useEffect(() => {
    if (!open || resendIn <= 0) return
    const t = setInterval(() => setResendIn(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [open, resendIn])

  /* Confirmación de reenvío se autooculta */
  useEffect(() => {
    if (!resentAt) return
    const t = setTimeout(() => setResentAt(0), 3200)
    return () => clearTimeout(t)
  }, [resentAt])

  /* Secuencia de validación */
  useEffect(() => {
    if (phase !== 'validating') return
    const timers = [
      setTimeout(() => setStep(1), 600),
      setTimeout(() => setStep(2), 1300),
      setTimeout(() => setStep(3), 2000),
      setTimeout(() => { const entered = digits.join(''); setPhase(entered === demoCode ? 'success' : 'error') }, 2600),
    ]
    return () => timers.forEach(clearTimeout)
  }, [phase, digits, demoCode])

  /* Error → reintentar; Éxito → continuar */
  useEffect(() => {
    if (phase === 'error') {
      const t = setTimeout(() => { setDigits(['', '', '', '', '', '']); setPhase('input'); setStep(0) }, 1800)
      return () => clearTimeout(t)
    }
    if (phase === 'success') {
      const t = setTimeout(() => onVerified(), 950)
      return () => clearTimeout(t)
    }
  }, [phase, onVerified])

  const handleResend = () => {
    if (resendIn > 0 || resending || phase !== 'input') return
    setResending(true)
    setTimeout(() => {
      setResending(false)
      setDigits(['', '', '', '', '', ''])
      setSeconds(180); setResendIn(30); setResentAt(Date.now())
      inputRefs.current[0]?.focus()
    }, 1200)
  }

  const handleDigit = (i: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]; next[i] = ch; setDigits(next)
    if (ch && i < 5) inputRefs.current[i + 1]?.focus()
    if (next.every(d => d !== '') && ch) setTimeout(() => setPhase('validating'), 200)
  }

  if (!open) return null

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`

  return createPortal(
    <div
      className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 fade-in"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div role="dialog" aria-modal="true" className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden scale-in">
        {/* Header */}
        <div className="bg-[#06005A] px-6 py-5 relative overflow-hidden">
          <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-[#00DB8E]/10 pointer-events-none" />
          <button onClick={onClose} aria-label="Cerrar" className="absolute top-4 right-4 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
          <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">{kicker}</p>
          <p className="text-white font-black text-[18px] mt-1 leading-tight">{title}</p>
          <p className="text-white/55 text-[12px] mt-1">{description}</p>
        </div>

        <div className="px-6 py-6 relative min-h-[264px] flex flex-col justify-center">
          {/* Validating overlay */}
          {(phase === 'validating' || phase === 'success' || phase === 'error') && (
            <div className="absolute inset-0 bg-white/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-5 px-6 py-6 rounded-b-3xl">
              <div className="relative w-16 h-16 flex items-center justify-center">
                {phase === 'validating' ? (
                  <>
                    <div className="absolute inset-0 rounded-full border-2 border-[#06005A]/15 border-t-[#06005A] animate-spin" />
                    <div className="absolute inset-[9px] rounded-full border-2 border-[#00DB8E]/25 border-t-[#00DB8E] animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#06005A] mint-pulse" />
                  </>
                ) : (
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-[#00DB8E]' : 'bg-[#FA467F]'}`}>
                    {phase === 'success' ? (
                      <svg className="w-[26px] h-[26px] text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    ) : (
                      <svg className="w-[26px] h-[26px] text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                    )}
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
                {STEPS.map((s, i) => {
                  const failIdx = STEPS.length - 1
                  const failed = phase === 'error' && i === failIdx
                  const done = phase === 'success' || (phase === 'error' ? i < failIdx : step > i)
                  const active = phase === 'validating' && step === i
                  return (
                    <div key={s} className="flex items-center gap-2.5">
                      <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-[#00DB8E]' : failed ? 'bg-[#FA467F]' : active ? 'bg-[#06005A]/10' : 'bg-[#F0F2F5]'}`}>
                        {done && <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                        {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                        {active && <span className="w-1.5 h-1.5 rounded-full bg-[#06005A] mint-pulse" />}
                      </div>
                      <p className={`text-[11px] font-semibold ${done ? 'text-[#005E3C]' : failed ? 'text-[#F70C5B]' : active ? 'text-[#2A3036]' : 'text-gray-300'}`}>{s}</p>
                    </div>
                  )
                })}
              </div>
              {phase === 'error' && <p className="text-[12px] font-bold text-[#F70C5B]">Código incorrecto</p>}
            </div>
          )}

          {/* OTP input */}
          <div className={`grid grid-cols-6 gap-1.5 sm:gap-2 mb-4 ${phase === 'error' ? 'animate-[shake_0.35s_ease-in-out]' : ''}`}>
            {digits.map((d, i) => (
              <input
                key={i}
                ref={el => { inputRefs.current[i] = el }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={d}
                autoFocus={i === 0}
                onChange={e => handleDigit(i, e.target.value)}
                onKeyDown={e => { if (e.key === 'Backspace' && !d && i > 0) inputRefs.current[i - 1]?.focus() }}
                className={`w-full h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all ${d ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]' : 'border-[#E8ECF2] bg-white'}`}
                disabled={phase !== 'input'}
              />
            ))}
          </div>

          <div className="flex items-center justify-between gap-3">
            <p className="font-figures text-[12px] text-gray-400">Código válido por <span className={`font-bold ${seconds < 30 ? 'text-[#F70C5B]' : 'text-[#2A3036]'}`}>{fmt}</span></p>
            {resending ? (
              <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A]">
                <span className="w-3.5 h-3.5 rounded-full border-2 border-[#06005A]/25 border-t-[#06005A] animate-spin" />
                Enviando…
              </span>
            ) : resendIn > 0 ? (
              <span aria-hidden />
            ) : (
              <button
                onClick={handleResend}
                disabled={phase !== 'input'}
                className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A] hover:text-[#08007A] cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <svg className="w-[13px] h-[13px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                Reenviar código
              </button>
            )}
          </div>

          {/* Confirmación de reenvío / demo hint */}
          {resentAt ? (
            <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5 fade-in">
              <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <p className="text-[11px] text-[#005E3C] font-semibold">Enviamos un nuevo código a tu correo y celular registrado.</p>
            </div>
          ) : (
            <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2 flex items-center gap-2">
              <svg className="w-3 h-3 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              <p className="text-[11px] text-[#005E3C]">Demo: código es <span className="font-figures font-black">{demoCode}</span></p>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body,
  )
}
