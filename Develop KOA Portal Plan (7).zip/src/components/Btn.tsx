// Backward-compatible alias. Btn is the historic name used across the Portal;
// the canonical primitive now lives in ui/Button. Keep importing either.
export { default } from './ui/Button'
export type { ButtonVariant, ButtonSize } from './ui/Button'
