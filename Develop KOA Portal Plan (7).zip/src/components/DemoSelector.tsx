import { useDemoContext, type Productos } from '../context/DemoContext'
import { useState } from 'react'

type Scenario = { id: Productos; label: string; sub: string; icon: React.ReactNode }

const SCENARIOS: Scenario[] = [
  {
    id: 'ambos',
    label: 'CDT + Libranza',
    sub: 'Ambos productos',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
      </svg>
    ),
  },
  {
    id: 'solo-cdt',
    label: 'Solo CDT',
    sub: 'Sin libranza',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
  },
  {
    id: 'solo-libranza',
    label: 'Solo Libranza',
    sub: 'Sin CDT',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    id: 'ninguno',
    label: 'Sin productos',
    sub: 'Cliente nuevo',
    icon: (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
]

export default function DemoSelector() {
  const { personType, productos, pendientes, setPersonType, setProductos, setPendientes } = useDemoContext()
  const [open, setOpen] = useState(false)

  const current = SCENARIOS.find(s => s.id === productos) ?? SCENARIOS[0]
  const isDisabled = (id: Productos) =>
    personType === 'juridica' && (id === 'ambos' || id === 'solo-libranza')

  return (
    <div className="fixed bottom-20 right-3 sm:bottom-5 sm:right-5 z-50">
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 bg-white border border-[#E8ECF2] rounded-2xl shadow-lg px-3.5 py-2.5 cursor-pointer hover:shadow-xl transition-all"
        >
          <span className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#FA467F] bg-[#FA467F]/10 px-2 py-0.5 rounded-full">
            DEMO
          </span>
          <span className="text-[12px] font-semibold text-[#2A3036]">{current.label}</span>
          <svg className="w-3.5 h-3.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
          </svg>
        </button>
      )}

      {open && (
        <div className="bg-white border border-[#E8ECF2] rounded-2xl shadow-2xl w-[244px] overflow-hidden scale-in">
          <div
            className="flex items-center justify-between px-4 py-3 border-b border-[#E8ECF2]"
            style={{ background: '#06005A' }}
          >
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold tracking-[0.16em] uppercase text-[#FA467F] bg-[#FA467F]/20 px-2 py-0.5 rounded-full">
                DEMO
              </span>
              <span className="text-white text-[12px] font-semibold">Modo demo</span>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer"
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>

          <div className="p-3 space-y-3.5">
            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2 px-0.5">Productos en Home</p>
              <div className="grid grid-cols-2 gap-1.5">
                {SCENARIOS.map(s => {
                  const disabled = isDisabled(s.id)
                  const active = productos === s.id
                  return (
                    <button
                      key={s.id}
                      onClick={() => !disabled && setProductos(s.id)}
                      disabled={disabled}
                      className={`flex flex-col items-start gap-1 px-3 py-2.5 rounded-xl border text-left transition-all ${
                        disabled
                          ? 'border-[#E8ECF2] bg-[#F7F7F7] opacity-40 cursor-not-allowed'
                          : active
                          ? 'border-[#0C1E4C] bg-[#0C1E4C] text-white cursor-pointer'
                          : 'border-[#E8ECF2] bg-white text-gray-600 hover:border-gray-300 cursor-pointer'
                      }`}
                    >
                      <span className={active ? 'text-[#00DB8E]' : 'text-gray-400'}>{s.icon}</span>
                      <span className="text-[11px] font-bold leading-none">{s.label}</span>
                      <span className={`text-[9px] leading-none ${active ? 'text-white/50' : 'text-gray-400'}`}>
                        {disabled ? 'Solo natural' : s.sub}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>

            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1.5 px-0.5">Persona</p>
              <div className="flex rounded-xl overflow-hidden border border-[#E8ECF2]">
                {(['natural', 'juridica'] as const).map(p => (
                  <button
                    key={p}
                    onClick={() => setPersonType(p)}
                    className={`flex-1 py-2 text-[11px] font-semibold transition-colors cursor-pointer ${
                      personType === p ? 'bg-[#0C1E4C] text-white' : 'bg-white text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {p === 'natural' ? 'Natural' : 'Jurídica'}
                  </button>
                ))}
              </div>
              {personType === 'juridica' && (
                <p className="text-[9px] text-[#FFD400] mt-1.5 px-0.5">
                  Jurídica solo puede tener CDT
                </p>
              )}
            </div>

            <div>
              <p className="text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1.5 px-0.5">Estado</p>
              <button
                onClick={() => setPendientes(!pendientes)}
                role="switch"
                aria-checked={pendientes}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-[#E8ECF2] bg-white hover:border-gray-300 transition-colors cursor-pointer"
              >
                <span className={pendientes ? 'text-[#005E3C]' : 'text-gray-400'}>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M5.07 19h13.86c1.54 0 2.5-1.67 1.73-3L13.73 4c-.77-1.33-2.69-1.33-3.46 0L3.34 16c-.77 1.33.19 3 1.73 3z" />
                  </svg>
                </span>
                <span className="flex-1 text-left">
                  <span className="block text-[11px] font-bold leading-none text-[#2A3036]">Pendientes</span>
                  <span className="block text-[9px] leading-none text-gray-400 mt-1">{pendientes ? 'Mostrar avisos' : 'Sin pendientes'}</span>
                </span>
                <span className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${pendientes ? 'bg-[#00DB8E]' : 'bg-[#E8ECF2]'}`}>
                  <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${pendientes ? 'translate-x-4' : ''}`} />
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
