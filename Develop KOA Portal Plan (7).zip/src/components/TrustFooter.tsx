import { KoaLogo } from './koa'
import sfcBlack from '../imports/sfc-black-1.svg'
import fogafinBlack from '../imports/fogafin-black.svg'

/**
 * TrustFooter — footer regulatorio del portal, alineado al patrón del KOA DS
 * ("Uso en contexto · Footer del portal" en Componentes). Usa los SVG de marca
 * empaquetados (SFC / Fogafín) en lugar de PNG externos, con el logotipo KOA y
 * el aviso de copyright. Responsive: fila en desktop, apilado en móvil.
 */
export default function TrustFooter() {
  return (
    <footer className="border-t border-[#E8ECF2] mt-10 bg-white overflow-hidden">
      {/* Móvil — patrón del footer del Login: logos compactos centrados + texto debajo */}
      <div className="sm:hidden px-5 py-5 flex flex-col items-center gap-3">
        <div className="flex items-center gap-5">
          <img src={sfcBlack} alt="Vigilado Superintendencia Financiera de Colombia" className="h-5 w-auto object-contain" />
          <img src={fogafinBlack} alt="Respaldado por Fogafín" className="h-8 w-auto object-contain" />
        </div>
        <p className="w-full text-center text-[10px] text-gray-400 leading-snug">
          © 2026 KOA C.F. · Compañía de Financiamiento S.A.
        </p>
      </div>

      {/* Desktop — fila con divisor + copyright + isotipo */}
      <div className="hidden sm:block max-w-5xl mx-auto px-6 py-7">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-8">
            <img src={sfcBlack} alt="Vigilado Superintendencia Financiera de Colombia" className="h-8 w-auto object-contain" />
            <div className="w-px h-12 bg-[#E8ECF2]" />
            <img src={fogafinBlack} alt="Respaldado por Fogafín" className="h-12 w-auto object-contain" />
          </div>
          <div className="flex items-center justify-between gap-4 ml-auto">
            <div className="text-right">
              <p className="text-[11px] font-bold text-[#2A3036] leading-tight">KOA C.F.</p>
              <p className="text-[10px] text-gray-400 leading-snug mt-0.5">
                Compañía de Financiamiento S.A. · © 2026
              </p>
            </div>
            <KoaLogo kind="isotipo" tone="color" height={28} />
          </div>
        </div>
      </div>
    </footer>
  )
}
