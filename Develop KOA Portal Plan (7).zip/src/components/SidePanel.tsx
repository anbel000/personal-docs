import { useEffect, type ReactNode } from 'react'

interface SidePanelProps {
  open: boolean
  onClose: () => void
  title: string
  width?: number
  children: ReactNode
}

export default function SidePanel({ open, onClose, title, width = 380, children }: SidePanelProps) {
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => { document.body.style.overflow = '' }
  }, [open])

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/30 z-40 transition-opacity duration-300 ${open ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      {/* Panel — full width on mobile */}
      <div
        className={`fixed top-0 right-0 h-full bg-surface shadow-2xl z-50 flex flex-col transition-transform duration-300 ease-out w-full sm:w-auto`}
        style={{ ['--panel-width' as string]: `${width}px`, maxWidth: `${width}px`, transform: open ? 'translateX(0)' : 'translateX(100%)' }}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-line">
          <h2 className="font-bold text-[17px] text-ink">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-surface-alt transition-colors cursor-pointer">
            <svg className="w-5 h-5 text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto scrollable">
          {children}
        </div>
      </div>
    </>
  )
}
