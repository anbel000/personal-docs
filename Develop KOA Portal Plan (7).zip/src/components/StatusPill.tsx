type Variant =
  | 'activo'
  | 'en-mora'
  | 'al-dia'
  | 'pendiente'
  | 'en-proceso'
  | 'resuelto'
  | 'terminado'
  | 'proximo'
  | 'error'

interface StatusPillProps {
  variant: Variant
  label?: string
}

const config: Record<Variant, { dot: string; bg: string; text: string; defaultLabel: string; pulse?: boolean }> = {
  'activo':     { dot: 'bg-[#00DB8E]', bg: 'bg-[#EFFFF7]', text: 'text-[#005E3C]', defaultLabel: 'Activo', pulse: true },
  'en-mora':    { dot: 'bg-[#FA467F]', bg: 'bg-[#FA467F]/12', text: 'text-[#F70C5B]', defaultLabel: 'En mora' },
  'al-dia':     { dot: 'bg-[#10B981]', bg: 'bg-[#10B981]/12', text: 'text-[#005E3C]', defaultLabel: 'Al día', pulse: true },
  'pendiente':  { dot: 'bg-[#FFD400]', bg: 'bg-[#FFD400]/12', text: 'text-[#8A6D00]', defaultLabel: 'Pendiente' },
  'en-proceso': { dot: 'bg-[#FFD400]', bg: 'bg-[#FFD400]/12', text: 'text-[#8A6D00]', defaultLabel: 'En proceso' },
  'resuelto':   { dot: 'bg-[#0098FF]', bg: 'bg-[#0098FF]/12', text: 'text-[#0068B3]', defaultLabel: 'Resuelto' },
  'terminado':  { dot: 'bg-[#9CA3AF]', bg: 'bg-gray-100',      text: 'text-gray-500',  defaultLabel: 'Terminado' },
  'proximo':    { dot: 'bg-[#0098FF]', bg: 'bg-[#0098FF]/12', text: 'text-[#0068B3]', defaultLabel: 'Próximo' },
  'error':      { dot: 'bg-[#FA467F]', bg: 'bg-[#FA467F]/12', text: 'text-[#F70C5B]', defaultLabel: 'Error' },
}

export default function StatusPill({ variant, label }: StatusPillProps) {
  const c = config[variant]
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c.dot} ${c.pulse ? 'mint-pulse' : ''}`} />
      {label ?? c.defaultLabel}
    </span>
  )
}
