import { NavLink } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'

/**
 * BottomNav — navegación inferior (solo móvil), alineada al KOA DS.
 * Estado activo: píldora con tinte del color de producto + ícono en ese color
 * y etiqueta en navy de marca. Inactivo: iconografía en muted. Los colores
 * replican el coding de producto del Sidebar (CDT azul · Libranza verde · mint).
 */
const TABS = [
  {
    label: 'Inicio',
    href: '/',
    exact: true,
    color: '#00DB8E',
    icon: (sw: number) => (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={sw} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    ),
  },
  {
    label: 'CDT',
    href: '/cdt',
    color: '#0098FF',
    icon: (sw: number) => (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={sw} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    ),
  },
  {
    label: 'Libranza',
    href: '/libranza',
    libranzaOnly: true,
    color: '#059669',
    icon: (sw: number) => (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={sw} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    ),
  },
  {
    label: 'Ayuda',
    href: '/contactanos',
    color: '#00DB8E',
    icon: (sw: number) => (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={sw} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    ),
  },
  {
    label: 'Perfil',
    href: '/mis-datos',
    color: '#00DB8E',
    icon: (sw: number) => (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={sw} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    ),
  },
]

export default function BottomNav() {
  const { personType } = useDemoContext()

  const tabs = personType === 'juridica'
    ? TABS.filter(t => !t.libranzaOnly)
    : TABS

  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t border-line bg-white/95 backdrop-blur-sm"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="flex items-stretch h-[62px] px-1.5">
        {tabs.map(tab => (
          <NavLink
            key={tab.href}
            to={tab.href}
            end={tab.exact}
            aria-label={tab.label}
            className="group flex-1 flex flex-col items-center justify-center gap-1 pt-1.5 pb-1 active:scale-95 transition-transform"
          >
            {({ isActive }) => (
              <>
                {/* Píldora con tinte del color de producto (activo) */}
                <span
                  className="flex items-center justify-center h-7 w-12 rounded-full transition-colors duration-200"
                  style={isActive ? { background: `${tab.color}1F` } : undefined}
                >
                  <svg
                    className="h-[22px] w-[22px] transition-colors duration-200"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke={isActive ? tab.color : '#6B7280'}
                  >
                    {tab.icon(isActive ? 2.1 : 1.8)}
                  </svg>
                </span>
                <span
                  className="text-[10px] leading-none transition-colors duration-200"
                  style={{
                    color: isActive ? '#06005A' : '#6B7280',
                    fontWeight: isActive ? 700 : 500,
                  }}
                >
                  {tab.label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
