import { useEffect, useRef } from 'react'
import { KoaLogo } from './koa'

/**
 * WelcomeBanner — aviso destacado (solo imagen) que aparece apenas el usuario
 * inicia sesión. Oscurece todo el portal (overlay) y centra un banner
 * horizontal (16:9). Sin texto ni botones: únicamente la imagen. Mientras no
 * haya imagen, muestra un placeholder branded navy para reservar el espacio.
 *
 * Accesible: role=dialog + aria-modal, Escape para cerrar, bloqueo de scroll
 * del body y foco inicial en el botón de cierre.
 */
interface WelcomeBannerProps {
  open: boolean
  onClose: () => void
  /** Imagen del banner (horizontal, 16:9). Si se omite, se muestra el placeholder. */
  image?: string
  imageAlt?: string
}

export default function WelcomeBanner({
  open,
  onClose,
  image,
  imageAlt = 'Aviso destacado de KOA',
}: WelcomeBannerProps) {
  const closeRef = useRef<HTMLButtonElement>(null)
  const restoreRef = useRef<HTMLElement | null>(null)

  useEffect(() => {
    if (!open) return
    restoreRef.current = document.activeElement as HTMLElement
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
      restoreRef.current?.focus?.()
    }
  }, [open, onClose])

  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6 fade-in"
      style={{ background: 'rgba(6,0,90,0.72)', backdropFilter: 'blur(4px)' }}
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Aviso destacado de KOA"
        className="bloom-in relative w-full max-w-2xl overflow-hidden rounded-3xl bg-[#0C1E4C] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ── Zona de imagen (16:9, horizontal) — reservada y responsive ── */}
        <div className="relative aspect-[16/9] w-full overflow-hidden">
          {image ? (
            <img src={image} alt={imageAlt} className="absolute inset-0 h-full w-full object-cover" />
          ) : (
            // Placeholder branded mientras no haya imagen definitiva
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <div
                aria-hidden="true"
                className="pointer-events-none absolute -top-10 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full blur-3xl"
                style={{ background: 'radial-gradient(circle, rgba(0,219,144,0.35), transparent 70%)' }}
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 opacity-60"
                style={{ background: 'radial-gradient(120% 120% at 50% -10%, rgba(0,152,255,0.25), transparent 60%)' }}
              />
              <KoaLogo kind="logotipo" tone="white" height={34} className="relative" />
              <span className="relative text-[10px] font-bold uppercase tracking-[0.22em] text-white/60">
                Espacio para imagen · 16:9
              </span>
            </div>
          )}
        </div>

        {/* ── Botón cerrar (única affordance, sin texto) ── */}
        <button
          ref={closeRef}
          type="button"
          onClick={onClose}
          aria-label="Cerrar aviso"
          className="focus-ring absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-black/30 text-white backdrop-blur-sm transition-colors hover:bg-black/50"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  )
}
