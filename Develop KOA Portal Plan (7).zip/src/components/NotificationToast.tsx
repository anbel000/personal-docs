import { useEffect } from 'react'

/**
 * NotificationToast — notificación flotante del Portal KOA.
 *
 * Replica EXACTAMENTE el patrón canónico del KOA Design System documentado en
 * /componentes (ToastDemo): tarjeta blanca `rounded-2xl` con sombra suave,
 * barra de acento lateral por tono, IconTile 40×40, título en negrita + cuerpo,
 * botón de cierre y animación `slide-up-toast`. Se posiciona fija abajo a la
 * derecha para un uso consistente en todo el portal.
 */
export type ToastTone = 'success' | 'neutral' | 'error' | 'info'

/** Contenido de una notificación: título + texto descriptivo (patrón KOA DS). */
export interface ToastPayload {
  tone?: ToastTone
  title: string
  message?: string
}

const ICON_PATH: Record<ToastTone, string> = {
  success: 'M5 13l4 4L19 7',
  neutral: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
  error: 'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
  info: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
}

const TONE: Record<ToastTone, { bar: string; iconBg: string; iconColor: string }> = {
  success: { bar: '#00DB8E', iconBg: '#EFFFF7', iconColor: '#005E3C' },
  neutral: { bar: '#06005A', iconBg: '#F0F2F5', iconColor: '#06005A' },
  error: { bar: '#F70C5B', iconBg: '#FFF0F5', iconColor: '#F70C5B' },
  info: { bar: '#0098FF', iconBg: '#EBF5FF', iconColor: '#0068B3' },
}

interface NotificationToastProps {
  tone?: ToastTone
  title: string
  message?: string
  onClose?: () => void
  /** Auto-cierre en ms. 0 lo desactiva (el llamador gestiona el timing). */
  duration?: number
}

export default function NotificationToast({
  tone = 'success',
  title,
  message,
  onClose,
  duration = 4000,
}: NotificationToastProps) {
  useEffect(() => {
    if (!duration || !onClose) return
    const t = setTimeout(onClose, duration)
    return () => clearTimeout(t)
  }, [duration, onClose])

  const meta = TONE[tone]

  return (
    <div className="fixed bottom-4 right-4 z-[60] w-[calc(100%-2rem)] max-w-md">
      <div
        role="status"
        aria-live="polite"
        className="bg-white rounded-2xl shadow-[0_16px_40px_-12px_rgba(6,0,90,0.28)] ring-1 ring-black/[0.04] overflow-hidden flex items-stretch slide-up-toast"
      >
        {/* Barra de acento por tono */}
        <span className="w-1.5 flex-shrink-0" style={{ background: meta.bar }} />
        <div className="flex items-start gap-3.5 px-4 py-3.5 flex-1">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: meta.iconBg }}>
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={meta.iconColor} strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d={ICON_PATH[tone]} />
            </svg>
          </div>
          <div className="min-w-0 flex-1 pt-0.5">
            <p className="text-[14px] font-bold text-[#2A3036] leading-tight">{title}</p>
            {message && <p className="text-[12.5px] text-[#6B7280] leading-snug mt-1">{message}</p>}
          </div>
          {onClose && (
            <button
              onClick={onClose}
              aria-label="Cerrar notificación"
              className="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 hover:text-[#2A3036] hover:bg-[#F0F2F5] transition-colors flex-shrink-0 cursor-pointer"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
