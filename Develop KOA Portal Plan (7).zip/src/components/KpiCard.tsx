import type { ReactNode } from 'react'

interface KpiCardProps {
  icon: ReactNode
  iconBg?: string
  label: string
  value: string
  chip?: string
  chipColor?: string
  delay?: number
  accent?: string
}

export default function KpiCard({
  icon,
  iconBg = 'bg-[#EFFFF7]',
  label,
  value,
  chip,
  chipColor = 'text-[#005E3C] bg-[#EFFFF7]',
  delay = 0,
  accent,
}: KpiCardProps) {
  return (
    <div
      className="card card-enter p-5 flex flex-col gap-4 relative overflow-hidden"
      style={{ animationDelay: `${delay}s` }}
    >
      {accent && (
        <div
          className="absolute top-0 left-0 right-0 h-0.5 rounded-t-[20px] opacity-80"
          style={{ background: accent }}
        />
      )}
      <div className="flex items-start justify-between">
        <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${iconBg}`}>
          {icon}
        </div>
        {chip && (
          <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full tracking-wide ${chipColor}`}>
            {chip}
          </span>
        )}
      </div>
      <div>
        <p className="text-[10px] font-bold tracking-[0.14em] text-gray-400 uppercase mb-1.5">{label}</p>
        <p className="font-figures text-[28px] font-black text-[#2A3036] leading-none">{value}</p>
      </div>
    </div>
  )
}
