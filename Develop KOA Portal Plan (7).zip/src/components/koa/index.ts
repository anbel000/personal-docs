// KOA Design System — domain layer.
// Components that know the business (credit states, products, KOA routes),
// composed on top of the neutral primitives in ../ui.
export { default as CreditStatusPill } from './CreditStatusPill'
export type { CreditStatus } from './CreditStatusPill'
export { default as KoaFlor } from './KoaFlor'
export { default as KoaLogo } from './KoaLogo'
export type { KoaLogoKind, KoaLogoTone } from './KoaLogo'

// Existing domain components (re-exported for a single import surface).
export { default as ProductCard } from '../ProductCard'
export { default as Breadcrumb } from '../Breadcrumb'
export { default as KpiCard } from '../KpiCard'
