// Official KOA brand logos. Assets imported as ES modules (Vite fingerprints
// them at build time) — never hardcode the /src/imports path in src.
import isotipoGreen from '../../imports/koa-logo-green.svg'
import isotipoBlue from '../../imports/koa-logo-blue.svg'
import isotipoBlack from '../../imports/koa-logo-black.svg'
import isotipoWhite from '../../imports/koa-logo-white.svg'
import logotipoGreenBlue from '../../imports/koa-logotipo-green-blue.svg'
import logotipoBlack from '../../imports/koa-logotipo-black.svg'
import logotipoWhite from '../../imports/koa-logotipo-white.svg'

export type KoaLogoKind = 'isotipo' | 'logotipo'
export type KoaLogoTone = 'color' | 'blue' | 'black' | 'white'

const MAP: Record<KoaLogoKind, Partial<Record<KoaLogoTone, string>>> = {
  isotipo: { color: isotipoGreen, blue: isotipoBlue, black: isotipoBlack, white: isotipoWhite },
  logotipo: { color: logotipoGreenBlue, black: logotipoBlack, white: logotipoWhite },
}

interface KoaLogoProps {
  /** isotipo = flor + K · logotipo = wordmark "koa" + flor */
  kind?: KoaLogoKind
  tone?: KoaLogoTone
  className?: string
  height?: number
}

export default function KoaLogo({ kind = 'logotipo', tone = 'color', className = '', height }: KoaLogoProps) {
  const src = MAP[kind][tone] ?? MAP[kind].color!
  return (
    <img
      src={src}
      alt={`KOA — ${kind}`}
      className={`object-contain ${className}`}
      style={height ? { height } : undefined}
    />
  )
}

export {
  isotipoGreen, isotipoBlue, isotipoBlack, isotipoWhite,
  logotipoGreenBlue, logotipoBlack, logotipoWhite,
}
