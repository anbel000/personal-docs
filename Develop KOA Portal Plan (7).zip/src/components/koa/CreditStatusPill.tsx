import { Badge } from '../ui'
import type { BadgeTone } from '../ui'

/**
 * CreditStatusPill — KOA domain component.
 * Knows the business vocabulary (mora, al día, radicado…) and maps each
 * state onto a neutral Badge tone. This is the pattern for the domain
 * layer: encode meaning here, borrow appearance from the primitive.
 */
export type CreditStatus =
  | 'activo'
  | 'en-mora'
  | 'al-dia'
  | 'pendiente'
  | 'en-proceso'
  | 'resuelto'
  | 'terminado'
  | 'proximo'
  | 'error'

const map: Record<CreditStatus, { tone: BadgeTone; label: string; pulse?: boolean }> = {
  'activo':     { tone: 'mint',    label: 'Activo', pulse: true },
  'al-dia':     { tone: 'success', label: 'Al día', pulse: true },
  'en-mora':    { tone: 'error',   label: 'En mora' },
  'pendiente':  { tone: 'warning', label: 'Pendiente' },
  'en-proceso': { tone: 'warning', label: 'En proceso' },
  'resuelto':   { tone: 'info',    label: 'Resuelto' },
  'proximo':    { tone: 'info',    label: 'Próximo' },
  'terminado':  { tone: 'neutral', label: 'Terminado' },
  'error':      { tone: 'error',   label: 'Error' },
}

interface CreditStatusPillProps {
  status: CreditStatus
  label?: string
}

export default function CreditStatusPill({ status, label }: CreditStatusPillProps) {
  const cfg = map[status]
  return (
    <Badge tone={cfg.tone} dot>
      <span className={cfg.pulse ? '' : ''}>{label ?? cfg.label}</span>
    </Badge>
  )
}
