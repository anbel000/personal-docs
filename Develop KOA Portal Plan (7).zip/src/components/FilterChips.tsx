interface Option {
  label: string
  value: string
}

interface FilterChipsProps {
  options: Option[]
  value: string
  onChange: (v: string) => void
}

export default function FilterChips({ options, value, onChange }: FilterChipsProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`px-3 py-1.5 rounded-xl text-[13px] font-semibold transition-colors duration-150 cursor-pointer ${
            value === opt.value
              ? 'bg-[#0C1E4C] text-white'
              : 'bg-white border border-[#E8ECF2] text-gray-600 hover:border-[#0C1E4C] hover:text-[#2A3036]'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}
