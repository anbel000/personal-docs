import { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import { useAuth } from '../context/AuthContext'
import { KoaLogo } from './koa'
import { clienteNatural, clienteJuridico, notificaciones } from '../data/mockData'
import NotificationsPanel from './NotificationsPanel'

const NAV_ITEMS = [
  {
    label: 'Inicio',
    href: '/',
    exact: true,
    icon: (
      <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
    ),
  },
  {
    label: 'CDT',
    href: '/cdt',
    icon: (
      <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
  },
  {
    label: 'Libranza',
    href: '/libranza',
    icon: (
      <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    label: 'Contáctanos',
    href: '/contactanos',
    icon: (
      <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
      </svg>
    ),
  },
]

function productColor(href: string) {
  if (href.startsWith('/libranza')) return '#059669'
  if (href.startsWith('/cdt')) return '#0098FF'
  return '#00DB8E'
}

export default function TopNav() {
  const { personType } = useDemoContext()
  const { logout } = useAuth()
  const navigate = useNavigate()
  const [avatarOpen, setAvatarOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)

  const nombre = personType === 'juridica'
    ? clienteJuridico.razonSocial.split(' ')[0]
    : 'Andrés'
  const correo = personType === 'juridica'
    ? clienteJuridico.correoMascarado
    : clienteNatural.correoMascarado
  const iniciales = personType === 'juridica' ? 'CA' : 'AB'
  const unread = notificaciones.filter(n => !n.leida).length

  const visibleItems = personType === 'juridica'
    ? NAV_ITEMS.filter(i => i.href !== '/libranza')
    : NAV_ITEMS

  return (
    <>
      <header className="sticky top-0 z-40 h-16 flex items-center px-4 sm:px-6 gap-2 flex-shrink-0 bg-surface border-b border-line">
        {/* Logo */}
        <NavLink to="/" className="flex items-center mr-2 lg:mr-6 flex-shrink-0">
          <KoaLogo kind="logotipo" tone="color" height={52} />
        </NavLink>

        {/* Desktop nav links */}
        <nav className="hidden lg:flex items-center gap-1 flex-1">
          {visibleItems.map(item => (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.exact}
              className={({ isActive }) =>
                `relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-[13px] font-semibold transition-all duration-150 ${
                  isActive
                    ? 'text-brand bg-brand/[0.06]'
                    : 'text-muted hover:text-ink hover:bg-surface-alt'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-0.5 rounded-full" style={{ background: productColor(item.href) }} />
                  )}
                  <span className="transition-colors" style={isActive ? { color: productColor(item.href) } : {}}>
                    {item.icon}
                  </span>
                  {item.label}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Tablet icon-only nav */}
        <nav className="hidden md:flex lg:hidden items-center gap-0.5 flex-1">
          {visibleItems.map(item => (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.exact}
              title={item.label}
              className={({ isActive }) =>
                `w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-150 ${
                  isActive
                    ? 'bg-brand/[0.06] text-brand'
                    : 'text-muted hover:text-ink hover:bg-surface-alt'
                }`
              }
            >
              {({ isActive }) => (
                <span style={isActive ? { color: productColor(item.href) } : {}}>{item.icon}</span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="flex-1 md:hidden" />

        {/* Right actions */}
        <div className="flex items-center gap-1">
          {/* Notifications */}
          <button
            onClick={() => setNotifOpen(true)}
            className="relative w-10 h-10 rounded-xl flex items-center justify-center text-muted hover:text-ink hover:bg-surface-alt transition-all cursor-pointer"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            {unread > 0 && (
              <span className="absolute top-1.5 right-1.5 min-w-[16px] h-4 bg-error rounded-full text-[9px] font-bold text-white flex items-center justify-center px-1 border-2 border-surface">
                {unread}
              </span>
            )}
          </button>

          {/* User */}
          <div className="relative">
            <button
              onClick={() => setAvatarOpen(!avatarOpen)}
              className="flex items-center gap-2 pl-1 pr-2 py-1.5 rounded-2xl hover:bg-surface-alt transition-all cursor-pointer ml-1"
            >
              <div className="w-8 h-8 rounded-xl bg-mint-bg border border-mint/30 flex items-center justify-center text-mint-text font-bold text-[12px]">
                {iniciales}
              </div>
              <span className="hidden sm:block text-[13px] font-semibold text-ink-soft">{nombre}</span>
              <svg className={`hidden sm:block w-3.5 h-3.5 text-muted-soft transition-transform duration-200 ${avatarOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {avatarOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setAvatarOpen(false)} />
                <div className="absolute right-0 top-full mt-2 w-64 bg-surface rounded-2xl shadow-[0_20px_50px_-12px_rgba(6,0,90,0.35)] border border-line z-50 overflow-hidden scale-in">
                  {/* Header — superficie de marca con bloom mint */}
                  <div className="relative overflow-hidden px-4 py-4 bg-brand">
                    <div className="absolute -top-10 -right-8 w-32 h-32 rounded-full bg-mint/[0.14] blur-xl pointer-events-none" />
                    <div className="relative flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-mint/20 border border-mint/30 flex items-center justify-center text-mint font-bold text-[15px]">
                        {iniciales}
                      </div>
                      <div className="min-w-0">
                        <p className="text-white font-bold text-[13.5px] leading-tight truncate">{nombre}</p>
                        <p className="text-white/50 text-[11px] font-figures leading-tight truncate">{correo}</p>
                      </div>
                    </div>
                  </div>

                  <div className="p-1.5">
                    <button
                      onClick={() => { setAvatarOpen(false); navigate('/mis-datos') }}
                      className="group w-full text-left px-3 py-2.5 rounded-xl text-[13px] font-semibold text-ink-soft hover:bg-app-bg transition-colors cursor-pointer flex items-center gap-3"
                    >
                      <span className="w-8 h-8 rounded-lg bg-app-bg group-hover:bg-mint-bg text-brand flex items-center justify-center flex-shrink-0 transition-colors">
                        <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                      </span>
                      Mi perfil
                    </button>
                    <button
                      onClick={() => { setAvatarOpen(false); navigate('/seguridad') }}
                      className="group w-full text-left px-3 py-2.5 rounded-xl text-[13px] font-semibold text-ink-soft hover:bg-app-bg transition-colors cursor-pointer flex items-center gap-3"
                    >
                      <span className="w-8 h-8 rounded-lg bg-app-bg group-hover:bg-mint-bg text-brand flex items-center justify-center flex-shrink-0 transition-colors">
                        <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                      </span>
                      Seguridad
                    </button>
                  </div>

                  <div className="border-t border-line p-1.5">
                    <button
                      className="group w-full text-left px-3 py-2.5 rounded-xl text-[13px] font-semibold text-error hover:bg-error-bg transition-colors cursor-pointer flex items-center gap-3"
                      onClick={() => { setAvatarOpen(false); logout() }}
                    >
                      <span className="w-8 h-8 rounded-lg bg-error-bg text-error flex items-center justify-center flex-shrink-0">
                        <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                      </span>
                      Cerrar sesión
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      <NotificationsPanel open={notifOpen} onClose={() => setNotifOpen(false)} />
    </>
  )
}
