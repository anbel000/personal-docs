import { useState } from 'react'
import SidePanel from './SidePanel'
import { IconTile } from './ui'
import type { IconTileTone } from './ui'
import { notificaciones } from '../data/mockData'
import { useNavigate } from 'react-router-dom'

interface NotificationsPanelProps {
  open: boolean
  onClose: () => void
}

/* Mapa tipo → tono del DS (IconTile) + glifo, según la paleta semántica del Design System. */
const TYPE_META: Record<string, { tone: IconTileTone; icon: string }> = {
  proceso:   { tone: 'warning', icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' },
  pago:      { tone: 'success', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
  documento: { tone: 'info',    icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
  aviso:     { tone: 'mint',    icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
  info:      { tone: 'neutral', icon: 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
}

export default function NotificationsPanel({ open, onClose }: NotificationsPanelProps) {
  const navigate = useNavigate()
  const [items, setItems] = useState(notificaciones)

  const markAllRead = () => setItems(items.map(n => ({ ...n, leida: true })))

  const hasUnread = items.some(n => !n.leida)
  const unreadCount = items.filter(n => !n.leida).length

  return (
    <SidePanel open={open} onClose={onClose} title="Notificaciones">
      {/* Barra de acción */}
      <div className="px-5 py-3 border-b border-line flex items-center justify-between">
        <span className="text-[12px] text-muted">
          {hasUnread ? `${unreadCount} sin leer` : 'Todas leídas'}
        </span>
        {hasUnread && (
          <button onClick={markAllRead} className="text-[12px] text-mint-text font-bold hover:underline cursor-pointer">
            Marcar todas como leídas
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center text-center py-14 px-6 gap-3">
          <span className="w-14 h-14 rounded-2xl bg-mint-bg flex items-center justify-center">
            <svg className="w-7 h-7 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </span>
          <p className="text-[14px] text-muted">Estás al día. No tienes notificaciones nuevas.</p>
        </div>
      ) : (
        <div className="px-4 py-3 flex flex-col gap-2">
          {items.map((n) => {
            const meta = TYPE_META[n.tipo] ?? TYPE_META.info
            return (
              <div
                key={n.id}
                className={`flex items-start gap-3 rounded-xl p-3 transition-colors duration-150 ${
                  n.leida ? 'bg-surface hover:bg-surface-alt' : 'bg-warning-bg'
                }`}
              >
                <IconTile toneName={meta.tone} sizeName="sm" className="mt-0.5">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d={meta.icon} />
                  </svg>
                </IconTile>
                <div className="flex-1 min-w-0">
                  <p className={`text-[13px] leading-snug ${n.leida ? 'text-ink-soft' : 'font-semibold text-ink'}`}>{n.titulo}</p>
                  <p className="text-[12px] text-muted mt-0.5">{n.detalle}</p>
                  <p className="text-[11px] text-muted-soft mt-1">{n.tiempo}</p>
                </div>
                {!n.leida && <span className="w-2 h-2 rounded-full bg-warning flex-shrink-0 mt-1.5" />}
              </div>
            )
          })}
        </div>
      )}

      <div className="px-5 py-4 border-t border-line mt-auto">
        <button
          onClick={() => { onClose(); navigate('/') }}
          className="w-full text-center text-[13px] text-brand font-bold hover:underline cursor-pointer"
        >
          Ver todo en el inicio
        </button>
      </div>
    </SidePanel>
  )
}
