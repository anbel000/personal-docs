import React, { useState, useRef, useEffect } from 'react'
import type { PersonType } from '../context/DemoContext'
import { Field, Button } from '../components/ui'
import { KoaLogo, KoaFlor } from '../components/koa'
import sfcBlack from '../imports/sfc-black-1.svg'
import sfcWhite from '../imports/sfc-white-1.svg'
import fogafinBlack from '../imports/fogafin-black.svg'
import fogafinWhite from '../imports/fogafin-white.svg'

const OTP_LENGTH = 6
const DEMO_OTP = '248731'

const DOC_TYPES = [
  { value: 'CC', label: 'CC', desc: 'Cédula de Ciudadanía' },
  { value: 'CE', label: 'CE', desc: 'Cédula de Extranjería' },
]

/* Brand-panel value props — DS iconography (stroke, 1.8w). */
const FEATURES = [
  { icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', label: 'Acceso seguro con doble verificación' },
  { icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6', label: 'Tasas CDT hasta 12,20 % E.A.' },
  { icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z', label: 'Crédito de libranza sin filas ni trámites' },
]

/* Canonical KOA hero gradient (from Design System · /componentes). */
const HERO_BG = 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)'

type Step = 'form' | 'otp'

interface LoginProps {
  onLogin: (personType: PersonType) => void
}

/* ─── OTP modal — replica exacta del componente FirmaElectronica del Design System (/componentes) ─── */
function OtpModal({ onSuccess, onClose }: { onSuccess: () => void; onClose: () => void }) {
  const [digits, setDigits] = useState(['', '', '', '', '', ''])
  const [phase, setPhase] = useState<'input' | 'validating' | 'success' | 'error'>('input')
  const [step, setStep] = useState(0)
  const [seconds, setSeconds] = useState(180)
  const [resendIn, setResendIn] = useState(30)
  const [resending, setResending] = useState(false)
  const [resentAt, setResentAt] = useState(0)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  // Countdown de vigencia
  useEffect(() => {
    if (phase !== 'input') return
    const t = setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [phase])

  // Cooldown de reenvío
  useEffect(() => {
    if (resendIn <= 0) return
    const t = setInterval(() => setResendIn(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [resendIn])

  // Confirmación "código reenviado" se autooculta
  useEffect(() => {
    if (!resentAt) return
    const t = setTimeout(() => setResentAt(0), 3200)
    return () => clearTimeout(t)
  }, [resentAt])

  const handleResend = () => {
    if (resendIn > 0 || resending || phase !== 'input') return
    setResending(true)
    setTimeout(() => {
      setResending(false)
      setDigits(['', '', '', '', '', ''])
      setSeconds(180)
      setResendIn(30)
      setResentAt(Date.now())
      inputRefs.current[0]?.focus()
    }, 1200)
  }

  // Secuencia de validación
  useEffect(() => {
    if (phase !== 'validating') return
    const timers = [
      setTimeout(() => setStep(1), 600),
      setTimeout(() => setStep(2), 1300),
      setTimeout(() => setStep(3), 2000),
      setTimeout(() => { const entered = digits.join(''); setPhase(entered === DEMO_OTP ? 'success' : 'error') }, 2600),
    ]
    return () => timers.forEach(clearTimeout)
  }, [phase, digits])

  // Error → reinicia; Success → continúa al portal
  useEffect(() => {
    if (phase === 'error') {
      const t = setTimeout(() => { setDigits(['', '', '', '', '', '']); setPhase('input'); setStep(0) }, 1800)
      return () => clearTimeout(t)
    }
    if (phase === 'success') {
      const t = setTimeout(onSuccess, 900)
      return () => clearTimeout(t)
    }
  }, [phase])

  const handleDigit = (i: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]; next[i] = ch; setDigits(next)
    if (ch && i < 5) inputRefs.current[i + 1]?.focus()
    if (next.every(d => d !== '') && ch) setTimeout(() => setPhase('validating'), 200)
  }

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
  const steps = ['Verificando identidad', 'Validando operación', 'Generando resultados']

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-surface rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden scale-in">
        {/* Header */}
        <div className="bg-brand px-6 py-5 relative overflow-hidden">
          <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-mint/10 pointer-events-none" />
          <button onClick={onClose} className="absolute top-4 right-4 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
          <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">Autenticación de Portal</p>
          <p className="text-white font-black text-[18px] mt-1 leading-tight">Verifica tu identidad</p>
          <p className="text-white/55 text-[12px] mt-1">Ingresa el código enviado a tu correo y celular registrado para confirmar</p>
        </div>

        <div className="px-6 py-6 relative min-h-[264px] flex flex-col justify-center">
          {/* Validating overlay */}
          {(phase === 'validating' || phase === 'success' || phase === 'error') && (
            <div className="absolute inset-0 bg-surface/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-5 px-6 py-6 rounded-b-3xl">
              <div className="relative w-16 h-16 flex items-center justify-center">
                {phase === 'validating' ? (
                  <>
                    <div className="absolute inset-0 rounded-full border-2 border-brand/15 border-t-brand animate-spin" />
                    <div className="absolute inset-[9px] rounded-full border-2 border-mint/25 border-t-mint animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                    <span className="w-2.5 h-2.5 rounded-full bg-brand mint-pulse" />
                  </>
                ) : (
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-mint' : 'bg-error'}`}>
                    <svg className={`w-6 h-6 ${phase === 'success' ? 'text-brand' : 'text-white'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d={phase === 'success' ? 'M5 13l4 4L19 7' : 'M6 18L18 6M6 6l12 12'} />
                    </svg>
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
                {steps.map((s, i) => {
                  const failIdx = steps.length - 1
                  const failed = phase === 'error' && i === failIdx
                  const done = phase === 'success' || (phase === 'error' ? i < failIdx : step > i)
                  const active = phase === 'validating' && step === i
                  return (
                    <div key={s} className="flex items-center gap-2.5">
                      <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-mint' : failed ? 'bg-error' : active ? 'bg-brand/10' : 'bg-surface-alt'}`}>
                        {done && <svg className="w-2.5 h-2.5 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                        {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                        {active && <span className="w-1.5 h-1.5 rounded-full bg-brand mint-pulse" />}
                      </div>
                      <p className={`text-[11px] font-semibold ${done ? 'text-mint-text' : failed ? 'text-error-strong' : active ? 'text-ink' : 'text-muted-soft'}`}>{s}</p>
                    </div>
                  )
                })}
              </div>
              {phase === 'error' && <p className="text-[12px] font-bold text-error-strong">Código incorrecto</p>}
            </div>
          )}

          {/* OTP input — grid de 6 columnas: escala al ancho del modal */}
          <div className={`grid grid-cols-6 gap-1.5 sm:gap-2 mb-4 ${phase === 'error' ? 'animate-[shake_0.35s_ease-in-out]' : ''}`}>
            {digits.map((d, i) => (
              <input
                key={i}
                ref={el => { inputRefs.current[i] = el }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={d}
                onChange={e => handleDigit(i, e.target.value)}
                onKeyDown={e => { if (e.key === 'Backspace' && !d && i > 0) inputRefs.current[i - 1]?.focus() }}
                autoFocus={i === 0}
                className={`w-full h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all ${d ? 'border-brand bg-brand/[0.05] text-brand' : 'border-line bg-surface'}`}
                disabled={phase !== 'input'}
              />
            ))}
          </div>
          <div className="flex items-center justify-between gap-3">
            <p className="font-figures text-[12px] text-muted-soft">Código válido por <span className={`font-bold ${seconds < 30 ? 'text-error-strong' : 'text-ink'}`}>{fmt}</span></p>
            {resending ? (
              <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-brand">
                <span className="w-3.5 h-3.5 rounded-full border-2 border-brand/25 border-t-brand animate-spin" />
                Enviando…
              </span>
            ) : resendIn > 0 ? (
              <span aria-hidden />
            ) : (
              <button
                onClick={handleResend}
                disabled={phase !== 'input'}
                className="inline-flex items-center gap-1.5 text-[12px] font-bold text-brand hover:text-brand-hover cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                Reenviar código
              </button>
            )}
          </div>

          {/* Confirmación de reenvío / Demo */}
          {resentAt ? (
            <div className="mt-4 bg-mint-bg border border-mint/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5 fade-in">
              <div className="w-5 h-5 rounded-full bg-mint flex items-center justify-center flex-shrink-0">
                <svg className="w-3 h-3 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <p className="text-[11px] text-mint-text font-semibold">Enviamos un nuevo código a tu correo y celular registrado.</p>
            </div>
          ) : (
            <div className="mt-4 bg-mint-bg border border-mint/25 rounded-xl px-3 py-2 flex items-center gap-2">
              <svg className="w-3 h-3 text-mint shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              <p className="text-[11px] text-mint-text">Demo: código es <span className="font-figures font-black">{DEMO_OTP}</span></p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─── Recuperación de clave — flujo estilo Keycloak (forgot-password) adaptado al KOA DS ─── */
type ResetStep = 'identify' | 'code' | 'reset' | 'done'
const OTP_STEPS = ['Verificando identidad', 'Validando código', 'Habilitando restablecimiento']

function ForgotPasswordModal({ onClose }: { onClose: () => void }) {
  const [rstep, setRstep] = useState<ResetStep>('identify')
  const [docType, setDocType] = useState('CC')
  const [docNum, setDocNum] = useState('')
  const [correo, setCorreo] = useState('')
  const [err, setErr] = useState('')
  const [sending, setSending] = useState(false)

  // Paso "code": OTP de 6 dígitos — réplica del modal OTP del DS (fases, validación animada, reenvío)
  const [digits, setDigits] = useState(['', '', '', '', '', ''])
  const [phase, setPhase] = useState<'input' | 'validating' | 'success' | 'error'>('input')
  const [ostep, setOstep] = useState(0)
  const [seconds, setSeconds] = useState(180)
  const [resendIn, setResendIn] = useState(30)
  const [resending, setResending] = useState(false)
  const [resentAt, setResentAt] = useState(0)
  const codeRefs = useRef<(HTMLInputElement | null)[]>([])

  // Paso "reset": nueva clave
  const [clave, setClave] = useState('')
  const [clave2, setClave2] = useState('')
  const [showClave, setShowClave] = useState(false)

  // Countdown de vigencia del código
  useEffect(() => {
    if (rstep !== 'code' || phase !== 'input') return
    const t = setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [rstep, phase])

  // Cooldown de reenvío
  useEffect(() => {
    if (rstep !== 'code' || resendIn <= 0) return
    const t = setInterval(() => setResendIn(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [rstep, resendIn])

  // Confirmación "código reenviado" se autooculta
  useEffect(() => {
    if (!resentAt) return
    const t = setTimeout(() => setResentAt(0), 3200)
    return () => clearTimeout(t)
  }, [resentAt])

  // Secuencia de validación animada (idéntica al DS)
  useEffect(() => {
    if (phase !== 'validating') return
    const timers = [
      setTimeout(() => setOstep(1), 600),
      setTimeout(() => setOstep(2), 1300),
      setTimeout(() => setOstep(3), 2000),
      setTimeout(() => { setPhase(digits.join('') === DEMO_OTP ? 'success' : 'error') }, 2600),
    ]
    return () => timers.forEach(clearTimeout)
  }, [phase, digits])

  // Éxito → avanza a nueva clave; Error → reinicia el input
  useEffect(() => {
    if (phase === 'success') {
      const t = setTimeout(() => { setRstep('reset'); setPhase('input'); setOstep(0) }, 700)
      return () => clearTimeout(t)
    }
    if (phase === 'error') {
      const t = setTimeout(() => { setDigits(['', '', '', '', '', '']); setPhase('input'); setOstep(0); codeRefs.current[0]?.focus() }, 1800)
      return () => clearTimeout(t)
    }
  }, [phase])

  const maskedTarget = correo.trim()
    ? correo.replace(/^(.)(.*)(@.*)$/, (_, a, b, c) => `${a}${'•'.repeat(Math.max(2, b.length))}${c}`)
    : 'tu correo registrado'

  function submitIdentify(e: React.FormEvent) {
    e.preventDefault()
    setErr('')
    if (!docNum.trim()) { setErr('Ingresa tu número de documento'); return }
    if (!/^\S+@\S+\.\S+$/.test(correo.trim())) { setErr('Ingresa un correo válido'); return }
    setSending(true)
    setTimeout(() => {
      setSending(false)
      setRstep('code')
      setPhase('input')
      setDigits(['', '', '', '', '', ''])
      setOstep(0)
      setSeconds(180)
      setResendIn(30)
      setTimeout(() => codeRefs.current[0]?.focus(), 60)
    }, 1100)
  }

  const handleDigit = (i: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]; next[i] = ch; setDigits(next)
    if (ch && i < 5) codeRefs.current[i + 1]?.focus()
    if (next.every(d => d !== '') && ch) setTimeout(() => setPhase('validating'), 200)
  }

  const handleResend = () => {
    if (resendIn > 0 || resending || phase !== 'input') return
    setResending(true)
    setTimeout(() => {
      setResending(false)
      setDigits(['', '', '', '', '', ''])
      setSeconds(180)
      setResendIn(30)
      setResentAt(Date.now())
      codeRefs.current[0]?.focus()
    }, 1200)
  }

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`

  const claveValida = clave.length >= 6
  const claveCoincide = clave2.length > 0 && clave === clave2

  function submitReset(e: React.FormEvent) {
    e.preventDefault()
    setErr('')
    if (!claveValida) { setErr('La clave debe tener al menos 6 dígitos'); return }
    if (!claveCoincide) { setErr('Las claves no coinciden'); return }
    setSending(true)
    setTimeout(() => { setSending(false); setRstep('done') }, 1000)
  }

  const stepIndex = { identify: 0, code: 1, reset: 2, done: 3 }[rstep]

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-surface rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden scale-in">
        {/* Header hero */}
        <div className="bg-brand px-6 py-5 relative overflow-hidden">
          <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-mint/10 pointer-events-none" />
          <button onClick={onClose} className="absolute top-4 right-4 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
          <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">Recuperar acceso</p>
          <p className="text-white font-black text-[18px] mt-1 leading-tight">
            {rstep === 'identify' && 'Restablece tu clave'}
            {rstep === 'code' && 'Verifica que eres tú'}
            {rstep === 'reset' && 'Crea una nueva clave'}
            {rstep === 'done' && 'Clave actualizada'}
          </p>
          {/* Mini stepper */}
          <div className="flex items-center gap-1.5 mt-3">
            {[0, 1, 2].map(i => (
              <span key={i} className={`h-1 rounded-full transition-all duration-300 ${i <= stepIndex ? 'bg-mint w-7' : 'bg-white/20 w-4'}`} />
            ))}
          </div>
        </div>

        <div className="px-6 py-6">
          {/* ── Paso 1: identificar ── */}
          {rstep === 'identify' && (
            <form onSubmit={submitIdentify} className="space-y-4 fade-in">
              <p className="text-[12.5px] text-ink-soft leading-relaxed">
                Confirma tu documento y correo. Te enviaremos un código de verificación para restablecer tu clave de forma segura.
              </p>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">Tipo y número de documento</label>
                <div className="flex gap-2">
                  {DOC_TYPES.map(dt => (
                    <button key={dt.value} type="button" onClick={() => setDocType(dt.value)} title={dt.desc}
                      className={`px-3 py-2 rounded-xl text-[12px] font-bold transition-all cursor-pointer ${docType === dt.value ? 'bg-brand text-white shadow-md shadow-brand/20' : 'bg-surface-alt text-muted hover:bg-line hover:text-ink'}`}>
                      {dt.label}
                    </button>
                  ))}
                  <Field type="text" inputMode="numeric" placeholder="Ej. 1000123456" value={docNum}
                    onChange={e => setDocNum(e.target.value.replace(/\D/g, ''))} className="font-figures flex-1" />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">Correo registrado</label>
                <Field type="email" placeholder="nombre@correo.com" value={correo} onChange={e => setCorreo(e.target.value)}
                  leadingIcon={
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  } />
              </div>
              {err && (
                <div className="flex items-center gap-2 bg-error-bg border border-error/25 rounded-xl px-3.5 py-2.5">
                  <svg className="w-4 h-4 text-error-strong flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  <p className="text-[12px] font-semibold text-error-strong">{err}</p>
                </div>
              )}
              <Button type="submit" variant="primary" size="lg" className="w-full font-black" disabled={sending}
                leadingIcon={sending
                  ? <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                  : <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>}>
                {sending ? 'Enviando código…' : 'Enviar código'}
              </Button>
            </form>
          )}

          {/* ── Paso 2: código de verificación — réplica del modal OTP del DS ── */}
          {rstep === 'code' && (
            <div className="fade-in">
              <p className="text-[12.5px] text-ink-soft leading-relaxed mb-4">
                Ingresa el código de 6 dígitos que enviamos a <span className="font-bold text-ink">{maskedTarget}</span> y a tu celular registrado.
              </p>
              <div className="relative min-h-[210px] flex flex-col justify-center">
                {/* Overlay de validación */}
                {(phase === 'validating' || phase === 'success' || phase === 'error') && (
                  <div className="absolute inset-0 bg-surface/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-5">
                    <div className="relative w-16 h-16 flex items-center justify-center">
                      {phase === 'validating' ? (
                        <>
                          <div className="absolute inset-0 rounded-full border-2 border-brand/15 border-t-brand animate-spin" />
                          <div className="absolute inset-[9px] rounded-full border-2 border-mint/25 border-t-mint animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                          <span className="w-2.5 h-2.5 rounded-full bg-brand mint-pulse" />
                        </>
                      ) : (
                        <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-mint' : 'bg-error'}`}>
                          {phase === 'success'
                            ? <svg className="w-[26px] h-[26px] text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                            : <svg className="w-[26px] h-[26px] text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
                      {OTP_STEPS.map((s, i) => {
                        const failIdx = OTP_STEPS.length - 1
                        const failed = phase === 'error' && i === failIdx
                        const done = phase === 'success' || (phase === 'error' ? i < failIdx : ostep > i)
                        const active = phase === 'validating' && ostep === i
                        return (
                          <div key={s} className="flex items-center gap-2.5">
                            <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-mint' : failed ? 'bg-error' : active ? 'bg-brand/10' : 'bg-surface-alt'}`}>
                              {done && <svg className="w-2.5 h-2.5 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                              {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                              {active && <span className="w-1.5 h-1.5 rounded-full bg-brand mint-pulse" />}
                            </div>
                            <p className={`text-[11px] font-semibold ${done ? 'text-mint-text' : failed ? 'text-error-strong' : active ? 'text-ink' : 'text-muted-soft'}`}>{s}</p>
                          </div>
                        )
                      })}
                    </div>
                    {phase === 'error' && <p className="text-[12px] font-bold text-error-strong">Código incorrecto</p>}
                  </div>
                )}

                {/* Input OTP */}
                <div className={`grid grid-cols-6 gap-1.5 sm:gap-2 mb-4 ${phase === 'error' ? 'animate-[shake_0.35s_ease-in-out]' : ''}`}>
                  {digits.map((d, i) => (
                    <input key={i} ref={el => { codeRefs.current[i] = el }} type="text" inputMode="numeric" maxLength={1} value={d}
                      onChange={e => handleDigit(i, e.target.value)}
                      onKeyDown={e => { if (e.key === 'Backspace' && !d && i > 0) codeRefs.current[i - 1]?.focus() }}
                      disabled={phase !== 'input'}
                      className={`w-full h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all ${d ? 'border-brand bg-brand/[0.05] text-brand' : 'border-line bg-surface'}`} />
                  ))}
                </div>
                <div className="flex items-center justify-between gap-3">
                  <p className="font-figures text-[12px] text-muted-soft">Código válido por <span className={`font-bold ${seconds < 30 ? 'text-error-strong' : 'text-ink'}`}>{fmt}</span></p>
                  {resending ? (
                    <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-brand">
                      <span className="w-3.5 h-3.5 rounded-full border-2 border-brand/25 border-t-brand animate-spin" />
                      Enviando…
                    </span>
                  ) : resendIn > 0 ? (
                    <span aria-hidden />
                  ) : (
                    <button onClick={handleResend} disabled={phase !== 'input'}
                      className="inline-flex items-center gap-1.5 text-[12px] font-bold text-brand hover:text-brand-hover cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                      Reenviar código
                    </button>
                  )}
                </div>

                {/* Confirmación de reenvío / Demo */}
                {resentAt ? (
                  <div className="mt-4 bg-mint-bg border border-mint/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5 fade-in">
                    <div className="w-5 h-5 rounded-full bg-mint flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <p className="text-[11px] text-mint-text font-semibold">Enviamos un nuevo código a tu correo y celular registrado.</p>
                  </div>
                ) : (
                  <div className="mt-4 bg-mint-bg border border-mint/25 rounded-xl px-3 py-2 flex items-center gap-2">
                    <KoaFlor showK={false} color="#00DB8E" className="w-4 h-4 shrink-0" />
                    <p className="text-[11px] text-mint-text">Demo: código es <span className="font-figures font-black">{DEMO_OTP}</span></p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Paso 3: nueva clave ── */}
          {rstep === 'reset' && (
            <form onSubmit={submitReset} className="space-y-4 fade-in">
              <p className="text-[12.5px] text-ink-soft leading-relaxed">Define una nueva clave de acceso. Debe tener al menos 6 dígitos.</p>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">Nueva clave</label>
                <Field type={showClave ? 'text' : 'password'} inputMode="numeric" placeholder="••••••" value={clave}
                  onChange={e => setClave(e.target.value)} className="font-figures [&_input]:tracking-[0.2em]"
                  leadingIcon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>}
                  trailingIcon={
                    <button type="button" onClick={() => setShowClave(!showClave)} aria-label={showClave ? 'Ocultar clave' : 'Mostrar clave'} className="text-muted-soft hover:text-ink cursor-pointer transition-colors flex">
                      {showClave
                        ? <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
                        : <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>}
                    </button>
                  } />
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">Confirma tu clave</label>
                <Field type={showClave ? 'text' : 'password'} inputMode="numeric" placeholder="••••••" value={clave2}
                  onChange={e => setClave2(e.target.value)} className="font-figures [&_input]:tracking-[0.2em]"
                  leadingIcon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
              </div>
              {/* Chips de validación */}
              <div className="flex flex-wrap gap-2">
                <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1 rounded-full ${claveValida ? 'bg-mint-bg text-mint-text' : 'bg-surface-alt text-muted'}`}>
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  Mínimo 6 dígitos
                </span>
                <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-1 rounded-full ${claveCoincide ? 'bg-mint-bg text-mint-text' : 'bg-surface-alt text-muted'}`}>
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                  Coinciden
                </span>
              </div>
              {err && (
                <div className="flex items-center gap-2 bg-error-bg border border-error/25 rounded-xl px-3.5 py-2.5">
                  <svg className="w-4 h-4 text-error-strong flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  <p className="text-[12px] font-semibold text-error-strong">{err}</p>
                </div>
              )}
              <Button type="submit" variant="primary" size="lg" className="w-full font-black" disabled={sending}
                leadingIcon={sending ? <span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> : undefined}>
                {sending ? 'Guardando…' : 'Guardar nueva clave'}
              </Button>
            </form>
          )}

          {/* ── Paso 4: éxito ── */}
          {rstep === 'done' && (
            <div className="flex flex-col items-center text-center py-4 fade-in">
              <div className="w-16 h-16 rounded-full bg-mint flex items-center justify-center shadow-sm scale-in mb-4">
                <svg className="w-7 h-7 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <p className="text-ink font-black text-[16px]">¡Listo! Tu clave fue actualizada</p>
              <p className="text-[12.5px] text-ink-soft leading-relaxed mt-1.5 max-w-[260px]">
                Ya puedes ingresar al Portal KOA con tu nueva clave de acceso.
              </p>
              <Button variant="primary" size="lg" className="w-full font-black mt-5" onClick={onClose}>
                Volver a iniciar sesión
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─── Left branding panel (mirrors the DS hero language) ──── */
function BrandPanel() {
  return (
    <div className="hidden lg:flex aurora relative flex-col justify-between p-10 overflow-hidden h-full" style={{ background: HERO_BG }}>
      {/* Dot grid — DS hero texture */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }}
      />
      {/* Rotating flor watermark */}
      <KoaFlor
        className="absolute -right-12 top-1/2 -translate-y-1/2 w-80 h-80 opacity-[0.06] animate-orbit"
        color="#FFFFFF"
        style={{ ['--r' as string]: '0px', ['--dur' as string]: '44s' }}
      />
      {/* Logo + kicker */}
      <div className="relative z-10 flex items-center gap-3">
        <KoaLogo kind="logotipo" tone="white" height={40} />
        <span className="w-px h-6 bg-white/20" />
        <span className="text-[11px] font-bold tracking-[0.14em] uppercase text-white/55">Portal</span>
      </div>

      {/* Headline + value props */}
      <div className="relative z-10 space-y-9">
        <div>
          <h1 className="text-white font-black leading-[0.98] tracking-tight mb-4" style={{ fontSize: 'clamp(34px, 3.6vw, 46px)' }}>
            Tu dinero,<br /><span className="text-mint">floreciendo</span>.
          </h1>
          <p className="text-white/60 text-[15px] leading-relaxed max-w-xs">
            Gestiona tus CDT, tu crédito de libranza y más — seguro, simple y sin filas.
          </p>
        </div>

        <div className="space-y-2.5">
          {FEATURES.map(f => (
            <div key={f.label} className="flex items-center gap-3.5">
              <span className="w-9 h-9 rounded-xl bg-mint/12 border border-mint/20 flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.9}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={f.icon} />
                </svg>
              </span>
              <p className="text-white/70 text-[13.5px]">{f.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Regulatory trust row — one line; scales down before the panel narrows */}
      <div className="relative z-10 flex items-center gap-4 xl:gap-5 pt-8 border-t border-white/[0.1] min-w-0">
        <img src={sfcWhite} alt="SFC" className="h-6 xl:h-7 w-auto object-contain shrink-0" />
        <div className="w-px h-9 xl:h-11 bg-white/20 shrink-0" />
        <img src={fogafinWhite} alt="Fogafin" className="h-11 xl:h-12 w-auto object-contain shrink-0" />
      </div>
    </div>
  )
}

/* ─── Main login component ────────────────────────────────── */
export default function Login({ onLogin }: LoginProps) {
  const [personType, setPersonType] = useState<PersonType>('natural')
  const [docType, setDocType] = useState('CC')
  const [docNum, setDocNum] = useState('')
  const [nit, setNit] = useState('')
  const [clave, setClave] = useState('')
  const [showClave, setShowClave] = useState(false)
  const [step, setStep] = useState<Step>('form')
  const [formError, setFormError] = useState('')
  const [forgotOpen, setForgotOpen] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setFormError('')
    if (!docNum.trim()) { setFormError('Ingresa tu número de documento'); return }
    if (personType === 'juridica' && !nit.trim()) { setFormError('Ingresa el NIT de tu empresa'); return }
    if (!clave.trim()) { setFormError('Ingresa tu clave'); return }
    setStep('otp')
  }

  return (
    <div className="min-h-screen lg:h-screen lg:overflow-hidden flex" style={{ background: '#06005A' }}>
      {/* Left: branding */}
      <div className="lg:w-[440px] xl:w-[520px] flex-shrink-0 lg:h-full">
        <BrandPanel />
      </div>

      {/* Right: form panel */}
      <div className="flex-1 flex flex-col min-h-screen lg:h-screen lg:overflow-hidden bg-app-bg">
        {/* Mobile brand hero — minimalista: solo logo KOA + Portal */}
        <div className="lg:hidden relative overflow-hidden px-6 py-4 flex items-center gap-3" style={{ background: HERO_BG }}>
          <KoaFlor half showK={false} color="#00DB8E" className="absolute bottom-0 right-4 w-28 h-12 opacity-[0.14]" />
          <div
            className="absolute inset-0 opacity-[0.04] pointer-events-none"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '22px 22px' }}
          />
          <KoaLogo kind="logotipo" tone="white" height={44} className="relative z-10" />
          <span className="relative z-10 w-px h-6 bg-white/20" />
          <span className="relative z-10 text-[11px] font-bold tracking-[0.16em] uppercase text-white/55">Portal</span>
        </div>

        <div className="flex-1 flex items-center justify-center px-5 py-5 sm:py-8 lg:py-0 overflow-y-auto lg:overflow-visible">
          <div className="w-full max-w-md">

            {/* Card */}
            <div className="bg-surface rounded-card border border-line shadow-[var(--shadow-card)] overflow-hidden">

              {/* ── Form step ── */}
              <form onSubmit={handleSubmit} className="p-6 lg:p-5 space-y-4 lg:space-y-3.5">

                  {/* Person type toggle */}
                  <div className="flex rounded-2xl p-1 gap-1 bg-surface-alt">
                    {(['natural', 'juridica'] as PersonType[]).map(pt => (
                      <button
                        key={pt}
                        type="button"
                        onClick={() => { setPersonType(pt); setFormError('') }}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 lg:py-1.5 rounded-xl text-[13px] font-bold transition-all duration-150 cursor-pointer ${
                          personType === pt
                            ? 'bg-surface text-brand shadow-sm'
                            : 'text-muted hover:text-ink'
                        }`}
                      >
                        <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          {pt === 'natural'
                            ? <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            : <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                          }
                        </svg>
                        {pt === 'natural' ? 'Persona' : 'Empresa'}
                      </button>
                    ))}
                  </div>

                  {/* Divider */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-line" />
                    <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-muted-soft">Datos de acceso</p>
                    <div className="flex-1 h-px bg-line" />
                  </div>

                  {/* Document type chips */}
                  <div>
                    <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">
                      Tipo de documento
                    </label>
                    <div className="flex gap-2">
                      {DOC_TYPES.map(dt => (
                        <button
                          key={dt.value}
                          type="button"
                          onClick={() => setDocType(dt.value)}
                          title={dt.desc}
                          className={`flex-1 py-2 lg:py-1.5 rounded-xl text-[12px] font-bold transition-all duration-150 cursor-pointer ${
                            docType === dt.value
                              ? 'bg-brand text-white shadow-md shadow-brand/20'
                              : 'bg-surface-alt text-muted hover:bg-line hover:text-ink'
                          }`}
                        >
                          {dt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Document number */}
                  <div>
                    <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">
                      Número de documento
                    </label>
                    <Field
                      type="text"
                      inputMode="numeric"
                      placeholder="Ej. 1000123456"
                      value={docNum}
                      onChange={e => setDocNum(e.target.value.replace(/\D/g, ''))}
                      className="font-figures"
                      leadingIcon={
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5zM7 8h4m-4 4h6m-6 4h3" />
                        </svg>
                      }
                    />
                  </div>

                  {/* NIT empresa — solo jurídica */}
                  {personType === 'juridica' && (
                    <div>
                      <label className="block text-[11px] font-bold tracking-[0.1em] uppercase text-muted mb-1.5">
                        NIT de la empresa
                      </label>
                      <Field
                        type="text"
                        inputMode="numeric"
                        placeholder="Ej. 900123456-7"
                        value={nit}
                        onChange={e => setNit(e.target.value)}
                        className="font-figures"
                        leadingIcon={
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5" />
                          </svg>
                        }
                      />
                    </div>
                  )}

                  {/* Clave */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-[11px] font-bold tracking-[0.1em] uppercase text-muted">
                        Clave
                      </label>
                      <button
                        type="button"
                        onClick={() => setForgotOpen(true)}
                        className="text-[11px] font-semibold text-brand hover:underline cursor-pointer"
                      >
                        ¿Olvidaste tu clave?
                      </button>
                    </div>
                    <Field
                      type={showClave ? 'text' : 'password'}
                      inputMode="numeric"
                      placeholder="••••••"
                      value={clave}
                      onChange={e => setClave(e.target.value)}
                      className="font-figures [&_input]:tracking-[0.2em]"
                      leadingIcon={
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                      }
                      trailingIcon={
                        <button
                          type="button"
                          onClick={() => setShowClave(!showClave)}
                          aria-label={showClave ? 'Ocultar clave' : 'Mostrar clave'}
                          className="text-muted-soft hover:text-ink cursor-pointer transition-colors flex"
                        >
                          {showClave ? (
                            <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
                            </svg>
                          ) : (
                            <svg className="w-4.5 h-4.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                              <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                          )}
                        </button>
                      }
                    />
                  </div>

                  {/* Error */}
                  {formError && (
                    <div className="flex items-center gap-2 bg-error-bg border border-error/25 rounded-xl px-4 py-3">
                      <svg className="w-4 h-4 text-error-strong flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                      <p className="text-[12px] font-semibold text-error-strong">{formError}</p>
                    </div>
                  )}

                  {/* Submit */}
                  <Button
                    type="submit"
                    variant="primary"
                    size="lg"
                    className="w-full font-black shadow-lg shadow-brand/25"
                    leadingIcon={
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                      </svg>
                    }
                  >
                    Ingresar
                  </Button>

                  {/* Demo hint */}
                  <div className="bg-mint-bg border border-mint/25 rounded-xl px-3.5 py-2.5 flex items-center gap-2">
                    <KoaFlor showK={false} color="#00DB8E" className="w-4 h-4 shrink-0" />
                    <p className="text-[11px] text-mint-text">
                      <span className="font-bold">Demo:</span> cualquier documento y clave son válidos. OTP: <span className="font-figures font-black">{DEMO_OTP}</span>
                    </p>
                  </div>
              </form>
            </div>

            {/* Footer */}
            <div className="flex justify-center mt-4">
              <a
                href="/componentes"
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-muted hover:text-brand transition-colors cursor-pointer"
              >
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h8M4 18h8" />
                </svg>
                Design system
              </a>
            </div>
          </div>
        </div>

        {/* Mobile trust footer — logos en línea, texto debajo a todo el ancho */}
        <div className="lg:hidden border-t border-line px-5 py-4 flex flex-col items-center gap-3 bg-surface">
          <div className="flex items-center gap-5">
            <img src={sfcBlack} alt="SFC" className="h-5 w-auto" />
            <img src={fogafinBlack} alt="Fogafin" className="h-8 w-auto" />
          </div>
          <p className="w-full text-center text-[10px] text-muted">
            © 2026 KOA C.F. · Compañía de Financiamiento S.A.
          </p>
        </div>
      </div>

      {/* OTP · réplica del componente del Design System */}
      {step === 'otp' && (
        <OtpModal onSuccess={() => onLogin(personType)} onClose={() => setStep('form')} />
      )}

      {/* Recuperación de clave · flujo estilo Keycloak adaptado al DS */}
      {forgotOpen && <ForgotPasswordModal onClose={() => setForgotOpen(false)} />}
    </div>
  )
}
