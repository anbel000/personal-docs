import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import EmptyState from '../components/EmptyState'
import Btn from '../components/Btn'
import LoadingSkeleton from '../components/LoadingSkeleton'
import CDTGraficas from '../cdt/CDTGraficas'
import AsesorReferidos from '../cdt/AsesorReferidos'
import { KoaFlor } from '../components/koa'
import { cdts, cdtsTerminados, type CDT, formatPesos } from '../data/mockData'

/* ─── CDT growth sparkline — self-drawing (generación) loop.
       Alineado con el hero de CDT en Inicio (mismo lenguaje de marca). ─── */
function CDTSparkline() {
  return (
    <>
      <style>{`
        @keyframes cdtDraw { 0%{stroke-dashoffset:1} 42%{stroke-dashoffset:0} 76%{stroke-dashoffset:0} 100%{stroke-dashoffset:-1} }
        @keyframes cdtFade { 0%{opacity:0} 42%{opacity:1} 76%{opacity:1} 100%{opacity:0} }
        @keyframes cdtDot { 0%,38%{opacity:0} 44%{opacity:1} 76%{opacity:1} 100%{opacity:0} }
        .cdt-line{stroke-dasharray:1;animation:cdtDraw 3.6s cubic-bezier(0.22,1,0.36,1) infinite}
        .cdt-area{animation:cdtFade 3.6s ease-in-out infinite}
        .cdt-dot{animation:cdtDot 3.6s ease-in-out infinite}
        @media (prefers-reduced-motion: reduce){
          .cdt-line,.cdt-area,.cdt-dot{animation:none}
          .cdt-line{stroke-dashoffset:0}
          .cdt-area,.cdt-dot{opacity:1}
        }
      `}</style>
      <svg viewBox="0 0 320 44" className="w-full h-10 -mb-1" preserveAspectRatio="none" aria-hidden="true">
        <defs>
          <linearGradient id="cdt-hero-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00DB8E" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#00DB8E" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="cdt-area" d="M0,36 L40,33 L80,34 L120,24 L160,27 L200,16 L240,19 L280,9 L320,5 L320,44 L0,44 Z" fill="url(#cdt-hero-fill)" />
        <path className="cdt-line" pathLength={1} d="M0,36 L40,33 L80,34 L120,24 L160,27 L200,16 L240,19 L280,9 L320,5" fill="none" stroke="#00DB8E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <circle className="cdt-dot" cx="320" cy="5" r="3.5" fill="#00DB8E" />
      </svg>
    </>
  )
}

/* ─── Floating particles ─────────────────────────────────── */
const PARTICLES = [
  { size: 4, top: '12%', left: '7%', dur: '3.2s', delay: '0s', op: 0.3 },
  { size: 6, top: '65%', left: '12%', dur: '4.1s', delay: '0.9s', op: 0.2 },
  { size: 3, top: '22%', right: '9%', dur: '3.7s', delay: '1.5s', op: 0.35 },
  { size: 5, top: '75%', right: '18%', dur: '2.9s', delay: '0.3s', op: 0.22 },
  { size: 3, top: '48%', left: '38%', dur: '5.2s', delay: '2.1s', op: 0.15 },
]
function Particles() {
  return (
    <>
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            width: p.size, height: p.size,
            top: p.top, left: p.left, right: p.right,
            background: i % 2 === 0 ? '#0098FF' : '#00DB8E',
            opacity: p.op,
            ['--dur' as string]: p.dur,
            ['--delay' as string]: p.delay,
            ['--op' as string]: p.op,
            ['--fy' as string]: `${-10 - i * 3}px`,
          }}
        />
      ))}
    </>
  )
}

/* ─── Empty — invite to open first CDT ──────────────────── */
function CDTAperturaEmpty() {
  return (
    <div className="relative overflow-hidden rounded-3xl card-enter" style={{ background: '#06005A', minHeight: 340 }}>
      <Particles />
      <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-[#0098FF]/[0.06] pointer-events-none" />
      <div className="absolute -left-8 bottom-0 w-32 h-32 rounded-full bg-[#00DB8E]/[0.04] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-52 h-40 opacity-[0.1] pointer-events-none overflow-hidden">
        <svg viewBox="0 0 200 130" fill="none" className="w-full h-full">
          {[0, 1, 2, 3, 4].map(i => {
            const h = 30 + i * 20
            return <rect key={i} x={20 + i * 36} y={130 - h} width="24" height={h} rx="6" fill="#0098FF" fillOpacity={0.5 + i * 0.1} />
          })}
          <polyline points="32,100 68,78 104,60 140,42 176,22" stroke="#00DB8E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-8 py-14 gap-5">
        <div className="w-16 h-16 rounded-2xl bg-[#0098FF]/20 border border-[#0098FF]/20 flex items-center justify-center animate-number-pop" style={{ ['--delay' as string]: '0.1s' }}>
          <svg className="w-7 h-7 text-[#0098FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
        </div>
        <div className="space-y-2 animate-number-pop" style={{ ['--delay' as string]: '0.18s' }}>
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-[#0098FF]/70">CDT Digital · KOA</p>
          <h2 className="text-white font-bold text-[26px] tracking-tight">Abre tu primer CDT</h2>
          <p className="text-white/45 text-[14px] max-w-xs">
            Empieza a generar rendimientos desde el primer día. Tasas desde{' '}
            <span className="text-[#00DB8E] font-semibold">11,50 % E.A.</span>
          </p>
        </div>
        <div className="flex gap-6 border-t border-white/[0.08] pt-5 animate-number-pop" style={{ ['--delay' as string]: '0.26s' }}>
          {[{ label: 'Tasa desde', value: '11,50 %' }, { label: 'Plazo', value: '60–360 días' }, { label: 'Proceso', value: '100 % online' }].map(s => (
            <div key={s.label} className="text-center">
              <p className="font-figures text-white font-bold text-[15px]">{s.value}</p>
              <p className="text-white/35 text-[10px] mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="animate-number-pop" style={{ ['--delay' as string]: '0.34s' }}>
          <Btn variant="mint" size="lg" onClick={() => window.open('https://ebtcd-staging.quolab.biz/simulacion', '_blank', 'noopener')}>
            Comenzar apertura
          </Btn>
        </div>
      </div>
    </div>
  )
}

function CDTNoData() {
  return (
    <div className="border-2 border-dashed border-[#E8ECF2] rounded-2xl p-8 card-enter">
      <EmptyState
        icon={<svg className="w-8 h-8 text-[#0098FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>}
        iconBg="bg-[#0098FF]/12"
        title="No tienes CDTs aperturados"
        description="Abre tu primer CDT Digital KOA y empieza a generar rendimientos desde el primer día."
        action={<Btn variant="mint" onClick={() => window.open('https://ebtcd-staging.quolab.biz/simulacion', '_blank', 'noopener')}>Abrir mi primer CDT</Btn>}
      />
    </div>
  )
}

/* ─── Skeleton ───────────────────────────────────────────── */
function CDTSkeleton() {
  return (
    <div className="space-y-5">
      <div className="rounded-3xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}>
        <div className="px-8 py-7 flex flex-wrap gap-6 items-end justify-between">
          <div className="space-y-2">
            <LoadingSkeleton className="h-2.5 w-20 rounded-full opacity-30" />
            <LoadingSkeleton className="h-10 w-48 rounded-2xl opacity-40" />
          </div>
          <div className="flex gap-8 flex-wrap">
            {[0, 1, 2].map(i => (
              <div key={i} className="space-y-2">
                <LoadingSkeleton className="h-2.5 w-20 rounded-full opacity-20" />
                <LoadingSkeleton className="h-7 w-28 rounded-xl opacity-35" />
              </div>
            ))}
          </div>
        </div>
      </div>
      {[0, 1, 2].map(i => (
        <div key={i} className="card-flat flex items-center gap-4 px-5 py-4 rounded-2xl">
          <LoadingSkeleton className="w-2 h-2 rounded-full" />
          <LoadingSkeleton className="w-[100px] h-4 rounded-full" />
          <LoadingSkeleton className="flex-1 h-7 rounded-xl" />
          <LoadingSkeleton className="w-[72px] h-4 rounded-full hidden sm:block" />
          <LoadingSkeleton className="w-[120px] h-4 rounded-full hidden md:block" />
          <LoadingSkeleton className="w-[120px] h-4 rounded-full" />
          <LoadingSkeleton className="w-4 h-4 rounded" />
        </div>
      ))}
    </div>
  )
}

/* ─── CDT row ─── desktop table + mobile card ────────────── */
function CDTRow({ cdt, delay = 0 }: { cdt: CDT; delay?: number }) {
  const navigate = useNavigate()
  const terminado = cdt.estado === 'terminado'
  const displayName = cdt.nombre || cdt.numeroMascarado

  return (
    <div
      className={`card-flat card-enter transition-all duration-200 ${
        !terminado ? 'cursor-pointer hover:shadow-md hover:-translate-y-px' : 'opacity-55'
      }`}
      style={{ animationDelay: `${delay}s` }}
      onClick={() => !terminado && navigate(`/cdt/${cdt.id}`)}
    >
      {/* Mobile */}
      <div className="sm:hidden px-4 py-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-2 h-2 rounded-full flex-shrink-0 mt-0.5 ${terminado ? 'bg-gray-300' : 'bg-[#0098FF] mint-pulse'}`} />
            <div>
              {cdt.proposito ? (
                <>
                  <p className="text-[13px] font-bold text-[#2A3036]">{cdt.proposito}</p>
                  <p className="font-figures text-[10px] text-gray-400">{cdt.numeroMascarado}</p>
                </>
              ) : (
                <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.numeroMascarado}</p>
              )}
              {!terminado && cdt.renovacionAutomatica && (
                <p className="text-[9px] text-[#005E3C] font-bold">↻ Auto</p>
              )}
              {terminado && <p className="text-[9px] text-gray-400">Terminado</p>}
            </div>
          </div>
          <div className="text-right">
            <p className="font-figures text-[11px] font-bold text-[#0098FF]">{cdt.tasa} % E.A.</p>
            {!terminado && cdt.diasRestantes !== undefined && <p className="text-[10px] text-gray-400">{cdt.diasRestantes} días rest.</p>}
          </div>
        </div>
        <p className="font-figures text-[22px] font-black text-[#2A3036] leading-none mb-1.5">{formatPesos(cdt.montoInvertido)}</p>
        <div className="flex items-center justify-between">
          <p className="font-figures text-[13px] font-bold text-[#10B981]">+{formatPesos(cdt.rendimientos)}</p>
          <p className="font-figures text-[12px] text-gray-400">{cdt.fechaVencimiento}</p>
        </div>
        {!terminado && (
          <div className="mt-3">
            <div className="h-1.5 bg-[#F7F7F7] rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${cdt.progresoPct}%`, background: 'linear-gradient(90deg, #0098FF, #00DB8E)' }} />
            </div>
            <p className="text-[10px] text-gray-400 mt-1">{cdt.progresoPct}% transcurrido</p>
          </div>
        )}
      </div>

      {/* Desktop */}
      <div className="hidden sm:flex items-center gap-4 px-5 py-4 group">
        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${terminado ? 'bg-gray-300' : 'bg-[#0098FF] mint-pulse'}`} />
        <div className="w-[130px] flex-shrink-0">
          {cdt.proposito ? (
            <>
              <p className="text-[13px] font-bold text-[#2A3036] leading-tight line-clamp-1">{cdt.proposito}</p>
              <p className="font-figures text-[10px] text-gray-400">{cdt.numeroMascarado}</p>
            </>
          ) : (
            <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.numeroMascarado}</p>
          )}
          {!terminado && cdt.renovacionAutomatica && <p className="text-[9px] text-[#005E3C] font-bold">↻ Auto</p>}
          {terminado && <p className="text-[9px] text-gray-400">Terminado</p>}
        </div>
        <div className="w-[132px] flex-shrink-0">
          <p className="font-figures text-[20px] font-black text-[#2A3036] leading-none">{formatPesos(cdt.montoInvertido)}</p>
          <p className="text-[10px] text-gray-400 mt-0.5">monto invertido</p>
        </div>
        {/* Plazo — barra flexible que absorbe el espacio disponible */}
        <div className="flex-1 min-w-[90px]">
          <div className="h-2 bg-[#F1F3F7] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full"
              style={{
                width: `${cdt.progresoPct}%`,
                background: terminado ? '#CBD2DC' : 'linear-gradient(90deg, #0098FF, #00DB8E)',
              }}
            />
          </div>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[10px] text-gray-400">{terminado ? 'Completado' : `${cdt.progresoPct}% transcurrido`}</span>
            {!terminado && cdt.diasRestantes !== undefined && (
              <span className="font-figures text-[10px] font-semibold text-[#0098FF]">{cdt.diasRestantes} d. rest.</span>
            )}
          </div>
        </div>
        <div className="w-[64px] flex-shrink-0 text-right">
          <p className="font-figures text-[14px] font-bold text-[#0098FF]">{cdt.tasa} %</p>
          <p className="text-[10px] text-gray-400">E.A.</p>
        </div>
        <div className="w-[104px] flex-shrink-0 hidden md:block text-right">
          <p className="font-figures text-[13px] font-semibold text-[#2A3036]">{cdt.fechaVencimiento}</p>
          <p className="text-[10px] text-gray-400">vencimiento</p>
        </div>
        <div className="w-[116px] flex-shrink-0 text-right">
          <p className="font-figures text-[14px] font-bold text-[#10B981]">+{formatPesos(cdt.rendimientos)}</p>
          <p className="text-[10px] text-gray-400">rendimientos</p>
        </div>
        <svg className={`w-4 h-4 flex-shrink-0 transition-colors ${!terminado ? 'text-gray-300 group-hover:text-[#2A3036]' : 'text-transparent'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </div>
  )
}

function ListHeaders() {
  return (
    <div className="hidden sm:flex items-center gap-4 px-5 pb-1">
      <div className="w-2 flex-shrink-0" />
      <div className="w-[130px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400">CDT</div>
      <div className="w-[132px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400">Monto</div>
      <div className="flex-1 min-w-[90px] text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400">Plazo</div>
      <div className="w-[64px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Tasa</div>
      <div className="w-[104px] flex-shrink-0 hidden md:block text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Vencimiento</div>
      <div className="w-[116px] flex-shrink-0 text-[9px] font-bold tracking-[0.14em] uppercase text-gray-400 text-right">Rendimientos</div>
      <div className="w-4 flex-shrink-0" />
    </div>
  )
}

/* ─── Pager — paginación de la tabla de CDTs ─────────────── */
function Pager({
  page, totalPaginas, desde, hasta, total, onChange,
}: {
  page: number; totalPaginas: number; desde: number; hasta: number; total: number; onChange: (p: number) => void
}) {
  return (
    <div className="flex items-center justify-between gap-3 pt-3 mt-1">
      <p className="text-[11.5px] text-gray-400">
        Mostrando <span className="font-figures font-semibold text-[#2A3036]">{desde}–{hasta}</span> de{' '}
        <span className="font-figures font-semibold text-[#2A3036]">{total}</span> CDTs
      </p>
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => onChange(page - 1)}
          disabled={page <= 1}
          className="w-8 h-8 rounded-lg border border-[#E8ECF2] flex items-center justify-center text-gray-500 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          aria-label="Página anterior"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
        </button>
        {Array.from({ length: totalPaginas }, (_, i) => i + 1).map(p => (
          <button
            key={p}
            onClick={() => onChange(p)}
            className={`min-w-8 h-8 px-2 rounded-lg text-[12.5px] font-semibold cursor-pointer transition-colors ${
              p === page ? 'bg-[#0C1E4C] text-white' : 'text-gray-500 hover:bg-gray-50 border border-[#E8ECF2]'
            }`}
          >
            {p}
          </button>
        ))}
        <button
          onClick={() => onChange(page + 1)}
          disabled={page >= totalPaginas}
          className="w-8 h-8 rounded-lg border border-[#E8ECF2] flex items-center justify-center text-gray-500 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
          aria-label="Página siguiente"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
        </button>
      </div>
    </div>
  )
}

/* ─── Single CDT featured view ───────────────────────────── */
function SingleCDTView({ cdt }: { cdt: CDT }) {
  const navigate = useNavigate()
  const terminado = cdt.estado === 'terminado'

  return (
    <div className="space-y-5">
      {/* Featured card — DS hero surface (mint-forward), un solo CDT */}
      <div
        className="relative overflow-hidden rounded-3xl card-enter shadow-card"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        {/* organic mint blooms — DS hero surface */}
        <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-24 -left-12 w-72 h-72 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

        <div className="relative z-10 p-6 sm:p-8">
          {/* Header — marca */}
          <div className="flex items-start gap-3">
            <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">CDT Digital · KOA</p>
              {cdt.proposito ? (
                <>
                  <p className="text-white font-black text-[16px] leading-tight mt-0.5">{cdt.proposito}</p>
                  <p className="font-figures text-white/50 text-[12px] mt-0.5">{cdt.numeroCompleto}</p>
                </>
              ) : (
                <p className="text-white font-black text-[16px] leading-tight mt-0.5">
                  Tu inversión <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">florece</span>
                </p>
              )}
            </div>
            <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
              <span className="w-1.5 h-1.5 rounded-full bg-brand/60 mint-pulse" />
              {terminado ? 'Terminado' : 'Activo'}
            </span>
          </div>

          {/* Figure + KPIs */}
          <div className="flex flex-col lg:flex-row lg:items-end gap-6 lg:justify-between mt-6">
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Monto invertido</p>
              <p className="font-figures text-white font-black leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(30px, 7vw, 44px)', ['--delay' as string]: '0.1s' }}>
                {formatPesos(cdt.montoInvertido)}
              </p>
              <p className="font-figures text-mint text-[12px] font-black mt-2.5 inline-flex items-center gap-1.5 bg-mint/12 border border-mint/20 px-2.5 py-1 rounded-lg">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8m0 0h-5m5 0v5" /></svg>
                +{formatPesos(cdt.rendimientos)} en rendimientos
              </p>
            </div>
            <div className="flex flex-wrap gap-6 sm:gap-8">
              <div>
                <p className="text-white/50 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">Tasa</p>
                <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.22s' }}>
                  {cdt.tasa} %<span className="text-[13px] text-white/50 font-normal ml-1">E.A.</span>
                </p>
              </div>
              <div>
                <p className="text-white/50 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">Vencimiento</p>
                <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.28s' }}>
                  {cdt.fechaVencimiento}
                </p>
              </div>
            </div>
          </div>

          {!terminado && (
            <div className="mt-6">
              <div className="h-2 rounded-full overflow-hidden bg-white/10">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${cdt.progresoPct}%`,
                    background: 'linear-gradient(90deg, #0098FF 0%, #00DB8E 100%)',
                    boxShadow: '0 0 12px rgba(0,219,142,0.55)',
                  }}
                />
              </div>
              <div className="flex justify-between mt-1.5">
                <span className="text-white/70 text-[11px] font-medium">{cdt.progresoPct}% del plazo transcurrido</span>
                {cdt.diasRestantes !== undefined && (
                  <span className="font-figures text-mint text-[11px] font-bold">Faltan {cdt.diasRestantes} días</span>
                )}
              </div>
            </div>
          )}

          {/* Footer — CTAs */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 border-t border-white/10 pt-5 mt-6">
            <p className="flex-1 min-w-0 text-white/70 text-[12px] font-medium inline-flex items-center gap-2">
              {cdt.renovacionAutomatica ? (
                <>
                  <svg className="w-3.5 h-3.5 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 20v-5h-5M20 9a8 8 0 00-15-2M4 15a8 8 0 0015 2" /></svg>
                  Renovación automática activa
                </>
              ) : (
                'Sin renovación automática'
              )}
            </p>
            <div className="flex items-center gap-2.5 flex-shrink-0">
              <button
                onClick={() => navigate(`/cdt/${cdt.id}`)}
                className="flex items-center justify-center gap-2 bg-white/10 text-white text-[13px] font-bold px-4 py-3 rounded-xl border border-white/15 hover:bg-white/[0.16] transition cursor-pointer whitespace-nowrap"
              >
                Ver detalle
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
              </button>
              <button
                onClick={() => navigate('/cdt/abrir')}
                className="flex items-center justify-center gap-2 bg-mint text-brand text-[13px] font-bold px-5 py-3 rounded-xl hover:brightness-105 transition cursor-pointer btn-mint-glow whitespace-nowrap"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
                Abrir nuevo CDT
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Analytics */}
      <div>
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
          <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">Análisis de tu inversión</p>
        </div>
        <CDTGraficas showKPIs={false} cdts={[cdt]} />
      </div>

      {/* Referidos */}
      <div>
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
          <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">Plan de referidos</p>
        </div>
        <AsesorReferidos mode="referidos" />
      </div>

      {/* Open another CDT nudge */}
      <div
        className="rounded-2xl border border-dashed border-[#0098FF]/30 bg-[#EBF5FF]/60 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 card-enter stagger-3 cursor-pointer hover:border-[#0098FF]/60 transition-colors"
        onClick={() => navigate('/cdt/abrir')}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#0098FF]/15 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-[#0098FF]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div>
            <p className="font-bold text-[14px] text-[#0068B3]">Diversifica tu portafolio</p>
            <p className="text-[12px] text-[#0098FF]/70 mt-0.5">Abre un segundo CDT con diferentes plazos o tasas</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 text-[12px] font-bold text-[#0098FF] whitespace-nowrap">
          Abrir otro CDT
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
        </span>
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function CDT() {
  const { personType, productos } = useDemoContext()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'activos' | 'terminados'>('activos')
  const [page, setPage] = useState(1)

  const hasCDT = productos === 'ambos' || productos === 'solo-cdt'
  const activeCdts = productos === 'solo-cdt' ? cdts.slice(0, 1) : cdts
  const terminadosCdts = productos === 'solo-cdt' ? [] : cdtsTerminados

  /* Totales del portafolio derivados de la lista real (escalan con la
     cantidad de CDTs; la tasa se pondera por monto). */
  const inversionTotal = activeCdts.reduce((s, c) => s + c.montoInvertido, 0)
  const rendimientosTotal = activeCdts.reduce((s, c) => s + c.rendimientos, 0)
  const tasaPonderada = inversionTotal
    ? activeCdts.reduce((s, c) => s + parseFloat(c.tasa.replace(',', '.')) * c.montoInvertido, 0) / inversionTotal
    : 0
  const tasaPonderadaStr = tasaPonderada.toFixed(2).replace('.', ',')

  const PAGE_SIZE = 6
  const listaActual = activeTab === 'activos' ? activeCdts : terminadosCdts
  const totalPaginas = Math.max(1, Math.ceil(listaActual.length / PAGE_SIZE))
  const paginaSegura = Math.min(page, totalPaginas)
  const listaPaginada = listaActual.slice((paginaSegura - 1) * PAGE_SIZE, paginaSegura * PAGE_SIZE)

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <CDTSkeleton />
  if (!hasCDT) return <CDTAperturaEmpty />
  if (activeCdts.length === 0) return <CDTNoData />

  /* Single CDT — featured view */
  if (activeCdts.length === 1 && terminadosCdts.length === 0) {
    return <SingleCDTView cdt={activeCdts[0]} />
  }

  return (
    <div className="space-y-6">

      {/* 1 ── Portfolio hero — superficie hero del DS (mint-forward) ── */}
      <div
        className="relative overflow-hidden rounded-3xl card-enter shadow-card"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        {/* organic mint blooms — DS hero surface */}
        <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-24 -left-12 w-72 h-72 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

        <div className="relative z-10 p-6 sm:p-8">
          {/* Header — marca */}
          <div className="flex items-start gap-3">
            <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">CDT Digital · KOA</p>
              <p className="text-white font-black text-[16px] leading-tight mt-0.5">
                Tu inversión <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">florece</span>
              </p>
            </div>
            {/* trust badge — in-flow para no solaparse en mobile */}
            <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
              <span className="w-4 h-4 rounded-full bg-brand/15 flex items-center justify-center">
                <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
              </span>
              {activeCdts.length} CDT{activeCdts.length !== 1 ? 's' : ''} activo{activeCdts.length !== 1 ? 's' : ''}
            </span>
          </div>

          {/* Figure + KPIs */}
          <div className="flex flex-col lg:flex-row lg:items-end gap-6 lg:justify-between mt-6">
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Inversión total</p>
              <p className="font-figures text-white text-[36px] sm:text-[42px] font-black leading-none mt-1.5 animate-number-pop" style={{ ['--delay' as string]: '0.1s' }}>
                {formatPesos(inversionTotal)}
              </p>
              <p className="font-figures text-mint text-[12px] font-black mt-2.5 inline-flex items-center gap-1.5 bg-mint/12 border border-mint/20 px-2.5 py-1 rounded-lg">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8m0 0h-5m5 0v5" /></svg>
                +{formatPesos(rendimientosTotal)} en rendimientos
              </p>
            </div>
            <div className="flex flex-wrap gap-6 sm:gap-8">
              <div>
                <p className="text-white/50 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">Tasa ponderada</p>
                <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.22s' }}>
                  {tasaPonderadaStr} %<span className="text-[13px] text-white/50 font-normal ml-1">E.A.</span>
                </p>
              </div>
              <div>
                <p className="text-white/50 text-[10px] font-bold tracking-[0.16em] uppercase mb-1.5">CDTs en total</p>
                <p className="font-figures text-white text-[22px] font-black leading-none animate-number-pop" style={{ ['--delay' as string]: '0.28s' }}>
                  {activeCdts.length + terminadosCdts.length}
                </p>
              </div>
            </div>
          </div>

          {/* Growth sparkline — self-drawing (generación) loop */}
          <div className="mt-5">
            <CDTSparkline />
          </div>

          {/* Footer — CTA reforzado para abrir nuevo CDT */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 border-t border-white/10 pt-5 mt-1">
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold text-[14px]">¿Listo para hacer crecer más tu capital?</p>
              <p className="text-white/50 text-[12px] mt-0.5">Abre otro CDT en minutos y diversifica tu portafolio.</p>
            </div>
            <button
              onClick={() => navigate('/cdt/abrir')}
              className="flex items-center justify-center gap-2 bg-mint text-brand text-[13px] font-bold px-5 py-3 rounded-xl hover:brightness-105 transition cursor-pointer btn-mint-glow whitespace-nowrap flex-shrink-0"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
              Abrir nuevo CDT
            </button>
          </div>
        </div>
      </div>

      {/* 2 ── Analytics (no KPIs — hero already covers them) ── */}
      <div>
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
          <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">Análisis del portafolio</p>
        </div>
        <CDTGraficas showKPIs={false} cdts={activeCdts} />
      </div>

      {/* 3 ── Asesor / Referidos ─────────────────────────── */}
      <div>
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
          <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">
            {productos === 'solo-cdt' ? 'Plan de referidos' : 'Mi asesor'}
          </p>
        </div>
        <AsesorReferidos mode={productos === 'ambos' ? 'asesor' : 'referidos'} />
      </div>

      {/* 4 ── CDT list — last ──────────────────────────────── */}
      <div>
        <div className="flex items-center gap-1 border-b border-[#E8ECF2] mb-3">
          {(['activos', 'terminados'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); setPage(1) }}
              className={`flex items-center gap-2 px-5 py-3 text-[13px] font-semibold transition-colors cursor-pointer ${
                activeTab === tab
                  ? 'text-[#2A3036] border-b-2 border-[#0098FF] -mb-px'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              {tab === 'activos' ? 'Activos' : 'Terminados'}
              <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${
                activeTab === tab ? 'bg-[#0C1E4C] text-white' : 'bg-gray-100 text-gray-500'
              }`}>
                {tab === 'activos' ? activeCdts.length : terminadosCdts.length}
              </span>
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {listaActual.length > 0 ? (
            <>
              <ListHeaders />
              {listaPaginada.map((c, i) => <CDTRow key={c.id} cdt={c} delay={i * 0.04} />)}
              {totalPaginas > 1 && (
                <Pager
                  page={paginaSegura}
                  totalPaginas={totalPaginas}
                  desde={(paginaSegura - 1) * PAGE_SIZE + 1}
                  hasta={Math.min(paginaSegura * PAGE_SIZE, listaActual.length)}
                  total={listaActual.length}
                  onChange={setPage}
                />
              )}
            </>
          ) : activeTab === 'activos' ? (
            <CDTNoData />
          ) : (
            <EmptyState
              icon={
                <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              }
              title="Sin CDTs terminados"
              description="Cuando un CDT llegue a su fecha de vencimiento sin renovarse, aparecerá aquí."
            />
          )}
        </div>
      </div>

    </div>
  )
}
