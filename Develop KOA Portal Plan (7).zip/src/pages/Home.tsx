import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDemoContext } from '../context/DemoContext'
import LoadingSkeleton from '../components/LoadingSkeleton'
import { Card, StatCard, Button, Badge, IconTile, ProgressRing } from '../components/ui'
import type { BadgeTone, IconTileTone } from '../components/ui'
import { KoaFlor } from '../components/koa'
import {
  kpiLibranza, kpiCDT, cdts, creditos, pendientes, formatPesos,
} from '../data/mockData'
import recoUnificaDesktop from '../imports/357px_336px__1_.png'
import recoUnificaMobile from '../imports/268px_380px__1_.png'
import recoPensionDesktop from '../imports/357px_336px.png'
import recoPensionMobile from '../imports/268px_380px.png'

/* ─── DS stroke-icon helper (1.8w, currentColor) ──────────── */
const IC = {
  chart:   'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6',
  check:   'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
  shield:  'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  clock:   'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
  arrow:   'M9 5l7 7-7 7',
  growth:  'M3 17l6-6 4 4 8-8m0 0h-5m5 0v5',
  plus:    'M12 4v16m8-8H4',
  bolt:    'M13 10V3L4 14h7v7l9-11h-7z',
  money:   'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  sparkles:'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z',
  user:    'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
  bank:    'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z',
  bell:    'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
  refresh: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
  calendar:'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
}
function Icon({ d, className = 'w-4 h-4', sw = 1.8 }: { d: string; className?: string; sw?: number }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={sw}>
      <path strokeLinecap="round" strokeLinejoin="round" d={d} />
    </svg>
  )
}

/* Moneda compacta para KPIs en cards angostos (evita desbordes en mobile):
   $ 6.240.000 → $ 6,24 M · $ 850.000 → $ 850 K */
function formatPesosCompacto(v: number): string {
  if (v >= 1_000_000) return `$ ${(v / 1_000_000).toFixed(2).replace('.', ',')} M`
  if (v >= 1_000) return `$ ${Math.round(v / 1_000)} K`
  return formatPesos(v)
}

/* ─── CDT vigent rates ────────────────────────────────────── */
const TASAS_CDT = [
  { plazo: '60 días',  tasa: '10,50' },
  { plazo: '90 días',  tasa: '11,00' },
  { plazo: '180 días', tasa: '11,50' },
  { plazo: '360 días', tasa: '12,20' },
]

/* ─── Product identity — one shared template, differentiated only by
       icon + label + badge (fixes the CDT/Libranza divergence) ───── */
const PRODUCT = {
  cdt: { label: 'CDT Digital', kicker: 'Inversión · KOA', icon: IC.chart, route: '/cdt' },
  libranza: { label: 'Libranza', kicker: 'Crédito · KOA', icon: IC.check, route: '/libranza' },
} as const

/* ─── Pendientes — metadatos por tipo (icono, tono DS, ayuda) ─────── */
const PEND_META: Record<string, { icon: string; tone: IconTileTone; desc: string }> = {
  banco:  { icon: IC.bank, tone: 'info',    desc: 'Necesaria para recibir tus rendimientos al vencimiento' },
  perfil: { icon: IC.user, tone: 'warning', desc: 'Mantén tus datos al día para agilizar tus solicitudes' },
}
const PEND_FALLBACK = { icon: IC.bell, tone: 'mint' as IconTileTone, desc: 'Revisa este pendiente para continuar' }

/* ─── CDT growth sparkline — self-drawing (generación) loop.
       Shared by CDTHero (real) and CDTPromo (cross-sell) ────────── */
function CDTSparkline() {
  return (
    <>
      <style>{`
        @keyframes cdtDraw { 0%{stroke-dashoffset:1} 42%{stroke-dashoffset:0} 76%{stroke-dashoffset:0} 100%{stroke-dashoffset:-1} }
        @keyframes cdtFade { 0%{opacity:0} 42%{opacity:1} 76%{opacity:1} 100%{opacity:0} }
        @keyframes cdtDot { 0%,38%{opacity:0} 44%{opacity:1} 76%{opacity:1} 100%{opacity:0} }
        .cdt-line{stroke-dasharray:1;animation:cdtDraw 3.6s cubic-bezier(0.22,1,0.36,1) infinite}
        .cdt-area{animation:cdtFade 3.6s ease-in-out infinite}
        .cdt-dot{animation:cdtDot 3.6s ease-in-out infinite}
        @media (prefers-reduced-motion: reduce){
          .cdt-line,.cdt-area,.cdt-dot{animation:none}
          .cdt-line{stroke-dashoffset:0}
          .cdt-area,.cdt-dot{opacity:1}
        }
      `}</style>
      <svg viewBox="0 0 320 44" className="w-full h-10 -mb-1" preserveAspectRatio="none" aria-hidden="true">
        <defs>
          <linearGradient id="cdt-spark-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00DB8E" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#00DB8E" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="cdt-area" d="M0,36 L40,33 L80,34 L120,24 L160,27 L200,16 L240,19 L280,9 L320,5 L320,44 L0,44 Z" fill="url(#cdt-spark-fill)" />
        <path className="cdt-line" pathLength={1} d="M0,36 L40,33 L80,34 L120,24 L160,27 L200,16 L240,19 L280,9 L320,5" fill="none" stroke="#00DB8E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <circle className="cdt-dot" cx="320" cy="5" r="3.5" fill="#00DB8E" />
      </svg>
    </>
  )
}

/* ─── CDT — superficie hero del DS (brand-gradient · aurora · KoaFlor)
       con gráfica de crecimiento estilo Card · variant navy ─────── */
function CDTHero({
  navigate, count, inversion, rendimientos, tasa, delay = '0s',
}: {
  navigate: (p: string) => void
  count: number
  inversion: string
  rendimientos: string
  tasa: string
  delay?: string
}) {
  return (
    <div
      onClick={() => navigate(PRODUCT.cdt.route)}
      className="relative overflow-hidden rounded-[20px] group cursor-pointer card-enter h-full flex flex-col shadow-card"
      style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)', animationDelay: delay }}
    >
      {/* organic mint blooms — DS hero surface */}
      <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
      <div className="absolute -bottom-20 -left-10 w-64 h-64 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

      <div className="relative z-10 p-6 sm:p-7 flex flex-col h-full gap-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">CDT Digital · KOA</p>
            <p className="text-white font-black text-[16px] leading-tight mt-0.5">
              Tu inversión <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">florece</span>
            </p>
          </div>
          {/* count badge — in-flow para no solaparse en mobile */}
          <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
            <span className="w-4 h-4 rounded-full bg-brand/15 flex items-center justify-center">
              <Icon d={PRODUCT.cdt.icon} className="w-2.5 h-2.5" sw={2.5} />
            </span>
            {count} CDT{count !== 1 ? 's' : ''} activo{count !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Figure */}
        <div className="flex-1">
          <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Inversión total</p>
          <p className="font-figures text-white font-black leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(28px, 4vw, 40px)' }}>{inversion}</p>
          <p className="font-figures text-mint text-[12px] font-black mt-2.5 inline-flex items-center gap-1.5 bg-mint/12 border border-mint/20 px-2.5 py-1 rounded-lg">
            <Icon d={IC.growth} className="w-3 h-3" sw={2.5} /> +{rendimientos} en rendimientos
          </p>
        </div>

        {/* Growth sparkline — self-drawing (generación) loop */}
        <CDTSparkline />

        {/* Footer */}
        <div className="flex items-center justify-between pt-3.5 border-t border-white/10 gap-3">
          <div>
            <p className="text-white/50 text-[9px] font-bold tracking-[0.12em] uppercase">Tasa ponderada</p>
            <p className="font-figures text-white text-[16px] font-bold mt-0.5">{tasa} % <span className="text-[12px] font-normal text-white/60">E.A.</span></p>
          </div>
          <span className="inline-flex items-center gap-2 bg-white/10 group-hover:bg-white/20 transition-all rounded-xl px-4 py-2.5 text-white text-[12px] font-semibold flex-shrink-0">
            Ver mis CDTs
            <Icon d={IC.arrow} className="w-3.5 h-3.5 text-white/70 group-hover:translate-x-0.5 transition-transform" sw={2.5} />
          </span>
        </div>
      </div>
    </div>
  )
}

/* ─── CDT — misma superficie hero, pero en modo cross-sell (el cliente
       aún no tiene CDT). Conserva la línea visual de CDTHero ──────── */
function CDTPromo({ navigate, delay = '0s' }: { navigate: (p: string) => void; delay?: string }) {
  const best = TASAS_CDT[TASAS_CDT.length - 1]
  return (
    <div
      onClick={() => navigate('/cdt')}
      className="relative overflow-hidden rounded-[20px] group cursor-pointer card-enter h-full flex flex-col shadow-card"
      style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)', animationDelay: delay }}
    >
      {/* organic mint blooms — DS hero surface */}
      <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
      <div className="absolute -bottom-20 -left-10 w-64 h-64 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

      <div className="relative z-10 p-6 sm:p-7 flex flex-col h-full gap-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">CDT Digital · KOA</p>
            <p className="text-white font-black text-[16px] leading-tight mt-0.5">
              Haz <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">florecer</span> tu dinero
            </p>
          </div>
          {/* trust badge — in-flow para no solaparse en mobile */}
          <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
            <span className="w-4 h-4 rounded-full bg-brand/15 flex items-center justify-center">
              <Icon d={IC.shield} className="w-2.5 h-2.5" sw={2.5} />
            </span>
            Capital protegido
          </span>
        </div>

        {/* Figure — mejor tasa vigente */}
        <div className="flex-1">
          <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Mejor tasa · {best.plazo}</p>
          <p className="font-figures text-white font-black leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(28px, 4vw, 40px)' }}>
            {best.tasa} %<span className="text-mint text-[16px] font-bold ml-1.5">E.A.</span>
          </p>
          <p className="font-figures text-mint text-[12px] font-black mt-2.5 inline-flex items-center gap-1.5 bg-mint/12 border border-mint/20 px-2.5 py-1 rounded-lg">
            <Icon d={IC.growth} className="w-3 h-3" sw={2.5} /> Rendimientos garantizados
          </p>
        </div>

        {/* Growth sparkline — self-drawing (generación) loop */}
        <CDTSparkline />

        {/* Footer */}
        <div className="flex items-center justify-between pt-3.5 border-t border-white/10 gap-3">
          <div>
            <p className="text-white/50 text-[9px] font-bold tracking-[0.12em] uppercase">Plazos disponibles</p>
            <p className="font-figures text-white text-[16px] font-bold mt-0.5">60 – 360 <span className="text-[12px] font-normal text-white/60">días</span></p>
          </div>
          <span className="inline-flex items-center gap-2 bg-white/10 group-hover:bg-white/20 transition-all rounded-xl px-4 py-2.5 text-white text-[12px] font-semibold flex-shrink-0">
            Abrir mi CDT
            <Icon d={IC.arrow} className="w-3.5 h-3.5 text-white/70 group-hover:translate-x-0.5 transition-transform" sw={2.5} />
          </span>
        </div>
      </div>
    </div>
  )
}

/* ─── Libranza — DS Card · variant bloom (light, gradient top-bar).
       Cliente con créditos activos ──────────────────────────────── */
function LibranzaBloom({
  navigate, saldo, cuotaMensual, activos, delay = '0s',
}: {
  navigate: (p: string) => void
  saldo: string
  cuotaMensual?: string
  activos?: typeof creditos
  delay?: string
}) {
  const list = activos ?? []
  return (
    <Card
      variant="bloom"
      spotlight
      onClick={() => navigate(PRODUCT.libranza.route)}
      className="group relative overflow-hidden flex flex-col gap-3.5 h-full min-h-[236px] cursor-pointer card-enter !border-line p-6"
      style={{ background: '#FFFFFF', animationDelay: delay }}
    >
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-brand pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <IconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
            <Icon d={PRODUCT.libranza.icon} className="w-[18px] h-[18px]" sw={2} />
          </IconTile>
          <div>
            <p className="font-bold text-brand text-[15px] leading-tight">{PRODUCT.libranza.label}</p>
            <p className="text-[10px] font-bold uppercase tracking-wide text-mint-text flex items-center gap-1 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />Al día
            </p>
          </div>
        </div>
        <span className="text-[10px] font-bold text-brand bg-brand/[0.06] border border-brand/10 px-2.5 py-1 rounded-full whitespace-nowrap">
          {list.length} activo{list.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Figures */}
      <div className="relative z-10 flex items-end justify-between gap-4">
        <div>
          <p className="text-[10px] text-muted font-bold uppercase tracking-[0.16em]">Saldo total</p>
          <p className="font-figures font-black text-brand leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(26px, 4vw, 38px)' }}>{saldo}</p>
        </div>
        {cuotaMensual && (
          <div className="text-right">
            <p className="text-[10px] text-muted font-bold uppercase tracking-[0.12em]">Descuento mensual</p>
            <p className="font-figures font-black text-brand text-[18px] leading-none mt-1.5">{cuotaMensual}</p>
          </div>
        )}
      </div>

      <div className="relative z-10 flex-1 divide-y divide-line">
        {list.map(c => {
          const pct = Math.round((c.cuotasPagadas / c.totalCuotas) * 100)
          return (
            <div key={c.id} className="flex items-center gap-3 py-2">
              <p className="text-[12px] font-semibold text-ink truncate flex-1 min-w-0">{c.pagaduria}</p>
              <div className="w-16 h-1.5 rounded-full bg-surface-alt overflow-hidden shrink-0">
                <div className="h-full rounded-full" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #06005A, #00DB8E)' }} />
              </div>
              <span className="font-figures text-[10px] font-bold text-mint-text shrink-0 w-8 text-right">{pct}%</span>
            </div>
          )
        })}
      </div>

      <Button variant="primary" size="sm" onClick={() => navigate(PRODUCT.libranza.route)} className="w-full mt-auto" trailingIcon={<Icon d={IC.arrow} className="w-3.5 h-3.5" sw={2.5} />}>
        Ver mis créditos
      </Button>
    </Card>
  )
}

/* ─── Libranza — cross-sell honesto (cliente sin crédito). Invita a
       conocer/abrir el producto, sin prometer un pre-aprobado ─────── */
function LibranzaPromo({ navigate, delay = '0s' }: { navigate: (p: string) => void; delay?: string }) {
  const { productos } = useDemoContext()
  // Con "Solo CDT" o "Sin productos" el cliente puede iniciar la solicitud del
  // crédito en el portal (sección Libranza); en los demás casos lo enviamos a
  // hablar con un asesor.
  const puedeSolicitar = productos === 'solo-cdt' || productos === 'ninguno'
  const destino = puedeSolicitar ? '/libranza' : '/contactanos'
  const cta = puedeSolicitar ? 'Solicita tu crédito' : 'Hablar con asesor'
  return (
    <Card
      variant="bloom"
      spotlight
      onClick={() => navigate(destino)}
      className="group relative overflow-hidden flex flex-col gap-4 h-full min-h-[236px] cursor-pointer card-enter !border-line p-6"
      style={{ background: '#FFFFFF', animationDelay: delay }}
    >
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-brand pointer-events-none" />
      <KoaFlor half showK={false} color="#00DB90" className="absolute -bottom-4 -right-3 w-40 h-20 opacity-[0.06] pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex items-center gap-2.5">
        <IconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
          <Icon d={PRODUCT.libranza.icon} className="w-[18px] h-[18px]" sw={2} />
        </IconTile>
        <div>
          <p className="font-bold text-brand text-[15px] leading-tight">{PRODUCT.libranza.label}</p>
          <p className="text-[10px] font-bold uppercase tracking-wide text-mint-text flex items-center gap-1 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />Crédito · KOA
          </p>
        </div>
      </div>

      {/* Copy — invitación */}
      <div className="relative z-10 flex-1">
        <p className="font-black text-brand text-[17px] leading-snug">¿Necesitas un crédito?</p>
        <p className="text-[12px] text-muted font-medium mt-1 leading-snug">
          Crédito de Libranza para pensionados y empleados del sector público. Trámite 100 % digital, sin codeudor y con opciones para reportados.
        </p>
        <ul className="mt-3 space-y-1.5">
          {['Montos y plazos flexibles a tu medida', 'Proceso ágil, seguro y sin salir de casa', 'Cuota y tasa fija durante todo el crédito'].map(b => (
            <li key={b} className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-mint flex-shrink-0" />
              <span className="text-[11px] text-ink-soft font-medium leading-tight">{b}</span>
            </li>
          ))}
        </ul>
      </div>

      <Button variant="primary" size="sm" onClick={() => navigate(destino)} className="relative z-10 w-full mt-auto" trailingIcon={<Icon d={IC.arrow} className="w-3.5 h-3.5" sw={2.5} />}>
        {cta}
      </Button>
    </Card>
  )
}

/* ─── KOA recomienda — DS spotlight card ──────────────────── */
function RecoCard({
  product, icon, tone, stat, statLabel, statCaption, title, bullets, actionLabel, onAction, variant = 'primary', delay = '0s',
}: {
  product: 'CDT' | 'Libranza'
  icon: string
  tone: IconTileTone
  stat: string
  statLabel: string
  statCaption: string
  title: string
  bullets: string[]
  actionLabel: string
  onAction: () => void
  variant?: 'primary' | 'secondary'
  delay?: string
}) {
  const badgeTone: BadgeTone = product === 'CDT' ? 'brand' : 'mint'
  return (
    <Card spotlight sheen className="group flex-shrink-0 w-[268px] snap-start lg:w-auto flex flex-col gap-4 p-5 card-enter h-full" style={{ animationDelay: delay }}>
      <div className="flex items-start justify-between">
        <Badge tone={badgeTone}>{product}</Badge>
        <IconTile toneName={tone} className="transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
          <Icon d={icon} className="w-4 h-4" />
        </IconTile>
      </div>
      <div>
        <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted">{statLabel}</p>
        <p className="font-figures font-black text-mint leading-none mt-1.5 animate-number-pop" style={{ fontSize: '40px' }}>{stat}</p>
        <p className="text-[11px] text-muted font-semibold mt-1">{statCaption}</p>
      </div>
      <div className="flex-1">
        <p className="font-black text-ink text-[14px] leading-snug">{title}</p>
        <ul className="mt-2.5 space-y-1.5">
          {bullets.map(b => (
            <li key={b} className="flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-mint flex-shrink-0" />
              <span className="text-[11px] text-muted font-medium leading-tight">{b}</span>
            </li>
          ))}
        </ul>
      </div>
      <Button variant={variant} size="sm" onClick={onAction} className="w-full mt-auto" trailingIcon={<Icon d={IC.arrow} className="w-3.5 h-3.5" sw={2.5} />}>
        {actionLabel}
      </Button>
    </Card>
  )
}

/* ─── KOA recomienda — variante por imagen (piezas de campaña) ── */
function RecoImageCard({
  imageDesktop, imageMobile, alt, onAction, delay = '0s',
}: {
  imageDesktop: string
  imageMobile: string
  alt: string
  onAction: () => void
  delay?: string
}) {
  return (
    <Card
      spotlight
      sheen
      onClick={onAction}
      className="group relative flex-shrink-0 w-[268px] snap-start lg:w-auto overflow-hidden p-0 card-enter h-full min-h-[336px] cursor-pointer"
      style={{ animationDelay: delay }}
    >
      {/* Cada breakpoint recibe su recorte: escritorio (~cuadrado) vs móvil (vertical) */}
      <picture className="absolute inset-0 block h-full w-full">
        <source media="(min-width: 1024px)" srcSet={imageDesktop} />
        <img
          src={imageMobile}
          alt={alt}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-[1.04]"
        />
      </picture>
    </Card>
  )
}

function RecoSection({
  navigate, showCDT, showLibranza, personType,
}: {
  navigate: (p: string) => void
  showCDT: boolean
  showLibranza: boolean
  personType: string
}) {
  const best = TASAS_CDT[TASAS_CDT.length - 1]
  const cards: React.ReactNode[] = []

  if (showLibranza) {
    cards.push(<RecoCard key="lib-amplia" product="Libranza" icon={IC.plus} tone="mint" stat="$100M" statLabel="Cupo disponible" statCaption="Con tu mismo empleador" title="Amplía tu crédito activo" bullets={['Mismo empleador · sin fiador', 'Aprobación en 48 horas', '100 % digital · sin papeleos']} actionLabel="Iniciar proceso" onAction={() => navigate('/contactanos')} delay="0s" />)
  } else if (personType === 'natural') {
    cards.push(<RecoCard key="lib-cross" product="Libranza" icon={IC.money} tone="mint" stat="$100M" statLabel="Monto disponible" statCaption="Descuento nómina o pensión" title="Libranza KOA" bullets={['Sin trámites en caja', 'Tasas preferenciales', '100 % digital · sin fiador']} actionLabel="Hablar con asesor" onAction={() => navigate('/contactanos')} delay="0s" />)
  }
  cards.push(<RecoCard key="cdt-tasas" product="CDT" icon={IC.chart} tone="navy" stat={`${best.tasa}%`} statLabel={`Mejor tasa · ${best.plazo}`} statCaption="Efectiva Anual" title={showCDT ? 'Tasas CDT vigentes' : 'CDT Digital KOA'} bullets={['Plazos de 60 a 360 días', '100 % digital · sin filas', 'Capital respaldado Fogafín']} actionLabel={showCDT ? 'Nueva apertura' : 'Abrir mi CDT'} onAction={() => navigate(showCDT ? '/cdt/abrir' : '/cdt')} delay="0.05s" />)
  cards.push(<RecoCard key="cdt-info" product="CDT" icon={IC.shield} tone="mint" stat="100%" statLabel="Capital garantizado" statCaption="Protegido por Fogafín" title="Tu dinero crece protegido" bullets={['Rendimientos garantizados', 'Inversión desde $500.000', 'Sin riesgo de mercado']} actionLabel="Conocer CDT" onAction={() => navigate('/cdt')} variant="secondary" delay="0.1s" />)
  cards.push(<RecoImageCard key="lib-unifica" imageDesktop={recoUnificaDesktop} imageMobile={recoUnificaMobile} alt="¿Tienes varios préstamos? Unifícalos en uno solo con Libranza KOA" onAction={() => navigate('/contactanos')} delay="0.15s" />)
  cards.push(<RecoImageCard key="lib-pension" imageDesktop={recoPensionDesktop} imageMobile={recoPensionMobile} alt="Ya trabajaste, ahora disfruta — Libranza KOA para pensionados" onAction={() => navigate('/contactanos')} delay="0.2s" />)

  return (
    <section className="space-y-4 card-enter" style={{ animationDelay: '0.14s' }}>
      <div className="flex items-center gap-2 flex-wrap px-0.5">
        <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
        <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-muted">KOA recomienda</p>
        <Badge tone="mint" icon={<Icon d={IC.sparkles} className="w-2.5 h-2.5" sw={2.5} />}>Personalizado para ti</Badge>
      </div>
      <div className={[
        '-mx-4 px-4 sm:-mx-6 sm:px-6',
        'flex gap-3.5 overflow-x-auto snap-x snap-mandatory pb-3',
        'lg:mx-0 lg:px-0 lg:grid lg:grid-cols-3 lg:overflow-visible lg:snap-none lg:pb-0 lg:gap-4',
        '[scrollbar-width:none] [&::-webkit-scrollbar]:hidden',
      ].join(' ')}>
        {cards}
      </div>
    </section>
  )
}

/* ─── Skeleton ────────────────────────────────────────────── */
function HomeSkeleton() {
  return (
    <div className="space-y-8">
      <div className="rounded-[20px] bg-brand overflow-hidden" style={{ minHeight: 132 }}>
        <div className="p-7 flex flex-col gap-3">
          <LoadingSkeleton className="h-3 w-24 rounded-full opacity-30" />
          <LoadingSkeleton className="h-9 w-56 rounded-2xl opacity-40" />
        </div>
      </div>
      <div className="grid gap-4 lg:grid-cols-12">
        <div className="lg:col-span-7 rounded-[20px] bg-brand" style={{ minHeight: 260 }}>
          <div className="p-7 flex flex-col gap-5 h-full">
            <div className="flex justify-between">
              <LoadingSkeleton className="h-9 w-40 rounded-xl opacity-30" />
              <LoadingSkeleton className="h-6 w-20 rounded-full opacity-20" />
            </div>
            <div className="flex-1 space-y-2.5">
              <LoadingSkeleton className="h-3 w-24 rounded-full opacity-20" />
              <LoadingSkeleton className="h-12 w-64 rounded-2xl opacity-35" />
            </div>
          </div>
        </div>
        <div className="lg:col-span-5 card-flat rounded-[20px]" style={{ minHeight: 260 }} />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {[0, 1, 2].map(i => <div key={i} className="card-flat rounded-[20px]" style={{ minHeight: 110 }} />)}
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function Home() {
  const { personType, productos, pendientes: showPendientes } = useDemoContext()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 700)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <HomeSkeleton />

  const showCDT = productos === 'ambos' || productos === 'solo-cdt'
  // Juridica cannot have libranza
  const showLibranza = (productos === 'ambos' || productos === 'solo-libranza') && personType === 'natural'
  const emptyState = productos === 'ninguno'
  const hasProducts = showCDT || showLibranza

  // Pendientes dinámicos
  const cdtBankPendientes = showCDT
    ? cdts
        .filter(c => c.estado === 'activo' && !c.cuentaInscrita)
        .map(c => ({
          id: `bank-${c.id}`,
          texto: `Inscribe tu cuenta bancaria para CDT ${c.numeroMascarado}`,
          href: `/cdt/${c.id}`,
          icono: 'banco' as const,
        }))
    : []
  const allPendientes = [...pendientes, ...cdtBankPendientes]
  // Demo: solo Libranza → cliente con un único crédito; ambos → los 3.
  // Coherente con la sección /libranza para ver cómo se adaptan los cards.
  const creditosVisibles = productos === 'solo-libranza' ? creditos.slice(0, 1) : creditos
  const libranzaSaldo = creditosVisibles.length === creditos.length
    ? kpiLibranza.deudaTotal
    : creditosVisibles.reduce((s, c) => s + c.saldo, 0)
  const cuotaMensualTotal = creditosVisibles.reduce((s, c) => s + c.cuotaMensual, 0)
  const cuotasPagadasTotal = creditosVisibles.reduce((s, c) => s + c.cuotasPagadas, 0)
  const cuotasTotal = creditosVisibles.reduce((s, c) => s + c.totalCuotas, 0)
  const libranzaAvancePct = Math.round((cuotasPagadasTotal / cuotasTotal) * 100)
  // CDT — rendimiento proyectado al vencimiento y renovaciones automáticas
  const cdtProyectado = Math.round(cdts.reduce((s, c) => s + c.rendimientos / (c.progresoPct / 100), 0))
  const cdtAutoRenov = cdts.filter(c => c.renovacionAutomatica).length
  const hasPend = showPendientes && allPendientes.length > 0
  const pendCount = allPendientes.length

  return (
    <div className="space-y-6">

      {/* ── Pendientes — aviso prioritario (arriba de todo) ──── */}
      {hasPend && (
        <section className="space-y-3 card-enter">
          {/* Section header — mismo patrón que "KOA recomienda" */}
          <div className="px-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="w-1.5 h-1.5 rounded-full bg-warning animate-pulse" />
              <p className="text-[13px] font-black text-ink leading-tight">Tu atención es necesaria</p>
              <Badge tone="warning" className="flex-shrink-0">{pendCount} por resolver</Badge>
            </div>
            <p className="text-[11.5px] text-muted font-medium leading-snug mt-1">
              Por favor, gestiona los siguientes puntos para mantener tus productos financieros al día
            </p>
          </div>

          <Card className="p-0 overflow-hidden">
            <div className={`divide-y divide-line ${pendCount > 3 ? 'max-h-[228px] overflow-y-auto scrollable' : ''}`}>
              {allPendientes.map(p => {
                const meta = PEND_META[p.icono] ?? PEND_FALLBACK
                return (
                  <button
                    key={p.id}
                    onClick={() => navigate(p.href)}
                    className="w-full flex items-center gap-3.5 px-4 sm:px-5 py-3.5 hover:bg-mint-bg transition-colors cursor-pointer group text-left"
                  >
                    <IconTile toneName={meta.tone} sizeName="md">
                      <Icon d={meta.icon} className="w-[18px] h-[18px]" sw={2} />
                    </IconTile>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-semibold text-ink leading-snug truncate">{p.texto}</p>
                      <p className="text-[11.5px] text-muted font-medium leading-tight mt-0.5 truncate">{meta.desc}</p>
                    </div>
                    <Icon d={IC.arrow} className="w-4 h-4 text-muted-soft group-hover:text-ink group-hover:translate-x-0.5 transition-all flex-shrink-0" sw={2.5} />
                  </button>
                )
              })}
            </div>
          </Card>
        </section>
      )}

      {/* ── Mis productos ────────────────────────────────────── */}
      {emptyState ? (
        <div className="grid gap-4 lg:grid-cols-12">
          <div className={personType === 'natural' ? 'lg:col-span-7' : 'lg:col-span-12'}>
            <CDTPromo navigate={navigate} />
          </div>
          {personType === 'natural' && (
            <div className="lg:col-span-5">
              <LibranzaPromo navigate={navigate} delay="0.07s" />
            </div>
          )}
        </div>
      ) : hasProducts ? (
        <div className="grid gap-4 lg:grid-cols-12">
          {showCDT && (
            <div className={showLibranza ? 'lg:col-span-7' : (personType === 'natural' ? 'lg:col-span-8' : 'lg:col-span-12')}>
              <CDTHero
                navigate={navigate}
                count={cdts.length}
                inversion={formatPesos(kpiCDT.inversionTotal)}
                rendimientos={formatPesos(kpiCDT.rendimientos)}
                tasa={kpiCDT.tasaPonderada}
              />
            </div>
          )}
          {/* Solo CDT (natural) → tarjeta compacta de cross-sell Libranza */}
          {showCDT && !showLibranza && personType === 'natural' && (
            <div className="lg:col-span-4">
              <LibranzaPromo navigate={navigate} delay="0.06s" />
            </div>
          )}
          {showLibranza && (
            <div className={showCDT ? 'lg:col-span-5' : 'lg:col-span-7'}>
              <LibranzaBloom
                navigate={navigate}
                saldo={formatPesos(libranzaSaldo)}
                cuotaMensual={formatPesos(cuotaMensualTotal)}
                activos={creditosVisibles}
                delay="0.06s"
              />
            </div>
          )}
          {/* Solo Libranza → CDT en la misma línea visual (cross-sell) */}
          {showLibranza && !showCDT && (
            <div className="lg:col-span-5">
              <CDTPromo navigate={navigate} delay="0.06s" />
            </div>
          )}
        </div>
      ) : null}

      {/* ── KPIs (CDT) — info complementaria, no duplica el hero ── */}
      {showCDT && (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 card-enter" style={{ animationDelay: '0.1s' }}>
          <StatCard
            label="Rendimiento proyectado"
            value={formatPesosCompacto(cdtProyectado)}
            tone="mint"
            icon={<Icon d={IC.growth} className="w-5 h-5" />}
            trend={{ value: 'estimado al vencimiento', direction: 'up' }}
          />
          <StatCard
            label="Renovación automática"
            value={`${cdtAutoRenov} de ${cdts.length}`}
            tone="info"
            icon={<Icon d={IC.refresh} className="w-5 h-5" />}
            trend={{ value: cdtAutoRenov > 0 ? 'se renuevan sin gestión' : 'sin renovación activa', direction: 'flat' }}
          />
          <Card spotlight className="p-5 flex items-center gap-4 col-span-2 lg:col-span-1">
            <ProgressRing value={cdts[0].progresoPct} size={84} stroke={7} label={`${kpiCDT.proximoVencimiento.dias}d`} />
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wide text-muted">Próximo vencimiento</p>
              <p className="font-figures text-[18px] font-bold text-ink mt-1 leading-none">{kpiCDT.proximoVencimiento.fecha}</p>
              <p className="text-[12px] text-muted mt-1 font-figures">CDT {kpiCDT.proximoVencimiento.numeroMascarado}</p>
            </div>
          </Card>
        </div>
      )}

      {/* ── KPIs (Libranza) — info complementaria, no duplica el hero ── */}
      {showLibranza && !showCDT && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 card-enter" style={{ animationDelay: '0.1s' }}>
          <StatCard
            label="Total prestado"
            value={formatPesos(creditosVisibles.reduce((s, c) => s + c.montoDesembolsado, 0))}
            tone="mint"
            icon={<Icon d={IC.money} className="w-5 h-5" />}
          />
          <Card spotlight className="p-5 flex items-center gap-4">
            <ProgressRing value={libranzaAvancePct} size={84} stroke={7} label={`${libranzaAvancePct}%`} />
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wide text-muted">Avance de tus créditos</p>
              <p className="font-figures text-[18px] font-bold text-ink mt-1 leading-none">{libranzaAvancePct}% completado</p>
              <p className="text-[12px] text-muted mt-1">Vas al día con tus pagos</p>
            </div>
          </Card>
        </div>
      )}

      {/* ── KOA recomienda ───────────────────────────────────── */}
      {!emptyState && (
        <RecoSection navigate={navigate} showCDT={showCDT} showLibranza={showLibranza} personType={personType} />
      )}

    </div>
  )
}
