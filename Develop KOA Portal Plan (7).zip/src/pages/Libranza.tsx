import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import LoadingSkeleton from '../components/LoadingSkeleton'
import { Button, Card, IconTile } from '../components/ui'
import PazYSalvoFlow from '../libranza/PazYSalvoFlow'
import CreditoCard from '../libranza/CreditoCard'
import SolicitudCreditoLibranza from '../libranza/SolicitudCreditoLibranza'
import LibranzaSinActivos from '../libranza/LibranzaSinActivos'
import { creditos, kpiLibranza, formatPesos } from '../data/mockData'
import { useDemoContext } from '../context/DemoContext'

/* ─── Shared floating particles ─────────────────────────── */
const PARTICLES = [
  { size: 5, top: '12%', left: '6%',  dur: '3.5s', delay: '0s',   op: 0.22, fy: '-14px' },
  { size: 3, top: '68%', left: '10%', dur: '4.2s', delay: '1.1s', op: 0.16, fy: '-10px' },
  { size: 4, top: '22%', right: '8%', dur: '3.9s', delay: '0.6s', op: 0.28, fy: '-18px' },
  { size: 6, top: '76%', right: '14%',dur: '2.7s', delay: '1.8s', op: 0.13, fy: '-12px' },
  { size: 3, top: '48%', left: '44%', dur: '5s',   delay: '2.3s', op: 0.11, fy: '-8px'  },
]

function CardParticles() {
  return (
    <>
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float"
          style={{
            width: p.size, height: p.size,
            top: p.top, left: p.left, right: p.right,
            background: '#059669',
            opacity: p.op,
            ['--dur' as string]: p.dur,
            ['--delay' as string]: p.delay,
            ['--fy' as string]: p.fy,
            ['--op' as string]: p.op,
          }}
        />
      ))}
    </>
  )
}

function DotGrid({ id }: { id: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-[0.04] pointer-events-none" preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id={id} x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1.2" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  )
}

/* ─── Iconos ──────────────────────────────────────────────── */
const LIB_ICON = {
  cash: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z',
  shield: 'M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z',
  calendar: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
}

/* Máquina de escribir — se ejecuta una sola vez al entrar a la sección.
   Respeta prefers-reduced-motion mostrando el valor completo de inmediato. */
function Typewriter({ text, className, speed = 55 }: { text: string; className?: string; speed?: number }) {
  const reduced =
    typeof window !== 'undefined' &&
    window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  const [shown, setShown] = useState(reduced ? text.length : 0)

  useEffect(() => {
    if (reduced) return
    let i = 0
    const start = setTimeout(() => {
      const iv = setInterval(() => {
        i += 1
        setShown(i)
        if (i >= text.length) clearInterval(iv)
      }, speed)
    }, 260)
    return () => clearTimeout(start)
  }, [])

  const done = shown >= text.length
  return (
    <p className={className} aria-label={text}>
      {/* placeholder invisible reserva el ancho para evitar saltos */}
      <span className="relative inline-block">
        <span className="invisible" aria-hidden="true">{text}</span>
        <span className="absolute inset-0 whitespace-nowrap">
          {text.slice(0, shown)}
          <span
            className={`inline-block w-[3px] -mb-1 align-baseline ${done ? 'opacity-0' : 'animate-pulse'}`}
            style={{ height: '0.82em', background: '#00DB8E' }}
            aria-hidden="true"
          />
        </span>
      </span>
    </p>
  )
}

/* ─── Summary hero — superficie bloom blanca, alineada al Card
       principal de Libranza en Inicio ──────────────────────── */
function SummaryHero({ lista = creditos, onPazYSalvo }: { lista?: typeof creditos; onPazYSalvo: () => void }) {
  const activos = lista.length
  const deudaTotal = lista.length === kpiLibranza.creditosActivos
    ? kpiLibranza.deudaTotal
    : lista.reduce((s, c) => s + c.saldo, 0)
  return (
    <Card
      variant="bloom"
      spotlight
      className="group relative overflow-hidden card-enter !border-line p-5"
      style={{ background: '#FFFFFF' }}
    >
      {/* Barra superior de marca */}
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-brand pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center gap-5 lg:gap-6">
        {/* ── Identidad del producto ────────────────────────── */}
        <div className="flex items-center gap-3 lg:flex-shrink-0 lg:pr-6 lg:border-r lg:border-line">
          <IconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
            <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d={LIB_ICON.cash} />
            </svg>
          </IconTile>
          <div>
            <p className="font-bold text-brand text-[15px] leading-tight">Créditos de Libranza</p>
            <p className="text-[10px] font-bold uppercase tracking-wide text-mint-text flex items-center gap-1 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />Al día
            </p>
          </div>
        </div>

        {/* ── Protagonista: Deuda total ─────────────────────── */}
        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-muted font-bold uppercase tracking-[0.18em] mb-1">Deuda total</p>
          <Typewriter
            text={formatPesos(deudaTotal)}
            className="font-figures font-black text-brand leading-none text-[32px] sm:text-[40px] lg:text-[44px]"
            speed={55}
          />
          {/* Chips de contexto */}
          <div className="flex flex-wrap items-center gap-2 mt-3">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-app-bg border border-line px-3 py-1.5 text-[11px] font-semibold text-ink">
              <span className="font-figures font-black text-brand">{activos}</span>
              {activos === 1 ? 'crédito activo' : 'créditos activos'}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-app-bg border border-line px-3 py-1.5 text-[11px] font-medium text-ink-soft">
              <svg className="w-3.5 h-3.5 text-mint-text flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d={LIB_ICON.calendar} />
              </svg>
              Descuento por pagaduría
            </span>
          </div>
        </div>

        {/* ── Acción ────────────────────────────────────────── */}
        <Button
          variant="primary"
          size="md"
          onClick={onPazYSalvo}
          className="w-full lg:w-auto lg:flex-shrink-0"
          leadingIcon={
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d={LIB_ICON.shield} />
            </svg>
          }
        >
          Generar paz y salvo
        </Button>
      </div>
    </Card>
  )
}

/* ─── Credit card ────────────────────────────────────────── */
/* ─── Empty: Jurídica ────────────────────────────────────── */
function LibranzaJuridicaBlock() {
  const navigate = useNavigate()
  return (
    <div
      className="relative overflow-hidden rounded-3xl card-enter"
      style={{ background: '#06005A', minHeight: 320 }}
    >
      <DotGrid id="dots-jur" />
      <CardParticles />
      <div className="absolute -right-12 -top-12 w-52 h-52 rounded-full bg-[#059669]/[0.09] pointer-events-none" />
      <div className="absolute -left-8 bottom-0 w-36 h-36 rounded-full bg-white/[0.02] pointer-events-none" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {[0, 1].map(i => (
          <div
            key={i}
            className="absolute rounded-full border"
            style={{
              width: 110 + i * 50, height: 110 + i * 50,
              borderColor: `rgba(5,150,105,${0.15 - i * 0.05})`,
              animation: `pulseRing 3s ease-out ${i * 1.2}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center text-center px-8 py-14 gap-5">
        <div className="w-14 h-14 rounded-2xl bg-[#059669]/20 border border-[#059669]/20 flex items-center justify-center animate-number-pop"
          style={{ ['--delay' as string]: '0.08s' }}>
          <svg className="w-7 h-7 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
        </div>
        <div className="space-y-2 animate-number-pop" style={{ ['--delay' as string]: '0.16s' }}>
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-white/50">Libranza · KOA</p>
          <h2 className="text-white font-black text-[24px] tracking-tight">Crédito empresarial</h2>
          <p className="text-white/50 text-[13px] max-w-xs leading-relaxed">
            Los créditos de libranza para personas jurídicas requieren atención personalizada con un asesor especializado.
          </p>
        </div>
        <div className="animate-number-pop" style={{ ['--delay' as string]: '0.24s' }}>
          <Button variant="mint" size="lg" onClick={() => navigate('/contactanos')}>
            Hablar con un asesor
          </Button>
        </div>
      </div>
    </div>
  )
}

/* ─── Skeleton ───────────────────────────────────────────── */
function LibranzaSkeleton() {
  return (
    <div className="space-y-5">
      <div className="rounded-3xl overflow-hidden" style={{ background: '#06005A' }}>
        <div className="px-8 py-7 space-y-4">
          <LoadingSkeleton className="h-2.5 w-32 rounded-full opacity-25" />
          <LoadingSkeleton className="h-3 w-20 rounded-full opacity-20" />
          <LoadingSkeleton className="h-12 w-48 rounded-2xl opacity-35" />
          <div className="flex gap-8 pt-2">
            <LoadingSkeleton className="h-7 w-24 rounded-xl opacity-25" />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {[0, 1, 2].map(i => (
          <div key={i} className="bg-white rounded-2xl border border-[#E8ECF2] p-5 space-y-4">
            <div className="flex justify-between">
              <LoadingSkeleton className="h-4 w-36 rounded-full" />
              <LoadingSkeleton className="h-5 w-14 rounded-full" />
            </div>
            <LoadingSkeleton className="h-8 w-44 rounded-xl" />
            <div className="grid grid-cols-3 gap-2">
              {[0,1,2].map(j => <LoadingSkeleton key={j} className="h-14 rounded-xl" />)}
            </div>
            <LoadingSkeleton className="h-1.5 rounded-full" />
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─── Main ────────────────────────────────────────────────── */
export default function Libranza() {
  const { personType, productos } = useDemoContext()
  const [pazYSalvoOpen, setPazYSalvoOpen] = useState(false)
  const [loading, setLoading] = useState(true)

  const hasLibranza = (productos === 'ambos' || productos === 'solo-libranza') && personType === 'natural'

  // Demo: CDT + Libranza ("ambos") muestra los 3 créditos; solo Libranza muestra 1
  // para evidenciar cómo se adaptan los cards a distintas densidades.
  const creditosVisibles = productos === 'solo-libranza' ? creditos.slice(0, 1) : creditos

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 800)
    return () => clearTimeout(t)
  }, [personType, productos])

  if (loading) return <LibranzaSkeleton />
  if (personType === 'juridica') return <LibranzaJuridicaBlock />
  // "Sin productos": el cliente tuvo créditos que ya terminaron. Se le comunica
  // que no hay activos y decide entre solicitar uno nuevo o generar paz y salvo.
  if (productos === 'ninguno') return <LibranzaSinActivos />
  if (!hasLibranza) return <SolicitudCreditoLibranza />

  // Filas de máximo 3; la última fila estira sus tarjetas para llenar el ancho
  const rows: typeof creditos[] = []
  for (let i = 0; i < creditosVisibles.length; i += 3) rows.push(creditosVisibles.slice(i, i + 3))
  const lgCols: Record<number, string> = { 1: 'lg:grid-cols-1', 2: 'lg:grid-cols-2', 3: 'lg:grid-cols-3' }

  return (
    <div className="space-y-4">
      <SummaryHero lista={creditosVisibles} onPazYSalvo={() => setPazYSalvoOpen(true)} />

      <div>
        <div className="flex items-center gap-2 px-0.5 mb-3">
          <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
          <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-gray-400">
            Tus créditos · {creditosVisibles.length} {creditosVisibles.length === 1 ? 'activo' : 'activos'}
          </p>
        </div>
        <div className="space-y-4">
          {rows.map((row, ri) => (
            <div key={ri} className={`grid grid-cols-1 sm:grid-cols-2 ${lgCols[row.length]} gap-4`}>
              {row.map((c, i) => (
                <CreditoCard key={c.id} credito={c} delay={(ri * 3 + i) * 0.05} />
              ))}
            </div>
          ))}
        </div>
      </div>

      {pazYSalvoOpen && <PazYSalvoFlow onClose={() => setPazYSalvoOpen(false)} />}
    </div>
  )
}
