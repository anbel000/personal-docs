import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import OtpModalKoa from '../cdt/OtpModalKoa'
import MediosDePago from './MediosDePago'
import { formatPesos, clienteNatural } from '../data/mockData'

type Paso = 1 | 2 | 3 | 4

/* ─── Constants ──────────────────────────────────── */
const TASAS: Record<string, string> = {
  '30': '7,80', '60': '8,50', '90': '9,00', '120': '9,50',
  '180': '10,50', '270': '10,90', '360': '11,80', '540': '12,00', '720': '12,20',
}
const PLAZOS = [
  { label: '30 días', value: '30' },
  { label: '60 días', value: '60' },
  { label: '90 días', value: '90' },
  { label: '120 días', value: '120' },
  { label: '180 días', value: '180' },
  { label: '270 días', value: '270' },
  { label: '1 año', value: '360', popular: true },
  { label: '18 meses', value: '540' },
  { label: '2 años', value: '720' },
]
const PERIODICIDADES = [
  { value: 'Al vencimiento', desc: 'Todo al final' },
  { value: 'Mensual', desc: 'Cada mes' },
  { value: 'Trimestral', desc: 'Cada 3 meses' },
  { value: 'Semestral', desc: 'Cada 6 meses' },
]
const REGLAMENTOS = [
  { id: 'r1', titulo: 'Condiciones generales del CDT Digital', desc: 'Términos, plazos, tasas y renovación.', color: '#06005A' },
  { id: 'r2', titulo: 'Política de retención en la fuente', desc: 'Cobro del 4% sobre rendimientos.', color: '#0068B3' },
  { id: 'r3', titulo: 'Reglamento de inversión colectiva', desc: 'Normativa Superintendencia Financiera.', color: '#6007FF' },
  { id: 'r4', titulo: 'Política de protección de datos', desc: 'Tratamiento de información personal.', color: '#005E3C' },
]

/* Step meta for the DS navy stepper */
const STEPS: { label: string; icon: string }[] = [
  { label: 'Simulación', icon: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6' },
  { label: 'Reglamento', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
  { label: 'Pago', icon: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z' },
  { label: 'Listo', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
]

/* ─── Helpers ────────────────────────────────────── */
function addDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}
function formatFecha(date: Date): string {
  const M = ['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEP','OCT','NOV','DIC']
  return `${String(date.getDate()).padStart(2,'0')} ${M[date.getMonth()]} ${date.getFullYear()}`
}

/* ─── Count-up hook ──────────────────────────────── */
function useCountUp(target: number, active: boolean, duration = 650) {
  const [value, setValue] = useState(0)
  const raf = useRef(0)
  const from = useRef(0)
  useEffect(() => {
    if (!active || target === 0) { setValue(0); from.current = 0; return }
    cancelAnimationFrame(raf.current)
    const start = performance.now()
    const prev = from.current
    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)
      setValue(Math.round(prev + (target - prev) * ease))
      if (t < 1) raf.current = requestAnimationFrame(tick)
      else from.current = target
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [target, active, duration])
  return value
}

/* ─── DS Stepper — navy header con título + progreso ──────── */
function FlowStepper({ current, onBack, summary }: { current: number; onBack: () => void; summary?: React.ReactNode }) {
  const pct = Math.round((current / (STEPS.length - 1)) * 100)
  return (
    <div className="relative overflow-hidden px-5 sm:px-6 pt-4 pb-4" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}>
      <div className="absolute -top-16 -right-10 w-44 h-44 rounded-full bg-[#00DB8E]/[0.12] blur-2xl pointer-events-none" />
      <div className="relative">
        {/* Título integrado */}
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-xl bg-white/10 border border-white/15 flex items-center justify-center hover:bg-white/[0.16] text-white cursor-pointer flex-shrink-0 transition"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-[17px] text-white leading-tight tracking-tight">Abrir CDT Digital KOA</h1>
            <p className="text-[11px] text-white/50 mt-0.5">Paso <span className="font-figures font-bold text-white/80">{current + 1}</span> de {STEPS.length} · {STEPS[current].label}</p>
          </div>
          {summary
            ? <div className="hidden sm:block flex-shrink-0">{summary}</div>
            : <p className="font-figures text-[12px] font-bold text-mint flex-shrink-0">{pct}%</p>
          }
        </div>
        <div className="flex items-center">
          {STEPS.map((s, i) => {
            const done = i < current
            const active = i === current
            return (
              <div key={s.label} className="flex items-center flex-1 last:flex-none">
                <div className="flex items-center gap-2 shrink-0">
                  <div className="relative flex items-center justify-center">
                    {active && <span className="absolute inset-0 rounded-full bg-white/25 animate-pulse-ring" />}
                    <div className={`relative w-7 h-7 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                      done ? 'bg-mint border-mint'
                      : active ? 'bg-white border-white shadow-[0_4px_14px_-2px_rgba(0,219,142,0.5)]'
                      : 'border-white/25'
                    }`}>
                      {done ? (
                        <svg className="w-3.5 h-3.5 text-brand scale-in" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                      ) : (
                        <svg className="w-[15px] h-[15px]" fill="none" viewBox="0 0 24 24" stroke={active ? '#06005A' : 'rgba(255,255,255,0.5)'} strokeWidth={1.9}><path strokeLinecap="round" strokeLinejoin="round" d={s.icon} /></svg>
                      )}
                    </div>
                  </div>
                  <p className={`text-[11px] font-bold whitespace-nowrap transition-colors ${active ? 'text-white' : done ? 'text-mint' : 'text-white/40'} ${active ? '' : 'hidden sm:block'}`}>{s.label}</p>
                </div>
                {i < STEPS.length - 1 && (
                  <div className="flex-1 h-[2px] rounded-full bg-white/12 mx-2 overflow-hidden">
                    <div className="h-full rounded-full bg-mint transition-[width] duration-500 ease-out" style={{ width: done ? '100%' : '0%' }} />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ─── PlazoSelect — desplegable compacto plazo + tasa ──── */
function PlazoSelect({ plazo, onChange }: { plazo: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const sel = PLAZOS.find(p => p.value === plazo)

  useEffect(() => {
    if (!open) return
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [open])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className={`w-full flex items-center justify-between gap-3 border-2 rounded-2xl px-4 py-3 cursor-pointer transition-colors ${open ? 'border-[#0C1E4C]' : 'border-[#E8ECF2] hover:border-[#0C1E4C]/30'}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="text-[15px] font-bold text-[#2A3036]">{sel?.label}</span>
          {(sel as { popular?: boolean })?.popular && (
            <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-[#0098FF]/12 text-[#0098FF]">Popular</span>
          )}
        </div>
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <span className="font-figures font-black text-[15px] text-[#0098FF]">{TASAS[plazo]} % <span className="text-[10px] font-bold text-gray-400">E.A.</span></span>
          <svg className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
        </div>
      </button>

      {open && (
        <div className="absolute z-30 left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-[#E8ECF2] shadow-[0_20px_50px_-12px_rgba(6,0,90,0.28)] overflow-hidden scale-in">
          <div className="max-h-[264px] overflow-y-auto p-1.5">
            {PLAZOS.map(p => {
              const active = p.value === plazo
              return (
                <button
                  key={p.value}
                  onClick={() => { onChange(p.value); setOpen(false) }}
                  className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-colors ${active ? 'bg-[#0C1E4C] text-white' : 'hover:bg-[#F7F7F7]'}`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-[13px] font-semibold ${active ? 'text-white' : 'text-[#2A3036]'}`}>{p.label}</span>
                    {(p as { popular?: boolean }).popular && (
                      <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${active ? 'bg-mint/25 text-mint' : 'bg-[#0098FF]/12 text-[#0098FF]'}`}>Popular</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-figures font-black text-[13px] ${active ? 'text-mint' : 'text-[#0098FF]'}`}>{TASAS[p.value]} %</span>
                    {active && <svg className="w-3.5 h-3.5 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

/* ─── Main ───────────────────────────────────────── */
export default function CDTAbrir() {
  const navigate = useNavigate()

  const [paso, setPaso] = useState<Paso>(1)
  const [monto, setMonto] = useState('')
  const [plazo, setPlazo] = useState('360')
  const [periodicidad, setPeriodicidad] = useState('Al vencimiento')
  const [errMonto, setErrMonto] = useState('')
  const [descargados, setDescargados] = useState<Set<string>>(new Set())
  const [descargando, setDescargando] = useState<string | null>(null)
  const [aceptoReglamento, setAceptoReglamento] = useState(false)
  const [otpOpen, setOtpOpen] = useState(false)

  /* Derived */
  const montoNum = parseInt(monto.replace(/\D/g, '')) || 0
  const tasa = TASAS[plazo] || '11,80'
  const tasaBase = parseFloat(tasa.replace(',', '.'))
  const rendimientosBrutos = Math.round(montoNum * tasaBase / 100 * parseInt(plazo) / 365)
  const retencion = Math.round(rendimientosBrutos * 0.04)
  const rendimientosNetos = rendimientosBrutos - retencion
  const totalARecibir = montoNum + rendimientosNetos
  const activo = montoNum >= 1_000_000

  /* Count-ups */
  const animBrutos = useCountUp(rendimientosBrutos, activo)
  const animNetos = useCountUp(rendimientosNetos, activo)
  const animTotal = useCountUp(totalARecibir, activo)

  /* Dates */
  const today = new Date()
  const fechaApertura = formatFecha(today)
  const fechaVencimiento = formatFecha(addDays(today, parseInt(plazo)))
  const cdtNumero = `000${3000 + Math.min(Math.floor(montoNum / 1_000_000), 999)}`

  /* Handlers */
  const handleMontoChange = (val: string) => {
    const digits = val.replace(/\D/g, '')
    setMonto(digits ? parseInt(digits).toLocaleString('es-CO') : '')
    setErrMonto('')
  }
  const validarMonto = () => {
    if (montoNum < 1_000_000) { setErrMonto('El monto mínimo es $ 1.000.000.'); return false }
    if (montoNum > 2_000_000_000) { setErrMonto('El monto máximo es $ 2.000.000.000.'); return false }
    return true
  }
  const handleDescargar = (id: string) => {
    setDescargando(id)
    setTimeout(() => { setDescargando(null); setDescargados(prev => new Set([...prev, id])) }, 900)
  }
  const handleFirmaSuccess = () => { setOtpOpen(false); setPaso(3) }

  const plazoLabel = PLAZOS.find(p => p.value === plazo)?.label

  const summaryChip = paso > 1 && activo ? (
    <div className="flex items-center gap-2.5 bg-white/10 border border-white/15 rounded-full px-3.5 py-1.5">
      <span className="font-figures font-black text-[13px] text-white">{formatPesos(montoNum)}</span>
      <span className="w-px h-3 bg-white/25" />
      <span className="text-[12px] text-white/60">{plazoLabel}</span>
      <span className="w-px h-3 bg-white/25" />
      <span className="font-figures font-bold text-[12px] text-mint">{tasa} %</span>
    </div>
  ) : undefined

  return (
    <div className="max-w-5xl mx-auto">
      {/* ── Flow shell: navy stepper (con título) + step body ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden shadow-[0_10px_36px_-16px_rgba(6,0,90,0.28)]">
        <FlowStepper
          current={paso - 1}
          onBack={() => paso === 1 ? navigate('/cdt') : setPaso(p => (p - 1) as Paso)}
          summary={summaryChip}
        />

        {/* ── Paso 1 — Simulador (2 columnas) ── */}
        {paso === 1 && (
          <div className="grid lg:grid-cols-[1.05fr_1fr]">
            {/* Left — formulario */}
            <div className="p-5 sm:p-6 space-y-5 lg:border-r border-[#F0F2F5]">
              {/* Monto */}
              <div>
                <label className="block text-[11px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-2">Monto a invertir</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-[15px] font-figures font-bold select-none">$</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={monto}
                    onChange={e => handleMontoChange(e.target.value)}
                    placeholder="0"
                    autoFocus
                    className={`w-full border-2 rounded-2xl pl-9 pr-4 py-3 text-[22px] font-figures font-black text-[#2A3036] outline-none transition-colors ${
                      errMonto ? 'border-[#FA467F] bg-[#FFF0F5]' : activo ? 'border-[#0C1E4C]/30 focus:border-[#0C1E4C]' : 'border-[#E8ECF2] focus:border-[#0C1E4C]'
                    }`}
                  />
                </div>
                {errMonto
                  ? <p className="text-[12px] text-[#F70C5B] mt-1.5">{errMonto}</p>
                  : <p className="text-[11px] text-gray-400 mt-1.5">Mínimo $ 1.000.000 · Máximo $ 2.000.000.000</p>
                }
              </div>

              {/* Plazo */}
              <div>
                <label className="block text-[11px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-2">Plazo e interés anual</label>
                <PlazoSelect plazo={plazo} onChange={setPlazo} />
              </div>

              {/* Periodicidad */}
              <div>
                <label className="block text-[11px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-2">Cobro de rendimientos</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PERIODICIDADES.map(p => (
                    <button
                      key={p.value}
                      onClick={() => setPeriodicidad(p.value)}
                      className={`flex flex-col items-center py-2 px-1.5 rounded-xl border-2 transition-all duration-150 cursor-pointer ${
                        periodicidad === p.value
                          ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white'
                          : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0C1E4C]/30'
                      }`}
                    >
                      <span className="text-[11.5px] font-semibold leading-none text-center">{p.value}</span>
                      <span className={`text-[9px] mt-1 ${periodicidad === p.value ? 'text-white/55' : 'text-gray-400'}`}>{p.desc}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right — simulación en vivo */}
            <div className="relative overflow-hidden flex flex-col" style={{ background: 'linear-gradient(160deg, #0C1E4C 0%, #06005A 100%)' }}>
              <div className="absolute -top-14 -right-12 w-44 h-44 rounded-full bg-[#0098FF]/[0.10] blur-2xl pointer-events-none" />
              <div className="absolute -bottom-10 -left-8 w-40 h-40 rounded-full bg-mint/[0.08] blur-2xl pointer-events-none" />
              <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

              {activo ? (
                <div className="relative z-10 p-5 sm:p-6 flex flex-col h-full">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-white/40 text-[10px] font-bold tracking-[0.2em] uppercase">Tu simulación</p>
                    <span className="bg-mint text-brand text-[13px] font-black px-3 py-1 rounded-full font-figures shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
                      {tasa} % E.A.
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-white/40 text-[10px] uppercase tracking-wide mb-1">Capital</p>
                      <p className="font-figures font-black text-white leading-none" style={{ fontSize: 'clamp(18px, 3.4vw, 22px)' }}>{formatPesos(montoNum)}</p>
                    </div>
                    <div>
                      <p className="text-white/40 text-[10px] uppercase tracking-wide mb-1">Rendimientos</p>
                      <p className="font-figures font-black text-mint leading-none animate-number-pop" style={{ fontSize: 'clamp(18px, 3.4vw, 22px)' }}>{formatPesos(animBrutos)}</p>
                    </div>
                  </div>

                  <div className="bg-white/[0.06] border border-white/10 rounded-2xl px-4 py-3 space-y-2 mb-4">
                    <div className="flex justify-between text-[12px]">
                      <span className="text-white/50">Retención en la fuente (4 %)</span>
                      <span className="font-figures text-[#FA467F] font-semibold">— {formatPesos(retencion)}</span>
                    </div>
                    <div className="flex justify-between text-[13px] font-semibold pt-1 border-t border-white/10">
                      <span className="text-white/75">Rendimientos netos</span>
                      <span className="font-figures text-mint">{formatPesos(animNetos)}</span>
                    </div>
                    <div className="flex justify-between text-[15px] font-bold pt-2 border-t border-white/10">
                      <span className="text-white">Total a recibir</span>
                      <span className="font-figures text-white">{formatPesos(animTotal)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] mb-5">
                    <div>
                      <p className="text-white/30 uppercase tracking-wide text-[9px]">Inicio</p>
                      <p className="font-figures text-white/60 font-semibold mt-0.5">{fechaApertura}</p>
                    </div>
                    <div className="flex-1 mx-3">
                      <div className="h-px bg-gradient-to-r from-white/15 via-mint/40 to-white/15" />
                      <p className="text-center text-white/25 text-[9px] mt-1">{plazoLabel}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-white/30 uppercase tracking-wide text-[9px]">Vencimiento</p>
                      <p className="font-figures text-white/60 font-semibold mt-0.5">{fechaVencimiento}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => { if (validarMonto()) setPaso(2) }}
                    className="mt-auto w-full flex items-center justify-center gap-2 bg-mint text-brand font-black text-[15px] py-3.5 rounded-2xl hover:brightness-105 transition cursor-pointer btn-mint-glow"
                  >
                    Continuar
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                  </button>
                </div>
              ) : (
                <div className="relative z-10 p-6 flex flex-col items-center justify-center text-center h-full min-h-[320px]">
                  <div className="w-14 h-14 rounded-2xl bg-white/[0.06] border border-white/10 flex items-center justify-center mb-4">
                    <svg className="w-7 h-7 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                  </div>
                  <p className="text-white font-bold text-[15px]">Simula tu inversión</p>
                  <p className="text-white/50 text-[12.5px] mt-1.5 max-w-[240px] leading-relaxed">Ingresa un monto desde <span className="text-mint font-semibold">$ 1.000.000</span> y verás aquí tus rendimientos estimados al instante.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Paso 2 — Reglamento ── */}
        {paso === 2 && (
          <div className="p-5 sm:p-6 space-y-4">
            <div>
              <p className="font-bold text-[16px] text-[#2A3036]">Información legal</p>
              <p className="text-[13px] text-gray-500 mt-0.5">Descarga y lee los documentos antes de firmar tu CDT.</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-2.5">
              {REGLAMENTOS.map(r => (
                <div key={r.id} className="flex items-center gap-3 rounded-2xl border border-[#E8ECF2] overflow-hidden transition-all hover:shadow-sm">
                  <div className="w-1.5 self-stretch flex-shrink-0" style={{ background: r.color }} />
                  <div className="flex items-center gap-3 flex-1 py-2.5 pr-3 min-w-0">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${r.color}18` }}>
                      {descargados.has(r.id)
                        ? <svg className="w-4 h-4 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                        : <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8} style={{ color: r.color }}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[12.5px] text-[#2A3036] leading-tight">{r.titulo}</p>
                      <p className="text-[11px] text-gray-400 mt-0.5 truncate">{r.desc}</p>
                    </div>
                    <button
                      onClick={() => handleDescargar(r.id)}
                      disabled={descargando === r.id}
                      className={`flex items-center gap-1.5 text-[12px] font-bold px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer flex-shrink-0 ${
                        descargados.has(r.id) ? 'text-[#005E3C] bg-[#EFFFF7]' : 'text-white hover:opacity-90'
                      }`}
                      style={descargados.has(r.id) ? {} : { background: r.color }}
                    >
                      {descargando === r.id
                        ? <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        : descargados.has(r.id)
                          ? <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>Listo</>
                          : <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>PDF</>
                      }
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <label className="flex items-start gap-3 cursor-pointer bg-[#F7F7F7] border border-[#F0F2F5] rounded-xl px-4 py-3 flex-1">
                <input
                  type="checkbox"
                  checked={aceptoReglamento}
                  onChange={e => setAceptoReglamento(e.target.checked)}
                  className="mt-0.5 accent-[#00DB8E] w-4 h-4 cursor-pointer flex-shrink-0"
                />
                <span className="text-[12.5px] text-gray-600 leading-snug">
                  He leído y acepto el reglamento, las condiciones del CDT y la política de retención en la fuente.
                </span>
              </label>
              <button
                disabled={!aceptoReglamento}
                onClick={() => setOtpOpen(true)}
                className="flex items-center justify-center gap-2 bg-[#0C1E4C] text-white font-bold text-[14px] px-6 py-3.5 rounded-2xl hover:bg-[#06005A] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed sm:self-stretch flex-shrink-0"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                Firmar y continuar
              </button>
            </div>
          </div>
        )}

        {/* ── Paso 3 — Pago ── */}
        {paso === 3 && (
          <div className="p-5 sm:p-6">
            <MediosDePago
              modo="apertura"
              monto={montoNum}
              onExito={() => setPaso(4)}
              onVolver={() => setPaso(2)}
            />
          </div>
        )}

        {/* ── Paso 4 — Confirmación / Certificado (2 columnas) ── */}
        {paso === 4 && (
          <div className="grid lg:grid-cols-[0.85fr_1fr]">
            {/* Left — celebración + acciones */}
            <div className="p-6 flex flex-col justify-center lg:border-r border-[#F0F2F5]">
              <div className="relative inline-flex items-center justify-center mb-4">
                <div className="w-16 h-16 rounded-full bg-[#EFFFF7] flex items-center justify-center scale-in">
                  <svg className="w-8 h-8 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-mint flex items-center justify-center">
                  <svg className="w-3 h-3 text-[#005E3C]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                </div>
              </div>
              <p className="font-black text-[20px] text-[#2A3036] leading-tight">¡Tu CDT está activo!</p>
              <p className="text-[13px] text-gray-500 mt-1.5 leading-relaxed">
                Recibirás la confirmación en <span className="font-semibold text-[#2A3036]">{clienteNatural.correoMascarado}</span> con todos los detalles.
              </p>

              <div className="flex flex-col gap-2.5 mt-5">
                <button
                  onClick={() => navigate('/cdt')}
                  className="w-full flex items-center justify-center gap-2 bg-mint text-brand font-black text-[14px] py-3 rounded-2xl hover:brightness-105 transition cursor-pointer btn-mint-glow"
                >
                  Ver mis CDT
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                </button>
                <button
                  onClick={() => {}}
                  className="w-full flex items-center justify-center gap-1.5 bg-white border-2 border-[#E8ECF2] text-[#2A3036] font-semibold text-[13px] py-3 rounded-2xl hover:border-[#0C1E4C]/30 transition-colors cursor-pointer"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                  Descargar certificado
                </button>
              </div>
            </div>

            {/* Right — certificado */}
            <div className="relative overflow-hidden" style={{ background: 'linear-gradient(145deg, #0C1E4C 0%, #06005A 100%)' }}>
              <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-[#0098FF]/[0.07] pointer-events-none" />
              <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-mint/[0.05] pointer-events-none" />
              <div className="absolute inset-0 opacity-[0.025] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

              <div className="relative px-6 pt-5 pb-4 border-b border-white/10">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-white/30 text-[9px] font-bold tracking-[0.24em] uppercase">Certificado de Depósito a Término</p>
                    <p className="text-white font-black text-[18px] mt-0.5 leading-tight">CDT Digital KOA</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/25 text-[9px] tracking-widest uppercase">N° Certificado</p>
                    <p className="font-figures text-mint/80 font-black text-[13px] tracking-widest mt-0.5">{cdtNumero}</p>
                  </div>
                </div>
              </div>

              <div className="relative px-6 pt-3 pb-3 border-b border-white/10">
                <p className="text-white/25 text-[9px] tracking-widest uppercase mb-1">Titular</p>
                <p className="text-white font-bold text-[15px]">{clienteNatural.nombre}</p>
              </div>

              <div className="relative px-6 py-4">
                <div className="grid grid-cols-2 gap-x-6 gap-y-3.5">
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Capital invertido</p>
                    <p className="font-figures font-black text-white leading-none" style={{ fontSize: 'clamp(16px, 3.4vw, 20px)' }}>{formatPesos(montoNum)}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Tasa efectiva anual</p>
                    <p className="font-figures font-black text-mint leading-none" style={{ fontSize: 'clamp(16px, 3.4vw, 20px)' }}>{tasa} %</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Apertura</p>
                    <p className="font-figures font-bold text-white text-[13px]">{fechaApertura}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Vencimiento</p>
                    <p className="font-figures font-bold text-white text-[13px]">{fechaVencimiento}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Periodicidad</p>
                    <p className="font-semibold text-white/80 text-[12.5px]">{periodicidad}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Plazo</p>
                    <p className="font-semibold text-white/80 text-[12.5px]">{plazoLabel}</p>
                  </div>
                </div>
              </div>

              <div className="relative px-6 py-3.5 bg-mint/[0.08] border-t border-white/10">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Rendimientos netos estimados</p>
                    <p className="font-figures font-black text-mint text-[18px] leading-none">+{formatPesos(rendimientosNetos)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/30 text-[9px] tracking-widest uppercase mb-1">Total a recibir</p>
                    <p className="font-figures font-bold text-white text-[14px] leading-none">{formatPesos(totalARecibir)}</p>
                  </div>
                </div>
                <p className="text-white/20 text-[9px] mt-2.5 leading-snug">
                  Rendimientos estimados con tasa vigente hoy. Retención en la fuente aplicada (4%).
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <OtpModalKoa
        open={otpOpen}
        kicker="Firma de apertura de CDT"
        onSuccess={handleFirmaSuccess}
        onClose={() => setOtpOpen(false)}
      />
    </div>
  )
}
