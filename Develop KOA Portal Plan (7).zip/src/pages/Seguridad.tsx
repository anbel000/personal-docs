import { useState, useEffect } from 'react'
import { OtpInput } from '../components/ui'
import OtpModalKoa from '../cdt/OtpModalKoa'

const D = 6

type FlowStep = 'idle' | 'new-pin' | 'saving' | 'success'

/* ── Main ───────────────────────────────────────────────────── */
export default function Seguridad() {
  const [step, setStep] = useState<FlowStep>('idle')
  const [otpOpen, setOtpOpen] = useState(false)

  const [newPin, setNewPin] = useState('')
  const [confirmPin, setConfirmPin] = useState('')
  const [shakeConfirm, setShakeConfirm] = useState(false)

  useEffect(() => {
    if (confirmPin.length === D && step === 'new-pin' && newPin.length === D) {
      if (confirmPin === newPin) {
        setStep('saving')
        setTimeout(() => setStep('success'), 1200)
      } else {
        setShakeConfirm(true)
        setTimeout(() => {
          setShakeConfirm(false)
          setConfirmPin('')
        }, 500)
      }
    }
  }, [confirmPin])

  function reset() {
    setStep('idle')
    setNewPin('')
    setConfirmPin('')
  }

  const isActive = step !== 'idle' && step !== 'success'

  return (
    <div className="max-w-xl mx-auto space-y-5">

      {/* ── Page header ──────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-black text-[#2A3036] tracking-tight leading-none">Seguridad</h1>
          <p className="text-[13px] text-gray-400 mt-1">Gestiona tu clave de acceso</p>
        </div>
        <div className="flex items-center gap-2 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-full px-3.5 py-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse" />
          <span className="text-[11px] font-bold text-[#005E3C]">Cuenta protegida</span>
        </div>
      </div>

      {/* ── Clave de acceso ──────────────────────────────────── */}
      <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden card-enter">

        {/* Card header */}
        <div className="px-5 pt-4 pb-3.5 flex items-center justify-between border-b border-[#F0F2F5]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#06005A] flex items-center justify-center flex-shrink-0">
              <svg className="w-[18px] h-[18px] text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 11V8a5 5 0 0110 0v3M6 11h12a1 1 0 011 1v7a1 1 0 01-1 1H6a1 1 0 01-1-1v-7a1 1 0 011-1zm6 4v2" />
              </svg>
            </div>
            <div>
              <p className="font-bold text-[14px] text-[#2A3036]">Clave de acceso</p>
              <p className="text-[11px] text-gray-400">Clave numérica de 6 dígitos</p>
            </div>
          </div>
          {isActive && (
            <button onClick={reset} className="text-[11px] font-semibold text-gray-400 hover:text-gray-600 cursor-pointer transition-colors">
              Cancelar
            </button>
          )}
        </div>

        {/* ── idle ── */}
        {step === 'idle' && (
          <div className="px-5 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <p className="text-[13px] text-gray-500 leading-relaxed">
              Para cambiar tu clave verificaremos tu identidad con un código de un solo uso enviado a tu correo registrado.
            </p>
            <button
              onClick={() => setOtpOpen(true)}
              className="flex-shrink-0 flex items-center justify-center gap-2 bg-[#06005A] text-white text-[13px] font-bold px-4 py-2.5 rounded-xl hover:bg-[#08007A] transition-colors cursor-pointer shadow-md shadow-[#06005A]/20"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
              </svg>
              Cambiar clave
            </button>
          </div>
        )}

        {/* ── New PIN ── */}
        {step === 'new-pin' && (
          <div className="px-5 py-6 flex flex-col items-center gap-5">
            <div className="text-center">
              <p className="font-bold text-[14px] text-[#2A3036]">Elige tu nueva clave</p>
              <p className="text-[11px] text-gray-400 mt-0.5">Ingresa y confirma tu clave de 6 dígitos</p>
            </div>

            <div className="space-y-4 w-full flex flex-col items-center">
              <div className="flex flex-col items-center gap-2">
                <p className="text-[10px] font-black tracking-[0.16em] uppercase text-gray-400">Nueva clave</p>
                <OtpInput value={newPin} onChange={setNewPin} length={D} masked autoFocus />
              </div>
              <div className={`flex flex-col items-center gap-2 transition-all duration-300 ${newPin.length === D ? 'opacity-100' : 'opacity-40'}`}>
                <p className="text-[10px] font-black tracking-[0.16em] uppercase text-gray-400">Confirmar clave</p>
                <OtpInput value={confirmPin} onChange={setConfirmPin} length={D} masked state={shakeConfirm ? 'error' : 'default'} disabled={newPin.length < D} />
                {shakeConfirm && <p className="text-[11px] font-bold text-[#F70C5B]">Las claves no coinciden</p>}
              </div>
            </div>
          </div>
        )}

        {/* ── Saving ── */}
        {step === 'saving' && (
          <div className="px-5 py-8 flex flex-col items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#06005A] flex items-center justify-center">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            </div>
            <p className="text-[13px] font-semibold text-gray-500">Actualizando clave…</p>
          </div>
        )}

        {/* ── Success ── */}
        {step === 'success' && (
          <div className="px-5 py-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/30 flex items-center justify-center flex-shrink-0 scale-in">
              <svg className="w-6 h-6 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-[15px] text-[#2A3036]">Clave actualizada</p>
              <p className="text-[12px] text-gray-400 mt-0.5">Tu nueva clave está activa desde ahora</p>
            </div>
            <button onClick={reset} className="text-[13px] font-bold text-[#06005A] hover:underline cursor-pointer">
              Listo
            </button>
          </div>
        )}

      </div>

      {/* ── OTP — Modal del KOA DS ───────────────────────────── */}
      <OtpModalKoa
        open={otpOpen}
        kicker="Actualización de contraseña"
        onSuccess={() => {
          setOtpOpen(false)
          setNewPin('')
          setConfirmPin('')
          setStep('new-pin')
        }}
        onClose={() => setOtpOpen(false)}
      />

    </div>
  )
}
