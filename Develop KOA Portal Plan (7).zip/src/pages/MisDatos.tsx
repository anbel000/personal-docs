import { useState, useEffect } from 'react'
import { useDemoContext } from '../context/DemoContext'
import SectionHeader from '../components/SectionHeader'
import Btn from '../components/Btn'
import { ProgressRing } from '../components/ui'
import LoadingSkeleton from '../components/LoadingSkeleton'
import NotificationToast, { type ToastPayload } from '../components/NotificationToast'
import OtpModalKoa from '../cdt/OtpModalKoa'

/* ── Iconos (paths del KOA DS) ────────────────────────────── */
const ICON_PATHS: Record<string, string> = {
  profile: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
  home: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',
  coin: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z',
  education: 'M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z',
  shield: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  bank: 'M3 21h18M4 10h16M5 21V10m4 11V10m6 11V10m4 11V10M12 3L4 7v3h16V7l-8-4z',
  contact: 'M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z',
}

/* Tipos de vínculo familiar (declaración PEP) */
const VINCULOS = ['Cónyuge / Esposo(a)', 'Compañero(a) permanente', 'Padre', 'Madre', 'Hijo', 'Hija', 'Hermano(a)', 'Abuelo(a)', 'Suegro(a)', 'Otro']

function Icon({ name, className = 'w-[18px] h-[18px]' }: { name: string; className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
      <path d={ICON_PATHS[name]} />
    </svg>
  )
}

/* ── Ocultamiento de datos sensibles con asteriscos ───────── */
function maskSensitive(v: string, visible = 3): string {
  const chars = [...v]
  const alnum = chars.map((c, i) => (/[a-zA-Z0-9]/.test(c) ? i : -1)).filter(i => i >= 0)
  const keep = new Set(alnum.slice(-visible))
  return chars.map((c, i) => (/[a-zA-Z0-9]/.test(c) && !keep.has(i) ? '*' : c)).join('')
}

/* ── Acordeón (patrón KOA DS) ─────────────────────────────── */
interface AcordeonProps {
  title: string
  meta: string
  icon: string
  complete: boolean
  dirty?: boolean
  id: string
  defaultOpen?: boolean
  children: React.ReactNode
}

function Acordeon({ title, meta, icon, complete, dirty = false, id, defaultOpen = false, children }: AcordeonProps) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div
      id={id}
      className={`scroll-mt-24 bg-white rounded-2xl border overflow-hidden transition-all duration-300 ${
        open ? 'border-[#00DB8E]/50 shadow-[0_8px_30px_-12px_rgba(6,0,90,0.18)]' : 'border-[#E8ECF2] hover:border-[#06005A]/25'
      }`}
    >
      <button
        onClick={() => setOpen(!open)}
        className="group w-full flex items-center gap-3.5 px-4 py-3.5 cursor-pointer text-left"
      >
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${open ? 'bg-[#06005A] text-white' : 'bg-[#F0F2F5] text-[#06005A]'}`}>
          <Icon name={icon} />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-[13.5px] font-bold text-[#2A3036]">{title}</p>
            {dirty ? (
              /* Cambios sin guardar — rojo si la sección estaba completa, amarillo si estaba pendiente */
              <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${complete ? 'bg-[#FFF0F5] text-[#F70C5B]' : 'bg-[#FFFBEB] text-[#8A6D00]'}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${complete ? 'bg-[#F70C5B]' : 'bg-[#FFD400]'}`} />Cambios sin guardar
              </span>
            ) : complete ? (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 bg-[#ECFDF5] text-[#059669]">
                <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>Completado
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 bg-[#FFFBEB] text-[#8A6D00]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FFD400]" />Pendiente
              </span>
            )}
          </div>
          <p className="text-[11.5px] text-gray-400 mt-0.5">{meta}</p>
        </div>

        <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${open ? 'bg-[#00DB8E] text-[#06005A]' : 'bg-[#F0F2F5] text-gray-400 group-hover:text-[#06005A]'}`}>
          <svg className={`w-3.5 h-3.5 transition-transform duration-300 ${open ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      <div className={`grid transition-all duration-300 ease-out ${open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
        <div className="overflow-hidden">
          <div className="px-4 pb-5 pt-1">
            <div className="border-t border-[#E8ECF2] pt-4">{children}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── Campo ────────────────────────────────────────────────── */
function Field({ label, value, readonly = false, sensitive = false, onChange }: {
  label: string; value: string; readonly?: boolean; sensitive?: boolean; onChange?: (v: string) => void
}) {
  const [revealed, setRevealed] = useState(false)
  const showMasked = sensitive && !revealed

  const EyeBtn = sensitive ? (
    <button
      type="button"
      onClick={() => setRevealed(r => !r)}
      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#06005A] transition-colors cursor-pointer p-1"
      aria-label={revealed ? 'Ocultar' : 'Mostrar'}
    >
      {revealed ? (
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 5.1A9.4 9.4 0 0112 5c4.5 0 8.3 2.9 9.5 7a11 11 0 01-2.2 3.6M6.6 6.6A11 11 0 002.5 12c1.2 4.1 5 7 9.5 7 1.3 0 2.5-.2 3.6-.7" /></svg>
      ) : (
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
      )}
    </button>
  ) : null

  return (
    <div>
      <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">{label}</label>
      <div className="relative">
        {readonly ? (
          <div className={`bg-gray-100 border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] text-gray-500 select-none cursor-not-allowed ${sensitive ? 'pr-10 font-figures' : ''}`}>
            {showMasked ? maskSensitive(value) : value}
          </div>
        ) : showMasked ? (
          <div
            onClick={() => setRevealed(true)}
            className="bg-white border border-[#E8ECF2] rounded-xl px-3 py-2.5 pr-10 text-[14px] font-figures text-[#2A3036] cursor-text"
          >
            {maskSensitive(value)}
          </div>
        ) : (
          <input
            type="text"
            value={value}
            onChange={e => onChange?.(e.target.value)}
            className={`w-full border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] focus:ring-1 focus:ring-[#00DB8E]/30 transition-colors bg-white ${sensitive ? 'pr-10 font-figures' : ''}`}
          />
        )}
        {EyeBtn}
      </div>
    </div>
  )
}

export default function MisDatos() {
  const { personType } = useDemoContext()

  // Editable state
  const [correo, setCorreo] = useState('andres@correo.com')
  const [celular, setCelular] = useState('315 456 7890')
  const [ciudad, setCiudad] = useState('Bogotá D.C.')
  const [barrio, setBarrio] = useState('Chapinero')
  const [direccion, setDireccion] = useState('Calle 63 # 12-34')
  const [ingresos, setIngresos] = useState('4.500.000')
  const [declaraRenta, setDeclaraRenta] = useState(false)
  const [pepFuncionario, setPepFuncionario] = useState(false)
  const [pepRecursos, setPepRecursos] = useState(false)
  const [pepExpuesto, setPepExpuesto] = useState(false)
  const [pepFamiliar, setPepFamiliar] = useState(false)
  const [familiares, setFamiliares] = useState<{ vinculo: string; nombre: string; apellido: string }[]>([{ vinculo: '', nombre: '', apellido: '' }])
  const [estrato, setEstrato] = useState<number>(3)

  const [dirty, setDirty] = useState(false)
  const [dirtySections, setDirtySections] = useState<Set<string>>(new Set())
  const [otpOpen, setOtpOpen] = useState(false)
  const [toast, setToast] = useState<ToastPayload | null>(null)

  // Marca una sección como modificada (para el badge "Cambios sin guardar")
  const touch = (sectionId: string) => setDirtySections(prev => { const n = new Set(prev); n.add(sectionId); return n })
  const markDirtyIn = (sectionId: string, setter: (v: any) => void) => (v: any) => {
    setter(v)
    setDirty(true)
    touch(sectionId)
  }
  const clearDirty = () => { setDirty(false); setDirtySections(new Set()) }

  // Familiares PEP — lista dinámica
  const updateFamiliar = (i: number, key: 'vinculo' | 'nombre' | 'apellido', val: string) => {
    setFamiliares(prev => prev.map((f, idx) => (idx === i ? { ...f, [key]: val } : f)))
    setDirty(true); touch('bloque-pep')
  }
  const addFamiliar = () => { setFamiliares(prev => [...prev, { vinculo: '', nombre: '', apellido: '' }]); setDirty(true); touch('bloque-pep') }
  const removeFamiliar = (i: number) => { setFamiliares(prev => prev.filter((_, idx) => idx !== i)); setDirty(true); touch('bloque-pep') }

  const [loading, setLoading] = useState(true)
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700)
    return () => clearTimeout(t)
  }, [])

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="space-y-1"><LoadingSkeleton className="h-8 w-36" /><LoadingSkeleton className="h-4 w-56" /></div>
        <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex gap-5 items-center">
          <LoadingSkeleton className="h-24 w-24 rounded-full" />
          <div className="flex-1 space-y-2"><LoadingSkeleton className="h-4 w-48" /><LoadingSkeleton className="h-3 w-full rounded-full" /></div>
        </div>
        {[0, 1, 2, 3].map(i => (
          <div key={i} className="bg-white rounded-2xl border border-[#E8ECF2] p-4 flex items-center gap-3.5">
            <LoadingSkeleton className="h-10 w-10 rounded-xl" />
            <LoadingSkeleton className="h-5 w-40" />
          </div>
        ))}
      </div>
    )
  }

  // Secciones del perfil (fuente de verdad para progreso y estado)
  const secciones = personType === 'natural'
    ? [
        { id: 'bloque-perfil', label: 'Datos de perfil', icon: 'profile', meta: '6 campos', complete: true },
        { id: 'bloque-residencia', label: 'Datos de residencia', icon: 'home', meta: '4 campos', complete: true },
        { id: 'bloque-financiera', label: 'Información financiera', icon: 'coin', meta: '6 campos · falta completar', complete: false },
        { id: 'bloque-profesional', label: 'Datos profesionales', icon: 'education', meta: '3 campos', complete: true },
        { id: 'bloque-pep', label: 'Exposición política (PEP)', icon: 'shield', meta: '4 declaraciones', complete: true },
      ]
    : [
        { id: 'bloque-rep', label: 'Datos del representante legal', icon: 'profile', meta: '4 campos', complete: true },
        { id: 'bloque-empresa', label: 'Información de la empresa', icon: 'bank', meta: '4 campos', complete: true },
      ]

  const total = secciones.length
  const done = secciones.filter(s => s.complete).length
  const pendientes = secciones.filter(s => !s.complete)
  const completeness = Math.round((done / total) * 100)
  const meta = (id: string) => secciones.find(s => s.id === id)?.meta ?? ''
  const estado = (id: string) => secciones.find(s => s.id === id)?.complete ?? true

  const scrollToBlock = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5 pb-24">
      <SectionHeader title="Mi perfil" subtitle="Mantén tu información actualizada" />

      {/* Completeness — ProgressRing DS + pendientes explícitos */}
      <div className="relative overflow-hidden rounded-2xl border border-[#E8ECF2] bg-white">
        <div className="flex flex-col sm:flex-row sm:items-center gap-5 p-5">
          <ProgressRing
            value={completeness}
            size={96}
            label={`${completeness}%`}
            className="flex-shrink-0 mx-auto sm:mx-0"
          />
          <div className="min-w-0 flex-1">
            <p className="text-[15px] font-bold text-[#2A3036]">
              {completeness >= 100 ? 'Perfil al día' : 'Completa tu perfil'}
            </p>
            <p className="text-[12.5px] text-gray-500 mt-0.5">
              {completeness >= 100
                ? 'Toda tu información está completa y verificada.'
                : `Tienes ${done} de ${total} secciones listas. Completa las pendientes para acceder a todos los beneficios.`}
            </p>

            {pendientes.length > 0 && (
              <div className="mt-3 space-y-1.5">
                {pendientes.map(p => (
                  <button
                    key={p.id}
                    onClick={() => scrollToBlock(p.id)}
                    className="group w-full flex items-center gap-2.5 rounded-xl border border-[#FFD400]/40 bg-[#FFFBEB] px-3 py-2 text-left transition-colors hover:bg-[#FFF7D6] cursor-pointer"
                  >
                    <span className="w-6 h-6 rounded-lg bg-[#FFD400] flex items-center justify-center flex-shrink-0 text-white">
                      <Icon name={p.icon} className="w-3.5 h-3.5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[12.5px] font-bold text-[#8A6D00] leading-tight">{p.label}</span>
                      <span className="block text-[11px] text-[#8A6D00]/70">Toca para completar</span>
                    </span>
                    <svg className="w-4 h-4 text-[#8A6D00] flex-shrink-0 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {personType === 'natural' ? (
        <div className="grid grid-cols-1 gap-3">
          <Acordeon title="Datos de perfil" meta={meta('bloque-perfil')} icon="profile" complete={estado('bloque-perfil')} dirty={dirtySections.has('bloque-perfil')} id="bloque-perfil" defaultOpen>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Nombres" value="Andrés Ricardo" readonly />
              <Field label="Apellidos" value="Beltrán Sarta" readonly />
              <Field label="Tipo de documento" value="Cédula de ciudadanía" readonly />
              <Field label="Número de documento" value="1.030.456.789" readonly sensitive />
              <Field label="Correo electrónico" value={correo} sensitive onChange={markDirtyIn('bloque-perfil', setCorreo)} />
              <Field label="Celular" value={celular} sensitive onChange={markDirtyIn('bloque-perfil', setCelular)} />
            </div>
          </Acordeon>

          <Acordeon title="Datos de residencia" meta={meta('bloque-residencia')} icon="home" complete={estado('bloque-residencia')} dirty={dirtySections.has('bloque-residencia')} id="bloque-residencia">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Departamento" value="Cundinamarca" readonly />
              <Field label="Ciudad" value={ciudad} onChange={markDirtyIn('bloque-residencia', setCiudad)} />
              <Field label="Dirección" value={direccion} onChange={markDirtyIn('bloque-residencia', setDireccion)} />
              <Field label="Barrio" value={barrio} onChange={markDirtyIn('bloque-residencia', setBarrio)} />
            </div>
            <div className="mt-4">
              <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-2">Estrato</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5, 6].map(e => (
                  <button
                    key={e}
                    onClick={() => { setEstrato(e); setDirty(true); touch('bloque-residencia') }}
                    className={`w-10 h-10 rounded-xl border text-[14px] font-bold transition-colors cursor-pointer ${
                      estrato === e ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white' : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0C1E4C]/40'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          </Acordeon>

          <Acordeon title="Información financiera" meta={meta('bloque-financiera')} icon="coin" complete={estado('bloque-financiera')} dirty={dirtySections.has('bloque-financiera')} id="bloque-financiera">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Origen de fondos" value="Salario" onChange={markDirtyIn('bloque-financiera', () => {})} />
              <Field label="Ingresos mensuales" value={ingresos} sensitive onChange={markDirtyIn('bloque-financiera', setIngresos)} />
              <Field label="Egresos mensuales" value="2.200.000" sensitive onChange={markDirtyIn('bloque-financiera', () => {})} />
              <Field label="Activos totales" value="85.000.000" sensitive onChange={markDirtyIn('bloque-financiera', () => {})} />
              <Field label="Pasivos totales" value="22.000.000" sensitive onChange={markDirtyIn('bloque-financiera', () => {})} />
            </div>
            <div className="mt-4">
              <p className="text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-2">¿Declaras renta?</p>
              <div className="flex gap-3">
                {[true, false].map(val => (
                  <button
                    key={String(val)}
                    onClick={() => { setDeclaraRenta(val); setDirty(true); touch('bloque-financiera') }}
                    className={`px-4 py-2 rounded-xl border text-[14px] font-semibold transition-colors cursor-pointer ${
                      declaraRenta === val ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white' : 'bg-white border-[#E8ECF2] text-gray-600 hover:border-[#0C1E4C]/40'
                    }`}
                  >
                    {val ? 'Sí' : 'No'}
                  </button>
                ))}
              </div>
            </div>
          </Acordeon>

          <Acordeon title="Datos profesionales" meta={meta('bloque-profesional')} icon="education" complete={estado('bloque-profesional')} dirty={dirtySections.has('bloque-profesional')} id="bloque-profesional">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Nivel educativo</label>
                <select onChange={() => { setDirty(true); touch('bloque-profesional') }} className="w-full border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Universitario</option>
                  <option>Posgrado</option>
                  <option>Técnico</option>
                  <option>Bachillerato</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Ocupación</label>
                <select onChange={() => { setDirty(true); touch('bloque-profesional') }} className="w-full border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Empleado</option>
                  <option>Independiente</option>
                  <option>Pensionado</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Actividad económica</label>
                <select onChange={() => { setDirty(true); touch('bloque-profesional') }} className="w-full border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] text-[#2A3036] focus:outline-none focus:border-[#00DB8E] bg-white cursor-pointer">
                  <option>Educación</option>
                  <option>Salud</option>
                  <option>Comercio</option>
                  <option>Servicios</option>
                </select>
              </div>
            </div>
          </Acordeon>

          <Acordeon title="Exposición política (PEP)" meta={meta('bloque-pep')} icon="shield" complete={estado('bloque-pep')} dirty={dirtySections.has('bloque-pep')} id="bloque-pep">
            <div className="space-y-3">
              {[
                { label: '¿Eres funcionario público?', val: pepFuncionario, set: setPepFuncionario },
                { label: '¿Administras recursos públicos?', val: pepRecursos, set: setPepRecursos },
                { label: '¿Eres una persona expuesta políticamente?', val: pepExpuesto, set: setPepExpuesto },
              ].map(({ label, val, set }) => (
                <div key={label} className="flex items-center justify-between py-1 gap-3">
                  <span className="text-[14px] text-[#2A3036]">{label}</span>
                  <div className="flex gap-2 flex-shrink-0">
                    {[true, false].map(v => (
                      <button
                        key={String(v)}
                        onClick={() => { set(v); setDirty(true); touch('bloque-pep') }}
                        className={`px-3 py-1.5 rounded-xl border text-[13px] font-semibold transition-colors cursor-pointer ${
                          val === v ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white' : 'bg-white border-[#E8ECF2] text-gray-500 hover:border-[#0C1E4C]/40'
                        }`}
                      >
                        {v ? 'Sí' : 'No'}
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <div>
                <div className="flex items-center justify-between py-1 gap-3">
                  <span className="text-[14px] text-[#2A3036]">¿Tienes familiares PEP?</span>
                  <div className="flex gap-2 flex-shrink-0">
                    {[true, false].map(v => (
                      <button
                        key={String(v)}
                        onClick={() => { setPepFamiliar(v); setDirty(true); touch('bloque-pep') }}
                        className={`px-3 py-1.5 rounded-xl border text-[13px] font-semibold transition-colors cursor-pointer ${
                          pepFamiliar === v ? 'bg-[#0C1E4C] border-[#0C1E4C] text-white' : 'bg-white border-[#E8ECF2] text-gray-500 hover:border-[#0C1E4C]/40'
                        }`}
                      >
                        {v ? 'Sí' : 'No'}
                      </button>
                    ))}
                  </div>
                </div>
                {pepFamiliar && (
                  <div className="mt-3 space-y-3 pl-3 border-l-2 border-[#FFD400]/40">
                    {familiares.map((fam, i) => (
                      <div key={i} className="rounded-xl bg-[#F7F7F7] p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[11px] font-bold tracking-widest uppercase text-gray-400">Familiar {i + 1}</span>
                          {familiares.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeFamiliar(i)}
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-[#F70C5B] hover:text-[#C40048] cursor-pointer transition-colors"
                            >
                              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                              Quitar
                            </button>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-[11px] font-bold tracking-widest uppercase text-gray-400 mb-1">Vínculo</label>
                            <select
                              value={fam.vinculo}
                              onChange={e => updateFamiliar(i, 'vinculo', e.target.value)}
                              className={`w-full border border-[#E8ECF2] rounded-xl px-3 py-2.5 text-[14px] focus:outline-none focus:border-[#00DB8E] focus:ring-1 focus:ring-[#00DB8E]/30 bg-white cursor-pointer transition-colors ${fam.vinculo ? 'text-[#2A3036]' : 'text-gray-400'}`}
                            >
                              <option value="" disabled>Selecciona…</option>
                              {VINCULOS.map(v => <option key={v} value={v} className="text-[#2A3036]">{v}</option>)}
                            </select>
                          </div>
                          <Field label="Nombre" value={fam.nombre} onChange={v => updateFamiliar(i, 'nombre', v)} />
                          <Field label="Apellido" value={fam.apellido} onChange={v => updateFamiliar(i, 'apellido', v)} />
                        </div>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={addFamiliar}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-dashed border-[#0C1E4C]/30 text-[13px] font-bold text-[#06005A] hover:bg-[#06005A]/[0.04] hover:border-[#0C1E4C]/50 transition-colors cursor-pointer"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
                      Añadir familiar
                    </button>
                  </div>
                )}
              </div>
            </div>
          </Acordeon>
        </div>
      ) : (
        /* Jurídica */
        <div className="grid grid-cols-1 gap-3">
          <Acordeon title="Datos del representante legal" meta={meta('bloque-rep')} icon="profile" complete={estado('bloque-rep')} dirty={dirtySections.has('bloque-rep')} id="bloque-rep" defaultOpen>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Nombres" value="Carlos Alberto" onChange={markDirtyIn('bloque-rep', () => {})} />
              <Field label="Apellidos" value="Sánchez Rojas" onChange={markDirtyIn('bloque-rep', () => {})} />
              <Field label="Tipo de documento" value="Cédula de ciudadanía" readonly />
              <Field label="Número de documento" value="79.456.123" readonly sensitive />
            </div>
          </Acordeon>
          <Acordeon title="Información de la empresa" meta={meta('bloque-empresa')} icon="bank" complete={estado('bloque-empresa')} dirty={dirtySections.has('bloque-empresa')} id="bloque-empresa">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Razón social" value="Comercializadora Andina S.A.S." readonly />
              <Field label="NIT" value="900.123.456-7" readonly sensitive />
              <Field label="Correo electrónico" value="contacto@andina.com" readonly />
              <Field label="Celular" value="601 456 7890" readonly />
            </div>
          </Acordeon>
        </div>
      )}

      {/* Save bar */}
      {dirty && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#E8ECF2] px-6 py-4 z-40 flex items-center justify-between gap-4 shadow-lg">
          <p className="text-[14px] text-gray-600 font-medium">Tienes cambios sin guardar</p>
          <div className="flex gap-3">
            <Btn variant="ghost" size="md" onClick={clearDirty}>Descartar</Btn>
            <Btn variant="primary" size="md" onClick={() => setOtpOpen(true)}>Guardar cambios</Btn>
          </div>
        </div>
      )}

      {/* OTP — autorización de la actualización de datos (KOA DS) */}
      <OtpModalKoa
        open={otpOpen}
        onSuccess={() => {
          setOtpOpen(false)
          clearDirty()
          setToast({ tone: 'success', title: 'Datos actualizados', message: 'Tus cambios se guardaron correctamente.' })
        }}
        onClose={() => setOtpOpen(false)}
      />

      {toast && <NotificationToast tone={toast.tone} title={toast.title} message={toast.message} onClose={() => setToast(null)} />}
    </div>
  )
}
