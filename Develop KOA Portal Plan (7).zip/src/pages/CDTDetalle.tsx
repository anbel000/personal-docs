import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { copyText } from '../lib/copy'
import { useDemoContext } from '../context/DemoContext'
import Btn from '../components/Btn'
import { Modal, Button, Field, Card, Badge, IconTile } from '../components/ui'
import type { IconTileTone } from '../components/ui'
import LoadingSkeleton from '../components/LoadingSkeleton'
import CDTRenovacion from '../cdt/CDTRenovacion'
import CuentaDesembolso from '../cdt/CuentaDesembolso'
import FirmaElectronica from '../cdt/FirmaElectronica'
import { cdts, cdtsTerminados, formatPesos } from '../data/mockData'
import { KoaFlor } from '../components/koa'
import NotificationToast, { type ToastPayload } from '../components/NotificationToast'

/* ── Count-up hook ──────────────────────────────────── */
function useCountUp(target: number, duration = 1100, active = true) {
  const [value, setValue] = useState(0)
  const raf = useRef<number>(0)
  useEffect(() => {
    if (!active) return
    const start = performance.now()
    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1)
      const ease = 1 - Math.pow(1 - t, 3)
      setValue(Math.round(target * ease))
      if (t < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [target, duration, active])
  return value
}

/* ── Icons ──────────────────────────────────────────── */
function CopyIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
}
function DownloadIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
}
function InfoIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 16v-4m0-4h.01" /></svg>
}
function EditIcon() {
  return <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
}

/* ── Hero skeleton ──────────────────────────────────── */
function HeroSkeleton() {
  return (
    <div className="rounded-3xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)', minHeight: 220 }}>
      <div className="px-6 sm:px-8 py-8 space-y-5">
        <div className="flex items-center justify-between">
          <LoadingSkeleton className="h-3 w-24 rounded-full opacity-30" />
          <LoadingSkeleton className="h-6 w-20 rounded-full opacity-20" />
        </div>
        <LoadingSkeleton className="h-12 w-52 rounded-2xl opacity-40" />
        <div className="flex gap-4 flex-wrap">
          {[0, 1, 2].map(i => <LoadingSkeleton key={i} className="h-14 w-28 rounded-xl opacity-20" />)}
        </div>
        <LoadingSkeleton className="h-2 w-full rounded-full opacity-20" />
      </div>
    </div>
  )
}

type Alerta = { id: string; tipo: 'info' | 'warning' | 'error' | 'success'; titulo: string; texto: string }

export default function CDTDetalle() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { productos } = useDemoContext()
  const hasCDT = productos === 'ambos' || productos === 'solo-cdt'
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<ToastPayload | null>(null)
  const [downloading, setDownloading] = useState<string | null>(null)

  const [proposito, setProposito] = useState('Ahorro de largo plazo')
  const [infoProposito, setInfoProposito] = useState(false)
  const [editProposito, setEditProposito] = useState(false)
  const [propositoTemp, setPropositoTemp] = useState('')
  const [firmaProposito, setFirmaProposito] = useState(false)

  const [alertas, setAlertas] = useState<Alerta[]>([
    { id: 'a1', tipo: 'warning', titulo: 'Tu CDT vence pronto', texto: 'Vence en menos de 60 días. Revisa tus opciones de renovación antes de la fecha.' },
    { id: 'a2', tipo: 'info', titulo: 'Inscribe tu cuenta de desembolso', texto: 'Necesitas una cuenta inscrita para recibir tu capital e intereses al vencimiento.' },
  ])

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(t)
  }, [])

  const allCdts = [...cdts, ...cdtsTerminados]
  const cdt = allCdts.find(c => c.id === id) ?? cdts[0]
  const terminado = cdt.estado === 'terminado'

  const montoAnimado = useCountUp(cdt.montoInvertido, 1100, !loading)

  const handleDownload = (docId: string) => {
    setDownloading(docId)
    setTimeout(() => { setDownloading(null); setToast({ tone: 'success', title: 'Descarga completada', message: 'El documento de tu CDT se guardó en tu dispositivo.' }) }, 900)
  }
  const copyNumero = () => {
    copyText(cdt.numeroCompleto)
    setToast({ tone: 'success', title: 'Número copiado', message: 'El número del CDT quedó en tu portapapeles.' })
  }
  const handleEditarProposito = () => { setPropositoTemp(proposito); setEditProposito(true) }
  const handleGuardarProposito = () => { if (!propositoTemp.trim()) return; setEditProposito(false); setFirmaProposito(true) }
  const handleFirmaPropositoSuccess = () => { setFirmaProposito(false); setProposito(propositoTemp); setToast({ tone: 'success', title: 'Propósito actualizado', message: 'El propósito de tu CDT se guardó correctamente.' }) }
  const dismissAlerta = (alertaId: string) => setAlertas(prev => prev.filter(a => a.id !== alertaId))

  /* Conditions grid */
  const condiciones = [
    { label: 'Tasa fija', value: `${cdt.tasa} % E.A.`, highlight: true },
    { label: 'Periodicidad', value: cdt.periodicidad },
    { label: 'Apertura', value: cdt.fechaApertura },
    { label: 'Vencimiento', value: cdt.fechaVencimiento },
    { label: 'Estado', value: terminado ? 'Terminado' : 'Activo' },
    { label: 'Renovación', value: terminado ? '—' : cdt.renovacionAutomatica ? 'Automática' : 'Manual' },
    { label: 'Rendimientos fin.', value: formatPesos(Math.round(cdt.montoInvertido * parseFloat(cdt.tasa.replace(',', '.')) / 100)) },
    { label: 'Días restantes', value: terminado ? '—' : `${cdt.diasRestantes ?? '—'} días` },
  ]

  /* Alert styles — Alertas y notificaciones del KOA Design System */
  const alertaStyle: Record<string, { bg: string; border: string; iconBg: string; iconColor: string; path: string }> = {
    success: {
      bg: '#EFFFF7', border: 'rgba(0,219,142,0.25)', iconBg: '#00DB8E', iconColor: '#06005A',
      path: 'M5 13l4 4L19 7',
    },
    warning: {
      bg: '#FFFBEB', border: 'rgba(255,212,0,0.45)', iconBg: '#FFD400', iconColor: '#FFFFFF',
      path: 'M12 8v4m0 4h.01M12 3a9 9 0 100 18 9 9 0 000-18z',
    },
    info: {
      bg: '#EBF5FF', border: 'rgba(0,152,255,0.3)', iconBg: '#0098FF', iconColor: '#FFFFFF',
      path: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    },
    error: {
      bg: '#FFF0F5', border: 'rgba(239,68,68,0.25)', iconBg: '#FA467F', iconColor: '#FFFFFF',
      path: 'M6 18L18 6M6 6l12 12',
    },
  }

  /* Cert documents */
  const certs = [
    { id: 'cert-deposito', nombre: 'Certificado de depósito', desc: 'Certifica tu inversión a término.', habilitado: true, band: '#06005A', iconColor: '#00DB8E' },
    { id: 'cert-terminos', nombre: 'Términos y condiciones', desc: 'Condiciones del certificado a término.', habilitado: true, band: '#0068B3', iconColor: '#0098FF' },
  ]

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <LoadingSkeleton className="h-5 w-36" />
        <HeroSkeleton />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[0, 1, 2, 3].map(i => <LoadingSkeleton key={i} className="h-20 rounded-2xl" />)}
        </div>
        <LoadingSkeleton className="h-40 rounded-2xl" />
        <LoadingSkeleton className="h-56 rounded-2xl" />
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Back */}
      <button
        onClick={() => navigate('/cdt')}
        className="flex items-center gap-1.5 text-[13px] font-semibold text-[#0098FF] hover:underline cursor-pointer"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" /></svg>
        Volver a mis CDT
      </button>

      {/* ── Alertas y notificaciones — mismo patrón que "Tu atención es necesaria" del Inicio ── */}
      {(() => {
        const cuentaLista = cdt.cuentaEstado === 'validada' || cdt.cuentaEstado === 'en-validacion'
        const alertasVisibles = alertas.filter(a => !(a.id === 'a2' && cuentaLista))
        if (alertasVisibles.length === 0) return null
        const toneMap: Record<string, IconTileTone> = { success: 'success', warning: 'warning', info: 'info', error: 'error' }
        return (
        <section className="space-y-3 card-enter">
          {/* Section header — patrón del Inicio */}
          <div className="px-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="w-1.5 h-1.5 rounded-full bg-warning animate-pulse" />
              <p className="text-[13px] font-black text-ink leading-tight">Tu atención es necesaria</p>
              <Badge tone="warning" className="flex-shrink-0">{alertasVisibles.length} por resolver</Badge>
            </div>
            <p className="text-[11.5px] text-muted font-medium leading-snug mt-1">
              Gestiona los siguientes puntos para mantener este CDT al día
            </p>
          </div>

          <Card className="p-0 overflow-hidden">
            <div className="divide-y divide-line">
              {alertasVisibles.map(a => {
                const s = alertaStyle[a.tipo]
                return (
                  <div key={a.id} className="flex items-center gap-3.5 px-4 sm:px-5 py-3.5">
                    <IconTile toneName={toneMap[a.tipo] ?? 'info'} sizeName="md">
                      <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d={s.path} />
                      </svg>
                    </IconTile>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-semibold text-ink leading-snug">{a.titulo}</p>
                      <p className="text-[11.5px] text-muted font-medium leading-tight mt-0.5">{a.texto}</p>
                    </div>
                    <button onClick={() => dismissAlerta(a.id)} aria-label="Descartar alerta" className="w-6 h-6 rounded-lg flex items-center justify-center text-muted-soft hover:text-ink hover:bg-black/[0.04] transition-colors cursor-pointer flex-shrink-0">
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                  </div>
                )
              })}
            </div>
          </Card>
        </section>
        )
      })()}

      {/* ── HERO — superficie hero del DS (mint-forward), alineada con CDT / Inicio ── */}
      <div
        className="relative overflow-hidden rounded-3xl card-enter shadow-card"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        {/* organic mint blooms — DS hero surface */}
        <div className="absolute -top-24 -right-16 w-80 h-80 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-24 -left-12 w-72 h-72 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float pointer-events-none" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />

        <div className="relative z-10 p-6 sm:p-8">
          {/* Header — marca + identidad del CDT */}
          <div className="flex items-start gap-3">
            <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-9 h-9 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-mint">CDT Digital · KOA</p>
              {proposito ? (
                <div className="flex items-start gap-2 mt-0.5">
                  <h1 className="text-white font-black text-[20px] sm:text-[22px] leading-tight min-w-0">{proposito}</h1>
                  {!terminado && (
                    <button onClick={handleEditarProposito} aria-label="Editar propósito" className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer text-white/50 flex-shrink-0 mt-0.5">
                      <EditIcon />
                    </button>
                  )}
                </div>
              ) : (
                <h1 className="text-white font-black text-[16px] leading-tight mt-0.5">
                  Tu inversión <span className="text-mint [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">florece</span>
                </h1>
              )}
              <div className="flex items-center gap-2 mt-1.5">
                <span className="font-figures text-white/65 text-[12px]">{cdt.numeroCompleto}</span>
                <button onClick={copyNumero} aria-label="Copiar número" className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors cursor-pointer text-white/70">
                  <CopyIcon />
                </button>
              </div>
              {!proposito && !terminado && (
                <button onClick={handleEditarProposito} className="flex items-center gap-1.5 mt-2 text-mint/80 hover:text-mint text-[11px] font-semibold transition-colors cursor-pointer">
                  <EditIcon />
                  Añadir propósito de inversión
                </button>
              )}
            </div>
            {/* Estado — badge in-flow (no se solapa en mobile) */}
            {terminado ? (
              <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-white/10 border border-white/15 px-3 py-1 text-[11px] font-bold text-white/70">
                <span className="w-1.5 h-1.5 rounded-full bg-white/50" />
                Terminado
              </span>
            ) : (
              <span className="shrink-0 inline-flex items-center gap-1.5 rounded-full bg-mint pl-2 pr-2.5 py-1 text-[11px] font-black text-brand shadow-[0_6px_18px_-4px_rgba(0,219,142,0.6)]">
                <span className="w-1.5 h-1.5 rounded-full bg-brand/60 mint-pulse" />
                Activo
              </span>
            )}
          </div>

          {/* Figure — monto invertido */}
          <div className="mt-6">
            <p className="text-white/70 text-[10px] font-bold uppercase tracking-[0.16em]">Monto invertido</p>
            <p className="font-figures text-white font-black leading-none mt-1.5 animate-number-pop" style={{ fontSize: 'clamp(30px, 6vw, 42px)', ['--delay' as string]: '0.1s' }}>
              {formatPesos(montoAnimado)}
            </p>
          </div>

          {/* Progress bar */}
          {!terminado && (
            <div className="mt-6">
              <div className="flex justify-between text-[10px] font-figures font-semibold mb-1.5">
                <span className="text-white/70">{cdt.fechaApertura}</span>
                <span className="text-white/70">{cdt.fechaVencimiento}</span>
              </div>
              <div className="h-2 rounded-full overflow-hidden bg-white/10">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${cdt.progresoPct}%`,
                    background: 'linear-gradient(90deg, #0098FF 0%, #0098FF 60%, #00DB8E 100%)',
                    boxShadow: '0 0 10px rgba(59,130,246,0.5)',
                    transition: 'width 0.8s cubic-bezier(0.22,1,0.36,1)',
                  }}
                />
              </div>
              <div className="flex justify-between items-center mt-1.5">
                <span className="text-white/70 text-[10px] font-medium">Plazo transcurrido · {cdt.progresoPct}%</span>
                {cdt.diasRestantes !== undefined && (
                  <span className="font-figures text-mint text-[11px] font-bold">Faltan {cdt.diasRestantes} días</span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Conditions grid ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-1">
        <div className="px-5 pt-4 pb-3 border-b border-[#F0F2F5]">
          <p className="font-bold text-[14px] text-[#2A3036]">Condiciones del CDT</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4">
          {condiciones.map((c, i) => (
            <div
              key={c.label}
              className={`px-4 py-3.5 ${i % 2 === 0 ? 'bg-white' : 'bg-[#F7F7F7]'} ${
                Math.floor(i / 4) < Math.floor((condiciones.length - 1) / 4) ? 'border-b border-[#F0F2F5]' : ''
              } ${i % 4 !== 3 ? 'sm:border-r sm:border-[#F0F2F5]' : ''}`}
            >
              <p className="text-[9px] font-bold tracking-[0.16em] uppercase text-gray-400 mb-1">{c.label}</p>
              <p className={`font-figures font-bold text-[13px] leading-snug ${c.highlight ? 'text-[#0098FF]' : 'text-[#2A3036]'}`}>{c.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Cuenta de desembolso ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-3">
        <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5]">
          <p className="font-bold text-[15px] text-[#2A3036]">Cuenta de desembolso</p>
          <p className="text-[12px] text-gray-400 mt-0.5">Recibirás tu capital e intereses aquí al vencimiento</p>
        </div>
        <div className="p-5">
          <CuentaDesembolso estadoInicial={cdt.cuentaEstado} onToast={t => setToast(t)} />
        </div>
      </div>

      {/* ── Renovación ── */}
      {!terminado && hasCDT && (
        <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden card-enter stagger-4">
          <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5] flex items-center justify-between gap-3">
            <div>
              <p className="font-bold text-[15px] text-[#2A3036]">Renovación</p>
              <p className="text-[12px] text-gray-400 mt-0.5">Instrucción al vencimiento de tu CDT</p>
            </div>
            <span className="text-[11px] font-semibold text-gray-400 flex-shrink-0">Modifica hasta el 29 SEP 2026</span>
          </div>
          <div className="p-5">
            <CDTRenovacion
              cdt={{ id: cdt.id, montoInvertido: cdt.montoInvertido, rendimientos: cdt.rendimientos, fechaVencimiento: cdt.fechaVencimiento, tasa: cdt.tasa, cuentaEstado: cdt.cuentaEstado, cuentaBanco: cdt.cuentaBanco, cuentaTipo: cdt.cuentaTipo, cuentaNumeroMascarado: cdt.cuentaNumeroMascarado }}
              onToast={t => setToast(t)}
            />
          </div>
        </div>
      )}

      {/* ── Certificados ── */}
      <div className="bg-white rounded-3xl border border-[#E8ECF2] overflow-hidden">
        <div className="px-5 pt-5 pb-4 border-b border-[#F0F2F5]">
          <p className="font-bold text-[15px] text-[#2A3036]">Documentos y certificados</p>
          <p className="text-[12px] text-gray-400 mt-0.5">Documentos oficiales de tu CDT</p>
        </div>
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {certs.map(cert => (
            <div key={cert.id} className="rounded-2xl border border-[#E8ECF2] overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-0.5">
              <div className="h-1.5" style={{ background: cert.band }} />
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${cert.band}22` }}>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8} style={{ color: cert.iconColor }}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-[13px] text-[#2A3036] leading-tight">{cert.nombre}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{cert.desc}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(cert.id)}
                  disabled={downloading === cert.id}
                  className="w-full flex items-center justify-center gap-1.5 text-white text-[12px] font-bold px-3 py-2 rounded-xl cursor-pointer hover:opacity-90 active:scale-[0.98] transition-all duration-150"
                  style={{ background: cert.band }}
                >
                  {downloading === cert.id ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <DownloadIcon />
                  )}
                  Descargar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dialogs */}
      <Modal
        open={infoProposito}
        onClose={() => setInfoProposito(false)}
        title="¿Qué es el propósito de inversión?"
        footer={<Button variant="primary" size="md" className="w-full" onClick={() => setInfoProposito(false)}>Entendido</Button>}
      >
        <div className="space-y-4">
          <p className="text-[13px] text-gray-600 leading-relaxed">El propósito es una descripción corta del objetivo de ahorro para este CDT. Es un campo informativo que te ayuda a organizar tus inversiones, como "Fondo de emergencia", "Viaje 2027" o "Educación".</p>
          <p className="text-[13px] text-gray-600 leading-relaxed">Este campo no afecta los términos del CDT ni genera obligaciones adicionales.</p>
        </div>
      </Modal>

      <Modal
        open={editProposito}
        onClose={() => setEditProposito(false)}
        title="Editar propósito"
        footer={
          <>
            <Button variant="secondary" size="md" className="flex-1" onClick={() => setEditProposito(false)}>Cancelar</Button>
            <Button variant="primary" size="md" className="flex-1" disabled={!propositoTemp.trim()} onClick={handleGuardarProposito}>Guardar</Button>
          </>
        }
      >
        <Field
          label="Propósito (máx. 50 caracteres)"
          type="text"
          maxLength={50}
          value={propositoTemp}
          onChange={e => setPropositoTemp(e.target.value)}
          helperText={`${propositoTemp.length}/50`}
          autoFocus
        />
      </Modal>

      <FirmaElectronica
        open={firmaProposito}
        operacion="editar-proposito"
        onSuccess={handleFirmaPropositoSuccess}
        onClose={() => setFirmaProposito(false)}
      />

      {toast && <NotificationToast tone={toast.tone} title={toast.title} message={toast.message} onClose={() => setToast(null)} />}
    </div>
  )
}
