import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { copyText } from '../lib/copy'
import LoadingSkeleton from '../components/LoadingSkeleton'
import TabPagos from '../libranza/TabPagos'
import CertificadosInmediatos from '../libranza/CertificadosInmediatos'
import CertificacionDeSaldo, { getCertificacionEstado, CertificacionEnProcesoBanner } from '../libranza/CertificacionDeSaldo'
import { Card, IconTile } from '../components/ui'
import { CreditStatusPill } from '../components/koa'
import { creditos, formatPesos } from '../data/mockData'
import NotificationToast, { type ToastPayload } from '../components/NotificationToast'

function useCountUp(target: number, duration = 950, active = true) {
  const [value, setValue] = useState(0)
  useEffect(() => {
    if (!active) return
    setValue(0)
    let raf: number
    const start = performance.now()
    const tick = (time: number) => {
      const p = Math.min((time - start) / duration, 1)
      setValue(Math.round(target * (1 - Math.pow(1 - p, 4))))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, active])
  return value
}

function CopyIcon() {
  return (
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  )
}

function CheckMini() {
  return (
    <svg className="w-3.5 h-3.5 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
  )
}

function HeroSkeleton() {
  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <LoadingSkeleton className="h-5 w-40" />
      <div className="bg-[#06005A] rounded-3xl p-6 space-y-5">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <LoadingSkeleton className="h-3 w-24" style={{ background: 'rgba(255,255,255,0.12)' }} />
            <LoadingSkeleton className="h-5 w-36" style={{ background: 'rgba(255,255,255,0.12)' }} />
            <LoadingSkeleton className="h-3.5 w-28" style={{ background: 'rgba(255,255,255,0.08)' }} />
          </div>
          <LoadingSkeleton className="h-6 w-16 rounded-full" style={{ background: 'rgba(255,255,255,0.1)' }} />
        </div>
        <div className="space-y-2">
          <LoadingSkeleton className="h-3 w-20" style={{ background: 'rgba(255,255,255,0.08)' }} />
          <LoadingSkeleton className="h-12 w-56" style={{ background: 'rgba(255,255,255,0.12)' }} />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[0,1,2].map(i => <LoadingSkeleton key={i} className="h-[62px] rounded-xl" style={{ background: 'rgba(255,255,255,0.07)' }} />)}
        </div>
        <LoadingSkeleton className="h-12 rounded-xl" style={{ background: 'rgba(255,255,255,0.06)' }} />
      </div>
      <div className="bg-white rounded-3xl border border-[#E8ECF2] p-5 space-y-3">
        <LoadingSkeleton className="h-4 w-40" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {[0,1,2,3,4,5,6,7].map(i => <LoadingSkeleton key={i} className="h-[62px] rounded-xl" />)}
        </div>
      </div>
    </div>
  )
}

export default function LibranzaDetalle() {
  const { id } = useParams()
  const navigate = useNavigate()
  const credito = creditos.find(c => c.id === id) ?? creditos[0]
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<ToastPayload | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 800)
    return () => clearTimeout(t)
  }, [id])

  const pct = Math.round((credito.cuotaActual / credito.totalCuotas) * 100)
  const enMora = credito.estado === 'en-mora'
  const animatedSaldo = useCountUp(credito.saldo, 950, !loading)

  if (loading) return <HeroSkeleton />

  const copyNumero = () => {
    copyText(credito.numeroCompleto)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    setToast({ tone: 'success', title: 'Número copiado', message: 'El número del crédito quedó en tu portapapeles.' })
  }

  // Nota: la información expuesta en el hero (número, pagaduría, saldo,
  // progreso de cuotas) NO se repite aquí para evitar redundancia.
  const condiciones = [
    { label: 'Valor del crédito', value: formatPesos(credito.montoDesembolsado), figures: true },
    { label: 'Modalidad', value: credito.modalidad, figures: false },
    { label: 'Plazo', value: `${credito.plazoMeses} meses`, figures: true },
    { label: 'Cuota mensual', value: formatPesos(credito.cuotaMensual), figures: true },
    { label: 'Cuotas pendientes', value: String(credito.cuotasPendientes), figures: true },
    { label: 'Fecha desembolso', value: credito.fechaDesembolso, figures: true },
  ]

  return (
    <div className="max-w-3xl mx-auto space-y-5">

      {/* Back */}
      <button
        onClick={() => navigate('/libranza')}
        className="flex items-center gap-1.5 text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
        Volver a mis créditos
      </button>

      {/* ── Hero card — alineado al SummaryHero de /libranza ─── */}
      <Card
        variant="bloom"
        spotlight
        className="group relative overflow-hidden card-enter !border-line p-5 sm:p-6"
        style={{ background: '#FFFFFF' }}
      >
        {/* Barra superior de marca */}
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-brand pointer-events-none" />

        <div className="relative z-10">
          {/* Identidad + estado */}
          <div className="flex items-start justify-between gap-3 mb-5">
            <div className="flex items-center gap-3 min-w-0">
              <IconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
                <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m3-6h9a2 2 0 012 2v6a2 2 0 01-2 2h-9a2 2 0 01-2-2v-6a2 2 0 012-2zm7 5a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </IconTile>
              <div className="min-w-0">
                <p className="text-[10px] font-bold tracking-[0.16em] uppercase text-muted leading-none mb-1">
                  Crédito de Libranza
                </p>
                <div className="flex items-center gap-2">
                  <span className="font-figures font-bold text-brand text-[16px] tracking-tight truncate">
                    {credito.numeroCompleto}
                  </span>
                  <button
                    onClick={copyNumero}
                    className="w-6 h-6 rounded-lg bg-app-bg hover:bg-line flex items-center justify-center transition-colors cursor-pointer text-ink-soft flex-shrink-0"
                    title="Copiar número"
                  >
                    {copied ? <CheckMini /> : <CopyIcon />}
                  </button>
                </div>
                <p className="text-ink-soft text-[12.5px] font-medium mt-0.5 truncate">{credito.pagaduria}</p>
              </div>
            </div>
            <div className="flex-shrink-0 mt-1">
              <CreditStatusPill status={credito.estado} />
            </div>
          </div>

          {/* Mora alert — tokens del DS sobre superficie clara */}
          {enMora && (
            <div className="mb-5 bg-[#FFF0F5] border border-[#FA467F]/25 rounded-xl px-4 py-3 flex items-center gap-2.5">
              <svg className="w-4 h-4 text-[#F70C5B] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <p className="text-[13px] font-semibold text-[#F70C5B]">
                Saldo en mora — comunícate con nosotros para regularizarlo.
              </p>
            </div>
          )}

          {/* Saldo protagonista */}
          <p className="text-[11px] text-muted font-bold uppercase tracking-[0.18em] mb-1">Saldo total</p>
          <p className="font-figures font-black text-brand leading-none text-[36px] sm:text-[44px] tracking-tight">
            {formatPesos(animatedSaldo)}
          </p>

          {/* Progreso de cuotas */}
          <div className="mt-5">
            <div className="flex justify-between items-baseline mb-1.5">
              <span className="text-[12px] text-ink-soft">
                Cuota{' '}
                <span className="font-figures font-semibold text-ink">{credito.cuotaActual}</span>
                {' '}de{' '}
                <span className="font-figures text-ink-soft">{credito.totalCuotas}</span>
              </span>
              <span className="font-figures text-[12px] font-bold text-mint-text">{pct}% pagado</span>
            </div>
            <div className="h-2 bg-app-bg rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000 ease-out bg-gradient-to-r from-mint to-brand"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        </div>
      </Card>

      {/* ── Certificación de saldo en proceso — debajo del card principal ── */}
      {getCertificacionEstado(credito.id) === 'en-proceso' && <CertificacionEnProcesoBanner />}

      {/* ── Condiciones del crédito ─────────────────── */}
      <div className="bg-white rounded-3xl border border-line p-5 sm:p-6 card-enter stagger-1">
        {/* Encabezado con IconTile — coherente con las demás tarjetas */}
        <div className="flex items-start gap-3 mb-4">
          <IconTile toneName="navy" sizeName="md">
            <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </IconTile>
          <div>
            <p className="font-bold text-[15px] text-ink">Condiciones del crédito</p>
            <p className="text-[12px] text-muted mt-0.5">Términos pactados en el desembolso</p>
          </div>
        </div>

        {/* Grilla de campos — 2 col en móvil, 3 en escritorio */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {condiciones.map(d => (
            <div
              key={d.label}
              className="bg-surface-alt rounded-xl px-3.5 py-3 border border-transparent hover:border-line transition-colors"
            >
              <p className="text-[9px] font-bold text-muted tracking-[0.12em] uppercase mb-1.5 leading-none">
                {d.label}
              </p>
              <p className={`font-semibold text-ink text-[13px] leading-snug ${d.figures ? 'font-figures' : ''}`}>
                {d.value}
              </p>
            </div>
          ))}
        </div>

        {/* Número de radicado — identificador destacado para soporte */}
        <div className="mt-2.5 flex items-center justify-between gap-3 rounded-xl bg-brand/[0.04] border border-brand/10 px-3.5 py-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <svg className="w-4 h-4 text-brand flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5a1.99 1.99 0 011.414.586l7 7a2 2 0 010 2.828l-5 5a2 2 0 01-2.828 0l-7-7A1.99 1.99 0 013 12V7a4 4 0 014-4z" />
            </svg>
            <div className="min-w-0">
              <p className="text-[9px] font-bold text-muted tracking-[0.12em] uppercase leading-none mb-1">
                Número de radicado
              </p>
              <p className="font-figures font-bold text-brand text-[13px] leading-none truncate">
                {credito.numeroRadicado}
              </p>
            </div>
          </div>
          <button
            onClick={() => { copyText(credito.numeroRadicado); setToast({ tone: 'success', title: 'Radicado copiado', message: 'El número de radicado quedó en tu portapapeles.' }) }}
            className="w-8 h-8 rounded-lg bg-white hover:bg-app-bg border border-line flex items-center justify-center transition-colors cursor-pointer text-ink-soft flex-shrink-0"
            title="Copiar radicado"
          >
            <CopyIcon />
          </button>
        </div>
      </div>

      {/* ── Historial de pagos ──────────────────────── */}
      <div className="bg-white rounded-3xl border border-line overflow-hidden card-enter stagger-2">
        <div className="px-5 sm:px-6 pt-5 pb-4 flex items-start gap-3">
          <IconTile toneName="mint" sizeName="md">
            <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 7h6m-6 4h6m-6 4h4M5 5a2 2 0 012-2h10a2 2 0 012 2v14l-3-2-2 2-2-2-2 2-2-2-2 2V5z" />
            </svg>
          </IconTile>
          <div>
            <p className="font-bold text-[15px] text-ink">Historial de pagos</p>
            <p className="text-[12px] text-muted mt-0.5">
              <span className="font-figures font-semibold text-ink">{credito.cuotasPagadas}</span> cuotas recaudadas por tu pagaduría
            </p>
          </div>
        </div>

        <div className="px-5 sm:px-6 pt-1 pb-5">
          <TabPagos />
        </div>
      </div>

      {/* ── Documentos ─────────────────────────────── */}
      <div className="bg-white rounded-3xl border border-line p-5 sm:p-6 card-enter stagger-3">
        <div className="flex items-start gap-3 mb-5">
          <IconTile toneName="navy" sizeName="md">
            <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </IconTile>
          <div>
            <p className="font-bold text-[15px] text-ink">Documentos</p>
            <p className="text-[12px] text-muted mt-0.5">Certificados y extractos de tu crédito</p>
          </div>
        </div>
        <CertificadosInmediatos onToast={t => setToast(t)} />
        {getCertificacionEstado(credito.id) !== 'en-proceso' && (
          <div className="mt-6 pt-6 border-t border-line">
            <CertificacionDeSaldo
              creditoId={credito.id}
              numeroMascarado={credito.numeroMascarado}
              pagaduria={credito.pagaduria}
              onToast={t => setToast(t)}
            />
          </div>
        )}
      </div>

      {toast && <NotificationToast tone={toast.tone} title={toast.title} message={toast.message} onClose={() => setToast(null)} />}
    </div>
  )
}
