import React, { useState, useEffect, useRef } from 'react'
import type { ReactNode } from 'react'
import { copyText } from '../lib/copy'
import Btn from '../components/Btn'
import StatusPill from '../components/StatusPill'
import EmptyState from '../components/EmptyState'
import FilterChips from '../components/FilterChips'
import KpiCard from '../components/KpiCard'
import SectionHeader from '../components/SectionHeader'
import SidePanel from '../components/SidePanel'
import { Button, Card, Field, Badge, Switch, Modal, IconTile as UiIconTile, StatCard, FeatureCard, ProgressRing } from '../components/ui'
import { CreditStatusPill, KoaFlor, KoaLogo } from '../components/koa'
import fogafinBlack from '../imports/fogafin-black.svg'
import fogafinBlue from '../imports/fogafin-blue.svg'
import fogafinWhite from '../imports/fogafin-white.svg'
import sfcBlack from '../imports/sfc-black-1.svg'
import sfcWhite from '../imports/sfc-white-1.svg'

/* ── Sections, grouped by layer ───────────────────────────── */
type Section = { id: string; label: string; group: string }
const SECTIONS: Section[] = [
  { id: 'arquitectura', label: 'Arquitectura', group: 'Fundamentos' },
  { id: 'logotipo',     label: 'Logotipo',     group: 'Fundamentos' },
  { id: 'isotipo-motion', label: 'Isotipo en movimiento', group: 'Fundamentos' },
  { id: 'identidad',    label: 'Identidad',    group: 'Fundamentos' },
  { id: 'colores',      label: 'Color',        group: 'Fundamentos' },
  { id: 'tipografia',   label: 'Tipografía',   group: 'Fundamentos' },
  { id: 'iconografia',  label: 'Iconografía',  group: 'Fundamentos' },
  { id: 'marcas',       label: 'Marcas legales', group: 'Fundamentos' },
  { id: 'botones',      label: 'Botones',      group: 'Primitivas' },
  { id: 'badges',       label: 'Badges',       group: 'Primitivas' },
  { id: 'formularios',  label: 'Formularios',  group: 'Primitivas' },
  { id: 'componentes-ui', label: 'Componentes', group: 'Primitivas' },
  { id: 'cards',        label: 'Cards',        group: 'Primitivas' },
  { id: 'alertas',      label: 'Alertas',      group: 'Primitivas' },
  { id: 'indicadores',  label: 'Indicadores',  group: 'Primitivas' },
  { id: 'premium',      label: 'Premium',      group: 'Efectos & superficies' },
  { id: 'efectos',      label: 'Efectos',      group: 'Efectos & superficies' },
  { id: 'productos',    label: 'Productos KOA', group: 'Dominio KOA' },
  { id: 'animaciones',  label: 'Animaciones',  group: 'Motion & CSS' },
  { id: 'clases',       label: 'Utilidades',   group: 'Motion & CSS' },
]
const GROUP_ORDER = ['Fundamentos', 'Primitivas', 'Efectos & superficies', 'Dominio KOA', 'Motion & CSS']

/* ── Section title ────────────────────────────────────────── */
function SectionTitle({ children, kicker }: { children: React.ReactNode; kicker?: string }) {
  return (
    <div className="mb-7">
      {kicker && (
        <div className="flex items-center gap-2 mb-2">
          <KoaFlor className="w-3.5 h-3.5" color="#0C1E4C" showK={false} />
          <span className="text-[10px] font-bold tracking-[0.18em] uppercase text-mint-text">{kicker}</span>
        </div>
      )}
      <div className="flex items-center gap-4">
        <h2 className="text-[26px] sm:text-[30px] font-black text-[#06005A] tracking-tight whitespace-nowrap leading-none">{children}</h2>
        <div className="flex-1 h-px bg-gradient-to-r from-[#E8ECF2] to-transparent" />
      </div>
    </div>
  )
}

/* ── Preview box ──────────────────────────────────────────── */
function Preview({ label, children, dark = false }: { label?: string; children: React.ReactNode; dark?: boolean }) {
  return (
    <div>
      {label && <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2">{label}</p>}
      <div
        className={`rounded-2xl border px-5 py-5 flex flex-wrap gap-3 items-center ${
          dark ? 'bg-[#06005A] border-[#06005A]' : 'bg-[#F7F7F7] border-[#E8ECF2]'
        }`}
      >
        {children}
      </div>
    </div>
  )
}

/* ── Color swatch ─────────────────────────────────────────── */
function Swatch({ hex, name, sub }: { hex: string; name: string; sub?: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      className="flex flex-col gap-2 cursor-pointer group text-left"
      onClick={() => { copyText(hex); setCopied(true); setTimeout(() => setCopied(false), 1400) }}
    >
      <div className="w-14 h-14 rounded-xl border border-[#E8ECF2] shadow-sm group-hover:scale-105 transition-transform" style={{ background: hex }} />
      <div>
        <p className="text-[11px] font-bold text-[#2A3036] leading-tight">{name}</p>
        <p className="font-figures text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
          {copied ? (
            <>
              <svg className="w-3 h-3 text-[#059669]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              Copiado
            </>
          ) : hex}
        </p>
        {sub && <p className="text-[9px] text-gray-400 mt-0.5">{sub}</p>}
      </div>
    </button>
  )
}

/* ── Type specimen ────────────────────────────────────────── */
function TypeSpec({ size, weight, label, sample, mono = false }: {
  size: string; weight: string; label: string; sample: string; mono?: boolean
}) {
  return (
    <div className="flex items-baseline gap-4 py-3 border-b border-[#F0F2F5] last:border-0">
      <div className="w-36 flex-shrink-0">
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{label}</p>
        <p className="font-figures text-[11px] text-gray-400 mt-0.5">{size} · {weight}</p>
      </div>
      <p
        className={`flex-1 text-[#2A3036] leading-tight ${mono ? 'font-figures' : ''}`}
        style={{ fontSize: size, fontWeight: weight }}
      >
        {sample}
      </p>
    </div>
  )
}

/* ── Anim demo card ───────────────────────────────────────── */
function AnimDemo({ name, desc, cls = '', children }: {
  name: string; desc: string; cls?: string; children?: React.ReactNode
}) {
  const [key, setKey] = useState(0)
  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-4 flex flex-col gap-3">
      <div>
        <p className="text-[12px] font-black text-[#06005A]">.{name}</p>
        <p className="text-[11px] text-gray-400 mt-0.5">{desc}</p>
      </div>
      <div className="flex items-center justify-center min-h-[64px] bg-[#F7F7F7] rounded-xl overflow-hidden">
        <div key={key} className={cls}>
          {children || <div className="w-10 h-10 rounded-xl bg-[#06005A]" />}
        </div>
      </div>
      <button
        onClick={() => setKey(k => k + 1)}
        className="inline-flex items-center justify-center gap-1.5 text-[11px] font-bold text-[#06005A] bg-[#06005A]/[0.06] hover:bg-[#06005A]/[0.1] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
      >
        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
          <path d="M8 5v14l11-7z"/>
        </svg>
        Reproducir
      </button>
    </div>
  )
}

/* ── KOA Icon component ───────────────────────────────────── */
function KoaIcon({ name, size = 20, color = 'currentColor' }: { name: string; size?: number; color?: string }) {
  const icons: Record<string, React.ReactNode> = {
    home: <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />,
    credit: <path strokeLinecap="round" strokeLinejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />,
    cdt: <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />,
    profile: <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />,
    security: <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />,
    contact: <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />,
    education: <path strokeLinecap="round" strokeLinejoin="round" d="M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />,
    coin: <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />,
    calendar: <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />,
    rate: <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />,
    trend: <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />,
    amount: <path strokeLinecap="round" strokeLinejoin="round" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2z" />,
    returns: <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />,
    check: <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />,
    plus: <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />,
    arrow: <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />,
    edit: <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />,
    download: <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />,
    eye: <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />,
    shield: <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />,
    clock: <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />,
    xmark: <>
      <path strokeLinecap="round" strokeLinejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </>,
    notify: <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />,
    settings: <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z" />,

    /* ── Fintech / financiero / comercial ── */
    wallet: <path strokeLinecap="round" strokeLinejoin="round" d="M21 12V7H5a2 2 0 010-4h14v4M3 5v14a2 2 0 002 2h16v-5M18 12a2 2 0 000 4h4v-4h-4z" />,
    bank: <path strokeLinecap="round" strokeLinejoin="round" d="M3 21h18M4 10h16M5 21V10m4 11V10m6 11V10m4 11V10M12 3L4 7v3h16V7l-8-4z" />,
    piggy: <path strokeLinecap="round" strokeLinejoin="round" d="M19 8.5c1.2.6 2 1.9 2 3.3 0 1.3-.7 2.5-1.8 3.2l.3 2.5h-2l-.3-1.5H9.8L9.5 19.5h-2l.3-2.6C6 15.6 5 13.9 5 12c0-3 2.7-5.5 6-5.5.9 0 1.7.2 2.5.5L17 5v3zM8 6.5V5M16 11h.01" />,
    transfer: <path strokeLinecap="round" strokeLinejoin="round" d="M4 8h13m0 0l-4-4m4 4l-4 4M20 16H7m0 0l4-4m-4 4l4 4" />,
    send: <path strokeLinecap="round" strokeLinejoin="round" d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />,
    receive: <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v13m0 0l5-5m-5 5l-5-5M5 21h14" />,
    percent: <path strokeLinecap="round" strokeLinejoin="round" d="M19 5L5 19M8.5 7.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm10 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />,
    target: <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18zm0-4a5 5 0 100-10 5 5 0 000 10zm0-4a1 1 0 100-2 1 1 0 000 2z" />,
    growth: <path strokeLinecap="round" strokeLinejoin="round" d="M3 17l6-6 4 4 8-8m0 0h-5m5 0v5" />,
    chartBar: <path strokeLinecap="round" strokeLinejoin="round" d="M4 20V10m5 10V4m5 16v-7m5 7V8M3 20h18" />,
    invoice: <path strokeLinecap="round" strokeLinejoin="round" d="M8 3H6a2 2 0 00-2 2v14l3-2 2 2 2-2 2 2 2-2 3 2V5a2 2 0 00-2-2h-2M9 8h6M9 12h6M9 16h4" />,
    lock: <path strokeLinecap="round" strokeLinejoin="round" d="M7 11V8a5 5 0 0110 0v3M6 11h12a1 1 0 011 1v7a1 1 0 01-1 1H6a1 1 0 01-1-1v-7a1 1 0 011-1zm6 4v2" />,
    key: <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a4 4 0 11-3.9 5H8v3H5v3H2v-3l6.1-6.1A4 4 0 0115 7zm1.5 1.5h.01" />,
    handshake: <path strokeLinecap="round" strokeLinejoin="round" d="M8 11l2.5 2.5a1.5 1.5 0 002.1 0L18 8l3 3M3 9l4-4 4 4-2.5 2.5M14 6l3-1 4 4M3 9l3 3m9 0l2 2m-4-4l2 2" />,
    qr: <path strokeLinecap="round" strokeLinejoin="round" d="M4 4h6v6H4V4zm0 10h6v6H4v-6zm10-10h6v6h-6V4zm0 10h2v2h-2v-2zm4 0h2v2h-2v-2zm-4 4h2v2h-2v-2zm4 0h2v2h-2v-2z" />,
    calculator: <path strokeLinecap="round" strokeLinejoin="round" d="M7 3h10a2 2 0 012 2v14a2 2 0 01-2 2H7a2 2 0 01-2-2V5a2 2 0 012-2zm1 4h8v3H8V7zm0 6h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01" />,
    signature: <path strokeLinecap="round" strokeLinejoin="round" d="M3 17c2 0 2-4 4-4s2 4 4 4 2-6 4-6 2 3 4 3M3 21h18" />,
    star: <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 18.8 6.2 21.9l1.1-6.5L2.6 9.8l6.5-.9L12 3z" />,
    refresh: <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v6h6M20 20v-6h-6M20 9A8 8 0 006 6L4 8m0 8a8 8 0 0014 3l2-2" />,
    document: <path strokeLinecap="round" strokeLinejoin="round" d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8l-5-5zm0 0v5h5M9 13h6M9 17h6" />,
    store: <path strokeLinecap="round" strokeLinejoin="round" d="M4 9l1-5h14l1 5M4 9h16M4 9v11a1 1 0 001 1h14a1 1 0 001-1V9M9 21v-6h6v6M4 9a2 2 0 004 0 2 2 0 004 0 2 2 0 004 0 2 2 0 004 0" />,
  }
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
      {icons[name]}
    </svg>
  )
}

/* ── Animated icon specimen ───────────────────────────────── */
function AnimIcon({ name, anim, label }: { name: string; anim: string; label: string }) {
  return (
    <div className="icon-anim group flex-col items-center gap-2 bg-white rounded-2xl border border-[#E8ECF2] p-4 cursor-pointer hover:border-[#00DB8E]/40 transition-colors" style={{ display: 'flex' }}>
      <div className="w-11 h-11 rounded-xl bg-[#F0F2F5] group-hover:bg-[#EFFFF7] transition-colors flex items-center justify-center">
        <span className={anim}><KoaIcon name={name} size={22} color="#06005A" /></span>
      </div>
      <p className="text-[10px] font-semibold text-[#6B7280] text-center">{label}</p>
    </div>
  )
}

/* ── Demo: organic bloom modal ────────────────────────────── */
function PremiumModalDemo() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <Button variant="mint" size="sm" onClick={() => setOpen(true)}>Ver modal orgánico</Button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        bloom
        icon={<KoaFlor color="#00DB8E" kColor="#0C1E4C" className="w-14 h-14 animate-orbit" style={{ ['--r' as string]: '0px', ['--dur' as string]: '18s' }} />}
        title="¡Tu CDT está activo!"
        description="Recibirás tus rendimientos al vencimiento. Puedes seguirlo desde tu portal en cualquier momento."
        footer={<Button variant="primary" size="sm" onClick={() => setOpen(false)}>Entendido</Button>}
      >
        <div className="rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/25 p-4 text-center">
          <p className="text-[11px] font-bold uppercase tracking-wide text-[#6B7280]">Monto invertido</p>
          <p className="font-figures text-[26px] font-bold text-ink animate-number-pop">$10.000.000</p>
        </div>
      </Modal>
    </>
  )
}

/* ── Icon specimen tile ───────────────────────────────────── */
function IconTile({ name, label }: { name: string; label: string }) {
  return (
    <div className="flex flex-col items-center gap-3 bg-white rounded-2xl border border-[#E8ECF2] p-4">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-[#F0F2F5] flex items-center justify-center">
          <KoaIcon name={name} size={18} color="#2A3036" />
        </div>
        <div className="w-9 h-9 rounded-xl bg-[#06005A] flex items-center justify-center">
          <KoaIcon name={name} size={18} color="#FFFFFF" />
        </div>
        <div className="w-9 h-9 rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/25 flex items-center justify-center">
          <KoaIcon name={name} size={18} color="#00B874" />
        </div>
      </div>
      <p className="text-[10px] font-bold text-gray-400 text-center">{label}</p>
      <code className="text-[9px] font-bold text-[#06005A] bg-[#06005A]/[0.06] px-1.5 py-0.5 rounded">{name}</code>
    </div>
  )
}

/* ── Main ─────────────────────────────────────────────────── */
export default function Componentes() {
  const [active, setActive] = useState('arquitectura')
  const navRef = useRef<HTMLDivElement>(null)
  const [otpDigits, setOtpDigits] = useState(['2','4','8','7','3','1'])
  const [toggleA, setToggleA] = useState(true)
  const [toggleB, setToggleB] = useState(false)
  const otpRefs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => { entries.forEach(e => { if (e.isIntersecting) setActive(e.target.id) }) },
      { rootMargin: '-30% 0px -60% 0px', threshold: 0 }
    )
    SECTIONS.forEach(s => { const el = document.getElementById(s.id); if (el) observer.observe(el) })
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const pill = navRef.current?.querySelector(`[data-id="${active}"]`) as HTMLElement
    pill?.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' })
  }, [active])

  const activeGroup = SECTIONS.find(s => s.id === active)?.group

  return (
    <div className="max-w-5xl mx-auto">

      {/* ── Immersive organic hero ───────────────────────── */}
      <div className="relative overflow-hidden rounded-[32px] mb-6 -mx-1" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}>
        {/* organic mint blooms */}
        <div className="absolute -top-28 -right-16 w-96 h-96 rounded-full bg-[#00DB8E]/[0.12] blur-2xl animate-float" style={{ ['--fy' as string]: '-24px', ['--dur' as string]: '9s' }} />
        <div className="absolute -bottom-24 -left-10 w-72 h-72 rounded-full bg-[#00DB8E]/[0.08] blur-2xl animate-float" style={{ ['--fy' as string]: '18px', ['--dur' as string]: '11s', ['--delay' as string]: '1s' }} />
        {/* half-bloom zone anchored to the corner */}
        <KoaFlor half color="#00DB8E" className="absolute bottom-0 left-8 w-40 h-20 opacity-[0.18]" showK={false} />
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '26px 26px' }} />
        {/* rotating flor mark */}
        <KoaFlor className="absolute -right-4 top-1/2 -translate-y-1/2 w-72 h-72 opacity-[0.07] animate-orbit" color="#FFFFFF" style={{ ['--r' as string]: '0px', ['--dur' as string]: '40s' }} />

        <div className="relative z-10 px-8 sm:px-12 py-12 sm:py-16 max-w-2xl">
          <div className="flex items-center gap-3 mb-6">
            <KoaLogo kind="logotipo" tone="white" height={30} />
            <span className="w-px h-6 bg-white/20" />
            <span className="text-[11px] font-bold tracking-[0.14em] uppercase text-white/70">Design System · v2.0</span>
          </div>
          <h1 className="text-[40px] sm:text-[52px] font-black text-white leading-[0.98] tracking-tight">
            El sistema que hace<br /><span className="text-[#00DB8E]">florecer</span> el Portal KOA.
          </h1>
          <p className="mt-5 text-[15px] text-white/70 leading-relaxed max-w-xl">
            Una base viva de dos capas: <span className="text-white font-semibold">primitivas neutras</span> reutilizables
            y una <span className="text-white font-semibold">capa de dominio KOA</span> encima. Tokens, movimiento y
            accesibilidad — con la calidez de <span className="font-figures text-[#00DB8E]">koa.co</span>.
          </p>
          <div className="mt-7 flex flex-wrap gap-6">
            {[['15', 'componentes'], ['2', 'capas'], ['AA', 'accesibilidad'], ['0', 'hex sueltos*']].map(([n, l]) => (
              <div key={l}>
                <p className="font-figures text-[28px] font-bold text-white leading-none">{n}</p>
                <p className="text-[11px] text-white/50 mt-1">{l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Sticky grouped nav ───────────────────────────── */}
      <div className="sticky top-0 z-20 bg-white/85 backdrop-blur-md -mx-4 px-4 sm:-mx-6 sm:px-6 py-3 border-b border-[#F0F2F5] mb-10">
        <div className="flex items-center gap-2 mb-2">
          <KoaFlor className="w-3.5 h-3.5" color="#0C1E4C" showK={false} />
          <span className="text-[10px] font-bold tracking-[0.16em] uppercase text-[#06005A]">{activeGroup}</span>
        </div>
        <div ref={navRef} className="flex gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {GROUP_ORDER.map((group, gi) => (
            <div key={group} className="flex items-center gap-1 flex-shrink-0">
              {gi > 0 && <span className="mx-1.5 w-px h-4 bg-[#E8ECF2]" />}
              {SECTIONS.filter(s => s.group === group).map(s => (
                <button
                  key={s.id}
                  data-id={s.id}
                  onClick={() => { document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); setActive(s.id) }}
                  className={`flex-shrink-0 text-[11px] font-bold px-3 py-1.5 rounded-full transition-all cursor-pointer ${
                    active === s.id ? 'bg-[#06005A] text-white shadow-sm' : 'text-gray-400 hover:text-[#06005A] hover:bg-[#EFFFF7]'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-24">

        {/* ═══════════════════════════════════════════════════ */}
        {/* 0. ARQUITECTURA ──────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="arquitectura">
          <SectionTitle kicker="Cómo está construido">Arquitectura del sistema</SectionTitle>

          <div className="grid md:grid-cols-2 gap-4 mb-6">
            {/* Primitive layer */}
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <Badge tone="mint" dot>Capa 1</Badge>
                <h3 className="text-[15px] font-black text-[#2A3036]">Primitivas neutras</h3>
              </div>
              <p className="text-[13px] text-[#6B7280] leading-relaxed">
                Componentes agnósticos de dominio que consumen <span className="font-figures text-[#005E3C]">tokens</span>,
                no hex. Reutilizables en cualquier producto. Aquí vive la accesibilidad
                (foco, <code className="text-[12px]">aria</code>, focus-trap, movimiento reducido).
              </p>
              <pre className="mt-3 text-[11px] bg-[#F0F2F5] rounded-xl px-3 py-2.5 overflow-x-auto font-figures text-[#2A3036]">import {'{ Button, Card, Field }'} from '@/components/ui'</pre>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button size="sm">Button</Button>
                <Badge tone="brand">Badge</Badge>
                <Badge tone="info">Field</Badge>
                <Badge tone="neutral">Modal · Toast · Switch</Badge>
              </div>
            </Card>

            {/* Domain layer */}
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <Badge tone="brand" dot>Capa 2</Badge>
                <h3 className="text-[15px] font-black text-[#2A3036]">Dominio KOA</h3>
              </div>
              <p className="text-[13px] text-[#6B7280] leading-relaxed">
                Componentes que conocen el negocio (mora, libranza, CDT, marcas SFC/Fogafín)
                <span className="font-semibold text-[#2A3036]"> construidos encima</span> de las primitivas:
                codifican el significado y toman la apariencia de la Capa 1.
              </p>
              <pre className="mt-3 text-[11px] bg-[#F0F2F5] rounded-xl px-3 py-2.5 overflow-x-auto font-figures text-[#2A3036]">import {'{ CreditStatusPill }'} from '@/components/koa'</pre>
              <div className="mt-4 flex flex-wrap gap-2 items-center">
                <CreditStatusPill status="al-dia" />
                <CreditStatusPill status="en-mora" />
                <CreditStatusPill status="pendiente" />
              </div>
            </Card>
          </div>

          <ArchDemo />
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* LOGOTIPO ─────────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="logotipo">
          <SectionTitle kicker="Fundamentos">Logotipo y marca</SectionTitle>

          {/* Hero of the mark itself */}
          <div className="relative overflow-hidden rounded-3xl mb-4" style={{ background: '#0C1E4C' }}>
            <KoaFlor half color="#00DB8E" showK={false} className="absolute -bottom-2 right-8 w-56 h-28 opacity-[0.15]" />
            <div className="relative z-10 flex flex-col sm:flex-row items-center gap-8 px-8 py-10">
              <KoaLogo kind="isotipo" tone="white" height={96} />
              <div>
                <KoaLogo kind="logotipo" tone="white" height={40} />
                <p className="mt-3 text-[13px] text-white/60 max-w-sm leading-relaxed">
                  La flor KOA nace de pétalos que orbitan una <span className="text-white font-semibold">K</span> central —
                  crecimiento, calidez y movimiento. Es la firma del sistema.
                </p>
              </div>
            </div>
          </div>

          {/* Isotipo variants */}
          <div className="grid sm:grid-cols-2 gap-4 mb-4">
            <Card className="p-6">
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Isotipo · flor + K</p>
              <div className="grid grid-cols-3 gap-3">
                {([['color', 'Mint'], ['blue', 'Navy'], ['black', 'Negro']] as const).map(([tone, label]) => (
                  <div key={tone} className="flex flex-col items-center gap-2">
                    <div className={`w-full rounded-2xl flex items-center justify-center py-5 ${tone === 'blue' ? 'bg-[#F0F2F5]' : 'bg-[#F7F7F7]'} border border-[#E8ECF2]`}>
                      <KoaLogo kind="isotipo" tone={tone} height={44} />
                    </div>
                    <span className="text-[11px] text-gray-500">{label}</span>
                  </div>
                ))}
                <div className="flex flex-col items-center gap-2">
                  <div className="w-full rounded-2xl flex items-center justify-center py-5 bg-[#0C1E4C]">
                    <KoaLogo kind="isotipo" tone="white" height={44} />
                  </div>
                  <span className="text-[11px] text-gray-500">Blanco</span>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Logotipo · palabra + flor</p>
              <div className="space-y-3">
                <div className="rounded-2xl flex items-center justify-center py-6 bg-[#F7F7F7] border border-[#E8ECF2]">
                  <KoaLogo kind="logotipo" tone="color" height={40} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-2xl flex items-center justify-center py-4 bg-[#F7F7F7] border border-[#E8ECF2]">
                    <KoaLogo kind="logotipo" tone="black" height={30} />
                  </div>
                  <div className="rounded-2xl flex items-center justify-center py-4 bg-[#0C1E4C]">
                    <KoaLogo kind="logotipo" tone="white" height={30} />
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Flor as a motif — petals only + half zone */}
          <Card variant="flat" className="p-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">
              La flor como motivo — <code className="text-[11px] font-figures">{'<KoaFlor/>'}</code>
            </p>
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="rounded-2xl bg-[#EFFFF7] border border-[#00DB8E]/20 p-5 flex flex-col items-center gap-3">
                <KoaFlor color="#00DB8E" kColor="#0C1E4C" className="w-16 h-16" />
                <div className="text-center">
                  <p className="text-[12px] font-bold text-[#005E3C]">Isotipo completo</p>
                  <code className="text-[10px] text-gray-400 font-figures">showK</code>
                </div>
              </div>
              <div className="rounded-2xl bg-[#F7F7F7] border border-[#E8ECF2] p-5 flex flex-col items-center gap-3">
                <KoaFlor color="#00DB8E" showK={false} className="w-16 h-16" />
                <div className="text-center">
                  <p className="text-[12px] font-bold text-[#2A3036]">Solo pétalos</p>
                  <code className="text-[10px] text-gray-400 font-figures">showK={'{false}'}</code>
                </div>
              </div>
              <div className="relative rounded-2xl bg-[#0C1E4C] overflow-hidden p-5 flex flex-col items-center justify-end gap-3 min-h-[132px]">
                <KoaFlor half color="#00DB8E" showK={false} className="absolute -bottom-1 inset-x-0 mx-auto w-40 h-20 opacity-40" />
                <div className="relative text-center">
                  <p className="text-[12px] font-bold text-white">Media flor · zona</p>
                  <code className="text-[10px] text-white/50 font-figures">half</code>
                </div>
              </div>
            </div>
          </Card>

          {/* Usage rules */}
          <div className="grid sm:grid-cols-2 gap-4 mt-4">
            <Card className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-mint-bg">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#005E3C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </span>
                <p className="text-[13px] font-bold text-[#2A3036]">Sí</p>
              </div>
              <ul className="space-y-1.5 text-[12px] text-[#6B7280]">
                <li>Mantener aire de respeto alrededor de la flor.</li>
                <li>Usar mint sobre fondos claros, blanco sobre navy.</li>
                <li>La media flor solo como textura decorativa de fondo.</li>
              </ul>
            </Card>
            <Card className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-error/12">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#F70C5B" strokeWidth="3" strokeLinecap="round"/></svg>
                </span>
                <p className="text-[13px] font-bold text-[#2A3036]">No</p>
              </div>
              <ul className="space-y-1.5 text-[12px] text-[#6B7280]">
                <li>No deformar, rotar ni recolorear los pétalos arbitrariamente.</li>
                <li>No poner el isotipo mint sobre fondos de bajo contraste.</li>
                <li>No recrear la flor con formas propias — usar <code className="text-[11px] font-figures">KoaFlor</code>.</li>
              </ul>
            </Card>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* ISOTIPO EN MOVIMIENTO — la flor es hoja, jugamos */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="isotipo-motion">
          <SectionTitle kicker="Fundamentos · Motion de marca">Isotipo en movimiento</SectionTitle>
          <p className="text-[14px] text-[#6B7280] max-w-2xl -mt-2 mb-6">
            Los pétalos son hojas: florecen, se mecen y respiran. Cada modo se activa con la prop
            <code className="text-[11px] mx-1 bg-[#06005A]/[0.07] text-[#06005A] px-1.5 py-0.5 rounded font-bold">animate</code>
            de <code className="text-[11px] font-figures">KoaFlor</code>, con stagger por pétalo y respeto a <code className="text-[11px]">prefers-reduced-motion</code>.
          </p>

          {/* Motto ribbon */}
          <div className="brand-gradient aurora rounded-[20px] overflow-hidden relative mb-6">
            <div className="relative py-8 px-6 flex items-center gap-5">
              <KoaFlor animate="breathe" color="#00DB8E" kColor="#FFFFFF" className="w-16 h-16 shrink-0" />
              <div>
                <p className="text-[11px] font-bold tracking-[0.18em] uppercase text-[#00DB8E]">KOA</p>
                <p className="text-[28px] sm:text-[34px] font-black text-white leading-tight">Tu plata, <span className="text-[#00DB8E] [text-shadow:0_1px_16px_rgba(0,219,144,0.45)]">tú mandas</span></p>
              </div>
            </div>
            <div className="relative border-t border-white/10 py-2.5 overflow-hidden">
              <div className="marquee-track text-white/70 text-[12px] font-light tracking-wide">
                {Array.from({ length: 2 }).map((_, r) => (
                  <span key={r} className="inline-flex items-center">
                    {['CDT desde $100.000', 'Libranza por nómina', 'Vigilado SFC', 'Rendimientos diarios', 'Sin letra pequeña', 'Tu plata, tú mandas'].map((t, i) => (
                      <span key={i} className="inline-flex items-center">
                        <KoaFlor color="#00DB8E" showK={false} className="w-3 h-3 mx-3 inline-block" />
                        {t}
                      </span>
                    ))}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Motion modes */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {([
              { m: 'bloom', label: 'bloom', desc: 'Entrada · escala desde el centro' },
              { m: 'sway', label: 'sway', desc: 'Hojas al viento' },
              { m: 'twinkle', label: 'twinkle', desc: 'Destello en onda' },
              { m: 'breathe', label: 'breathe', desc: 'Respiración suave' },
              { m: 'spin', label: 'spin', desc: 'Giro · K estable' },
            ] as const).map(({ m, label, desc }) => (
              <div key={m} className="card-flat p-5 flex flex-col items-center text-center gap-3">
                <div className="w-20 h-20 flex items-center justify-center">
                  <KoaFlor animate={m} color="#00DB8E" kColor="#0C1E4C" className="w-16 h-16" />
                </div>
                <div>
                  <p className="text-[13px] font-bold text-ink">animate="{label}"</p>
                  <p className="text-[11px] text-[#6B7280] mt-0.5">{desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Applied — isotipo as loader, empty bloom, hero watermark */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <Card className="p-6 flex flex-col items-center justify-center gap-3 text-center">
              <KoaFlor animate="spin" color="#00DB8E" showK={false} className="w-14 h-14" />
              <p className="text-[12px] font-semibold text-[#6B7280]">Loader de marca</p>
            </Card>
            <Card variant="bloom" className="p-6 flex flex-col items-center justify-center gap-3 text-center">
              <KoaFlor animate="bloom" color="#00DB8E" kColor="#0C1E4C" className="w-14 h-14" />
              <p className="text-[12px] font-semibold text-mint-text">Estado de éxito · florece</p>
            </Card>
            <Card variant="navy" className="p-6 relative overflow-hidden flex flex-col items-center justify-center gap-3 text-center">
              <KoaFlor half animate="sway" color="#00DB8E" showK={false} className="absolute -bottom-2 inset-x-0 mx-auto w-40 h-20 opacity-40" />
              <KoaFlor animate="breathe" color="#FFFFFF" showK={false} className="w-14 h-14 relative" />
              <p className="text-[12px] font-semibold text-white/80 relative">Watermark en hero navy</p>
            </Card>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 1. IDENTIDAD ─────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="identidad">
          <SectionTitle kicker="Fundamentos">Identidad de marca</SectionTitle>

          <div className="relative overflow-hidden rounded-3xl mb-8" style={{ background: '#06005A' }}>
            <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-[#00DB8E]/[0.06] pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-56 h-56 rounded-full bg-white/[0.02] pointer-events-none" />
            <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
            <div className="relative z-10 px-8 py-10 flex flex-col sm:flex-row items-start sm:items-center gap-8">
              <div className="flex-1">
                <p className="text-[10px] font-black tracking-[0.28em] uppercase text-white/40 mb-3">Portal KOA · Compañía de Financiamiento</p>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#00DB8E]/20 border border-[#00DB8E]/25 flex items-center justify-center">
                    <KoaIcon name="coin" size={24} color="#00DB8E" />
                  </div>
                  <div>
                    <p className="text-white font-black text-[32px] leading-none tracking-tight">KOA</p>
                    <p className="text-[#00DB8E] text-[11px] font-bold tracking-[0.14em] uppercase mt-0.5">Compañía de Financiamiento</p>
                  </div>
                </div>
                <p className="text-white/55 text-[13px] leading-relaxed max-w-sm">
                  Finanzas digitales con propósito. Crédito libranza y CDT para empleados y pensionados de Colombia.
                </p>
              </div>
              <div className="flex flex-col gap-3">
                {[
                  { label: 'Vigilado SFC', icon: 'security' },
                  { label: 'Respaldado Fogafin', icon: 'shield' },
                  { label: '100% Digital', icon: 'trend' },
                ].map(b => (
                  <div key={b.label} className="flex items-center gap-2.5 bg-white/[0.07] rounded-xl px-4 py-2.5">
                    <KoaIcon name={b.icon} size={16} color="#00DB8E" />
                    <span className="text-white/80 text-[12px] font-semibold">{b.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Primaria', value: '#06005A', desc: 'Navy · Identidad' },
              { label: 'Acento', value: '#00DB8E', desc: 'Mint · Acción' },
              { label: 'Tipografía', value: 'Montserrat', desc: 'Sans · UI' },
              { label: 'Figuras', value: 'Space Grotesk', desc: 'Sans · Datos' },
            ].map(v => (
              <div key={v.label} className="bg-white rounded-2xl border border-[#E8ECF2] px-4 py-4">
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">{v.label}</p>
                <p className="font-black text-[#2A3036] text-[15px] mt-1 leading-tight">{v.value}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{v.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 2. MARCAS LEGALES ────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="marcas">
          <SectionTitle kicker="Fundamentos">Marcas legales</SectionTitle>

          <div className="space-y-10">

            {/* FOGAFIN */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Fogafín</p>
                <span className="text-[10px] bg-[#EBF5FF] text-[#0068B3] px-2 py-0.5 rounded-full font-bold border border-[#0098FF]/20">Fondo de Garantías</span>
                <span className="text-[10px] text-gray-400">3 variantes</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Blue (institutional) */}
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] font-bold text-gray-400">Institucional · Azul</p>
                  <div className="rounded-2xl overflow-hidden border border-[#E8ECF2]">
                    <img src={fogafinBlue} alt="Fogafin institucional azul" className="w-full object-contain" />
                  </div>
                  <p className="text-[10px] text-gray-400">Fondo: <span className="font-figures font-bold text-[#2A3036]">#00639B</span> · Uso: fondos institucionales</p>
                </div>
                {/* Black (on white) */}
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] font-bold text-gray-400">Negro · Sobre blanco</p>
                  <div className="rounded-2xl overflow-hidden border border-[#E8ECF2] bg-white p-2">
                    <img src={fogafinBlack} alt="Fogafin negro" className="w-full object-contain" />
                  </div>
                  <p className="text-[10px] text-gray-400">Fondo: <span className="font-figures font-bold text-[#2A3036]">#FFFFFF</span> · Uso: documentos, impresión</p>
                </div>
                {/* White (on dark) */}
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] font-bold text-gray-400">Blanco · Sobre oscuro</p>
                  <div className="rounded-2xl overflow-hidden border border-[#E8ECF2] bg-[#06005A] p-2">
                    <img src={fogafinWhite} alt="Fogafin blanco" className="w-full object-contain" />
                  </div>
                  <p className="text-[10px] text-gray-400">Fondo: <span className="font-figures font-bold text-[#2A3036]">#06005A</span> · Uso: fondos navy / oscuros</p>
                </div>
              </div>

              {/* Usage note */}
              <div className="mt-3 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-4 py-3 flex items-start gap-3">
                <div className="w-5 h-5 rounded-lg bg-[#00DB8E] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <KoaIcon name="shield" size={12} color="#06005A" />
                </div>
                <div>
                  <p className="text-[12px] font-bold text-[#005E3C]">Obligatorio en portal y comunicaciones de productos CDT</p>
                  <p className="text-[11px] text-[#005E3C]/70 mt-0.5">El logo de Fogafín debe acompañar siempre cualquier comunicación relacionada con CDT. Respetar el área de protección mínima y no alterar proporciones.</p>
                </div>
              </div>
            </div>

            {/* SFC */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Superfinanciera</p>
                <span className="text-[10px] bg-[#F0F2F5] text-[#2A3036] px-2 py-0.5 rounded-full font-bold">SFC · Vigilado</span>
                <span className="text-[10px] text-gray-400">2 variantes</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Black */}
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] font-bold text-gray-400">Negro · Sobre blanco</p>
                  <div className="rounded-2xl overflow-hidden border border-[#E8ECF2] bg-white px-4 py-6">
                    <img src={sfcBlack} alt="Superintendencia Financiera de Colombia - negro" className="w-full object-contain h-9" />
                  </div>
                  <p className="text-[10px] text-gray-400">Fondo: <span className="font-figures font-bold text-[#2A3036]">#FFFFFF</span> · Uso: documentos, comunicaciones</p>
                </div>
                {/* White */}
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] font-bold text-gray-400">Blanco · Sobre oscuro</p>
                  <div className="rounded-2xl overflow-hidden border border-[#E8ECF2] bg-[#06005A] px-4 py-6">
                    <img src={sfcWhite} alt="Superintendencia Financiera de Colombia - blanco" className="w-full object-contain h-9" />
                  </div>
                  <p className="text-[10px] text-gray-400">Fondo: <span className="font-figures font-bold text-[#2A3036]">#06005A</span> · Uso: pie portal, fondos navy</p>
                </div>
              </div>

              {/* Usage note */}
              <div className="mt-3 bg-[#EBF5FF] border border-[#0098FF]/20 rounded-xl px-4 py-3 flex items-start gap-3">
                <div className="w-5 h-5 rounded-lg bg-[#0098FF] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <KoaIcon name="security" size={12} color="white" />
                </div>
                <div>
                  <p className="text-[12px] font-bold text-[#0068B3]">Vigilado Superintendencia Financiera de Colombia</p>
                  <p className="text-[11px] text-[#0068B3]/70 mt-0.5">Debe aparecer en el pie de página del portal y en comunicaciones oficiales. La versión blanca se usa sobre el fondo navy del portal.</p>
                </div>
              </div>
            </div>

            {/* In-context preview */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Uso en contexto · Footer del portal</p>
              <div className="rounded-2xl border border-[#E8ECF2] overflow-hidden">
                <div className="bg-white px-6 py-5 flex items-center gap-8 flex-wrap">
                  <img src={sfcBlack} alt="SFC" className="h-6 w-auto object-contain" />
                  <div className="w-px h-10 bg-[#E8ECF2]" />
                  <img src={fogafinBlack} alt="Fogafin" className="h-10 w-auto object-contain" />
                  <div className="ml-auto text-right">
                    <p className="text-[11px] font-bold text-[#2A3036]">KOA C.F.</p>
                    <p className="text-[10px] text-gray-400">Compañía de Financiamiento</p>
                  </div>
                </div>
                <div className="bg-[#06005A] px-6 py-5 flex items-center gap-8 flex-wrap">
                  <img src={sfcWhite} alt="SFC" className="h-6 w-auto object-contain" />
                  <div className="w-px h-10 bg-white/20" />
                  <img src={fogafinWhite} alt="Fogafin" className="h-10 w-auto object-contain" />
                  <div className="ml-auto text-right">
                    <p className="text-[11px] font-bold text-white">KOA C.F.</p>
                    <p className="text-[10px] text-white/50">Compañía de Financiamiento</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 3. COLORES ───────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="colores">
          <SectionTitle kicker="Fundamentos">Paleta de color</SectionTitle>
          <div className="space-y-8">
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Marca</p>
              <div className="flex flex-wrap gap-5">
                <Swatch hex="#06005A" name="Navy" sub="Principal · Identidad" />
                <Swatch hex="#08007A" name="Navy Hover" sub="Estado activo" />
                <Swatch hex="#0C1E4C" name="Navy Marca" sub="Fondo hero · logotipo" />
                <Swatch hex="#00DB8E" name="Mint 500" sub="Acento · Acción" />
                <Swatch hex="#00B874" name="Mint 400" sub="Hover / variante" />
                <Swatch hex="#00EFA0" name="Mint 600" sub="Highlight" />
                <Swatch hex="#005E3C" name="Mint Deep" sub="Texto sobre mint" />
                <Swatch hex="#EFFFF7" name="Mint Surface" sub="Fondos mint" />
              </div>
            </div>
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Semánticos</p>
              <div className="flex flex-wrap gap-5">
                <Swatch hex="#10B981" name="Success" sub="Confirmación" />
                <Swatch hex="#059669" name="Success Dark" sub="Texto / borde" />
                <Swatch hex="#ECFDF5" name="Success Bg" sub="Fondo éxito" />
                <Swatch hex="#FA467F" name="Error" sub="Error / mora" />
                <Swatch hex="#F70C5B" name="Error Dark" sub="Texto error" />
                <Swatch hex="#FFF0F5" name="Error Bg" sub="Fondo error" />
                <Swatch hex="#FFD400" name="Warning" sub="Pendiente" />
                <Swatch hex="#8A6D00" name="Warning Dark" sub="Texto sobre tinte" />
                <Swatch hex="#FFFBEB" name="Warning Bg" sub="Fondo warning" />
                <Swatch hex="#0098FF" name="Info" sub="CDT · Informativo" />
                <Swatch hex="#0068B3" name="Info Dark" sub="Texto info" />
                <Swatch hex="#EBF5FF" name="Info Bg" sub="Fondo info" />
              </div>
            </div>
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Neutros y superficies</p>
              <div className="flex flex-wrap gap-5">
                <Swatch hex="#2A3036" name="Text Primary" sub="Cuerpo de texto" />
                <Swatch hex="#6B7280" name="Text Secondary" sub="Subtítulos" />
                <Swatch hex="#9CA3AF" name="Text Muted" sub="Labels" />
                <Swatch hex="#E8ECF2" name="Border" sub="Separadores" />
                <Swatch hex="#F0F2F5" name="Surface 100" sub="Fondos suaves" />
                <Swatch hex="#F7F7F7" name="Surface 50" sub="Fondo app" />
                <Swatch hex="#FFFFFF" name="White" sub="Tarjetas / fondo" />
              </div>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 4. TIPOGRAFÍA ────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="tipografia">
          <SectionTitle kicker="Fundamentos">Tipografía</SectionTitle>
          <div className="space-y-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Montserrat</p>
                <span className="text-[10px] bg-[#06005A]/[0.07] text-[#06005A] px-2 py-0.5 rounded-full font-bold">UI · Principal</span>
              </div>
              <div className="bg-white rounded-2xl border border-[#E8ECF2] px-6 py-2 divide-y divide-[#F0F2F5]">
                <TypeSpec size="44px" weight="900" label="Display Black" sample="$120.500.000" />
                <TypeSpec size="32px" weight="900" label="Headline Black" sample="Portal KOA" />
                <TypeSpec size="22px" weight="900" label="Title Black" sample="Seguridad" />
                <TypeSpec size="18px" weight="800" label="Subtitle ExtraBold" sample="Clave de acceso" />
                <TypeSpec size="15px" weight="700" label="Body Bold" sample="Crédito activo · Al día" />
                <TypeSpec size="13px" weight="600" label="Body SemiBold" sample="Se enviará un código de verificación a tu correo registrado." />
                <TypeSpec size="12px" weight="500" label="Caption Medium" sample="Tasas efectivas anuales · Sujetas a cambio" />
                <TypeSpec size="10px" weight="700" label="Label Bold" sample="TASAS CDT · VIGENTE 2026" />
                <TypeSpec size="9px" weight="700" label="Micro Bold" sample="LIBRANZA · MÁS CAPITAL" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-3 mb-4">
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Space Grotesk</p>
                <span className="text-[10px] bg-[#EFFFF7] text-[#005E3C] px-2 py-0.5 rounded-full font-bold border border-[#00DB8E]/25">.font-figures · Datos</span>
              </div>
              <div className="bg-white rounded-2xl border border-[#E8ECF2] px-6 py-2 divide-y divide-[#F0F2F5]">
                <TypeSpec size="44px" weight="700" label="KPI Hero" sample="12,20%" mono />
                <TypeSpec size="32px" weight="700" label="Metric Large" sample="$45.200.000" mono />
                <TypeSpec size="22px" weight="700" label="Metric Mid" sample="248.731" mono />
                <TypeSpec size="16px" weight="700" label="Value Bold" sample="+$1.450.000 rendimientos" mono />
                <TypeSpec size="13px" weight="600" label="Value SemiBold" sample="10,50% E.A." mono />
                <TypeSpec size="11px" weight="400" label="Label Regular" sample="Cuota 3 de 48 · 6% pagado" mono />
              </div>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 5. ICONOGRAFÍA ───────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="iconografia">
          <SectionTitle kicker="Fundamentos">Iconografía KOA</SectionTitle>

          <p className="text-[12px] text-gray-400 mb-6 leading-relaxed">
            Iconos SVG de trazo (stroke), strokeWidth 1.8, estilo outlined. Tres fondos estandarizados: neutro claro, navy y mint surface. Todas las instancias de icono en el portal usan el componente <code className="text-[11px] bg-[#06005A]/[0.07] text-[#06005A] px-1.5 py-0.5 rounded font-bold">KoaIcon</code>.
          </p>

          {/* Sizes */}
          <div className="mb-8">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-4">Tamaños del sistema</p>
            <div className="bg-white rounded-2xl border border-[#E8ECF2] px-6 py-5 flex items-end gap-8 flex-wrap">
              {[12, 16, 18, 20, 24, 32].map(s => (
                <div key={s} className="flex flex-col items-center gap-2">
                  <KoaIcon name="coin" size={s} color="#06005A" />
                  <p className="font-figures text-[10px] text-gray-400">{s}px</p>
                  <p className="text-[9px] text-gray-300">
                    {s === 12 ? 'micro' : s === 16 ? 'sm' : s === 18 ? 'base' : s === 20 ? 'md' : s === 24 ? 'lg' : 'xl'}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="mb-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Navegación</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              <IconTile name="home" label="Home" />
              <IconTile name="credit" label="Libranza" />
              <IconTile name="cdt" label="CDT" />
              <IconTile name="profile" label="Mis datos" />
              <IconTile name="security" label="Seguridad" />
              <IconTile name="contact" label="Contacto" />
              <IconTile name="education" label="Educación" />
            </div>
          </div>

          {/* Financial */}
          <div className="mb-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Financiero</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
              <IconTile name="coin" label="Moneda" />
              <IconTile name="calendar" label="Calendario" />
              <IconTile name="rate" label="Tasa" />
              <IconTile name="trend" label="Tendencia" />
              <IconTile name="amount" label="Monto" />
              <IconTile name="returns" label="Rendimientos" />
            </div>
          </div>

          {/* Actions */}
          <div className="mb-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Acciones</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
              <IconTile name="plus" label="Agregar" />
              <IconTile name="arrow" label="Continuar" />
              <IconTile name="edit" label="Editar" />
              <IconTile name="download" label="Descargar" />
              <IconTile name="eye" label="Ver" />
              <IconTile name="settings" label="Configurar" />
            </div>
          </div>

          {/* Status */}
          <div className="mb-8">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Estado</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
              <IconTile name="check" label="Al día" />
              <IconTile name="xmark" label="Error" />
              <IconTile name="clock" label="Pendiente" />
              <IconTile name="shield" label="Protegido" />
              <IconTile name="notify" label="Notificación" />
            </div>
          </div>

          {/* Fintech / comercial */}
          <div className="mb-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Fintech &amp; comercial</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              <IconTile name="wallet" label="Billetera" />
              <IconTile name="bank" label="Banco" />
              <IconTile name="piggy" label="Ahorro" />
              <IconTile name="transfer" label="Transferir" />
              <IconTile name="send" label="Enviar" />
              <IconTile name="receive" label="Recibir" />
              <IconTile name="percent" label="Interés" />
              <IconTile name="target" label="Meta" />
              <IconTile name="growth" label="Crecimiento" />
              <IconTile name="chartBar" label="Reportes" />
              <IconTile name="invoice" label="Extracto" />
              <IconTile name="calculator" label="Simular" />
              <IconTile name="signature" label="Firma" />
              <IconTile name="handshake" label="Acuerdo" />
              <IconTile name="qr" label="Pago QR" />
              <IconTile name="lock" label="Bloqueo" />
              <IconTile name="key" label="Clave" />
              <IconTile name="document" label="Documento" />
              <IconTile name="store" label="Comercio" />
              <IconTile name="star" label="Beneficios" />
              <IconTile name="refresh" label="Renovar" />
            </div>
          </div>

          {/* Animated icons */}
          <div className="mb-8">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Iconografía animada</p>
            <p className="text-[12px] text-gray-400 mb-3 leading-relaxed">Gesto al pasar el cursor — reforzando la acción. Respeta <code className="text-[11px]">prefers-reduced-motion</code>.</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <AnimIcon name="notify" anim="icon-ring" label="Ring · hover" />
              <AnimIcon name="growth" anim="icon-rise" label="Rise · hover" />
              <AnimIcon name="coin" anim="icon-flip" label="Flip · hover" />
              <AnimIcon name="check" anim="icon-pop" label="Pop · hover" />
              <AnimIcon name="target" anim="icon-wobble" label="Wobble · hover" />
              <AnimIcon name="arrow" anim="icon-slide" label="Slide · hover" />
              <AnimIcon name="refresh" anim="icon-draw" label="Draw · hover" />
              <AnimIcon name="transfer" anim="icon-slide" label="Slide · hover" />
              <AnimIcon name="piggy" anim="icon-pop" label="Pop · hover" />
              <AnimIcon name="star" anim="icon-wobble" label="Wobble · hover" />
              <AnimIcon name="send" anim="icon-rise" label="Rise · hover" />
              <AnimIcon name="percent" anim="icon-flip" label="Flip · hover" />
            </div>
            <div className="mt-3 flex flex-wrap gap-3">
              <div className="flex items-center gap-2 bg-white rounded-xl border border-[#E8ECF2] px-3 py-2">
                <KoaIcon name="notify" size={20} color="#06005A" />
                <span className="icon-ring-loop inline-flex" />
                <span className="w-9 h-9 rounded-xl bg-[#EFFFF7] flex items-center justify-center"><span className="icon-ring-loop"><KoaIcon name="notify" size={18} color="#00B874" /></span></span>
                <span className="text-[11px] font-semibold text-[#6B7280]">loop · alertas</span>
              </div>
              <div className="flex items-center gap-2 bg-white rounded-xl border border-[#E8ECF2] px-3 py-2">
                <span className="w-9 h-9 rounded-xl bg-[#EFFFF7] flex items-center justify-center"><span className="icon-rise-loop"><KoaIcon name="growth" size={18} color="#00B874" /></span></span>
                <span className="text-[11px] font-semibold text-[#6B7280]">loop · crecimiento</span>
              </div>
              <div className="flex items-center gap-2 bg-white rounded-xl border border-[#E8ECF2] px-3 py-2">
                <span className="w-9 h-9 rounded-xl bg-[#06005A] flex items-center justify-center"><span className="icon-flip-loop"><KoaIcon name="coin" size={18} color="#00DB8E" /></span></span>
                <span className="text-[11px] font-semibold text-[#6B7280]">loop · moneda</span>
              </div>
            </div>
          </div>

          {/* Icon in context */}
          <div>
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Uso en contexto · Variantes de contenedor</p>
            <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] px-6 py-5 flex flex-wrap gap-4 items-center">
              {/* Plain */}
              <div className="flex flex-col items-center gap-2">
                <KoaIcon name="coin" size={20} color="#2A3036" />
                <p className="text-[9px] text-gray-400">plain</p>
              </div>
              {/* Neutral bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#F0F2F5] flex items-center justify-center">
                  <KoaIcon name="coin" size={20} color="#6B7280" />
                </div>
                <p className="text-[9px] text-gray-400">neutral</p>
              </div>
              {/* Navy bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#06005A] flex items-center justify-center">
                  <KoaIcon name="coin" size={20} color="#FFFFFF" />
                </div>
                <p className="text-[9px] text-gray-400">navy</p>
              </div>
              {/* Mint surface */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/20 flex items-center justify-center">
                  <KoaIcon name="coin" size={20} color="#00B874" />
                </div>
                <p className="text-[9px] text-gray-400">mint</p>
              </div>
              {/* Mint dim */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#00DB8E]/20 border border-[#00DB8E]/25 flex items-center justify-center">
                  <KoaIcon name="coin" size={20} color="#00DB8E" />
                </div>
                <p className="text-[9px] text-gray-400">mint dim</p>
              </div>
              {/* Error bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#FFF0F5] flex items-center justify-center">
                  <KoaIcon name="xmark" size={20} color="#FA467F" />
                </div>
                <p className="text-[9px] text-gray-400">error</p>
              </div>
              {/* Success bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#ECFDF5] flex items-center justify-center">
                  <KoaIcon name="check" size={20} color="#059669" />
                </div>
                <p className="text-[9px] text-gray-400">success</p>
              </div>
              {/* Warning bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#FFFBEB] flex items-center justify-center">
                  <KoaIcon name="clock" size={20} color="#FFD400" />
                </div>
                <p className="text-[9px] text-gray-400">warning</p>
              </div>
              {/* Info bg */}
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-[#EBF5FF] flex items-center justify-center">
                  <KoaIcon name="security" size={20} color="#0098FF" />
                </div>
                <p className="text-[9px] text-gray-400">info</p>
              </div>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 6. BOTONES ───────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="botones">
          <SectionTitle kicker="Primitivas · Capa 1">Botones</SectionTitle>
          <div className="space-y-5">
            <Preview label="Variantes · Tamaño md">
              <Btn variant="primary">Primary</Btn>
              <Btn variant="mint">Mint</Btn>
              <Btn variant="secondary">Secondary</Btn>
              <Btn variant="ghost">Ghost</Btn>
              <Btn variant="danger">Danger</Btn>
            </Preview>
            <Preview label="Tamaños · Variante primary">
              <Btn variant="primary" size="sm">Small</Btn>
              <Btn variant="primary" size="md">Medium</Btn>
              <Btn variant="primary" size="lg">Large</Btn>
            </Preview>
            <Preview label="Tamaños · Variante mint">
              <Btn variant="mint" size="sm">Abrir CDT</Btn>
              <Btn variant="mint" size="md">Abrir mi CDT</Btn>
              <Btn variant="mint" size="lg">Nueva apertura</Btn>
            </Preview>
            <Preview label="Estado loading">
              <Btn variant="primary" loading size="sm">Verificando</Btn>
              <Btn variant="mint" loading size="md">Procesando</Btn>
              <Btn variant="secondary" loading size="lg">Cargando datos</Btn>
            </Preview>
            <Preview label="Estado disabled">
              <Btn variant="primary" disabled>Primary</Btn>
              <Btn variant="mint" disabled>Mint</Btn>
              <Btn variant="secondary" disabled>Secondary</Btn>
              <Btn variant="danger" disabled>Danger</Btn>
            </Preview>
            <Preview label="Botones personalizados del portal" dark>
              <button className="bg-[#06005A] text-[#00DB8E] font-black text-[13px] px-5 py-2.5 rounded-xl shadow-md shadow-[#06005A]/20 hover:bg-[#08007A] cursor-pointer transition-colors">
                Cambiar clave
              </button>
              <button className="bg-[#00DB8E] text-[#06005A] font-black text-[13px] px-5 py-2.5 rounded-xl btn-mint-glow hover:bg-[#00B874] cursor-pointer transition-colors">
                Iniciar proceso
              </button>
              <button className="text-[#06005A] font-bold text-[13px] px-5 py-2.5 rounded-xl cursor-pointer inline-flex items-center gap-1.5" style={{ background: 'rgba(6,0,90,0.05)', border: '1px solid rgba(6,0,90,0.08)' }}>
                Ver condiciones
                <KoaIcon name="arrow" size={14} color="#06005A" />
              </button>
              <button className="w-10 h-10 rounded-xl bg-[#00DB8E]/20 border border-[#00DB8E]/25 flex items-center justify-center text-[#00DB8E] hover:bg-[#00DB8E]/30 cursor-pointer transition-colors">
                <KoaIcon name="plus" size={16} color="#00DB8E" />
              </button>
            </Preview>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 7. BADGES ────────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="badges">
          <SectionTitle kicker="Primitivas · Capa 1">Badges y pills</SectionTitle>
          <div className="space-y-5">
            <Preview label="Estado de crédito / producto">
              <span className="flex items-center gap-1.5 text-[10px] font-bold bg-[#ECFDF5] text-[#059669] px-2.5 py-1 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-[#059669] animate-pulse" />Al día
              </span>
              <span className="flex items-center gap-1.5 text-[10px] font-bold bg-[#FFF0F5] text-[#F70C5B] px-2.5 py-1 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FA467F]" />En mora
              </span>
              <span className="text-[10px] font-bold bg-[#F7F7F7] text-gray-500 px-2.5 py-1 rounded-full">Vencido</span>
              <span className="text-[10px] font-bold bg-[#FFFBEB] text-[#8A6D00] px-2.5 py-1 rounded-full">Por vencer</span>
              <span className="text-[10px] font-bold bg-[#EBF5FF] text-[#0068B3] px-2.5 py-1 rounded-full">En trámite</span>
            </Preview>
            <Preview label="Producto">
              <span className="text-[9px] font-black tracking-[0.18em] uppercase bg-[#06005A] text-white px-2.5 py-[5px] rounded-full">CDT</span>
              <span className="text-[9px] font-black tracking-[0.18em] uppercase text-[#005E3C] px-2.5 py-[5px] rounded-full" style={{ background: 'rgba(0,219,142,0.12)', border: '1px solid rgba(0,219,142,0.25)' }}>Libranza</span>
              <span className="text-[10px] font-bold text-[#06005A] bg-[#06005A]/[0.07] px-2.5 py-1 rounded-full">CDT Digital</span>
              <span className="text-[10px] font-bold text-[#005E3C] bg-[#EFFFF7] px-2.5 py-1 rounded-full border border-[#00DB8E]/25">Crédito activo</span>
            </Preview>
            <Preview label="Notificación / conteo">
              <div className="relative inline-flex">
                <div className="w-10 h-10 rounded-xl bg-[#F0F2F5] flex items-center justify-center">
                  <KoaIcon name="notify" size={18} color="#9CA3AF" />
                </div>
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-[#FA467F] text-white text-[9px] font-black rounded-full flex items-center justify-center">3</span>
              </div>
              <span className="text-[10px] font-black text-[#FFD400] bg-[#FFD400]/12 px-2 py-0.5 rounded-full leading-none">2</span>
              <div className="w-5 h-5 rounded-full bg-[#FA467F]/10 flex items-center justify-center">
                <svg className="w-3 h-3 text-[#FA467F]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 4h.01" />
                </svg>
              </div>
            </Preview>
            <Preview label="Informativos y marketing">
              <span className="flex items-center gap-2 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-full px-3.5 py-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse" />
                <span className="text-[11px] font-bold text-[#005E3C]">Cuenta protegida</span>
              </span>
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-[#005E3C] px-2.5 py-1 rounded-full" style={{ background: 'rgba(0,219,142,0.1)', border: '1px solid rgba(0,219,142,0.2)' }}>
                <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
                Personalizado para ti
              </span>
              <span className="bg-[#00DB8E] text-[#06005A] text-[8px] font-black px-2.5 py-[3px] rounded-full tracking-[0.12em] uppercase">Mejor tasa</span>
              <span className="bg-[#06005A] text-[#00DB8E] text-[8px] font-black px-2.5 py-[3px] rounded-full tracking-[0.14em] uppercase">Vigente 2026</span>
              <span className="bg-gradient-to-r from-[#00DB8E] to-[#00B874] text-[#06005A] text-[9px] font-black px-2.5 py-1 rounded-full">Nuevo</span>
            </Preview>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* COMPONENTES UI ──────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="componentes-ui">
          <SectionTitle kicker="Primitivas · Capa 1">Componentes UI reutilizables</SectionTitle>

          <div className="space-y-10">

            {/* ── StatusPill ──────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">StatusPill</p>
              <p className="text-[12px] text-gray-400 mb-4">Estado visual de créditos y procesos. Dot pulsante en variantes activas.</p>
              <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex flex-wrap gap-3">
                <StatusPill variant="activo" />
                <StatusPill variant="al-dia" />
                <StatusPill variant="pendiente" />
                <StatusPill variant="en-proceso" />
                <StatusPill variant="en-mora" />
                <StatusPill variant="proximo" />
                <StatusPill variant="resuelto" />
                <StatusPill variant="terminado" />
                <StatusPill variant="error" />
              </div>
              <div className="mt-3 bg-[#F7F7F7] rounded-xl border border-[#E8ECF2] px-4 py-3 flex flex-wrap gap-2">
                <StatusPill variant="al-dia" label="Crédito vigente" />
                <StatusPill variant="en-mora" label="Cuota vencida" />
                <StatusPill variant="en-proceso" label="Solicitud en revisión" />
                <StatusPill variant="resuelto" label="Solicitud aprobada" />
              </div>
            </div>

            {/* ── SectionHeader ───────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">SectionHeader</p>
              <p className="text-[12px] text-gray-400 mb-4">Encabezado de página con título, subtítulo y slot de acciones.</p>
              <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 divide-y divide-[#F0F2F5] flex flex-col gap-0">
                <div className="pb-5">
                  <SectionHeader title="Mis créditos" />
                </div>
                <div className="py-5">
                  <SectionHeader
                    title="Certificaciones"
                    subtitle="Descarga y solicita documentos de tus créditos activos"
                  />
                </div>
                <div className="pt-5">
                  <SectionHeader
                    title="Mis CDTs"
                    subtitle="Portafolio de inversiones"
                    actions={<><Btn variant="secondary" size="sm">Filtrar</Btn><Btn variant="mint" size="sm">Abrir CDT</Btn></>}
                  />
                </div>
              </div>
            </div>

            {/* ── FilterChips ─────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">FilterChips</p>
              <p className="text-[12px] text-gray-400 mb-4">Fila de filtros de selección única. Pill activo en navy.</p>
              <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex flex-col gap-4">
                <FilterChipsDemo />
              </div>
            </div>

            {/* ── EmptyState ──────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">EmptyState</p>
              <p className="text-[12px] text-gray-400 mb-4">Estado vacío centrado con icono, título, descripción y acción opcional.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
                  <EmptyState
                    icon={<KoaIcon name="cdt" size={28} color="#005E3C" />}
                    title="Sin inversiones aún"
                    description="Abre tu primer CDT Digital y empieza a hacer crecer tu dinero."
                    action={<Btn variant="mint" size="md">Abrir CDT</Btn>}
                  />
                </div>
                <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
                  <EmptyState
                    icon={<KoaIcon name="credit" size={28} color="#6B7280" />}
                    iconBg="bg-[#F0F2F5]"
                    title="Sin créditos activos"
                    description="No tienes créditos libranza vigentes en este momento."
                  />
                </div>
              </div>
            </div>

            {/* ── KpiCard ─────────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">KpiCard</p>
              <p className="text-[12px] text-gray-400 mb-4">Tarjeta métrica con icono, valor grande y chip. Borde top de color opcional.</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <KpiCard
                  icon={<KoaIcon name="cdt" size={22} color="#005E3C" />}
                  label="CDTs activos"
                  value="2"
                  chip="Vigentes"
                  accent="#00DB8E"
                />
                <KpiCard
                  icon={<KoaIcon name="coin" size={22} color="#0068B3" />}
                  iconBg="bg-[#EBF5FF]"
                  label="Total invertido"
                  value="$45.2M"
                  chip="+3.2%"
                  chipColor="text-[#059669] bg-[#ECFDF5]"
                  accent="#0098FF"
                />
                <KpiCard
                  icon={<KoaIcon name="returns" size={22} color="#8A6D00" />}
                  iconBg="bg-[#FFFBEB]"
                  label="Rendimientos"
                  value="$1.45M"
                  chip="Acumulado"
                  chipColor="text-[#8A6D00] bg-[#FFFBEB]"
                  accent="#FFD400"
                />
              </div>
            </div>

            {/* ── SidePanel ───────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">SidePanel</p>
              <p className="text-[12px] text-gray-400 mb-4">Drawer lateral desde la derecha. Backdrop oscuro, scroll interior, cierre con clic fuera o X.</p>
              <SidePanelDemo />
            </div>

            {/* ── Toast ───────────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Toast · Notificación flotante</p>
              <p className="text-[12px] text-gray-400 mb-4">Pill fijo en la parte inferior. Auto-dismissal a los 3 s. Se usa para confirmaciones rápidas no bloqueantes.</p>
              <ToastDemo />
            </div>

            {/* ── OTP / FirmaElectronica ──────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">FirmaElectronica · OTP Modal</p>
              <p className="text-[12px] text-gray-400 mb-4">Modal de autorización de 6 dígitos. Usado en: abrir CDT, renovar CDT, cambiar cuenta, paz y salvo, cambio de clave. Incluye countdown, reenvío y overlay de validación de 3 pasos.</p>
              <OtpModalDemo />
            </div>

            {/* ── ValidatingOverlay ───────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">ValidatingOverlay · Animación de 3 pasos</p>
              <p className="text-[12px] text-gray-400 mb-4">Overlay de progreso que cubre el modal durante una operación async. Los pasos avanzan secuencialmente con dot pulsante → checkmark.</p>
              <ValidatingOverlayDemo />
            </div>

            {/* ── Stepper ─────────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Stepper · Encabezado de flujo multi-paso</p>
              <p className="text-[12px] text-gray-400 mb-4">Cabecera fija navy con pasos numerados. Paso activo en blanco, completado en verde, pendiente translúcido. Usado en: Paz y salvo, Abrir CDT.</p>
              <StepperDemo />
            </div>

            {/* ── Accordion ───────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Acordeón</p>
              <p className="text-[12px] text-gray-400 mb-4">Panel colapsable con indicador de completitud. Usado en Mis Datos para secciones de perfil.</p>
              <AcordeonDemo />
            </div>

            {/* ── UploadZone ──────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">UploadZone · Zona de carga</p>
              <p className="text-[12px] text-gray-400 mb-4">Dropzone con borde punteado para subir archivos PDF. Muestra nombre de archivo seleccionado. Usado en Bloqueo de documentos.</p>
              <UploadZoneDemo />
            </div>

            {/* ── Confirmation ────────────────────────────── */}
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Confirmation · Tabla resumen + acciones</p>
              <p className="text-[12px] text-gray-400 mb-4">Patrón de confirmación: tabla de datos de la operación + checkboxes de aceptación + botones Cancelar / Confirmar. Usado en renovar CDT, certificación de saldo.</p>
              <ConfirmationDemo />
            </div>

          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 8. CARDS ─────────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="cards">
          <SectionTitle kicker="Primitivas · Capa 1">Cards</SectionTitle>
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* ── Card variant navy · spotlight ── */}
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2">Card · variant navy</p>
                <Card variant="navy" spotlight className="group relative overflow-hidden p-5 flex flex-col gap-4 h-full">
                  <div className="absolute -top-16 -right-12 w-44 h-44 rounded-full bg-[#00DB8E]/[0.16] blur-2xl pointer-events-none transition-opacity duration-500 group-hover:opacity-80" />
                  <div className="absolute -bottom-20 -left-12 w-44 h-44 rounded-full bg-[#00DB8E]/[0.05] blur-2xl pointer-events-none" />
                  <div className="relative z-10 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <UiIconTile toneName="mint" sizeName="sm" className="transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110">
                        <KoaIcon name="trend" size={16} color="#005E3C" />
                      </UiIconTile>
                      <span className="text-white/70 text-[11px] font-semibold">Portafolio</span>
                    </div>
                    <span className="text-[10px] font-bold text-[#00DB8E] bg-[#00DB8E]/15 border border-[#00DB8E]/25 px-2 py-0.5 rounded-full">2 activos</span>
                  </div>
                  <div className="relative z-10">
                    <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.16em]">Inversión total</p>
                    <p className="font-figures text-white font-black text-[32px] leading-none mt-1.5 animate-number-pop">$45.200.000</p>
                    <p className="font-figures text-[#00DB8E] text-[12px] font-black mt-2.5 inline-flex items-center gap-1 bg-[#00DB8E]/12 border border-[#00DB8E]/20 px-2 py-1 rounded-lg">
                      <KoaIcon name="growth" size={12} color="#00DB8E" /> +$1.450.000 · +3,3%
                    </p>
                  </div>
                  <div className="relative z-10 mt-auto -mx-1 -mb-1">
                    <svg viewBox="0 0 240 56" className="w-full h-12" preserveAspectRatio="none" aria-hidden="true">
                      <defs>
                        <linearGradient id="navy-spark-fill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#00DB8E" stopOpacity="0.32" />
                          <stop offset="100%" stopColor="#00DB8E" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                      <path d="M0,44 L30,40 L60,43 L90,30 L120,35 L150,20 L180,25 L210,12 L240,7 L240,56 L0,56 Z" fill="url(#navy-spark-fill)" />
                      <path d="M0,44 L30,40 L60,43 L90,30 L120,35 L150,20 L180,25 L210,12 L240,7" fill="none" stroke="#00DB8E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" className="spark-draw" />
                      <circle cx="240" cy="7" r="3.5" fill="#00DB8E" className="animate-pulse" />
                    </svg>
                  </div>
                </Card>
              </div>

              {/* ── Card default · spotlight + sheen ── */}
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2">Card · spotlight</p>
                <Card spotlight sheen className="group p-5 flex flex-col gap-4 h-full">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <UiIconTile toneName="success" sizeName="md" className="transition-transform duration-300 group-hover:scale-105">
                        <KoaIcon name="bank" size={18} color="#059669" />
                      </UiIconTile>
                      <div>
                        <p className="font-bold text-[#2A3036] text-[13px]">Min. de Educación</p>
                        <p className="font-figures text-[11px] text-gray-400">••• 4821</p>
                      </div>
                    </div>
                    <span className="flex items-center gap-1.5 text-[10px] font-bold bg-[#ECFDF5] text-[#059669] px-2 py-0.5 rounded-full">
                      <span className="w-1 h-1 rounded-full bg-[#059669] animate-pulse" />Al día
                    </span>
                  </div>
                  <div>
                    <p className="text-[10px] text-gray-400 uppercase tracking-wider">Saldo pendiente</p>
                    <p className="font-figures font-black text-[#2A3036] text-[22px] leading-none mt-1">$18.400.000</p>
                  </div>
                  <div className="mt-auto">
                    <div className="flex justify-between text-[10px] text-gray-400 mb-1.5">
                      <span>Pagado 70%</span><span className="font-figures font-bold text-[#059669]">14 / 20 cuotas</span>
                    </div>
                    <div className="h-1.5 bg-[#F0F2F5] rounded-full overflow-hidden">
                      <div className="h-full w-[70%] rounded-full transition-all duration-700" style={{ background: 'linear-gradient(90deg, #10B981, #00DB8E)' }} />
                    </div>
                  </div>
                </Card>
              </div>

              {/* ── Card variant bloom · spotlight ── */}
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2">Card · variant bloom</p>
                <Card variant="bloom" spotlight className="group relative overflow-hidden p-5 flex flex-col gap-4 h-full !border-[#E8ECF2]" style={{ background: '#FFFFFF' }}>
                  <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-[#00DB8E] to-[#06005A] pointer-events-none" />
                  <div className="relative z-10 flex items-center gap-2.5">
                    <UiIconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
                      <KoaIcon name="credit" size={18} color="#00DB8E" />
                    </UiIconTile>
                    <div className="flex-1">
                      <p className="font-bold text-[#06005A] text-[13px] leading-tight">Crédito de libranza</p>
                      <p className="text-[10px] font-bold uppercase tracking-wide text-[#00A870] flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] animate-pulse" />Pre-aprobado
                      </p>
                    </div>
                  </div>
                  <div className="relative z-10">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.16em]">Cupo disponible</p>
                    <p className="font-figures font-black text-[#06005A] leading-none mt-1.5 animate-number-pop" style={{ fontSize: '42px' }}>$100M</p>
                    <div className="mt-3">
                      <div className="h-2 rounded-full bg-[#F0F2F5] overflow-hidden">
                        <div className="h-full w-[6%] rounded-full transition-all duration-700" style={{ background: 'linear-gradient(90deg, #06005A, #00DB8E)' }} />
                      </div>
                      <div className="flex justify-between text-[10px] font-semibold text-gray-400 mt-1.5">
                        <span>Usado $6M</span><span className="text-[#06005A]">Disponible $94M</span>
                      </div>
                    </div>
                  </div>
                  <div className="relative z-10 flex items-center justify-between rounded-xl bg-[#F7F7F7] border border-[#E8ECF2] px-3 py-2.5">
                    <span className="text-[10px] font-semibold text-gray-400">Cuota estimada desde</span>
                    <span className="font-figures font-black text-[#06005A] text-[15px]">$420.000<span className="text-[10px] font-bold text-gray-400">/mes</span></span>
                  </div>
                  <Btn variant="primary" size="sm" className="w-full mt-auto">Simular crédito</Btn>
                </Card>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-2">
              {[
                { cls: 'card', label: '.card', desc: 'Hover shadow + lift' },
                { cls: 'card-flat', label: '.card-flat', desc: 'Sin hover' },
                { cls: 'card-glass', label: '.card-glass', desc: 'Vidrio para fondos oscuros' },
              ].map(c => (
                <div key={c.label}>
                  <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-2">{c.label}</p>
                  <div className={`${c.cls} p-4 flex flex-col gap-1.5`}>
                    <p className="font-black text-[#2A3036] text-[13px]">{c.label}</p>
                    <p className="text-[11px] text-gray-400">{c.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 9. FORMULARIOS ──────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="formularios">
          <SectionTitle kicker="Primitivas · Capa 1">Formularios e inputs</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-4">
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400">Inputs de texto</p>
              <div>
                <label className="text-[11px] font-bold text-[#2A3036] block mb-1.5">Número de documento</label>
                <input type="text" defaultValue="" placeholder="Ej. 1020304050" className="w-full h-11 px-4 rounded-xl border-2 border-[#E8ECF2] text-[13px] text-[#2A3036] outline-none focus:border-[#06005A] transition-colors placeholder:text-gray-300 bg-white" />
              </div>
              <div>
                <label className="text-[11px] font-bold text-[#2A3036] block mb-1.5">Correo electrónico</label>
                <input type="email" defaultValue="ana@correo.com" className="w-full h-11 px-4 rounded-xl border-2 border-[#06005A] text-[13px] text-[#2A3036] outline-none bg-[#06005A]/[0.04] transition-colors" />
              </div>
              <div>
                <label className="text-[11px] font-bold text-[#2A3036] block mb-1.5">Clave</label>
                <input type="password" defaultValue="123" className="w-full h-11 px-4 rounded-xl border-2 border-[#FA467F] text-[13px] text-[#2A3036] outline-none bg-[#FFF0F5] transition-colors" />
                <p className="text-[11px] font-semibold text-[#F70C5B] mt-1">La clave debe tener 6 dígitos</p>
              </div>
              <div>
                <label className="text-[11px] font-bold text-[#2A3036] block mb-1.5">NIT empresa</label>
                <div className="relative">
                  <input type="text" defaultValue="900.123.456-7" className="w-full h-11 px-4 pr-10 rounded-xl border-2 border-[#059669] text-[13px] text-[#2A3036] outline-none bg-[#ECFDF5] transition-colors" />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <KoaIcon name="check" size={16} color="#059669" />
                  </div>
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold text-[#2A3036] block mb-1.5">Tipo de documento</label>
                <div className="relative">
                  <select className="w-full h-11 px-4 pr-10 rounded-xl border-2 border-[#E8ECF2] text-[13px] text-[#2A3036] outline-none focus:border-[#06005A] appearance-none bg-white cursor-pointer transition-colors">
                    <option>Cédula de Ciudadanía (CC)</option>
                    <option>Cédula de Extranjería (CE)</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                    <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">OTP · Código numérico 6 dígitos</p>
                <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] p-5">
                  <div className="flex gap-2 justify-center">
                    {otpDigits.map((d, i) => (
                      <input
                        key={i}
                        ref={el => { otpRefs.current[i] = el }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={d}
                        onChange={e => {
                          const ch = e.target.value.replace(/\D/g, '').slice(-1)
                          const next = [...otpDigits]; next[i] = ch; setOtpDigits(next)
                          if (ch && i < 5) otpRefs.current[i + 1]?.focus()
                        }}
                        onKeyDown={e => { if (e.key === 'Backspace' && !d && i > 0) otpRefs.current[i - 1]?.focus() }}
                        className={`w-10 h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all ${d ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]' : 'border-[#E8ECF2] bg-white'}`}
                      />
                    ))}
                  </div>
                  <p className="text-center text-[11px] text-gray-400 mt-3">Código de ejemplo: 248731</p>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">OTP · Estado error (.shake)</p>
                <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] p-5">
                  <div className="flex gap-2 justify-center animate-[shake_0.35s_ease-in-out]">
                    {['9','9','9','9','9','9'].map((d, i) => (
                      <div key={i} className="w-10 h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 flex items-center justify-center border-[#FA467F] bg-[#FFF0F5] text-[#F70C5B]">{d}</div>
                    ))}
                  </div>
                  <p className="text-center text-[11px] font-semibold text-[#F70C5B] mt-2">Código incorrecto</p>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Toggles / switches</p>
                <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] p-5 flex flex-col gap-4">
                  {[
                    { label: 'Notificaciones activas', val: toggleA, set: setToggleA },
                    { label: 'Recordar dispositivo', val: toggleB, set: setToggleB },
                  ].map(t => (
                    <div key={t.label} className="flex items-center justify-between">
                      <p className="text-[13px] font-semibold text-[#2A3036]">{t.label}</p>
                      <button onClick={() => t.set(!t.val)} className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer ${t.val ? 'bg-[#00DB8E]' : 'bg-[#E8ECF2]'}`}>
                        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-all ${t.val ? 'left-5' : 'left-0.5'}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Selector de tipo (login)</p>
                <PersonTypeToggle />
              </div>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 10. ALERTAS ──────────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="alertas">
          <SectionTitle kicker="Primitivas · Capa 1">Alertas y notificaciones</SectionTitle>
          <div className="space-y-3">
            {[
              {
                type: 'success', bg: '#EFFFF7', border: 'rgba(0,219,142,0.25)',
                iconBg: '#00DB8E', iconColor: '#06005A', iconName: 'check',
                title: 'Clave actualizada correctamente',
                desc: 'Tu nueva clave está activa desde ahora. Todos tus accesos han sido actualizados.',
              },
              {
                type: 'error', bg: '#FFF0F5', border: 'rgba(239,68,68,0.25)',
                iconBg: '#FA467F', iconColor: 'white', iconName: 'xmark',
                title: 'Código de verificación incorrecto',
                desc: 'El código ingresado no coincide. Revisa tu correo e inténtalo de nuevo.',
              },
              {
                type: 'warning', bg: '#FFFBEB', border: 'rgba(255,212,0,0.45)',
                iconBg: '#FFD400', iconColor: 'white', iconName: 'clock',
                title: 'Tienes 1 pago próximo a vencer',
                desc: 'Tu cuota del crédito Min. de Educación vence en 3 días. Asegúrate de tener saldo.',
              },
              {
                type: 'info', bg: '#EBF5FF', border: 'rgba(0,152,255,0.3)',
                iconBg: '#0098FF', iconColor: 'white', iconName: 'security',
                title: 'Demo activo · Datos simulados',
                desc: 'Esta sesión usa datos ficticios para demostración. No representan información real.',
              },
            ].map(a => (
              <div key={a.type} className="flex items-start gap-4 rounded-2xl px-4 py-4" style={{ background: a.bg, border: `1px solid ${a.border}` }}>
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: a.iconBg }}>
                  <KoaIcon name={a.iconName} size={14} color={a.iconColor} />
                </div>
                <div>
                  <p className="font-bold text-[#2A3036] text-[13px]">{a.title}</p>
                  <p className="text-[12px] text-gray-500 mt-0.5">{a.desc}</p>
                </div>
              </div>
            ))}
            <div className="bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3.5 py-2.5 flex items-center gap-2">
              <KoaIcon name="shield" size={14} color="#00DB8E" />
              <p className="text-[11px] text-[#005E3C]"><span className="font-bold">Demo:</span> código de verificación de ejemplo: <span className="font-figures font-black underline">248731</span></p>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 11. INDICADORES ─────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="indicadores">
          <SectionTitle kicker="Primitivas · Capa 1">Indicadores de estado</SectionTitle>
          <div className="space-y-5">
            <Preview label="Spinners">
              {['sm','md','lg'].map((s, i) => (
                <div key={s} className="flex flex-col items-center gap-2">
                  <div className={`border-2 border-[#06005A] border-t-transparent rounded-full animate-spin ${['w-4 h-4','w-6 h-6','w-8 h-8'][i]}`} />
                  <span className="text-[10px] text-gray-400">{s}</span>
                </div>
              ))}
              <div className="flex flex-col items-center gap-2">
                <div className="w-6 h-6 border-2 border-[#00DB8E] border-t-transparent rounded-full animate-spin" />
                <span className="text-[10px] text-gray-400">mint</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="w-6 h-6 rounded-full border-2 border-white/40 border-t-white animate-spin" />
                <span className="text-[10px] text-gray-400">white</span>
              </div>
            </Preview>
            <Preview label="Barra de progreso">
              <div className="w-full flex flex-col gap-3.5">
                {[
                  { pct: 8,   grad: 'linear-gradient(90deg,#0098FF,#00DB8E)', label: '8% · Inicio de crédito' },
                  { pct: 30,  grad: 'linear-gradient(90deg,#0098FF,#00DB8E)', label: '30% · Progreso normal' },
                  { pct: 75,  grad: 'linear-gradient(90deg,#0068B3,#0098FF,#00DB8E)', label: '75% · Avanzado' },
                  { pct: 95,  grad: 'linear-gradient(90deg,#FFC400,#FFDE5C)', label: '95% · Próximo a vencer' },
                  { pct: 100, grad: 'linear-gradient(90deg,#0068B3,#0098FF,#00DB8E)', label: '100% · Completado' },
                  { pct: 45,  grad: 'linear-gradient(90deg,#F70C5B,#FA467F)', label: '45% · En mora' },
                ].map(p => (
                  <div key={p.label} className="flex items-center gap-3">
                    <div className="flex-1 h-2.5 bg-[#EDEFF3] rounded-full">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${p.pct}%`, background: p.grad }}
                      />
                    </div>
                    <p className="font-figures text-[11px] font-bold text-[#2A3036] w-8 text-right">{p.pct}%</p>
                    <p className="text-[11px] text-gray-400 w-44">{p.label}</p>
                  </div>
                ))}
              </div>
            </Preview>
            <Preview label="Skeleton loading (.shimmer)">
              <div className="w-full space-y-3">
                <div className="flex items-center gap-3">
                  <div className="shimmer w-10 h-10 rounded-xl" />
                  <div className="flex-1 space-y-1.5">
                    <div className="shimmer h-3 w-32 rounded-full" />
                    <div className="shimmer h-3 w-20 rounded-full" />
                  </div>
                </div>
                <div className="shimmer h-24 w-full rounded-2xl" />
                <div className="flex gap-2">
                  <div className="shimmer h-3 flex-1 rounded-full" />
                  <div className="shimmer h-3 flex-1 rounded-full" />
                  <div className="shimmer h-3 w-12 rounded-full" />
                </div>
              </div>
            </Preview>
            <Preview label="Indicadores de puntos">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00DB8E] mint-pulse" />
                <span className="text-[12px] font-semibold text-[#2A3036]">mint-pulse · activo</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#059669] animate-pulse" />
                <span className="text-[12px] font-semibold text-[#2A3036]">animate-pulse · al día</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#FFD400] animate-pulse" />
                <span className="text-[12px] font-semibold text-[#2A3036]">animate-pulse · pendiente</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#FA467F]" />
                <span className="text-[12px] font-semibold text-[#2A3036]">estático · error</span>
              </div>
            </Preview>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* PREMIUM — StatCard / FeatureCard / ProgressRing / Modal */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="premium">
          <SectionTitle kicker="Efectos & superficies">Componentes premium</SectionTitle>
          <p className="text-[14px] text-[#6B7280] max-w-2xl -mt-2 mb-6">
            Piezas de alto impacto para Portal KOA — KPIs, tarjetas de feature y anillos de progreso.
            Cifras en Space Grotesk, glow mint que sigue el cursor y entradas orgánicas.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard label="Saldo total" value="$48.2M" tone="mint" trend={{ value: '+12.4% año', direction: 'up' }} icon={<KoaIcon name="coin" size={20} />} accent />
            <StatCard label="Rendimiento CDT" value="11.8" unit="% E.A." tone="navy" trend={{ value: 'estable', direction: 'flat' }} icon={<KoaIcon name="trend" size={20} />} />
            <StatCard label="Cuota libranza" value="$1.2M" tone="info" trend={{ value: '-3 meses', direction: 'down' }} icon={<KoaIcon name="calendar" size={20} />} />
            <StatCard label="Créditos activos" value="2" tone="success" icon={<KoaIcon name="credit" size={20} />} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <FeatureCard tone="mint" icon={<KoaIcon name="shield" size={24} />} title="Vigilado SFC" description="Tu dinero respaldado por la Superintendencia Financiera y Fogafín hasta $50M." />
            <FeatureCard tone="navy" icon={<KoaIcon name="coin" size={24} />} title="Tu plata, tú mandas" description="Invierte, retira y controla tus CDT desde un solo lugar, sin letra pequeña." />
            <FeatureCard tone="info" icon={<KoaIcon name="clock" size={24} />} title="Aprobación en minutos" description="Libranza por descuento de nómina con desembolso ágil y tasa preferencial." />
          </div>

          <div className="mt-4 grid grid-cols-1 lg:grid-cols-[auto_1fr] gap-4 items-stretch">
            <Card className="p-6 flex items-center justify-around gap-6">
              <ProgressRing value={68} label="68%" caption="Meta de ahorro" />
              <ProgressRing value={100} label="Pagado" caption="Crédito #1024" />
              <ProgressRing value={34} label="34%" caption="Plazo CDT" />
            </Card>
            <Card variant="navy" spotlight className="p-6 flex flex-col justify-center">
              <p className="text-[11px] font-bold tracking-wide uppercase text-white/60">Superficie navy · glass</p>
              <p className="mt-2 text-[22px] font-bold leading-tight text-gradient-mint">Diseñado para inspirar confianza</p>
              <p className="mt-2 text-[13px] text-white/70 max-w-md">Fondo navy translúcido con glow mint que sigue el cursor — ideal para hero cards y estados de bienvenida.</p>
              <div className="mt-4"><PremiumModalDemo /></div>
            </Card>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* EFECTOS — superficies y utilidades de marca */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="efectos">
          <SectionTitle kicker="Efectos & superficies">Efectos especiales de marca</SectionTitle>
          <p className="text-[14px] text-[#6B7280] max-w-2xl -mt-2 mb-6">
            Superficies vivas y micro-animaciones que dan alma al sistema — todas respetan
            <span className="font-semibold text-ink"> prefers-reduced-motion</span>. Pasa el cursor sobre las que reaccionan.
          </p>

          {/* ── Superficies de marca ── */}
          <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Superficies</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="brand-gradient rounded-[20px] p-5 text-white relative overflow-hidden h-40 flex flex-col justify-end">
              <KoaFlor half color="#00DB8E" showK={false} className="absolute -top-2 right-4 w-32 h-16 opacity-30" />
              <p className="font-bold">.brand-gradient</p>
              <p className="text-[12px] text-white/70">Degradado navy de marca</p>
            </div>
            <div className="aurora brand-gradient rounded-[20px] p-5 text-white relative overflow-hidden h-40 flex flex-col justify-end">
              <p className="font-bold">.aurora</p>
              <p className="text-[12px] text-white/70">Blooms mint a la deriva</p>
            </div>
            <div className="mint-gradient rounded-[20px] p-5 text-[#0C1E4C] relative overflow-hidden h-40 flex flex-col justify-end">
              <p className="font-bold">.mint-gradient</p>
              <p className="text-[12px] text-[#0C1E4C]/70">Degradado mint vibrante</p>
            </div>
            <div className="glass-navy rounded-[20px] p-5 text-white relative overflow-hidden h-40 flex flex-col justify-end">
              <p className="font-bold">.glass-navy</p>
              <p className="text-[12px] text-white/70">Panel navy translúcido</p>
            </div>
            <Card variant="bloom" spotlight className="p-5 h-40 flex flex-col justify-end">
              <p className="font-bold text-ink">bloom + spotlight</p>
              <p className="text-[12px] text-[#6B7280]">Glow mint que sigue el cursor</p>
            </Card>
            <Card sheen className="p-5 h-40 flex flex-col justify-end">
              <p className="font-bold text-ink">.sheen</p>
              <p className="text-[12px] text-[#6B7280]">Barrido de luz al pasar el cursor</p>
            </Card>
          </div>

          {/* ── Efectos & movimiento ── */}
          <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-gray-400 mt-8 mb-3">Movimiento & luz</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {/* Texto vivo */}
            <div className="rounded-[20px] p-5 h-40 flex flex-col justify-end bg-white border border-[#E8ECF2] relative overflow-hidden">
              <p
                className="mb-auto font-figures font-black text-[30px] leading-none animate-gradient-shift bg-clip-text text-transparent"
                style={{ backgroundImage: 'linear-gradient(90deg,#00DB90,#0C1E4C,#00DB90)', backgroundSize: '200% 100%' }}
              >Aa</p>
              <p className="font-bold text-ink text-[13px]">.animate-gradient-shift</p>
              <p className="text-[11px] text-[#6B7280]">Texto degradado en movimiento</p>
            </div>

            {/* Cifra con glow */}
            <div className="brand-gradient rounded-[20px] p-5 h-40 flex flex-col justify-end relative overflow-hidden">
              <p className="mb-auto font-figures font-bold text-white text-[26px] money-glow leading-none">$58.4M</p>
              <p className="font-bold text-white text-[13px]">.money-glow</p>
              <p className="text-[11px] text-white/65">Halo sobre cifras clave</p>
            </div>

            {/* Señal en vivo */}
            <div className="rounded-[20px] p-5 h-40 flex flex-col justify-end bg-white border border-[#E8ECF2] relative overflow-hidden">
              <div className="mb-auto grid place-items-center w-10 h-10">
                <span className="col-start-1 row-start-1 w-5 h-5 rounded-full bg-[#00DB8E]/40 animate-pulse-ring" />
                <span className="col-start-1 row-start-1 w-3 h-3 rounded-full bg-[#00DB8E] mint-pulse" />
              </div>
              <p className="font-bold text-ink text-[13px]">.animate-pulse-ring</p>
              <p className="text-[11px] text-[#6B7280]">Latido de estado en vivo</p>
            </div>

            {/* Pétalos flotando */}
            <div className="rounded-[20px] p-5 h-40 flex flex-col justify-end bg-[#EFFFF7] border border-[#00DB8E]/20 relative overflow-hidden">
              {[
                { l: '20%', d: '0s', du: '3.4s', s: 10 },
                { l: '45%', d: '0.6s', du: '4.2s', s: 7 },
                { l: '68%', d: '1.1s', du: '3.8s', s: 12 },
                { l: '82%', d: '0.3s', du: '4.6s', s: 6 },
              ].map((p, i) => (
                <span key={i} className="absolute rounded-full bg-[#00DB8E]/50 animate-float" style={{ left: p.l, top: '55%', width: p.s, height: p.s, animationDelay: p.d, animationDuration: p.du }} />
              ))}
              <p className="font-bold text-[#005E3C] text-[13px] relative">.animate-float</p>
              <p className="text-[11px] text-[#005E3C]/70 relative">Pétalos a la deriva</p>
            </div>

            {/* Órbita */}
            <div className="brand-gradient rounded-[20px] p-5 h-40 flex flex-col justify-end relative overflow-hidden">
              <div className="mb-auto relative grid place-items-center w-12 h-12">
                <KoaFlor color="#00DB8E" className="w-6 h-6 col-start-1 row-start-1" />
                {[0, 1, 2].map((i) => (
                  <span key={i} className="col-start-1 row-start-1 w-2 h-2 rounded-full bg-[#00DB8E] animate-orbit" style={{ animationDelay: `${i * 0.5}s` }} />
                ))}
              </div>
              <p className="font-bold text-white text-[13px]">.animate-orbit</p>
              <p className="text-[11px] text-white/65">Pétalos orbitando la K</p>
            </div>

            {/* Borde que respira */}
            <div className="rounded-[20px] p-5 h-40 flex flex-col justify-end bg-white border border-[#00DB8E]/30 animate-border-glow relative overflow-hidden">
              <div className="mb-auto"><UiIconTile toneName="mint"><KoaIcon name="shield" size={18} color="#005E3C" /></UiIconTile></div>
              <p className="font-bold text-ink text-[13px]">.animate-border-glow</p>
              <p className="text-[11px] text-[#6B7280]">Borde mint que respira</p>
            </div>

            {/* Destellos */}
            <div className="brand-gradient rounded-[20px] p-5 h-40 flex flex-col justify-end relative overflow-hidden">
              {[
                { l: '18%', t: '24%', d: '0s' },
                { l: '60%', t: '18%', d: '0.7s' },
                { l: '78%', t: '40%', d: '1.3s' },
                { l: '35%', t: '46%', d: '1.9s' },
              ].map((s, i) => (
                <span key={i} className="absolute text-[#00DB8E] animate-twinkle" style={{ left: s.l, top: s.t, animationDelay: s.d }}>
                  <KoaIcon name="star" size={14} color="#00DB8E" />
                </span>
              ))}
              <p className="font-bold text-white text-[13px]">.animate-twinkle</p>
              <p className="text-[11px] text-white/65">Destellos intermitentes</p>
            </div>

            {/* Loader */}
            <div className="rounded-[20px] p-5 h-40 flex flex-col justify-end bg-white border border-[#E8ECF2] relative overflow-hidden">
              <div className="mb-auto w-8 h-8 rounded-full border-[3px] border-[#EDEFF3] border-t-[#00DB8E] spin-slow" />
              <p className="font-bold text-ink text-[13px]">.spin-slow</p>
              <p className="text-[11px] text-[#6B7280]">Indicador de carga</p>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* PRODUCTOS KOA — capa de dominio fintech */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="productos">
          <SectionTitle kicker="Dominio KOA · Capa 2">Productos KOA</SectionTitle>
          <p className="text-[14px] text-[#6B7280] max-w-2xl -mt-2 mb-6">
            Piezas de negocio construidas sobre las primitivas — CDT, libranza, tasas y metas.
            Cifras en Space Grotesk, sellos regulatorios y el lema siempre presente.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* CDT card · superficie .brand-gradient */}
            <div className="brand-gradient aurora rounded-[20px] overflow-hidden relative p-6 text-white shadow-[0_18px_40px_-16px_rgba(12,30,76,0.7)] transition-transform duration-300 hover:-translate-y-0.5">
              <KoaFlor half animate="sway" color="#00DB8E" showK={false} className="absolute -top-4 right-2 w-40 h-20 opacity-25 pointer-events-none" />
              <div className="relative flex items-start justify-between">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold tracking-[0.14em] uppercase text-[#00DB8E]"><KoaFlor color="#00DB8E" showK={false} className="w-3 h-3" /> CDT Digital</span>
                  <p className="mt-2 text-[13px] text-white/60">Tu inversión a plazo fijo</p>
                </div>
                <UiIconTile toneName="mint"><KoaIcon name="cdt" size={20} /></UiIconTile>
              </div>
              <div className="relative mt-6">
                <p className="text-[11px] text-white/50">Rendimiento E.A.</p>
                <p className="font-figures text-[38px] font-bold text-white leading-none money-glow">12,20<span className="text-[20px] text-[#00DB8E]">%</span></p>
              </div>
              <div className="relative mt-6">
                <div className="flex items-center justify-between text-[11px] mb-1.5">
                  <span className="text-white/60">Plazo transcurrido</span>
                  <span className="font-figures font-bold text-[#00DB8E]">34%</span>
                </div>
                <div className="h-2 rounded-full bg-white/[0.14] overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700" style={{ width: '34%', background: 'linear-gradient(90deg,#00A870,#00DB8E)' }} />
                </div>
                <div className="flex items-center justify-between text-[11px] text-white/50 mt-1.5 font-figures">
                  <span>$10.000.000</span><span>Vence 12 dic 2026</span>
                </div>
              </div>
              <div className="relative mt-6 pt-5 border-t border-white/10 flex items-center justify-between gap-3">
                <div className="text-[12px]">
                  <p className="text-white/50">Ganancia proyectada</p>
                  <p className="font-figures font-bold text-[#00DB8E] text-[15px]">+$1.220.000</p>
                </div>
                <Button variant="mint" size="sm" trailingIcon={<KoaIcon name="arrow" size={16} />}>Renovar CDT</Button>
              </div>
            </div>

            {/* Libranza credit card · layout partido (panel mint + base blanca) */}
            <Card spotlight className="relative overflow-hidden p-0 flex flex-col">
              {/* Panel superior · mint-gradient con textura */}
              <div className="relative mint-gradient px-6 pt-6 pb-5 text-[#0C1E4C] overflow-hidden">
                <div className="absolute inset-0 opacity-[0.10] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #0C1E4C 1px, transparent 1px)', backgroundSize: '15px 15px' }} />
                <KoaFlor half color="#0C1E4C" showK={false} className="absolute -top-3 right-1 w-32 h-16 opacity-[0.14] pointer-events-none" />
                <div className="relative flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-white/85 flex items-center justify-center shadow-sm"><KoaIcon name="credit" size={18} color="#005E3C" /></div>
                    <div>
                      <span className="text-[10px] font-bold tracking-[0.14em] uppercase text-[#0C1E4C]">Libranza</span>
                      <p className="text-[12px] text-[#0C1E4C]/70 leading-tight">Descuento de nómina</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-[#0C1E4C] bg-white/85 px-2.5 py-1 rounded-full shadow-sm">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#005E3C] animate-pulse" />Al día
                  </span>
                </div>
                <div className="relative mt-5">
                  <p className="text-[11px] text-[#0C1E4C]/65 font-semibold">Cuota mensual</p>
                  <p className="font-figures text-[34px] font-bold text-[#0C1E4C] leading-none mt-0.5">$1.240.000</p>
                </div>
              </div>
              {/* Base blanca · detalles */}
              <div className="relative px-6 pt-5 pb-6 flex flex-col gap-5">
                <div className="grid grid-cols-3 gap-3 text-center">
                  {[
                    { k: 'Tasa', v: '1,45%', s: 'M.V.' },
                    { k: 'Plazo', v: '48', s: 'cuotas' },
                    { k: 'Restante', v: '$52M', s: 'saldo' },
                  ].map((c) => (
                    <div key={c.k} className="rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/20 px-2 py-2.5">
                      <p className="text-[10px] text-[#00A870] font-semibold">{c.k}</p>
                      <p className="font-figures text-[15px] font-bold text-[#005E3C] leading-none mt-0.5">{c.v}</p>
                      <p className="text-[9px] text-[#9CA3AF] mt-0.5">{c.s}</p>
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-[#6B7280] mb-1.5">
                    <span>Cuota 6 de 48</span>
                    <span className="font-figures font-bold text-ink">12,5% pagado</span>
                  </div>
                  <div className="h-2 rounded-full bg-[#EDEFF3] overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: '12.5%', background: 'linear-gradient(90deg,#0098FF,#00DB8E)' }} />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="primary" size="sm" leadingIcon={<KoaIcon name="calculator" size={16} />}>Simular abono</Button>
                  <Button variant="secondary" size="sm" leadingIcon={<KoaIcon name="invoice" size={16} />}>Extracto</Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Quick fintech KPIs / actions */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
            <StatCard label="Ahorro total" value="$58.4M" tone="mint" icon={<KoaIcon name="piggy" size={20} />} accent />
            <StatCard label="Meta de casa" value="72" unit="%" tone="info" icon={<KoaIcon name="target" size={20} />} trend={{ value: '+8% mes', direction: 'up' }} />
            <StatCard label="Rendimientos" value="+$1.45M" tone="success" icon={<KoaIcon name="growth" size={20} />} />
            <StatCard label="Cashback" value="$92K" tone="navy" icon={<KoaIcon name="star" size={20} />} />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            {[
              { icon: 'send', label: 'Enviar' },
              { icon: 'receive', label: 'Recibir' },
              { icon: 'qr', label: 'Pagar QR' },
              { icon: 'calculator', label: 'Simular' },
            ].map(a => (
              <button key={a.label} className="icon-anim group card-flat p-4 flex flex-col items-center gap-2 hover:shadow-md transition-shadow focus-ring">
                <span className="w-11 h-11 rounded-xl bg-[#EFFFF7] group-hover:bg-[#00DB8E] transition-colors flex items-center justify-center">
                  <span className="icon-pop"><KoaIcon name={a.icon} size={20} color="#005E3C" /></span>
                </span>
                <span className="text-[12px] font-bold text-ink">{a.label}</span>
              </button>
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 12. ANIMACIONES ─────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="animaciones">
          <SectionTitle kicker="Motion & CSS">Animaciones y transiciones</SectionTitle>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            <AnimDemo name="card-enter" desc="slideUp · entrada de cards">
              <div className="w-full bg-white rounded-xl border border-[#E8ECF2] p-3 text-center">
                <p className="text-[11px] font-bold text-[#2A3036]">Card</p>
              </div>
            </AnimDemo>
            <AnimDemo name="scale-in" cls="scale-in" desc="scaleIn · modales / éxito">
              <div className="w-10 h-10 rounded-xl bg-[#EFFFF7] border border-[#00DB8E]/30 flex items-center justify-center">
                <KoaIcon name="check" size={18} color="#00DB8E" />
              </div>
            </AnimDemo>
            <AnimDemo name="fade-in" cls="fade-in" desc="fadeIn · overlays">
              <div className="w-20 h-8 rounded-xl bg-[#06005A]/20 flex items-center justify-center">
                <p className="text-[11px] font-bold text-[#06005A]">Overlay</p>
              </div>
            </AnimDemo>
            <AnimDemo name="animate-float" cls="animate-float" desc="floatY · partículas decorativas">
              <div className="w-3 h-3 rounded-full bg-[#00DB8E]" />
            </AnimDemo>
            <AnimDemo name="animate-float-x" cls="animate-float-x" desc="floatX · elementos horizontales">
              <div className="w-3 h-3 rounded-full bg-[#06005A]" />
            </AnimDemo>
            <AnimDemo name="animate-number-pop" cls="animate-number-pop" desc="numberPop · métricas / tasas">
              <p className="font-figures font-black text-[#00DB8E] text-[28px] leading-none">12,20%</p>
            </AnimDemo>
            <AnimDemo name="animate-drift" cls="animate-drift" desc="driftOut · partículas que escapan">
              <div className="w-2 h-2 rounded-full bg-[#00DB8E]/60" />
            </AnimDemo>
            <AnimDemo name="animate-pulse-ring" cls="animate-pulse-ring" desc="pulseRing · confirmación">
              <div className="w-6 h-6 rounded-full border-2 border-[#00DB8E]" />
            </AnimDemo>
            <AnimDemo name="animate-orbit" cls="animate-orbit" desc="orbitSlow · elementos orbitales">
              <div className="w-2 h-2 rounded-full bg-[#06005A]" />
            </AnimDemo>
            <AnimDemo name="animate-twinkle" cls="animate-twinkle" desc="twinkle · destellos">
              <div className="w-2 h-2 rotate-45 bg-[#00DB8E]" />
            </AnimDemo>
            <AnimDemo name="mint-pulse" cls="mint-pulse" desc="limePulse · dots de estado">
              <div className="w-2.5 h-2.5 rounded-full bg-[#00DB8E]" />
            </AnimDemo>
            <AnimDemo name="animate-gradient-shift" desc="gradientShift · fondos animados">
              <div className="w-full h-10 rounded-xl animate-gradient-shift" style={{ background: 'linear-gradient(135deg, #06005A, #00DB8E, #06005A)', backgroundSize: '200% 200%' }} />
            </AnimDemo>
          </div>
          <div className="mt-6">
            <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Stagger helpers (.stagger-1 a .stagger-5)</p>
            <div className="flex gap-3">
              {[1,2,3,4,5].map(n => (
                <div key={n} className={`card-enter stagger-${n} flex-1 bg-white rounded-xl border border-[#E8ECF2] p-3 text-center`}>
                  <p className="text-[11px] font-bold text-[#2A3036]">.stagger-{n}</p>
                  <p className="font-figures text-[10px] text-gray-400">{n * 50}ms</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════ */}
        {/* 13. CLASES CSS ───────────────────────────────── */}
        {/* ═══════════════════════════════════════════════════ */}
        <section id="clases">
          <SectionTitle kicker="Motion & CSS">Utilidades CSS</SectionTitle>
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { cls: '.card', desc: 'Card blanca con sombra suave y hover lift + shadow' },
                { cls: '.card-flat', desc: 'Card blanca con sombra sin hover' },
                { cls: '.card-enter', desc: 'slideUp 0.4s entrada — aplicar en montaje de tarjeta' },
                { cls: '.fade-in', desc: 'fadeIn 0.3s — overlays y transiciones suaves' },
                { cls: '.scale-in', desc: 'scaleIn 0.3s — iconos de confirmación / modales' },
                { cls: '.shimmer', desc: 'Skeleton shimmer animado para loading states' },
                { cls: '.glass', desc: 'Glassmorphism: bg rgba(255,255,255,0.9) + blur(16px)' },
                { cls: '.card-glass', desc: 'Glass para fondos oscuros: bg rgba(255,255,255,0.06)' },
                { cls: '.sidebar-gradient', desc: 'Fondo del sidebar nav: #06005A' },
                { cls: '.btn-mint-glow', desc: 'Glow shadow mint para botones de acción principal' },
                { cls: '.nav-active', desc: 'Estado activo en navegación: bg rgba(0,219,142,0.12)' },
                { cls: '.progress-glow', desc: 'Glow azul en barras de progreso CDT' },
                { cls: '.quick-link', desc: 'Hover lift para accesos rápidos del home' },
                { cls: '.fab', desc: 'Floating action button con sombra profunda' },
                { cls: '.mint-pulse', desc: 'Pulso limePulse 2s en dots de estado activo' },
                { cls: '.scrollable', desc: 'Muestra scrollbar al hover (thin, gris, transparente)' },
                { cls: '.font-figures', desc: 'Space Grotesk — familia para datos y números' },
                { cls: '.gradient-border', desc: '::before pseudo-element con borde gradiente mint→navy' },
                { cls: '.animate-gradient-shift', desc: 'gradientShift 5s en background-position para fondos vivos' },
                { cls: '.animate-border-glow', desc: 'borderGlow 3s pulse en box-shadow mint' },
                { cls: '.stagger-1 a .stagger-5', desc: 'Delays de 50ms a 250ms para listas de cards' },
              ].map(c => (
                <div key={c.cls} className="flex items-start gap-3 bg-white rounded-xl border border-[#E8ECF2] px-4 py-3">
                  <code className="flex-shrink-0 text-[11px] font-black text-[#06005A] bg-[#06005A]/[0.07] px-2 py-0.5 rounded-lg whitespace-nowrap">{c.cls}</code>
                  <p className="text-[12px] text-gray-500 leading-snug">{c.desc}</p>
                </div>
              ))}
            </div>
            <div>
              <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">Efectos especiales</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] text-gray-400 mb-2">.glass</p>
                  <div className="relative overflow-hidden rounded-2xl h-24" style={{ background: 'linear-gradient(135deg, #06005A, #00DB8E)' }}>
                    <div className="glass absolute inset-3 rounded-xl flex items-center justify-center">
                      <p className="text-[12px] font-bold text-[#2A3036]">Glass panel</p>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 mb-2">.gradient-border</p>
                  <div className="gradient-border rounded-2xl bg-white p-5 h-24 flex items-center justify-center">
                    <p className="text-[12px] font-bold text-[#2A3036]">Borde gradiente mint→navy</p>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 mb-2">.btn-mint-glow</p>
                  <div className="flex items-center justify-center h-24 bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2]">
                    <button className="bg-[#00DB8E] text-[#06005A] font-black text-[14px] px-6 py-3 rounded-2xl btn-mint-glow cursor-pointer">
                      Acción principal
                    </button>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 mb-2">.animate-border-glow</p>
                  <div className="flex items-center justify-center h-24 bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2]">
                    <div className="w-24 h-12 rounded-xl border-2 border-[#00DB8E] animate-border-glow" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

      </div>

      <div className="mt-20 mb-8 border-t border-[#E8ECF2] pt-6 flex items-center justify-between">
        <p className="text-[11px] text-gray-400">KOA · Sistema de diseño · Portal C.F. v1.0</p>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E] mint-pulse" />
          <p className="text-[11px] font-bold text-[#005E3C]">Actualizado 2026</p>
        </div>
      </div>
    </div>
  )
}

/* ── FilterChips demo ─────────────────────────────────────── */
function FilterChipsDemo() {
  const [v, setV] = useState('todos')
  const opts = [
    { label: 'Todos', value: 'todos' },
    { label: 'Activos', value: 'activos' },
    { label: 'Terminados', value: 'terminados' },
    { label: 'En mora', value: 'mora' },
  ]
  return (
    <div className="flex flex-col gap-4">
      <FilterChips options={opts} value={v} onChange={setV} />
      <p className="text-[11px] text-gray-400">
        Filtro activo: <span className="font-bold text-[#06005A]">{opts.find(o => o.value === v)?.label}</span>
      </p>
    </div>
  )
}

/* ── SidePanel demo ───────────────────────────────────────── */
function SidePanelDemo() {
  const [open, setOpen] = useState(false)
  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex items-center gap-4">
      <Btn variant="secondary" size="md" onClick={() => setOpen(true)}>
        Abrir panel lateral
      </Btn>
      <p className="text-[12px] text-gray-400">width: 380px · backdrop oscuro · cierre con clic fuera</p>
      <SidePanel open={open} onClose={() => setOpen(false)} title="Notificaciones">
        <div className="px-5 py-4 flex flex-col gap-3">
          {[
            { icon: 'clock', color: '#FFD400', bg: '#FFFBEB', title: 'Cuota próxima a vencer', time: 'Hace 2 h', unread: true },
            { icon: 'check', color: '#059669', bg: '#ECFDF5', title: 'Pago registrado exitosamente', time: 'Hace 1 d', unread: true },
            { icon: 'cdt',   color: '#0068B3', bg: '#EBF5FF', title: 'CDT renovado automáticamente', time: 'Hace 3 d', unread: false },
          ].map((n, i) => (
            <div key={i} className={`flex items-start gap-3 rounded-xl p-3 ${n.unread ? 'bg-[#EFFFF7]/60' : 'bg-white'}`}>
              <div className="w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center" style={{ background: n.bg }}>
                <KoaIcon name={n.icon} size={16} color={n.color} />
              </div>
              <div className="flex-1">
                <p className="text-[13px] font-semibold text-[#2A3036] leading-snug">{n.title}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{n.time}</p>
              </div>
              {n.unread && <div className="w-2 h-2 rounded-full bg-[#00DB8E] flex-shrink-0 mt-1.5" />}
            </div>
          ))}
        </div>
      </SidePanel>
    </div>
  )
}

/* ── Toast demo ───────────────────────────────────────────── */
type ToastType = 'success' | 'neutral' | 'error'
const TOAST_META: Record<ToastType, {
  icon: string; accent: string; iconBg: string; iconColor: string; bar: string; title: string; body: string
}> = {
  success: { icon: 'check',  accent: '#00DB8E', iconBg: '#EFFFF7', iconColor: '#005E3C', bar: '#00DB8E', title: 'Operación exitosa',  body: 'Tu documento se descargó correctamente.' },
  neutral: { icon: 'notify', accent: '#06005A', iconBg: '#F0F2F5', iconColor: '#06005A', bar: '#06005A', title: 'Cambios guardados',   body: 'Actualizamos tu información sin novedad.' },
  error:   { icon: 'xmark',  accent: '#F70C5B', iconBg: '#FFF0F5', iconColor: '#F70C5B', bar: '#F70C5B', title: 'No se pudo completar', body: 'Revisa los datos e inténtalo nuevamente.' },
}

function ToastDemo() {
  const [toast, setToast] = useState<ToastType | null>(null)
  const show = (type: ToastType) => {
    setToast(type)
    setTimeout(() => setToast(null), 4000)
  }
  const meta = toast ? TOAST_META[toast] : null
  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex flex-col gap-4">
      <div className="flex flex-wrap gap-3">
        <Btn variant="mint" size="sm" onClick={() => show('success')}>Toast de éxito</Btn>
        <Btn variant="secondary" size="sm" onClick={() => show('neutral')}>Toast neutral</Btn>
        <Btn variant="danger" size="sm" onClick={() => show('error')}>Toast de error</Btn>
      </div>
      <div className="relative min-h-[132px] bg-[#F7F7F7] rounded-xl overflow-hidden flex items-end justify-center px-4 pb-4">
        <p className="absolute top-4 left-1/2 -translate-x-1/2 text-[11px] text-gray-300 font-semibold">Simulación de posición fixed bottom</p>
        {meta && (
          <div
            role="status"
            aria-live="polite"
            className="w-full max-w-md bg-white rounded-2xl shadow-[0_16px_40px_-12px_rgba(6,0,90,0.28)] ring-1 ring-black/[0.04] overflow-hidden flex items-stretch slide-up-toast"
          >
            {/* Barra de acento por tipo */}
            <span className="w-1.5 flex-shrink-0" style={{ background: meta.bar }} />
            <div className="flex items-start gap-3.5 px-4 py-3.5 flex-1">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: meta.iconBg }}>
                <KoaIcon name={meta.icon} size={20} color={meta.iconColor} />
              </div>
              <div className="min-w-0 flex-1 pt-0.5">
                <p className="text-[14px] font-bold text-[#2A3036] leading-tight">{meta.title}</p>
                <p className="text-[12.5px] text-[#6B7280] leading-snug mt-1">{meta.body}</p>
              </div>
              <button
                onClick={() => setToast(null)}
                aria-label="Cerrar notificación"
                className="w-6 h-6 rounded-lg flex items-center justify-center text-gray-300 hover:text-[#2A3036] hover:bg-[#F0F2F5] transition-colors flex-shrink-0 cursor-pointer"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* ── OTP modal demo ───────────────────────────────────────── */
function OtpModalDemo() {
  const [open, setOpen] = useState(false)
  const [digits, setDigits] = useState(['','','','','',''])
  const [phase, setPhase] = useState<'input' | 'validating' | 'success' | 'error'>('input')
  const [step, setStep] = useState(0)
  const [seconds, setSeconds] = useState(180)
  const [resendIn, setResendIn] = useState(30)
  const [resending, setResending] = useState(false)
  const [resentAt, setResentAt] = useState(0)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  const DEMO_CODE = '248731'

  useEffect(() => {
    if (!open) { setDigits(['','','','','','']); setPhase('input'); setStep(0); setSeconds(180); setResendIn(30); setResending(false); setResentAt(0) }
  }, [open])

  useEffect(() => {
    if (phase !== 'input' || !open) return
    const t = setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [phase, open])

  // Cooldown de reenvío
  useEffect(() => {
    if (!open || resendIn <= 0) return
    const t = setInterval(() => setResendIn(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [open, resendIn])

  // Confirmación "código reenviado" se autooculta
  useEffect(() => {
    if (!resentAt) return
    const t = setTimeout(() => setResentAt(0), 3200)
    return () => clearTimeout(t)
  }, [resentAt])

  const handleResend = () => {
    if (resendIn > 0 || resending || phase !== 'input') return
    setResending(true)
    setTimeout(() => {
      setResending(false)
      setDigits(['','','','','',''])
      setSeconds(180)
      setResendIn(30)
      setResentAt(Date.now())
      inputRefs.current[0]?.focus()
    }, 1200)
  }

  useEffect(() => {
    if (phase !== 'validating') return
    const timers = [
      setTimeout(() => setStep(1), 600),
      setTimeout(() => setStep(2), 1300),
      setTimeout(() => setStep(3), 2000),
      setTimeout(() => { const entered = digits.join(''); setPhase(entered === DEMO_CODE ? 'success' : 'error') }, 2600),
    ]
    return () => timers.forEach(clearTimeout)
  }, [phase, digits])

  useEffect(() => {
    if (phase === 'error') {
      const t = setTimeout(() => { setDigits(['','','','','','']); setPhase('input'); setStep(0) }, 1800)
      return () => clearTimeout(t)
    }
  }, [phase])

  const handleDigit = (i: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1)
    const next = [...digits]; next[i] = ch; setDigits(next)
    if (ch && i < 5) inputRefs.current[i + 1]?.focus()
    if (next.every(d => d !== '') && ch) setTimeout(() => setPhase('validating'), 200)
  }

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`

  const steps = ['Verificando identidad', 'Validando operación', 'Generando resultados']

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5 flex items-center gap-4">
      <Btn variant="primary" size="md" onClick={() => setOpen(true)}>
        Abrir FirmaElectronica
      </Btn>
      <p className="text-[12px] text-gray-400">Código demo: <span className="font-figures font-black text-[#06005A]">248731</span></p>

      {open && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setOpen(false) }}>
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden scale-in">
            {/* Header */}
            <div className="bg-[#06005A] px-6 py-5 relative overflow-hidden">
              <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-[#00DB8E]/10 pointer-events-none" />
              <button onClick={() => setOpen(false)} className="absolute top-4 right-4 w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
              <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">Actualización de datos</p>
              <p className="text-white font-black text-[18px] mt-1 leading-tight">Autorizar operación</p>
              <p className="text-white/55 text-[12px] mt-1">Ingresa el código enviado a tu correo y celular registrado para confirmar</p>
            </div>

            <div className="px-6 py-6 relative min-h-[264px] flex flex-col justify-center">
              {/* Validating overlay */}
              {(phase === 'validating' || phase === 'success' || phase === 'error') && (
                <div className="absolute inset-0 bg-white/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-5 px-6 py-6 rounded-b-3xl">
                  {/* Icon — rings spin only while validating; result is a clean solid disc */}
                  <div className="relative w-16 h-16 flex items-center justify-center">
                    {phase === 'validating' ? (
                      <>
                        <div className="absolute inset-0 rounded-full border-2 border-[#06005A]/15 border-t-[#06005A] animate-spin" />
                        <div className="absolute inset-[9px] rounded-full border-2 border-[#00DB8E]/25 border-t-[#00DB8E] animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                        <span className="w-2.5 h-2.5 rounded-full bg-[#06005A] mint-pulse" />
                      </>
                    ) : (
                      <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-[#00DB8E]' : 'bg-[#FA467F]'}`}>
                        {phase === 'success'
                          ? <KoaIcon name="check" size={26} color="#06005A" />
                          : <KoaIcon name="xmark" size={26} color="white" />}
                      </div>
                    )}
                  </div>
                  {/* Steps — on error the failing step shows the X so it matches the icon */}
                  <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
                    {steps.map((s, i) => {
                      const failIdx = steps.length - 1
                      const failed = phase === 'error' && i === failIdx
                      const done = phase === 'success' || (phase === 'error' ? i < failIdx : step > i)
                      const active = phase === 'validating' && step === i
                      return (
                        <div key={s} className="flex items-center gap-2.5">
                          <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-[#00DB8E]' : failed ? 'bg-[#FA467F]' : active ? 'bg-[#06005A]/10' : 'bg-[#F0F2F5]'}`}>
                            {done && <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                            {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                            {active && <span className="w-1.5 h-1.5 rounded-full bg-[#06005A] mint-pulse" />}
                          </div>
                          <p className={`text-[11px] font-semibold ${done ? 'text-[#005E3C]' : failed ? 'text-[#F70C5B]' : active ? 'text-[#2A3036]' : 'text-gray-300'}`}>{s}</p>
                        </div>
                      )
                    })}
                  </div>
                  {phase === 'error' && <p className="text-[12px] font-bold text-[#F70C5B]">Código incorrecto</p>}
                </div>
              )}

              {/* OTP input — grid de 6 columnas: escala al ancho del modal */}
              <div className={`grid grid-cols-6 gap-1.5 sm:gap-2 mb-4 ${phase === 'error' ? 'animate-[shake_0.35s_ease-in-out]' : ''}`}>
                {digits.map((d, i) => (
                  <input
                    key={i}
                    ref={el => { inputRefs.current[i] = el }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={d}
                    onChange={e => handleDigit(i, e.target.value)}
                    onKeyDown={e => { if (e.key === 'Backspace' && !d && i > 0) inputRefs.current[i - 1]?.focus() }}
                    className={`w-full h-12 text-center font-figures font-black text-[20px] rounded-xl border-2 outline-none transition-all ${d ? 'border-[#06005A] bg-[#06005A]/[0.05] text-[#06005A]' : 'border-[#E8ECF2] bg-white'}`}
                    disabled={phase !== 'input'}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between gap-3">
                <p className="font-figures text-[12px] text-gray-400">Código válido por <span className={`font-bold ${seconds < 30 ? 'text-[#F70C5B]' : 'text-[#2A3036]'}`}>{fmt}</span></p>
                {resending ? (
                  <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A]">
                    <span className="w-3.5 h-3.5 rounded-full border-2 border-[#06005A]/25 border-t-[#06005A] animate-spin" />
                    Enviando…
                  </span>
                ) : resendIn > 0 ? (
                  <span aria-hidden />
                ) : (
                  <button
                    onClick={handleResend}
                    disabled={phase !== 'input'}
                    className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A] hover:text-[#08007A] cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    <KoaIcon name="refresh" size={13} color="currentColor" />
                    Reenviar código
                  </button>
                )}
              </div>

              {/* Confirmación de reenvío */}
              {resentAt ? (
                <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5 fade-in">
                  <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                    <KoaIcon name="check" size={12} color="#06005A" />
                  </div>
                  <p className="text-[11px] text-[#005E3C] font-semibold">Enviamos un nuevo código a tu correo y celular registrado.</p>
                </div>
              ) : (
                <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2 flex items-center gap-2">
                  <KoaIcon name="shield" size={12} color="#00DB8E" />
                  <p className="text-[11px] text-[#005E3C]">Demo: código es <span className="font-figures font-black">248731</span></p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ── ValidatingOverlay demo ───────────────────────────────── */
function ValidatingOverlayDemo() {
  const [phase, setPhase] = useState<'idle' | 'running' | 'success' | 'error'>('idle')
  const [step, setStep] = useState(0)

  const run = (outcome: 'success' | 'error') => {
    setPhase('running'); setStep(0)
    setTimeout(() => setStep(1), 700)
    setTimeout(() => setStep(2), 1400)
    setTimeout(() => setStep(3), 2100)
    setTimeout(() => setPhase(outcome), 2700)
  }

  const steps = ['Verificando identidad', 'Validando operación', 'Generando resultados']

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
      <div className="flex items-center gap-3 px-5 py-4 border-b border-[#F0F2F5]">
        <Btn variant="mint" size="sm" onClick={() => run('success')} disabled={phase === 'running'}>Simular éxito</Btn>
        <Btn variant="danger" size="sm" onClick={() => run('error')} disabled={phase === 'running'}>Simular error</Btn>
        {phase !== 'idle' && phase !== 'running' && (
          <button onClick={() => { setPhase('idle'); setStep(0) }} className="text-[12px] font-bold text-gray-400 hover:text-[#2A3036] cursor-pointer transition-colors">Reiniciar</button>
        )}
      </div>
      <div className="relative min-h-[240px] flex items-center justify-center bg-[#F7F7F7]">
        {phase === 'idle' && <p className="text-[12px] text-gray-300 font-semibold">Presiona un botón para simular</p>}
        {phase !== 'idle' && (
          <div className="flex flex-col items-center gap-5 px-6 py-6">
            {/* Icon — rings spin only while validating; result is a clean solid disc */}
            <div className="relative w-16 h-16 flex items-center justify-center">
              {phase === 'running' ? (
                <>
                  <div className="absolute inset-0 rounded-full border-2 border-[#06005A]/15 border-t-[#06005A] animate-spin" />
                  <div className="absolute inset-[9px] rounded-full border-2 border-[#00DB8E]/25 border-t-[#00DB8E] animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06005A] mint-pulse" />
                </>
              ) : (
                <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-[#00DB8E]' : 'bg-[#FA467F]'}`}>
                  {phase === 'success'
                    ? <KoaIcon name="check" size={26} color="#06005A" />
                    : <KoaIcon name="xmark" size={26} color="white" />}
                </div>
              )}
            </div>
            {/* Steps — on error the failing step shows the X so it matches the icon */}
            <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
              {steps.map((s, i) => {
                const failIdx = steps.length - 1
                const failed = phase === 'error' && i === failIdx
                const done = phase === 'success' || (phase === 'error' ? i < failIdx : step > i)
                const active = step === i && phase === 'running'
                return (
                  <div key={s} className="flex items-center gap-2.5">
                    <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-[#00DB8E]' : failed ? 'bg-[#FA467F]' : active ? 'bg-[#06005A]/10' : 'bg-[#F0F2F5]'}`}>
                      {done && <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                      {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                      {active && <span className="w-1.5 h-1.5 rounded-full bg-[#06005A] mint-pulse" />}
                    </div>
                    <p className={`text-[11px] font-semibold ${done ? 'text-[#005E3C]' : failed ? 'text-[#F70C5B]' : active ? 'text-[#2A3036]' : 'text-gray-300'}`}>{s}</p>
                  </div>
                )
              })}
            </div>
            {phase === 'error' && <p className="text-[12px] font-bold text-[#F70C5B]">Código incorrecto</p>}
          </div>
        )}
      </div>
    </div>
  )
}

/* ── Stepper demo ─────────────────────────────────────────── */
function StepperDemo() {
  const [current, setCurrent] = useState(0)
  const steps = [
    { label: 'Verificación', caption: 'Identidad OTP', icon: 'security', desc: 'Confirmamos que eres tú con un código de un solo uso enviado a tus canales registrados.' },
    { label: 'Selección',    caption: 'Producto',      icon: 'cdt',      desc: 'Elige el CDT y el monto que quieres gestionar; calculamos tus rendimientos al instante.' },
    { label: 'Certificado',  caption: 'Documento',     icon: 'document', desc: 'Generamos y firmamos digitalmente tu certificado, listo para descargar y compartir.' },
  ]
  const pct = Math.round((current / (steps.length - 1)) * 100)

  return (
    <div className="rounded-3xl overflow-hidden border border-[#E8ECF2] shadow-[0_10px_36px_-16px_rgba(6,0,90,0.28)]">
      {/* Header — minimalista */}
      <div className="px-6 py-4" style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}>
        {/* Meta compacta + progreso */}
        <div className="flex items-center justify-between mb-3.5">
          <p className="text-[11px] font-semibold text-white/60">Paso <span className="font-figures font-bold text-white">{current + 1}</span> de {steps.length}</p>
          <p className="font-figures text-[11px] font-bold text-[#00DB8E]">{pct}%</p>
        </div>

        {/* Círculos + conectores */}
        <div className="flex items-center">
          {steps.map((s, i) => {
            const done = i < current
            const active = i === current
            return (
              <div key={s.label} className="flex items-center flex-1 last:flex-none">
                <button onClick={() => setCurrent(i)} className="group flex items-center gap-2 cursor-pointer shrink-0">
                  <div className="relative flex items-center justify-center">
                    {active && <span className="absolute inset-0 rounded-full bg-white/25 animate-pulse-ring" />}
                    <div className={`relative w-7 h-7 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                      done ? 'bg-[#00DB8E] border-[#00DB8E]'
                      : active ? 'bg-white border-white shadow-[0_4px_14px_-2px_rgba(0,219,142,0.5)]'
                      : 'border-white/25 group-hover:border-white/50'
                    }`}>
                      {done ? (
                        <svg className="w-3.5 h-3.5 text-[#06005A] scale-in" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                      ) : (
                        <KoaIcon name={s.icon} size={15} color={active ? '#06005A' : 'rgba(255,255,255,0.5)'} />
                      )}
                    </div>
                  </div>
                  <p className={`text-[11px] font-bold whitespace-nowrap transition-colors ${active ? 'text-white' : done ? 'text-[#00DB8E]' : 'text-white/40'} ${active ? '' : 'hidden sm:block'}`}>{s.label}</p>
                </button>
                {i < steps.length - 1 && (
                  <div className="flex-1 h-[2px] rounded-full bg-white/12 mx-2 overflow-hidden">
                    <div className="h-full rounded-full bg-[#00DB8E] transition-[width] duration-500 ease-out" style={{ width: done ? '100%' : '0%' }} />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* Body — compacto */}
      <div className="bg-white px-6 py-4 flex items-center justify-between gap-4">
        <p key={current} className="text-[12.5px] text-[#6B7280] leading-snug fade-in min-w-0">
          <span className="font-bold text-[#2A3036]">{steps[current].label}.</span> {steps[current].desc}
        </p>
        <div className="flex gap-2 shrink-0">
          <Btn variant="secondary" size="sm" disabled={current === 0} onClick={() => setCurrent(c => c - 1)}>Atrás</Btn>
          <Btn variant="primary" size="sm" disabled={current === steps.length - 1} onClick={() => setCurrent(c => c + 1)}>Siguiente</Btn>
        </div>
      </div>
    </div>
  )
}

/* ── Acordeón demo ────────────────────────────────────────── */
function AcordeonDemo() {
  const [open, setOpen] = useState<string | null>('datos')
  const sections = [
    { id: 'datos', icon: 'profile', label: 'Datos personales', meta: '5 campos', complete: true, content: 'Nombres, apellidos, tipo y número de documento, fecha de nacimiento.' },
    { id: 'contacto', icon: 'contact', label: 'Información de contacto', meta: '3 campos', complete: true, content: 'Correo electrónico, teléfono celular, teléfono fijo.' },
    { id: 'direccion', icon: 'home', label: 'Dirección de residencia', meta: '4 campos', complete: false, content: 'Dirección, ciudad, departamento, código postal.' },
    { id: 'financiero', icon: 'coin', label: 'Información financiera', meta: '3 campos', complete: false, content: 'Ingresos mensuales, egresos, actividad económica.' },
  ]
  const done = sections.filter(s => s.complete).length
  return (
    <div className="space-y-2.5">
      {/* Encabezado con progreso */}
      <div className="flex items-center justify-between px-1">
        <p className="text-[11px] font-semibold text-gray-400">Completa tu perfil</p>
        <p className="text-[11px] font-figures font-bold text-[#06005A]">{done} de {sections.length} listos</p>
      </div>

      {sections.map(s => {
        const isOpen = open === s.id
        return (
          <div
            key={s.id}
            className={`bg-white rounded-2xl border overflow-hidden transition-all duration-300 ${isOpen ? 'border-[#00DB8E]/50 shadow-[0_8px_30px_-12px_rgba(6,0,90,0.18)]' : 'border-[#E8ECF2] hover:border-[#06005A]/25'}`}
          >
            <button
              onClick={() => setOpen(isOpen ? null : s.id)}
              className="group w-full flex items-center gap-3.5 px-4 py-3.5 cursor-pointer text-left"
            >
              {/* Icon tile */}
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${isOpen ? 'bg-[#06005A] text-white' : 'bg-[#F0F2F5] text-[#06005A] group-hover:bg-[#F0F2F5]'}`}>
                <KoaIcon name={s.icon} size={18} color="currentColor" />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-[13.5px] font-bold text-[#2A3036] truncate">{s.label}</p>
                  <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${s.complete ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#FFFBEB] text-[#8A6D00]'}`}>
                    {s.complete
                      ? <><svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>Completo</>
                      : <><span className="w-1.5 h-1.5 rounded-full bg-[#FFD400]" />Pendiente</>
                    }
                  </span>
                </div>
                <p className="text-[11.5px] text-gray-400 mt-0.5">{s.meta}</p>
              </div>

              {/* Chevron disc */}
              <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${isOpen ? 'bg-[#00DB8E] text-[#06005A]' : 'bg-[#F0F2F5] text-gray-400 group-hover:text-[#06005A]'}`}>
                <svg className={`w-3.5 h-3.5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </button>

            {/* Contenido: transición suave con grid-rows */}
            <div className={`grid transition-all duration-300 ease-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
              <div className="overflow-hidden">
                <div className="px-4 pb-4 pl-[70px]">
                  <div className="border-l-2 border-[#00DB8E]/40 pl-3.5">
                    <p className="text-[12.5px] text-gray-500 leading-relaxed">{s.content}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ── UploadZone demo ──────────────────────────────────────── */
function UploadZoneDemo() {
  const [file, setFile] = useState<string | null>(null)
  const [drag, setDrag] = useState(false)
  const ref = useRef<HTMLInputElement>(null)
  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-5">
      <button
        onClick={() => ref.current?.click()}
        onDragOver={e => { e.preventDefault(); setDrag(true) }}
        onDragLeave={() => setDrag(false)}
        onDrop={e => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) setFile(f.name) }}
        className={`w-full border-2 border-dashed rounded-2xl px-6 py-8 flex flex-col items-center gap-3 cursor-pointer transition-all ${drag ? 'border-[#00DB8E] bg-[#EFFFF7]' : file ? 'border-[#059669] bg-[#ECFDF5]' : 'border-[#E8ECF2] hover:border-[#06005A]/30 bg-[#F7F7F7]'}`}
      >
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${file ? 'bg-[#ECFDF5]' : 'bg-[#F0F2F5]'}`}>
          {file
            ? <KoaIcon name="check" size={22} color="#059669" />
            : <KoaIcon name="download" size={22} color="#9CA3AF" />
          }
        </div>
        {file ? (
          <>
            <p className="text-[13px] font-bold text-[#059669]">{file}</p>
            <p className="text-[11px] text-gray-400">Clic para cambiar el archivo</p>
          </>
        ) : (
          <>
            <p className="text-[13px] font-bold text-[#2A3036]">Clic para subir PDF</p>
            <p className="text-[11px] text-gray-400">o arrastra y suelta aquí · Máx. 5 MB</p>
          </>
        )}
      </button>
      <input ref={ref} type="file" accept=".pdf" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) setFile(f.name) }} />
    </div>
  )
}

/* ── Confirmation demo ────────────────────────────────────── */
function ConfirmationDemo() {
  const [accepted, setAccepted] = useState(false)
  const [done, setDone] = useState(false)
  if (done) return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] p-8 flex flex-col items-center gap-4 scale-in">
      <div className="w-14 h-14 rounded-2xl bg-[#ECFDF5] flex items-center justify-center">
        <KoaIcon name="check" size={26} color="#059669" />
      </div>
      <div className="text-center">
        <p className="font-black text-[#2A3036] text-[16px]">Solicitud radicada</p>
        <p className="text-[13px] text-gray-500 mt-1">Radicado: <span className="font-figures font-bold">2026-KOA-004821</span></p>
      </div>
      <Btn variant="secondary" size="sm" onClick={() => { setDone(false); setAccepted(false) }}>Reiniciar demo</Btn>
    </div>
  )
  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden">
      <div className="px-5 pt-5 pb-3">
        <p className="text-[13px] font-bold text-[#2A3036] mb-3">Resumen de la operación</p>
        <div className="rounded-xl overflow-hidden border border-[#E8ECF2] divide-y divide-[#F0F2F5]">
          {[
            { label: 'Operación', value: 'Certificación de saldo' },
            { label: 'Crédito', value: 'Min. de Educación ••• 4821' },
            { label: 'Mes', value: 'Julio 2026' },
            { label: 'Costo', value: '$12.500' },
            { label: 'Tiempo de entrega', value: '2-3 días hábiles' },
          ].map(r => (
            <div key={r.label} className="flex items-center justify-between px-4 py-2.5 bg-[#F7F7F7]">
              <p className="text-[12px] text-gray-500">{r.label}</p>
              <p className="text-[12px] font-bold text-[#2A3036]">{r.value}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="px-5 pb-2">
        <label className="flex items-start gap-2.5 cursor-pointer py-2">
          <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} className="w-4 h-4 mt-0.5 accent-[#06005A] flex-shrink-0" />
          <p className="text-[12px] text-gray-500">Acepto el cobro de <span className="font-bold text-[#2A3036]">$12.500</span> y entiendo que el certificado se entregará en 2-3 días hábiles.</p>
        </label>
      </div>
      <div className="px-5 pb-5 flex gap-3">
        <Btn variant="secondary" size="md" className="flex-1">Cancelar</Btn>
        <Btn variant="primary" size="md" className="flex-1" disabled={!accepted} onClick={() => setDone(true)}>Confirmar solicitud</Btn>
      </div>
    </div>
  )
}

function PersonTypeToggle() {
  const [pt, setPt] = useState<'natural' | 'empresa'>('natural')
  return (
    <div className="bg-[#F7F7F7] rounded-2xl border border-[#E8ECF2] p-4">
      <div className="flex bg-white rounded-xl border border-[#E8ECF2] p-0.5 gap-0.5">
        {(['natural', 'empresa'] as const).map(v => (
          <button
            key={v}
            onClick={() => setPt(v)}
            className={`flex-1 py-2 rounded-lg text-[12px] font-bold cursor-pointer transition-all ${pt === v ? 'bg-[#06005A] text-white shadow-sm' : 'text-gray-400 hover:text-[#2A3036]'}`}
          >
            {v === 'natural' ? 'Persona' : 'Empresa'}
          </button>
        ))}
      </div>
      <p className="text-[11px] text-gray-400 mt-3 text-center">
        {pt === 'natural' ? 'CC / CE + Número + Clave' : 'CC / CE + Número + Clave + NIT empresa'}
      </p>
    </div>
  )
}

/* ── Arquitectura: live primitives + accessibility notes ──── */
function ArchDemo() {
  const [notifs, setNotifs] = useState(true)
  const [value, setValue] = useState('')

  return (
    <Card variant="flat" className="p-6">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Live primitives */}
        <div>
          <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">
            Primitivas en vivo
          </p>
          <div className="space-y-4">
            <Field
              label="Correo electrónico"
              type="email"
              placeholder="nombre@correo.com"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              helperText="Consume tokens y expone aria-describedby."
            />
            <div className="flex items-center justify-between">
              <span className="text-[13px] font-semibold text-[#2A3036]">Notificaciones</span>
              <Switch checked={notifs} onChange={setNotifs} label="Activar notificaciones" />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="primary" size="sm">Primary</Button>
              <Button variant="mint" size="sm">Mint</Button>
              <Button variant="secondary" size="sm">Secondary</Button>
              <Button variant="ghost" size="sm">Ghost</Button>
            </div>
          </div>
        </div>

        {/* Accessibility guarantees */}
        <div>
          <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-3">
            Garantías de accesibilidad
          </p>
          <ul className="space-y-2.5">
            {[
              'Foco visible (focus-ring) en todo elemento interactivo.',
              'Switch con role="switch" y aria-checked, operable por teclado.',
              'Modal con role="dialog", focus-trap, Escape y restauración de foco.',
              'Toast con role="status" / aria-live para lectores de pantalla.',
              'prefers-reduced-motion detiene animaciones infinitas.',
              'Botones-icono con aria-label obligatorio.',
            ].map((t) => (
              <li key={t} className="flex items-start gap-2 text-[12px] text-[#6B7280]">
                <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-mint-bg">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M5 13l4 4L19 7" stroke="#005E3C" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  )
}
