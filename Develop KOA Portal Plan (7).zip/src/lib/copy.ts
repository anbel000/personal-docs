/**
 * copyText — copia segura al portapapeles.
 * La Clipboard API puede estar bloqueada por permissions-policy (p. ej. dentro
 * de un iframe de preview), donde `navigator.clipboard.writeText` rechaza con
 * NotAllowedError. Intentamos la API moderna y, si falla, caemos a un
 * textarea + execCommand para no propagar el error.
 */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    /* cae al fallback */
  }
  try {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.setAttribute('readonly', '')
    ta.style.position = 'fixed'
    ta.style.top = '-9999px'
    document.body.appendChild(ta)
    ta.select()
    const ok = document.execCommand('copy')
    document.body.removeChild(ta)
    return ok
  } catch {
    return false
  }
}
