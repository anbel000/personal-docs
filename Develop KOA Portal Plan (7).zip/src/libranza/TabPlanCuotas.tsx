import { useState } from 'react'
import { planCuotasCredito4821, formatPesos } from '../data/mockData'

const CURRENT_CUOTA = 14

export default function TabPlanCuotas() {
  const [showAll, setShowAll] = useState(false)
  const cuotas = planCuotasCredito4821
  const shown = showAll ? cuotas : cuotas.slice(0, 20)

  return (
    <div>
      {/* Desktop table */}
      <div className="hidden sm:block overflow-x-auto scrollable rounded-xl border border-[#E8ECF2]">
        <table className="w-full text-[13px] border-collapse min-w-[600px]">
          <thead>
            <tr className="border-b border-[#E8ECF2] bg-gray-50">
              <th className="px-4 py-3 text-left text-[10px] font-bold tracking-widest uppercase text-gray-400">Cuota</th>
              <th className="px-4 py-3 text-left text-[10px] font-bold tracking-widest uppercase text-gray-400">Fecha</th>
              <th className="px-4 py-3 text-right text-[10px] font-bold tracking-widest uppercase text-gray-400">Capital</th>
              <th className="px-4 py-3 text-right text-[10px] font-bold tracking-widest uppercase text-gray-400">Intereses</th>
              <th className="px-4 py-3 text-right text-[10px] font-bold tracking-widest uppercase text-gray-400">Cuota total</th>
              <th className="px-4 py-3 text-right text-[10px] font-bold tracking-widest uppercase text-gray-400">Saldo</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((c) => {
              const paid = c.numero < CURRENT_CUOTA
              const next = c.numero === CURRENT_CUOTA
              return (
                <tr
                  key={c.numero}
                  className={`border-b border-[#E8ECF2] last:border-0 ${next ? 'bg-[#EFFFF7]' : paid ? 'bg-gray-50' : 'bg-white'}`}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className={`font-figures font-semibold ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{c.numero}</span>
                      {paid && (
                        <svg className="w-3.5 h-3.5 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                      {next && (
                        <span className="text-[9px] font-bold tracking-widest uppercase text-[#005E3C] bg-[#00DB8E]/20 px-1.5 py-0.5 rounded-full">
                          Próxima
                        </span>
                      )}
                    </div>
                  </td>
                  <td className={`px-4 py-3 font-figures ${paid ? 'text-gray-400' : 'text-gray-600'}`}>{c.fecha}</td>
                  <td className={`px-4 py-3 font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.capital)}</td>
                  <td className={`px-4 py-3 font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.intereses)}</td>
                  <td className={`px-4 py-3 font-figures font-semibold text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.cuotaTotal)}</td>
                  <td className={`px-4 py-3 font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.saldo)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="sm:hidden space-y-2">
        {shown.map((c) => {
          const paid = c.numero < CURRENT_CUOTA
          const next = c.numero === CURRENT_CUOTA
          return (
            <div
              key={c.numero}
              className={`rounded-xl border px-4 py-3 ${next ? 'border-[#00DB8E]/40 bg-[#EFFFF7]' : 'border-[#E8ECF2] bg-white'}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className={`font-figures font-bold text-[15px] ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>Cuota {c.numero}</span>
                  {paid && <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                  {next && <span className="text-[9px] font-bold tracking-widest uppercase text-[#005E3C] bg-[#00DB8E]/20 px-1.5 py-0.5 rounded-full">Próxima</span>}
                </div>
                <span className={`font-figures text-[12px] ${paid ? 'text-gray-400' : 'text-gray-500'}`}>{c.fecha}</span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[12px]">
                <span className="text-gray-500">Cuota total</span>
                <span className={`font-figures font-semibold text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.cuotaTotal)}</span>
                <span className="text-gray-500">Capital</span>
                <span className={`font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.capital)}</span>
                <span className="text-gray-500">Intereses</span>
                <span className={`font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.intereses)}</span>
                <span className="text-gray-500">Saldo</span>
                <span className={`font-figures text-right ${paid ? 'text-gray-400' : 'text-[#2A3036]'}`}>{formatPesos(c.saldo)}</span>
              </div>
            </div>
          )
        })}
      </div>

      {!showAll && cuotas.length > 20 && (
        <div className="flex justify-center py-4">
          <button
            onClick={() => setShowAll(true)}
            className="text-[13px] font-semibold text-[#005E3C] hover:underline cursor-pointer"
          >
            Ver plan completo ({cuotas.length} cuotas)
          </button>
        </div>
      )}
    </div>
  )
}
