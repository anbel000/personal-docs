import { useState } from 'react'
import { Button, Card, IconTile } from '../components/ui'
import PazYSalvoFlow from './PazYSalvoFlow'
import SolicitudCreditoLibranza from './SolicitudCreditoLibranza'

/* ─── Iconos (stroke DS) ─────────────────────────────────── */
const IC = {
  cash: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z',
  shield: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  check: 'M5 13l4 4L19 7',
  arrow: 'M9 5l7 7-7 7',
  back: 'M15 19l-7-7 7-7',
  doc: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
}

function Glyph({ d, className = 'w-4 h-4', sw = 2 }: { d: string; className?: string; sw?: number }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={sw}>
      <path strokeLinecap="round" strokeLinejoin="round" d={d} />
    </svg>
  )
}

export default function LibranzaSinActivos() {
  const [view, setView] = useState<'inicio' | 'solicitud'>('inicio')
  const [pazYSalvoOpen, setPazYSalvoOpen] = useState(false)

  /* ── Vista: solicitud de crédito ──────────────────────── */
  if (view === 'solicitud') {
    return (
      <div className="space-y-4">
        <button
          type="button"
          onClick={() => setView('inicio')}
          className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-muted hover:text-brand transition-colors focus-ring rounded-lg px-1 py-0.5 cursor-pointer"
        >
          <Glyph d={IC.back} className="w-4 h-4" sw={2.5} />
          Volver a tus opciones de libranza
        </button>
        <SolicitudCreditoLibranza />
      </div>
    )
  }

  /* ── Vista: decisión (sin créditos activos) ───────────── */
  return (
    <div className="space-y-4">
      {/* ── Hero de estado ──────────────────────────────── */}
      <div
        className="relative overflow-hidden rounded-3xl card-enter p-5 sm:p-6"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        {/* Adornos de fondo */}
        <div className="absolute -right-16 -top-16 w-56 h-56 rounded-full bg-mint/[0.08] pointer-events-none" />
        <div className="absolute -left-10 -bottom-14 w-40 h-40 rounded-full bg-white/[0.03] pointer-events-none" />
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-white/30 pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center gap-4">
          <IconTile toneName="mint" sizeName="lg" className="flex-shrink-0">
            <Glyph d={IC.check} className="w-6 h-6" sw={2.5} />
          </IconTile>

          <div className="flex-1 min-w-0">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 border border-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white/80">
              <span className="w-1.5 h-1.5 rounded-full bg-mint mint-pulse" />
              0 créditos disponibles
            </span>
            <h2 className="text-white font-black text-[22px] sm:text-[26px] tracking-tight leading-tight mt-2.5">
              No tienes créditos
            </h2>
            <p className="text-white/60 text-[13px] sm:text-[14px] leading-relaxed mt-1.5 max-w-xl">
              Tus créditos anteriores fueron cancelados en su totalidad, así que no hay obligaciones
              vigentes que mostrar. Puedes solicitar un nuevo crédito o generar el paz y salvo de los
              que ya terminaste.
            </p>
          </div>
        </div>
      </div>

      {/* ── Opciones ────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Solicitar crédito */}
        <Card
          variant="bloom"
          spotlight
          className="group card-enter !border-line p-5 flex flex-col"
          style={{ ['--delay' as string]: '0.05s' }}
        >
          <IconTile toneName="navy" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
            <Glyph d={IC.cash} className="w-[18px] h-[18px]" />
          </IconTile>
          <h3 className="font-bold text-brand text-[16px] mt-3.5">Solicita un nuevo crédito</h3>
          <p className="text-[13px] text-ink-soft leading-relaxed mt-1.5 flex-1">
            Crédito de libranza para pensionados y empleados del sector público. Trámite 100 % digital,
            sin codeudor y con cuota fija.
          </p>
          <Button
            variant="primary"
            size="md"
            onClick={() => setView('solicitud')}
            className="w-full mt-4"
            trailingIcon={<Glyph d={IC.arrow} className="w-3.5 h-3.5" sw={2.5} />}
          >
            Solicita tu crédito
          </Button>
        </Card>

        {/* Paz y salvo */}
        <Card
          variant="bloom"
          spotlight
          className="group card-enter !border-line p-5 flex flex-col"
          style={{ ['--delay' as string]: '0.1s' }}
        >
          <IconTile toneName="success" sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
            <Glyph d={IC.shield} className="w-[18px] h-[18px]" />
          </IconTile>
          <h3 className="font-bold text-brand text-[16px] mt-3.5">
            Genera tu paz y salvo
          </h3>
          <p className="text-[13px] text-ink-soft leading-relaxed mt-1.5 flex-1">
            Certifica que un crédito ya terminado fue pagado en su totalidad, sin saldos ni obligaciones
            pendientes con KOA. Documento oficial y con validez ante terceros.
          </p>
          <Button
            variant="secondary"
            size="md"
            onClick={() => setPazYSalvoOpen(true)}
            className="w-full mt-4"
            leadingIcon={<Glyph d={IC.doc} className="w-3.5 h-3.5" sw={2} />}
          >
            Generar paz y salvo
          </Button>
        </Card>
      </div>

      {pazYSalvoOpen && <PazYSalvoFlow onClose={() => setPazYSalvoOpen(false)} />}
    </div>
  )
}
