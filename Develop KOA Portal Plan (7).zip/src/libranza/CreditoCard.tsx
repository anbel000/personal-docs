import { useNavigate } from 'react-router-dom'
import { formatPesos, type Credito } from '../data/mockData'
import { CreditStatusPill } from '../components/koa'

interface CreditoCardProps {
  credito: Credito
  delay?: number
}

export default function CreditoCard({ credito, delay = 0 }: CreditoCardProps) {
  const navigate = useNavigate()
  const pct = Math.round((credito.cuotaActual / credito.totalCuotas) * 100)
  const enMora = credito.estado === 'en-mora'

  return (
    <div
      className="bg-white rounded-2xl border border-[#E8ECF2] overflow-hidden cursor-pointer group card-enter hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
      style={{ animationDelay: `${delay}s` }}
      onClick={() => navigate(`/libranza/credito/${credito.id}`)}
    >
      {/* Colored top accent */}
      <div
        className="h-1 w-full"
        style={{
          background: enMora
            ? 'linear-gradient(90deg, #F70C5B, #FA467F)'
            : 'linear-gradient(90deg, #00DB8E, #06005A)',
        }}
      />

      <div className="p-4">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="font-bold text-[#2A3036] text-[14px] leading-tight truncate">{credito.pagaduria}</p>
            <p className="font-figures text-[11px] text-gray-400 mt-0.5">{credito.numeroMascarado}</p>
          </div>
          <div className="flex-shrink-0">
            <CreditStatusPill status={enMora ? 'en-mora' : 'al-dia'} />
          </div>
        </div>

        {/* Saldo principal */}
        <div className="mb-3">
          <p className="text-[10px] font-bold tracking-[0.14em] uppercase text-gray-400 mb-1">Saldo pendiente</p>
          <p className="font-figures text-[24px] font-black text-[#2A3036] leading-none animate-number-pop"
            style={{ ['--delay' as string]: `${delay + 0.1}s` }}>
            {formatPesos(credito.saldo)}
          </p>
        </div>

        {/* Progress */}
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] text-gray-400">Cuota {credito.cuotaActual} de {credito.totalCuotas}</span>
            <span className="font-figures text-[11px] font-bold text-[#2A3036]">{pct} % pagado</span>
          </div>
          <div className="h-1.5 bg-[#F0F2F5] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${pct}%`,
                background: enMora
                  ? 'linear-gradient(90deg, #F70C5B, #FA467F)'
                  : 'linear-gradient(90deg, #0098FF, #00DB8E)',
              }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end pt-3 border-t border-[#F0F2F5]">
          <div className="flex items-center gap-1 text-[12px] font-bold text-[#06005A] group-hover:gap-2 transition-all">
            <span>Ver detalle</span>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  )
}
