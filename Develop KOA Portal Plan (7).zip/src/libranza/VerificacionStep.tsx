import { useState, useEffect } from 'react'
import { OtpInput } from '../components/ui'

interface VerificacionStepProps {
  onContinuar: () => void
}

const CODE_LENGTH = 6
const DEMO_CODE = '248731'

type OtpState = 'input' | 'validating' | 'success' | 'error'

const STEPS = ['Verificando identidad', 'Validando operación', 'Generando resultados']

/**
 * VerificacionStep — adaptación del "OTP Modal / FirmaElectronica" del KOA
 * Design System (ver Componentes → FirmaElectronica) para el flujo de paz y
 * salvo. Reutiliza la estructura de cabecera navy + cuerpo blanco + overlay de
 * validación (anillos girando → disco de resultado) y la primitiva OtpInput.
 */
export default function VerificacionStep({ onContinuar }: VerificacionStepProps) {
  const [code, setCode] = useState('')
  const [phase, setPhase] = useState<OtpState>('input')
  const [step, setStep] = useState(0)
  const [seconds, setSeconds] = useState(180)
  const [resendIn, setResendIn] = useState(30)
  const [resending, setResending] = useState(false)
  const [resentAt, setResentAt] = useState(0)

  // Vigencia del código
  useEffect(() => {
    if (phase !== 'input' || seconds <= 0) return
    const t = setInterval(() => setSeconds(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [phase, seconds])

  // Cooldown de reenvío
  useEffect(() => {
    if (resendIn <= 0) return
    const t = setInterval(() => setResendIn(s => Math.max(0, s - 1)), 1000)
    return () => clearInterval(t)
  }, [resendIn])

  // Confirmación "código reenviado" se autooculta
  useEffect(() => {
    if (!resentAt) return
    const t = setTimeout(() => setResentAt(0), 3200)
    return () => clearTimeout(t)
  }, [resentAt])

  // Auto-validar al completar los 6 dígitos
  useEffect(() => {
    if (code.length === CODE_LENGTH && phase === 'input') {
      const t = setTimeout(() => setPhase('validating'), 200)
      return () => clearTimeout(t)
    }
  }, [code, phase])

  // Secuencia de validación
  useEffect(() => {
    if (phase !== 'validating') return
    const timers = [
      setTimeout(() => setStep(1), 700),
      setTimeout(() => setStep(2), 1400),
      setTimeout(() => setPhase(code === DEMO_CODE ? 'success' : 'error'), 2100),
    ]
    return () => timers.forEach(clearTimeout)
  }, [phase, code])

  // Resolución: éxito → continuar; error → reset
  useEffect(() => {
    if (phase === 'success') {
      const t = setTimeout(onContinuar, 750)
      return () => clearTimeout(t)
    }
    if (phase === 'error') {
      const t = setTimeout(() => { setCode(''); setStep(0); setPhase('input') }, 1700)
      return () => clearTimeout(t)
    }
  }, [phase])

  function handleResend() {
    if (resendIn > 0 || resending || phase !== 'input') return
    setResending(true)
    setTimeout(() => {
      setResending(false)
      setCode('')
      setSeconds(180)
      setResendIn(30)
      setResentAt(Date.now())
    }, 1200)
  }

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
  const overlay = phase !== 'input'

  return (
    <div className="max-w-md mx-auto w-full">
      <div className="bg-white rounded-3xl border border-[#E8ECF2] shadow-[0_18px_50px_-24px_rgba(6,0,90,0.35)] overflow-hidden card-enter">
        {/* Cabecera navy — patrón OTP Modal del DS */}
        <div className="bg-[#06005A] px-6 py-5 relative overflow-hidden">
          <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-[#00DB8E]/10 pointer-events-none" />
          <p className="text-white/60 text-[10px] font-bold tracking-[0.18em] uppercase">Paz y salvo</p>
          <p className="text-white font-black text-[18px] mt-1 leading-tight">Autorizar operación</p>
          <p className="text-white/55 text-[12px] mt-1 leading-snug">
            Ingresa el código enviado a tu correo y celular registrado para confirmar
          </p>
        </div>

        {/* Cuerpo */}
        <div className="px-6 py-6 relative min-h-[268px] flex flex-col justify-center">
          {/* Overlay de validación — anillos + pasos + disco de resultado */}
          {overlay && (
            <div className="absolute inset-0 bg-white/95 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-5 px-6 py-6">
              <div className="relative w-16 h-16 flex items-center justify-center">
                {phase === 'validating' ? (
                  <>
                    <div className="absolute inset-0 rounded-full border-2 border-[#06005A]/15 border-t-[#06005A] animate-spin" />
                    <div className="absolute inset-[9px] rounded-full border-2 border-[#00DB8E]/25 border-t-[#00DB8E] animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.6s' }} />
                    <span className="w-2.5 h-2.5 rounded-full bg-[#06005A] mint-pulse" />
                  </>
                ) : (
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-sm scale-in ${phase === 'success' ? 'bg-[#00DB8E]' : 'bg-[#FA467F]'}`}>
                    {phase === 'success' ? (
                      <svg className="w-6 h-6 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    )}
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-2.5 w-full max-w-[210px]">
                {STEPS.map((s, i) => {
                  const failIdx = STEPS.length - 1
                  const failed = phase === 'error' && i === failIdx
                  const done = phase === 'success' || (phase === 'error' ? i < failIdx : step > i)
                  const active = phase === 'validating' && step === i
                  return (
                    <div key={s} className="flex items-center gap-2.5">
                      <div className={`w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center ${done ? 'bg-[#00DB8E]' : failed ? 'bg-[#FA467F]' : active ? 'bg-[#06005A]/10' : 'bg-[#F0F2F5]'}`}>
                        {done && <svg className="w-2.5 h-2.5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                        {failed && <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>}
                        {active && <span className="w-1.5 h-1.5 rounded-full bg-[#06005A] mint-pulse" />}
                      </div>
                      <p className={`text-[11px] font-semibold ${done ? 'text-[#005E3C]' : failed ? 'text-[#F70C5B]' : active ? 'text-[#2A3036]' : 'text-gray-300'}`}>{s}</p>
                    </div>
                  )
                })}
              </div>
              {phase === 'error' && <p className="text-[12px] font-bold text-[#F70C5B]">Código incorrecto</p>}
            </div>
          )}

          {/* Entrada OTP */}
          <div className="mb-4">
            <OtpInput
              value={code}
              onChange={setCode}
              length={CODE_LENGTH}
              state={phase === 'error' ? 'error' : 'default'}
              disabled={phase !== 'input'}
              fluid
              autoFocus
            />
          </div>

          <div className="flex items-center justify-between gap-3">
            <p className="font-figures text-[12px] text-gray-400">
              Código válido por <span className={`font-bold ${seconds < 30 ? 'text-[#F70C5B]' : 'text-[#2A3036]'}`}>{fmt}</span>
            </p>
            {resending ? (
              <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A]">
                <span className="w-3.5 h-3.5 rounded-full border-2 border-[#06005A]/25 border-t-[#06005A] animate-spin" />
                Enviando…
              </span>
            ) : resendIn > 0 ? (
              <span aria-hidden />
            ) : (
              <button
                onClick={handleResend}
                disabled={phase !== 'input'}
                className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#06005A] hover:text-[#08007A] cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Reenviar código
              </button>
            )}
          </div>

          {/* Confirmación de reenvío / hint demo */}
          {resentAt ? (
            <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5 fade-in">
              <div className="w-5 h-5 rounded-full bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <p className="text-[11px] text-[#005E3C] font-semibold">Enviamos un nuevo código a tu correo y celular registrado.</p>
            </div>
          ) : (
            <div className="mt-4 bg-[#EFFFF7] border border-[#00DB8E]/25 rounded-xl px-3 py-2.5 flex items-center gap-2.5">
              <svg className="w-3.5 h-3.5 text-[#00DB8E] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-[11px] text-[#005E3C] leading-snug">
                <span className="font-bold">Demo:</span> el código es{' '}
                <button
                  onClick={() => setCode(DEMO_CODE)}
                  className="font-figures font-black underline cursor-pointer"
                >
                  {DEMO_CODE}
                </button>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
