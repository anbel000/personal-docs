import { useState } from 'react'
import { Button, IconTile } from '../components/ui'
import type { IconTileTone } from '../components/ui/IconTile'
import type { ToastPayload } from '../components/NotificationToast'

type DocIconKey = 'terms' | 'calendar' | 'chart'

const ICON_PATH: Record<DocIconKey, string> = {
  terms: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4',
  calendar: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
  chart: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z',
}

const certificados: { id: string; nombre: string; descripcion: string; tone: IconTileTone; icon: DocIconKey }[] = [
  {
    id: 'carta',
    nombre: 'Carta de condiciones',
    descripcion: 'Condiciones financieras vigentes de tu crédito',
    tone: 'warning',
    icon: 'terms',
  },
  {
    id: 'plan',
    nombre: 'Plan de pagos',
    descripcion: 'Detalle de todas tus cuotas programadas',
    tone: 'info',
    icon: 'calendar',
  },
  {
    id: 'amort',
    nombre: 'Amortización',
    descripcion: 'Distribución de capital e intereses por cuota',
    tone: 'success',
    icon: 'chart',
  },
]

function DownloadIcon({ className = 'w-3.5 h-3.5' }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
  )
}

function Spinner() {
  return <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin" />
}

function getCurrentMonths() {
  const meses = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC']
  const now = new Date(2026, 7, 1)
  const result = []
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    result.push({ mes: meses[d.getMonth()], año: d.getFullYear(), key: `${meses[d.getMonth()]}-${d.getFullYear()}` })
  }
  return result
}

interface CertificadosInmediatosProps {
  onToast: (t: ToastPayload) => void
}

export default function CertificadosInmediatos({ onToast }: CertificadosInmediatosProps) {
  const [loadingId, setLoadingId] = useState<string | null>(null)
  const [selectedMes, setSelectedMes] = useState<string | null>(null)
  const [loadingExtracto, setLoadingExtracto] = useState(false)

  const meses = getCurrentMonths()
  const selected = meses.find(m => m.key === selectedMes)

  const handleDownload = (id: string, nombre: string) => {
    setLoadingId(id)
    setTimeout(() => {
      setLoadingId(null)
      onToast({ tone: 'success', title: 'Descarga completada', message: `Tu ${nombre.toLowerCase()} se guardó en tu dispositivo.` })
    }, 1100)
  }

  const handleExtracto = () => {
    setLoadingExtracto(true)
    setTimeout(() => {
      setLoadingExtracto(false)
      onToast({ tone: 'success', title: 'Descarga completada', message: 'Tu extracto de movimientos se guardó en tu dispositivo.' })
    }, 1100)
  }

  return (
    <div className="space-y-6">

      {/* ── Certificados del crédito ── */}
      <div>
        <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-muted mb-3">
          Certificados del crédito
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {certificados.map((cert, i) => {
            const isLoading = loadingId === cert.id
            return (
              <div
                key={cert.id}
                className="group flex flex-col rounded-2xl border border-line bg-white p-4 transition-all duration-200 hover:border-brand/20 hover:shadow-card hover:-translate-y-0.5 card-enter"
                style={{ animationDelay: `${0.05 + i * 0.06}s` }}
              >
                <div className="flex items-start justify-between gap-2 mb-3">
                  <IconTile toneName={cert.tone} sizeName="md" className="transition-transform duration-300 group-hover:-translate-y-0.5">
                    <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                      <path strokeLinecap="round" strokeLinejoin="round" d={ICON_PATH[cert.icon]} />
                    </svg>
                  </IconTile>
                  <span className="text-[9px] font-bold tracking-[0.14em] uppercase text-muted-soft bg-app-bg rounded-md px-1.5 py-1 leading-none">
                    PDF
                  </span>
                </div>

                <p className="font-bold text-ink text-[14px] leading-tight mb-1">{cert.nombre}</p>
                <p className="text-[12px] text-muted leading-snug flex-1 mb-3">{cert.descripcion}</p>

                <button
                  onClick={() => handleDownload(cert.id, cert.nombre)}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] font-bold bg-app-bg text-brand hover:bg-brand hover:text-white transition-colors cursor-pointer disabled:cursor-wait disabled:bg-app-bg disabled:text-muted-soft"
                >
                  {isLoading
                    ? <><Spinner /> Generando…</>
                    : <><DownloadIcon className="w-3.5 h-3.5 transition-transform group-hover:translate-y-0.5" /> Descargar</>}
                </button>
              </div>
            )
          })}
        </div>
      </div>

      {/* ── Extracto mensual ── */}
      <div>
        <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-muted mb-3">
          Extracto mensual
        </p>
        <div className="rounded-2xl border border-line bg-surface-alt p-4 sm:p-5">
          {/* Encabezado */}
          <div className="flex items-start gap-3 mb-4">
            <span className="inline-flex items-center justify-center shrink-0 w-11 h-11 rounded-xl bg-purple/10 text-purple">
              <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 3h12a1 1 0 011 1v17l-2.5-1.5L14 21l-2-1.5L10 21l-2.5-1.5L5 21V4a1 1 0 011-1zM9 8h6M9 12h4" />
              </svg>
            </span>
            <div>
              <p className="font-bold text-ink text-[14px] leading-tight">Extracto de movimientos</p>
              <p className="text-[12px] text-muted mt-0.5 leading-snug">
                Elige un mes para descargar sus movimientos, saldos y cuota del periodo.
              </p>
            </div>
          </div>

          {/* Selector de meses */}
          <div className="flex gap-2 overflow-x-auto pb-1 mb-4 scrollable -mx-1 px-1">
            {meses.map((m) => {
              const sel = selectedMes === m.key
              return (
                <button
                  key={m.key}
                  onClick={() => setSelectedMes(m.key)}
                  aria-pressed={sel}
                  className={`flex-shrink-0 flex flex-col items-center px-3.5 py-2.5 rounded-xl border-2 transition-all duration-150 cursor-pointer min-w-[60px] ${
                    sel
                      ? 'bg-brand border-brand shadow-md shadow-brand/20'
                      : 'bg-white border-line hover:border-brand/40'
                  }`}
                >
                  <span className={`text-[10px] font-black tracking-widest uppercase leading-none ${sel ? 'text-mint' : 'text-ink-soft'}`}>
                    {m.mes}
                  </span>
                  <span className={`font-figures text-[11px] font-semibold mt-1 leading-none ${sel ? 'text-white/70' : 'text-muted-soft'}`}>
                    {m.año}
                  </span>
                </button>
              )
            })}
          </div>

          {/* Vista previa dinámica + acción */}
          {selected ? (
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl bg-white border border-line p-3 scale-in">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-brand/[0.06] flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-brand" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div className="min-w-0">
                  <p className="font-bold text-ink text-[13px] leading-tight truncate">
                    Extracto de <span className="font-figures">{selected.mes} {selected.año}</span>
                  </p>
                  <p className="text-[11px] text-muted leading-tight">Documento PDF · listo para descargar</p>
                </div>
              </div>
              <Button
                variant="primary"
                size="md"
                loading={loadingExtracto}
                onClick={handleExtracto}
                className="w-full sm:w-auto flex-shrink-0"
                leadingIcon={!loadingExtracto ? <DownloadIcon className="w-4 h-4" /> : undefined}
              >
                {loadingExtracto ? 'Descargando…' : 'Descargar'}
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2.5 rounded-xl border border-dashed border-line px-3.5 py-3 text-muted-soft">
              <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
              </svg>
              <p className="text-[12px]">Selecciona un mes para continuar</p>
            </div>
          )}
        </div>
      </div>

    </div>
  )
}
