import { useState, useEffect } from 'react'
import VerificacionStep from './VerificacionStep'
import { Button } from '../components/ui'
import { KoaLogo } from '../components/koa'
import { creditosTerminados, formatPesos } from '../data/mockData'
import NotificationToast from '../components/NotificationToast'
import sfcBlack from '../imports/sfc-black-1.svg'

interface PazYSalvoFlowProps {
  onClose: () => void
}

type Paso = 1 | 2 | 'generando' | 3

const STEPS = ['Verificación', 'Selección', 'Certificado']
// Íconos por paso (shield-check · lista · badge-check)
const STEP_ICONS = [
  'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01',
  'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
]

/* ── Generating animation ──────────────────────────────────── */
const GEN_STEPS = [
  'Validando crédito seleccionado…',
  'Consultando estado de obligaciones…',
  'Emitiendo certificado oficial…',
]

function GenerandoScreen() {
  const [phase, setPhase] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 900)
    const t2 = setTimeout(() => setPhase(2), 1900)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [])

  return (
    <div className="flex flex-col items-center justify-center gap-10 py-16">
      <div className="relative flex items-center justify-center">
        <div className="absolute w-28 h-28 rounded-full border-2 border-[#00DB8E]/20 animate-spin"
          style={{ animationDuration: '3s', borderTopColor: '#00DB8E' }} />
        <div className="absolute w-20 h-20 rounded-full border-2 border-white/10 animate-spin"
          style={{ animationDuration: '2s', animationDirection: 'reverse', borderBottomColor: 'rgba(255,255,255,0.2)' }} />
        <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-xl shadow-black/10">
          <KoaLogo kind="isotipo" tone="color" height={28} />
        </div>
      </div>

      <div className="space-y-3 w-full max-w-[240px]">
        {GEN_STEPS.map((s, i) => (
          <div key={i} className={`flex items-center gap-3 transition-all duration-500 ${i <= phase ? 'opacity-100' : 'opacity-25'}`}>
            <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center transition-all duration-300 ${
              i < phase ? 'bg-[#00DB8E]' : i === phase ? 'border-2 border-white/60 bg-white/10' : 'bg-white/10'
            }`}>
              {i < phase ? (
                <svg className="w-3 h-3 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              ) : i === phase ? (
                <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
              ) : null}
            </div>
            <p className={`text-[13px] transition-colors duration-300 ${
              i < phase ? 'text-[#00DB8E] font-semibold' : i === phase ? 'text-white font-bold' : 'text-white/30'
            }`}>{s}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── Certificate document ──────────────────────────────────── */
function Certificado({ creditoId }: { creditoId: string }) {
  const credito = creditosTerminados.find(c => c.id === creditoId)
  const today = new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'long', year: 'numeric' })
    .format(new Date(2026, 7, 14))

  return (
    <div className="bg-white rounded-2xl border border-[#E8ECF2] shadow-lg w-full h-full flex flex-col justify-center p-7 sm:p-8">
      {/* Marca legal + estado */}
      <div className="flex items-center justify-between gap-3 mb-6">
        <KoaLogo kind="logotipo" tone="color" height={54} />
        <span className="bg-[#EFFFF7] text-[#005E3C] text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E]" />Cancelado
        </span>
      </div>

      {/* Título */}
      <p className="text-[9px] font-bold tracking-[0.2em] uppercase text-gray-400 mb-1.5">Documento oficial</p>
      <h3 className="text-[#06005A] font-black text-[22px] sm:text-[26px] tracking-tight leading-tight mb-5">
        Certificado de Paz y Salvo
      </h3>

      {/* Texto certificatorio — incluye crédito y fecha de expedición */}
      <p className="text-[13px] sm:text-[14px] text-gray-600 leading-relaxed">
        KOA Compañía de Financiamiento certifica que el crédito{' '}
        <span className="font-figures font-bold text-[#2A3036]">{credito?.numeroMascarado}</span>
        {credito?.pagaduria && <>, con pagaduría <span className="font-semibold text-[#2A3036]">{credito.pagaduria}</span></>}
        , se encuentra <span className="font-bold text-[#06005A]">completamente cancelado</span>, sin saldo ni
        obligación pendiente con la entidad a la fecha de expedición del presente certificado,{' '}
        <span className="font-semibold text-[#2A3036] capitalize">{today}</span>.
      </p>

      {/* Vigilancia — logo oficial de la SFC */}
      <div className="mt-6 pt-4 border-t border-[#F0F2F5]">
        <img
          src={sfcBlack}
          alt="Vigilado Superintendencia Financiera de Colombia"
          className="h-6 w-auto object-contain"
        />
      </div>
    </div>
  )
}

/* ── Main flow ─────────────────────────────────────────────── */
export default function PazYSalvoFlow({ onClose }: PazYSalvoFlowProps) {
  const [paso, setPaso] = useState<Paso>(1)
  const [selected, setSelected] = useState<string | null>(null)
  const [downloading, setDownloading] = useState(false)
  const [revealed, setRevealed] = useState(false)
  const [toast, setToast] = useState<{ tone: 'success' | 'info'; title: string; message?: string } | null>(null)

  const pasoNum = paso === 'generando' ? 3 : (paso as number)

  function handleSeleccion() {
    setPaso('generando')
    setTimeout(() => {
      setPaso(3)
      setToast({ tone: 'success', title: 'Certificado generado', message: 'Tu paz y salvo fue emitido exitosamente.' })
      setTimeout(() => setRevealed(true), 80)
    }, 2900)
  }

  function resetFlow() {
    setPaso(1)
    setSelected(null)
    setRevealed(false)
  }

  function handleDownload() {
    setDownloading(true)
    setTimeout(() => {
      setDownloading(false)
      setToast({ tone: 'info', title: 'Descarga lista', message: 'El PDF de tu paz y salvo se guardó en tu dispositivo.' })
    }, 1200)
  }

  const isDark = paso === 'generando'

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col overflow-hidden transition-colors duration-500"
      style={{ background: isDark ? 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' : '#F0F2F5' }}
    >
      {/* Toast flotante — notificación del DS */}
      {toast && (
        <NotificationToast
          tone={toast.tone}
          title={toast.title}
          message={toast.message}
          onClose={() => setToast(null)}
        />
      )}

      {/* ── Stepper header — patrón DS (navy, íconos, conectores mint) ── */}
      <div
        className="px-5 sm:px-6 pt-4 pb-4 sticky top-0 z-10 flex-shrink-0 relative"
        style={{ background: 'linear-gradient(135deg, #0C1E4C 0%, #06005A 100%)' }}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-5 w-8 h-8 rounded-lg bg-white/[0.1] hover:bg-white/[0.18] flex items-center justify-center transition-colors cursor-pointer z-20"
        >
          <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="max-w-3xl mx-auto pr-10">
          {/* Meta + progreso */}
          <div className="flex items-center justify-between mb-3.5">
            <p className="text-[11px] font-semibold text-white/60">
              Paso <span className="font-figures font-bold text-white">{pasoNum}</span> de {STEPS.length}
            </p>
            <p className="font-figures text-[11px] font-bold text-[#00DB8E]">
              {Math.round(((pasoNum - 1) / (STEPS.length - 1)) * 100)}%
            </p>
          </div>

          {/* Círculos + conectores */}
          <div className="flex items-center">
            {STEPS.map((label, i) => {
              const p = i + 1
              const done = pasoNum > p
              const active = pasoNum === p || (paso === 'generando' && p === 3)
              return (
                <div key={p} className="flex items-center flex-1 last:flex-none">
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="relative flex items-center justify-center">
                      {active && <span className="absolute inset-0 rounded-full bg-white/25 animate-pulse-ring" />}
                      <div className={`relative w-7 h-7 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                        done
                          ? 'bg-[#00DB8E] border-[#00DB8E]'
                          : active
                            ? 'bg-white border-white shadow-[0_4px_14px_-2px_rgba(0,219,142,0.5)]'
                            : 'border-white/25'
                      }`}>
                        {done ? (
                          <svg className="w-3.5 h-3.5 text-[#06005A] scale-in" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          <svg
                            className="w-[15px] h-[15px]"
                            fill="none" viewBox="0 0 24 24"
                            stroke={active ? '#06005A' : 'rgba(255,255,255,0.5)'}
                            strokeWidth={1.9}
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" d={STEP_ICONS[i]} />
                          </svg>
                        )}
                      </div>
                    </div>
                    <p className={`text-[11px] font-bold whitespace-nowrap transition-colors ${
                      active ? 'text-white' : done ? 'text-[#00DB8E]' : 'text-white/40'
                    } ${active ? '' : 'hidden sm:block'}`}>
                      {label}
                    </p>
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className="flex-1 h-[2px] rounded-full bg-white/12 mx-2 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#00DB8E] transition-[width] duration-500 ease-out"
                        style={{ width: done ? '100%' : '0%' }}
                      />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* ── Content ─────────────────────────────────────────── */}
      <div className="flex-1 min-h-0 w-full flex flex-col">

        {/* Step 1 — Verificación */}
        {paso === 1 && (
          <div className="flex-1 min-h-0 overflow-y-auto px-5 py-6 flex items-start sm:items-center justify-center">
            <VerificacionStep onContinuar={() => setPaso(2)} />
          </div>
        )}

        {/* Step 2 — Selección */}
        {paso === 2 && (
          <div className="flex-1 min-h-0 flex flex-col px-5 py-6">
            <div className="w-full max-w-lg mx-auto flex-1 min-h-0 flex flex-col gap-4">
              {/* Contexto */}
              <div className="shrink-0 bg-[#06005A] rounded-2xl px-5 py-3.5 flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#00DB8E]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-white font-bold text-[13px] leading-tight mb-0.5">Solo créditos terminados</p>
                  <p className="text-white/55 text-[12px] leading-snug">
                    El paz y salvo certifica que tu crédito fue pagado en su totalidad y no tienes obligaciones pendientes con KOA.
                  </p>
                </div>
              </div>

              {/* Encabezado + indicador de cantidad */}
              <div className="shrink-0 flex items-center justify-between gap-3">
                <h2 className="font-black text-[19px] text-[#2A3036]">Selecciona el crédito</h2>
                {creditosTerminados.length > 0 && (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-white border border-[#E8ECF2] px-3 py-1 text-[11px] font-bold text-[#06005A] flex-shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00DB8E]" />
                    {creditosTerminados.length} terminados
                  </span>
                )}
              </div>

              {creditosTerminados.length === 0 ? (
                <div className="bg-white rounded-2xl border border-[#E8ECF2] p-8 text-center space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-[#F7F7F7] flex items-center justify-center mx-auto">
                    <svg className="w-7 h-7 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <p className="font-bold text-[#2A3036]">Sin créditos terminados</p>
                  <p className="text-[13px] text-gray-400 leading-snug max-w-xs mx-auto">
                    Cuando finalices de pagar un crédito de libranza, aparecerá aquí para generar su paz y salvo.
                  </p>
                  <button onClick={onClose} className="text-[13px] font-bold text-[#06005A] hover:underline cursor-pointer mt-1">
                    Volver a mis créditos
                  </button>
                </div>
              ) : (
                <>
                  {/* Lista con scroll interno — evita el scroll general */}
                  <div className="flex-1 min-h-0 overflow-y-auto scrollable space-y-2.5 pr-1 -mr-1">
                    {creditosTerminados.map((c) => {
                      const isSelected = selected === c.id
                      return (
                        <button
                          key={c.id}
                          onClick={() => setSelected(c.id)}
                          className={`w-full text-left rounded-2xl border-2 px-4 py-3.5 transition-all duration-150 cursor-pointer flex items-center gap-4 ${
                            isSelected
                              ? 'border-[#06005A] bg-[#06005A]/04 shadow-sm'
                              : 'border-[#E8ECF2] bg-white hover:border-[#06005A]/30'
                          }`}
                        >
                          {/* Radio */}
                          <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all duration-150 ${
                            isSelected ? 'border-[#06005A] bg-[#06005A]' : 'border-[#E8ECF2]'
                          }`}>
                            {isSelected && (
                              <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-bold text-[#2A3036] text-[14px] truncate">{c.pagaduria}</p>
                              <span className="text-[9px] font-bold text-[#005E3C] bg-[#EFFFF7] px-2 py-0.5 rounded-full flex-shrink-0">Cancelado</span>
                            </div>
                            <div className="flex items-center gap-3 mt-1 flex-wrap">
                              <p className="font-figures text-[12px] text-gray-400">{c.numeroMascarado}</p>
                              <span className="w-1 h-1 rounded-full bg-gray-300" />
                              <p className="font-figures text-[12px] text-gray-400">{formatPesos(c.montoDesembolsado)}</p>
                              <span className="w-1 h-1 rounded-full bg-gray-300" />
                              <p className="font-figures text-[12px] text-gray-400">{c.periodoInicio} – {c.periodoFin}</p>
                            </div>
                          </div>
                        </button>
                      )
                    })}
                  </div>

                  <Button
                    variant="primary"
                    size="lg"
                    disabled={!selected}
                    onClick={handleSeleccion}
                    className="w-full shrink-0"
                  >
                    Generar certificado
                  </Button>
                </>
              )}
            </div>
          </div>
        )}

        {/* Generating */}
        {paso === 'generando' && (
          <div className="flex-1 min-h-0 flex items-center justify-center">
            <GenerandoScreen />
          </div>
        )}

        {/* Step 3 — Certificate */}
        {paso === 3 && selected && (
          <div className="flex-1 min-h-0 overflow-y-auto px-5 py-6 flex items-center">
            <div className={`w-full max-w-4xl mx-auto transition-all duration-500 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <div className="grid lg:grid-cols-[1fr_300px] gap-5 items-stretch">
                {/* Documento */}
                <Certificado creditoId={selected} />

                {/* Panel de estado + acciones */}
                <div className="flex flex-col justify-center gap-3">
                  <div className="flex items-center gap-3 bg-[#EFFFF7] border border-[#00DB8E]/30 rounded-2xl px-4 py-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#00DB8E] flex items-center justify-center flex-shrink-0">
                      <svg className="w-5 h-5 text-[#06005A]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-bold text-[#005E3C] text-[13px] leading-tight">Certificado generado</p>
                      <p className="text-[11px] text-[#005E3C]/70 mt-0.5">Emitido exitosamente</p>
                    </div>
                  </div>

                  {/* Notas de validez */}
                  <div className="bg-white border border-[#E8ECF2] rounded-2xl p-4 space-y-3">
                    {[
                      { icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', text: 'Documento con validez oficial ante terceros.' },
                      { icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z', text: 'Firmado digitalmente por KOA C.F.' },
                      { icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z', text: 'Vigente a la fecha de expedición.' },
                    ].map((r, i) => (
                      <div key={i} className="flex items-start gap-2.5">
                        <svg className="w-4 h-4 text-[#00DB8E] flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d={r.icon} />
                        </svg>
                        <p className="text-[12px] text-gray-500 leading-snug">{r.text}</p>
                      </div>
                    ))}
                  </div>

                  {/* Acciones */}
                  <Button
                    variant="primary"
                    size="lg"
                    loading={downloading}
                    onClick={handleDownload}
                    className="w-full"
                    leadingIcon={
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                    }
                  >
                    {downloading ? 'Descargando…' : 'Descargar PDF'}
                  </Button>
                  <Button variant="secondary" size="lg" onClick={resetFlow} className="w-full">
                    Consultar otro
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  )
}
