import { useEffect, useMemo, useRef, useState } from 'react'
import { Button, Stepper } from '../components/ui'
import { KoaFlor } from '../components/koa'
import { CATALOGO, normalizar, type Pagaduria, type Perfil } from './pagaduriasData'

/* ── Iconografía (stroke DS) ─────────────────────────────── */
const IC = {
  check: 'M5 13l4 4L19 7',
  arrow: 'M9 5l7 7-7 7',
  back: 'M15 19l-7-7 7-7',
  search: 'M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z',
  chevron: 'M6 9l6 6 6-6',
  mail: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z',
  phone: 'M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z',
  spark: 'M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z',
  wallet: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z',
  lock: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z',
}

function Glyph({ d, className = 'w-4 h-4', sw = 1.8 }: { d: string; className?: string; sw?: number }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={sw}>
      <path strokeLinecap="round" strokeLinejoin="round" d={d} />
    </svg>
  )
}

/* ── Perfiles ─────────────────────────────────────────────── */
const PERFILES: { value: Perfil; label: string; sub: string; icon: string }[] = [
  { value: 'pensionado', label: 'Pensionado', sub: 'Recibes una mesada pensional', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V7m0 1v8m0 0v1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
  { value: 'empleado_publico', label: 'Empleado público', sub: 'Nómina de una entidad del Estado', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' },
  { value: 'docente', label: 'Docente', sub: 'Secretaría de educación o FOMAG', icon: 'M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.42a12 12 0 01.84 4.42 12 12 0 01-.84 4.42L12 14zm0 0v6' },
]

const PERFIL_LABEL: Record<Perfil, string> = {
  pensionado: 'Pensionado',
  empleado_publico: 'Empleado público',
  docente: 'Docente',
}

const TIPO_PENSION = [
  { value: 'vejez', label: 'Pensión por vejez' },
  { value: 'sustitucion', label: 'Pensión de sustitución' },
  { value: 'invalidez', label: 'Pensión por invalidez' },
  { value: 'viudez', label: 'Pensión de viudez' },
  { value: 'policia', label: 'Pensión de la Policía' },
  { value: 'estado', label: 'Pensión del Estado' },
  { value: 'docencia', label: 'Pensión por docencia' },
]

const TIPO_CONTRATO = [
  { value: 'carrera_administrativa', label: 'Carrera administrativa' },
  { value: 'en_propiedad', label: 'En propiedad' },
  { value: 'indefinido', label: 'Indefinido' },
  { value: 'otro', label: 'Otro' },
]

const CANALES = [
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'correo', label: 'Correo electrónico' },
  { value: 'sms', label: 'Mensaje de texto' },
  { value: 'llamada', label: 'Llamada telefónica' },
]

const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i
const RE_CEL = /^3\d{9}$/

type Step = 'perfil' | 'entidad' | 'contacto' | 'sin-convenio' | 'ok'
const STEP_LABELS = ['Perfil', 'Tu entidad', 'Contacto']
const STEP_INDEX: Record<string, number> = { perfil: 0, entidad: 1, contacto: 2 }

/* ── Input estilo DS (label + campo) ─────────────────────── */
function TextField({
  label, hint, error, id, ...props
}: {
  label: string
  hint?: string
  error?: string
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label htmlFor={id} className="block text-[12px] font-semibold text-ink mb-1.5">
        {label}
        {hint && <span className="ml-1.5 font-normal text-[11px] text-muted-soft">{hint}</span>}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        className={`w-full bg-surface border rounded-xl px-3.5 py-2.5 text-[13px] text-ink placeholder:text-muted-soft outline-none transition-all ${
          error
            ? 'border-error focus:shadow-[0_0_0_3px_rgba(250,70,127,0.15)]'
            : 'border-line focus:border-mint focus:shadow-[0_0_0_3px_rgba(0,219,142,0.15)]'
        }`}
        {...props}
      />
      {error && <p className="mt-1.5 text-[11px] text-error font-medium">{error}</p>}
    </div>
  )
}

/* ── Select estilo DS ─────────────────────────────────────── */
function SelectField({
  label, error, id, value, onChange, options, placeholder = 'Selecciona una opción',
}: {
  label: string
  error?: string
  id: string
  value: string
  onChange: (v: string) => void
  options: { value: string; label: string }[]
  placeholder?: string
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-[12px] font-semibold text-ink mb-1.5">{label}</label>
      <div className="relative">
        <select
          id={id}
          value={value}
          onChange={e => onChange(e.target.value)}
          aria-invalid={error ? true : undefined}
          className={`w-full appearance-none bg-surface border rounded-xl pl-3.5 pr-10 py-2.5 text-[13px] outline-none transition-all cursor-pointer ${
            value ? 'text-ink' : 'text-muted-soft'
          } ${
            error
              ? 'border-error focus:shadow-[0_0_0_3px_rgba(250,70,127,0.15)]'
              : 'border-line focus:border-mint focus:shadow-[0_0_0_3px_rgba(0,219,142,0.15)]'
          }`}
        >
          <option value="" className="text-muted-soft">{placeholder}</option>
          {options.map(o => <option key={o.value} value={o.value} className="text-ink bg-white">{o.label}</option>)}
        </select>
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted">
          <Glyph d={IC.chevron} className="w-4 h-4" sw={2} />
        </span>
      </div>
      {error && <p className="mt-1.5 text-[11px] text-error font-medium">{error}</p>}
    </div>
  )
}

/* ── Combobox de pagaduría ───────────────────────────────── */
function PagaduriaCombo({
  perfil, value, query, onQuery, onSelect, onNoConvenio, error,
}: {
  perfil: Perfil
  value: Pagaduria | null
  query: string
  onQuery: (q: string) => void
  onSelect: (p: Pagaduria) => void
  onNoConvenio: () => void
  error?: string
}) {
  const [open, setOpen] = useState(false)
  const [idx, setIdx] = useState(-1)
  const boxRef = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLUListElement>(null)

  const visibles = useMemo(() => {
    const q = normalizar(query || '')
    return CATALOGO.filter(
      p => p.perfiles.includes(perfil) && (!q || normalizar(p.label).includes(q)),
    ).slice(0, 60)
  }, [perfil, query])

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [])

  useEffect(() => {
    if (idx >= 0 && listRef.current) {
      const el = listRef.current.querySelector<HTMLElement>(`[data-i="${idx}"]`)
      el?.scrollIntoView({ block: 'nearest' })
    }
  }, [idx])

  const total = visibles.length + 1 // +1 = "no está en la lista"

  function choose(i: number) {
    if (i === visibles.length) { setOpen(false); onNoConvenio(); return }
    const p = visibles[i]
    if (p) { onSelect(p); setOpen(false) }
  }

  return (
    <div>
      <label htmlFor="pagaduria" className="block text-[12px] font-semibold text-ink mb-1.5">
        Entidad que te paga
      </label>
      <div ref={boxRef} className="relative">
        <div className={`flex items-center gap-2 bg-surface border rounded-xl px-3.5 py-2.5 transition-all ${
          error
            ? 'border-error focus-within:shadow-[0_0_0_3px_rgba(250,70,127,0.15)]'
            : 'border-line focus-within:border-mint focus-within:shadow-[0_0_0_3px_rgba(0,219,142,0.15)]'
        }`}>
          <span className="text-muted-soft shrink-0"><Glyph d={IC.search} className="w-4 h-4" sw={2} /></span>
          <input
            id="pagaduria"
            role="combobox"
            aria-expanded={open}
            aria-controls="pagaduria-list"
            aria-autocomplete="list"
            autoComplete="off"
            value={query}
            placeholder="Ej.: Colpensiones, FOPEP, CASUR…"
            onFocus={() => setOpen(true)}
            onChange={e => { onQuery(e.target.value); setOpen(true); setIdx(-1) }}
            onKeyDown={e => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setIdx(i => Math.min(i + 1, total - 1)) }
              else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx(i => Math.max(i - 1, 0)) }
              else if (e.key === 'Enter' && open && idx >= 0) { e.preventDefault(); choose(idx) }
              else if (e.key === 'Escape') setOpen(false)
            }}
            className="w-full bg-transparent text-[13px] text-ink placeholder:text-muted-soft outline-none"
          />
          {value && (
            <span className="shrink-0 text-mint" aria-hidden="true"><Glyph d={IC.check} className="w-4 h-4" sw={2.5} /></span>
          )}
        </div>

        {open && (
          <ul
            id="pagaduria-list"
            ref={listRef}
            role="listbox"
            className="absolute z-30 top-[calc(100%+6px)] inset-x-0 max-h-[240px] overflow-y-auto scrollable bg-surface border border-line rounded-xl shadow-float p-1"
          >
            {visibles.length === 0 && (
              <li className="px-3 py-2.5 text-[12px] text-muted-soft">No encontramos esa entidad.</li>
            )}
            {visibles.map((p, i) => (
              <li
                key={p.slug + i}
                data-i={i}
                role="option"
                aria-selected={idx === i}
                onMouseDown={e => { e.preventDefault(); choose(i) }}
                onMouseEnter={() => setIdx(i)}
                className={`px-3 py-2 rounded-lg text-[12.5px] cursor-pointer leading-snug ${
                  idx === i ? 'bg-mint-bg text-mint-text' : 'text-ink'
                }`}
              >
                {p.label}
              </li>
            ))}
            <li
              data-i={visibles.length}
              role="option"
              aria-selected={idx === visibles.length}
              onMouseDown={e => { e.preventDefault(); choose(visibles.length) }}
              onMouseEnter={() => setIdx(visibles.length)}
              className={`mt-1 border-t border-line px-3 py-2.5 rounded-lg text-[12.5px] font-semibold cursor-pointer ${
                idx === visibles.length ? 'bg-brand/5 text-brand' : 'text-brand'
              }`}
            >
              Mi entidad no está en la lista
            </li>
          </ul>
        )}
      </div>
      {error && <p className="mt-1.5 text-[11px] text-error font-medium">{error}</p>}
    </div>
  )
}

/* ═══════════════════════════════════════════════════════════
   Formulario de solicitud de crédito de libranza
   ═══════════════════════════════════════════════════════════ */
export default function SolicitudCreditoLibranza() {
  const [step, setStep] = useState<Step>('perfil')
  const [perfil, setPerfil] = useState<Perfil | null>(null)
  const [pagaduria, setPagaduria] = useState<Pagaduria | null>(null)
  const [pagaduriaQuery, setPagaduriaQuery] = useState('')
  const [tipoPension, setTipoPension] = useState('')
  const [tipoContrato, setTipoContrato] = useState('')

  const [nombres, setNombres] = useState('')
  const [apellidos, setApellidos] = useState('')
  const [email, setEmail] = useState('')
  const [celular, setCelular] = useState('')
  const [canal, setCanal] = useState('')
  const [autorizacion, setAutorizacion] = useState(false)

  const [entidadLibre, setEntidadLibre] = useState('')
  const [emailSC, setEmailSC] = useState('')
  const [authSC, setAuthSC] = useState(false)

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [sending, setSending] = useState(false)
  const [okMsg, setOkMsg] = useState('')

  function clearErr(k: string) {
    setErrors(prev => { if (!prev[k]) return prev; const n = { ...prev }; delete n[k]; return n })
  }

  /* ── Validaciones ── */
  function validarPerfil() {
    if (!perfil) { setErrors({ perfil: 'Selecciona tu perfil para continuar.' }); return false }
    return true
  }

  function validarEntidad() {
    const e: Record<string, string> = {}
    if (nombres.trim().length < 2) e.nombres = 'Escribe tus nombres.'
    if (apellidos.trim().length < 2) e.apellidos = 'Escribe tus apellidos.'
    if (!pagaduria) e.pagaduria = 'Selecciona una entidad de la lista.'
    if (perfil === 'pensionado') {
      if (!tipoPension) e.tipoPension = 'Selecciona tu tipo de pensión.'
    } else if (!tipoContrato) {
      e.tipoContrato = 'Selecciona tu tipo de contrato.'
    }
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function validarContacto() {
    const e: Record<string, string> = {}
    if (!RE_EMAIL.test(email.trim())) e.email = 'Escribe un correo válido.'
    if (!RE_CEL.test(celular.trim())) e.celular = 'Celular de 10 dígitos que empiece por 3.'
    if (!canal) e.canal = 'Selecciona un canal de contacto.'
    if (!autorizacion) e.autorizacion = 'Necesitamos tu autorización para contactarte.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  /* ── Envíos ── */
  function submitContacto() {
    if (!validarContacto()) return
    setSending(true)
    setTimeout(() => {
      setSending(false)
      setOkMsg('Uno de nuestros asesores te contactará por WhatsApp o llamada dentro de las próximas 48 horas hábiles para acompañarte en el siguiente paso.')
      setStep('ok')
    }, 1100)
  }

  function submitSinConvenio() {
    const e: Record<string, string> = {}
    if (entidadLibre.trim().length < 3) e.entidadLibre = 'Escribe el nombre de tu entidad.'
    if (!RE_EMAIL.test(emailSC.trim())) e.emailSC = 'Escribe un correo válido.'
    if (!authSC) e.authSC = 'Necesitamos tu autorización.'
    setErrors(e)
    if (Object.keys(e).length) return
    setSending(true)
    setTimeout(() => {
      setSending(false)
      setOkMsg('Aún no tenemos convenio con tu entidad, pero registramos tu interés. Apenas lo tengamos te escribiremos para avanzar con tu crédito.')
      setStep('ok')
    }, 1100)
  }

  function pickPerfil(p: Perfil) {
    setPerfil(p)
    // Al cambiar de perfil se limpia la entidad: el catálogo es distinto.
    setPagaduria(null)
    setPagaduriaQuery('')
    clearErr('perfil')
  }

  const showStepper = step === 'perfil' || step === 'entidad' || step === 'contacto'

  return (
    <div className="card-enter grid grid-cols-1 lg:grid-cols-[minmax(0,320px)_1fr] rounded-3xl border border-line bg-white overflow-hidden shadow-card">

      {/* ── Rail de marca ──────────────────────────────────── */}
      <aside className="relative overflow-hidden bg-brand text-white p-6 lg:p-7 flex flex-col">
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-mint to-white/40 pointer-events-none" />
        {/* Isologo medio (half bloom) girado en vertical, sobre el borde derecho */}
        <KoaFlor
          half
          showK={false}
          color="#00DB90"
          animate="breathe"
          className="pointer-events-none absolute top-1/2 right-0 -translate-y-1/2 translate-x-1/2 rotate-90 w-40 h-20 opacity-90"
        />

        <div className="relative z-10 flex-1">
          <h2 className="font-black text-[24px] leading-tight tracking-tight">Solicita tu crédito</h2>
          <p className="text-white/60 text-[13px] mt-2 leading-relaxed">
            Para pensionados y empleados del sector público. Diligencia tus datos y un asesor te contacta.
          </p>

          <ul className="mt-5 space-y-3">
            {[
              { icon: IC.wallet, t: 'Montos y plazos a tu medida', s: 'Con cuota y tasa fija todo el crédito' },
              { icon: IC.spark, t: 'Trámite 100 % digital', s: 'Sin codeudor y con opciones para reportados' },
              { icon: IC.lock, t: 'Descuento por pagaduría', s: 'Se descuenta directo de tu nómina o pensión' },
            ].map(b => (
              <li key={b.t} className="flex items-start gap-3">
                <span className="mt-0.5 inline-flex items-center justify-center shrink-0 w-8 h-8 rounded-xl bg-white/10 text-mint">
                  <Glyph d={b.icon} className="w-4 h-4" />
                </span>
                <div>
                  <p className="text-[13px] font-semibold text-white leading-tight">{b.t}</p>
                  <p className="text-[11.5px] text-white/55 leading-snug mt-0.5">{b.s}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative z-10 text-[11px] text-white/45 leading-relaxed mt-5 pt-4 border-t border-white/10">
          Aprobación sujeta a estudio de crédito. KOA Compañía de Financiamiento S.A., vigilada por la Superfinanciera.
        </p>
      </aside>

      {/* ── Panel de formulario ────────────────────────────── */}
      <div className="p-6 lg:p-7 flex flex-col lg:min-h-[430px]">
        {showStepper && (
          <div className="mb-6 w-full">
            <Stepper steps={STEP_LABELS} current={STEP_INDEX[step]} />
          </div>
        )}

        {/* ── Paso 1: Perfil ── */}
        {step === 'perfil' && (
          <div className="flex flex-col flex-1">
            <div className="mb-4">
              <h3 className="font-bold text-ink text-[16px]">¿Cuál es tu perfil?</h3>
              <p className="text-[12.5px] text-muted mt-0.5">Así te mostramos solo las entidades con convenio para ti.</p>
            </div>

            <div role="radiogroup" aria-label="Perfil" className="grid sm:grid-cols-3 gap-3">
              {PERFILES.map(p => {
                const active = perfil === p.value
                return (
                  <button
                    key={p.value}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => pickPerfil(p.value)}
                    className={`text-left rounded-2xl border p-3.5 transition-all cursor-pointer focus-ring ${
                      active
                        ? 'border-mint bg-mint-bg ring-2 ring-mint/30'
                        : 'border-line hover:border-brand/30 hover:shadow-card'
                    }`}
                  >
                    <span className={`inline-flex items-center justify-center w-9 h-9 rounded-xl mb-2.5 ${
                      active ? 'bg-brand text-mint' : 'bg-app-bg text-brand'
                    }`}>
                      <Glyph d={p.icon} className="w-5 h-5" />
                    </span>
                    <p className={`font-bold text-[14px] leading-tight ${active ? 'text-mint-text' : 'text-ink'}`}>{p.label}</p>
                    <p className="text-[11.5px] text-muted leading-snug mt-1">{p.sub}</p>
                  </button>
                )
              })}
            </div>
            {errors.perfil && <p className="mt-3 text-[12px] text-error font-medium">{errors.perfil}</p>}

            <a
              href="https://wa.me/573157706670"
              target="_blank"
              rel="noopener"
              className="group/wa mt-4 flex items-center gap-3 rounded-2xl border border-mint/40 bg-mint-bg px-4 py-2.5 transition-all hover:border-mint hover:shadow-card focus-ring"
            >
              <span className="inline-flex items-center justify-center shrink-0 w-9 h-9 rounded-xl bg-brand text-mint">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 004.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0012.04 2zm5.8 14.13c-.24.68-1.42 1.32-1.95 1.36-.5.05-.97.24-3.28-.68-2.77-1.09-4.53-3.92-4.67-4.1-.14-.19-1.12-1.49-1.12-2.84 0-1.35.71-2.02.96-2.29.25-.27.55-.34.73-.34.18 0 .37 0 .53.01.17.01.4-.06.62.48.24.55.81 1.9.88 2.04.07.14.12.3.02.48-.09.19-.14.3-.28.46-.14.16-.29.36-.42.48-.14.14-.28.29-.12.57.16.27.72 1.19 1.55 1.93 1.06.95 1.96 1.24 2.24 1.38.27.14.43.12.59-.07.16-.19.68-.79.86-1.06.18-.27.36-.23.61-.14.25.09 1.59.75 1.86.89.27.14.46.2.53.32.07.11.07.66-.17 1.34z" />
                </svg>
              </span>
              <div>
                <p className="text-[12.5px] font-bold text-ink leading-tight">¿Independiente o entidad privada sin convenio?</p>
                <p className="text-[11.5px] text-mint-text font-medium leading-snug mt-0.5 flex items-center gap-1">
                  Escríbenos por WhatsApp y te orientamos
                  <svg className="w-3.5 h-3.5 transition-transform group-hover/wa:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5} aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </p>
              </div>
            </a>

            <div className="mt-auto pt-6 flex justify-end">
              <Button variant="primary" size="md" onClick={() => { if (validarPerfil()) setStep('entidad') }}
                trailingIcon={<Glyph d={IC.arrow} className="w-4 h-4" sw={2.5} />}>
                Continuar
              </Button>
            </div>
          </div>
        )}

        {/* ── Paso 2: Entidad ── */}
        {step === 'entidad' && perfil && (
          <div className="flex flex-col flex-1">
            <div className="mb-4">
              <h3 className="font-bold text-ink text-[16px]">Tu entidad y tus datos</h3>
              <p className="text-[12.5px] text-muted mt-0.5">Perfil seleccionado: <span className="font-semibold text-ink">{PERFIL_LABEL[perfil]}</span></p>
            </div>

            <div className="grid sm:grid-cols-2 gap-x-4 gap-y-3">
              <TextField id="nombres" label="Nombres" autoComplete="given-name" value={nombres}
                onChange={e => { setNombres(e.target.value); clearErr('nombres') }} error={errors.nombres} />
              <TextField id="apellidos" label="Apellidos" autoComplete="family-name" value={apellidos}
                onChange={e => { setApellidos(e.target.value); clearErr('apellidos') }} error={errors.apellidos} />

              <PagaduriaCombo
                perfil={perfil}
                value={pagaduria}
                query={pagaduriaQuery}
                onQuery={q => { setPagaduriaQuery(q); setPagaduria(null); clearErr('pagaduria') }}
                onSelect={p => { setPagaduria(p); setPagaduriaQuery(p.label); clearErr('pagaduria') }}
                onNoConvenio={() => { setEntidadLibre(pagaduriaQuery.trim()); setStep('sin-convenio') }}
                error={errors.pagaduria}
              />

              {perfil === 'pensionado' ? (
                <SelectField
                  id="tipoPension" label="Tipo de pensión" value={tipoPension}
                  onChange={v => { setTipoPension(v); clearErr('tipoPension') }}
                  options={TIPO_PENSION} error={errors.tipoPension}
                />
              ) : (
                <SelectField
                  id="tipoContrato" label="Tipo de contrato" value={tipoContrato}
                  onChange={v => { setTipoContrato(v); clearErr('tipoContrato') }}
                  options={TIPO_CONTRATO} error={errors.tipoContrato}
                />
              )}
            </div>

            <div className="mt-auto pt-6 flex items-center justify-between gap-3">
              <Button variant="ghost" size="md" onClick={() => setStep('perfil')}
                leadingIcon={<Glyph d={IC.back} className="w-4 h-4" sw={2.5} />}>
                Atrás
              </Button>
              <Button variant="primary" size="md" onClick={() => { if (validarEntidad()) setStep('contacto') }}
                trailingIcon={<Glyph d={IC.arrow} className="w-4 h-4" sw={2.5} />}>
                Continuar
              </Button>
            </div>
          </div>
        )}

        {/* ── Paso 3: Contacto ── */}
        {step === 'contacto' && perfil && (
          <div className="flex flex-col flex-1">
            <div className="mb-4">
              <h3 className="font-bold text-ink text-[16px]">Tus datos de contacto</h3>
              <p className="text-[12.5px] text-muted mt-0.5">Un asesor te contacta para continuar con tu solicitud.</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-x-4 gap-y-3">
              <TextField id="email" label="Correo electrónico" type="email" inputMode="email" autoComplete="email"
                placeholder="nombre@correo.com" value={email}
                onChange={e => { setEmail(e.target.value); clearErr('email') }} error={errors.email} />
              <TextField id="celular" label="Celular" hint="10 dígitos, empieza por 3" type="tel" inputMode="numeric"
                maxLength={10} autoComplete="tel-national" placeholder="3001234567" value={celular}
                onChange={e => { setCelular(e.target.value.replace(/\D/g, '').slice(0, 10)); clearErr('celular') }}
                error={errors.celular} />
              <div className="sm:col-span-2">
                <SelectField id="canal" label="Canal de contacto preferido" value={canal}
                  onChange={v => { setCanal(v); clearErr('canal') }} options={CANALES} error={errors.canal} />
              </div>
            </div>

            <label className="flex items-start gap-3 mt-4 cursor-pointer">
              <input type="checkbox" checked={autorizacion}
                onChange={e => { setAutorizacion(e.target.checked); clearErr('autorizacion') }}
                className="mt-0.5 w-4 h-4 accent-brand shrink-0 cursor-pointer" />
              <span className="text-[11.5px] text-muted leading-relaxed">
                He leído y acepto las{' '}
                <a href="https://koa.co/politica-de-tratamiento-de-datos/" target="_blank" rel="noopener" className="text-brand font-semibold underline">políticas de tratamiento</a>{' '}
                y autorizo el tratamiento de mis datos personales por KOA Compañía de Financiamiento S.A.
              </span>
            </label>
            {errors.autorizacion && <p className="mt-2 text-[11px] text-error font-medium">{errors.autorizacion}</p>}

            <div className="mt-auto pt-6 flex items-center justify-between gap-3">
              <Button variant="ghost" size="md" onClick={() => setStep('entidad')}
                leadingIcon={<Glyph d={IC.back} className="w-4 h-4" sw={2.5} />}>
                Atrás
              </Button>
              <Button variant="primary" size="md" loading={sending} onClick={submitContacto}>
                Enviar solicitud
              </Button>
            </div>
          </div>
        )}

        {/* ── Rama sin convenio ── */}
        {step === 'sin-convenio' && (
          <div className="flex flex-col flex-1">
            <div className="mb-5 rounded-xl border border-line border-l-[3px] border-l-warning bg-[#FFFBEB] px-4 py-3">
              <p className="text-[12.5px] text-[#8A6D00] leading-snug">
                Todavía no tenemos convenio con esa entidad. Déjanos tu correo y te avisamos apenas esté disponible.
              </p>
            </div>

            <div className="space-y-4 max-w-lg">
              <TextField id="entidadLibre" label="¿Cuál es tu entidad?" placeholder="Escribe el nombre de tu pagaduría"
                value={entidadLibre} onChange={e => { setEntidadLibre(e.target.value); clearErr('entidadLibre') }}
                error={errors.entidadLibre} />
              <TextField id="emailSC" label="Correo electrónico" type="email" inputMode="email"
                placeholder="nombre@correo.com" value={emailSC}
                onChange={e => { setEmailSC(e.target.value); clearErr('emailSC') }} error={errors.emailSC} />
              <label className="flex items-start gap-3 cursor-pointer">
                <input type="checkbox" checked={authSC}
                  onChange={e => { setAuthSC(e.target.checked); clearErr('authSC') }}
                  className="mt-0.5 w-4 h-4 accent-brand shrink-0 cursor-pointer" />
                <span className="text-[11.5px] text-muted leading-relaxed">
                  Acepto las{' '}
                  <a href="https://koa.co/politica-de-tratamiento-de-datos/" target="_blank" rel="noopener" className="text-brand font-semibold underline">políticas de tratamiento de datos</a>{' '}
                  de KOA Compañía de Financiamiento S.A.
                </span>
              </label>
              {errors.authSC && <p className="text-[11px] text-error font-medium">{errors.authSC}</p>}
            </div>

            <div className="mt-auto pt-7 flex items-center justify-between gap-3">
              <Button variant="ghost" size="md" onClick={() => setStep('entidad')}
                leadingIcon={<Glyph d={IC.back} className="w-4 h-4" sw={2.5} />}>
                Cambiar entidad
              </Button>
              <Button variant="primary" size="md" loading={sending} onClick={submitSinConvenio}>
                Avísenme
              </Button>
            </div>
          </div>
        )}

        {/* ── Éxito ── */}
        {step === 'ok' && (
          <div className="flex flex-col items-center justify-center text-center flex-1 py-6 scale-in">
            <div className="w-16 h-16 rounded-full bg-mint-bg flex items-center justify-center mb-4">
              <span className="w-11 h-11 rounded-full bg-mint flex items-center justify-center text-brand">
                <Glyph d={IC.check} className="w-6 h-6" sw={3} />
              </span>
            </div>
            <h3 className="font-black text-ink text-[20px]">¡Listo! Recibimos tu solicitud</h3>
            <p className="text-[13.5px] text-ink-soft mt-2 max-w-sm leading-relaxed">{okMsg}</p>

            {/* Contacto directo — opciones claras y separadas */}
            <div className="w-full max-w-sm mt-6">
              <p className="text-[11px] font-bold tracking-[0.14em] uppercase text-muted-soft mb-2.5">¿Prefieres avanzar ahora?</p>
              <div className="grid gap-2.5">
                <a
                  href="https://wa.me/573157706670"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-left transition-colors hover:border-mint/50 hover:bg-mint-bg/40"
                >
                  <span className="w-10 h-10 rounded-xl bg-mint-bg flex items-center justify-center flex-shrink-0 text-mint-text">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 004.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0012.04 2zm5.8 14.13c-.24.68-1.42 1.32-1.95 1.36-.5.05-.98.24-3.3-.69-2.79-1.1-4.56-3.95-4.7-4.13-.14-.19-1.13-1.5-1.13-2.86 0-1.36.71-2.03.97-2.31.24-.26.53-.32.71-.32.18 0 .35 0 .51.01.16.01.39-.06.6.46.24.58.79 2 .86 2.15.07.14.12.31.02.5-.09.19-.14.31-.28.48-.14.16-.29.36-.42.48-.14.14-.28.29-.12.57.16.28.72 1.18 1.54 1.91 1.06.95 1.96 1.24 2.24 1.38.28.14.44.12.6-.07.16-.19.69-.8.87-1.08.18-.28.36-.23.6-.14.24.09 1.55.73 1.82.86.27.14.44.21.51.32.07.12.07.66-.17 1.34z"/></svg>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-bold text-ink leading-tight">Escríbenos por WhatsApp</span>
                    <span className="block font-figures text-[12px] text-muted mt-0.5">315 770 6670</span>
                  </span>
                  <Glyph d={IC.arrow} className="w-4 h-4 text-muted-soft group-hover:text-mint-text group-hover:translate-x-0.5 transition-all flex-shrink-0" sw={2.5} />
                </a>
                <a
                  href="tel:6013902240"
                  className="group flex items-center gap-3 rounded-2xl border border-line bg-surface px-4 py-3 text-left transition-colors hover:border-brand/40 hover:bg-brand/[0.03]"
                >
                  <span className="w-10 h-10 rounded-xl bg-brand/[0.08] flex items-center justify-center flex-shrink-0 text-brand">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-bold text-ink leading-tight">Llama a nuestra línea de atención</span>
                    <span className="block font-figures text-[12px] text-muted mt-0.5">601 390 2240</span>
                  </span>
                  <Glyph d={IC.arrow} className="w-4 h-4 text-muted-soft group-hover:text-brand group-hover:translate-x-0.5 transition-all flex-shrink-0" sw={2.5} />
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
