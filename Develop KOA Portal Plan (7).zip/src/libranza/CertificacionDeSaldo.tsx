import { useState } from 'react'
import { createPortal } from 'react-dom'
import { Button, IconTile } from '../components/ui'
import { CreditStatusPill } from '../components/koa'
import OtpVerificationModal from '../components/OtpVerificationModal'
import type { ToastPayload } from '../components/NotificationToast'

const COSTO_ADICIONAL = '$ 8.900'
const DIAS_HABILES = '3 días hábiles'
const CORREO_MASCARADO = 'a****s@correo.com'

const DEMO_OTP = '248731'

export type EstadoSolicitud = 'libre' | 'en-proceso' | 'con-costo'

/* Estado de la certificación de saldo según el crédito (fuente de verdad compartida). */
export function getCertificacionEstado(creditoId: string): EstadoSolicitud {
  return creditoId === '7350' ? 'en-proceso' : creditoId === '2893' ? 'con-costo' : 'libre'
}

/* Banner "en proceso" — se muestra debajo del card principal del detalle. */
export function CertificacionEnProcesoBanner() {
  return (
    <div className="rounded-2xl border border-[#FFD400]/40 bg-[#FFFBEB] p-4 sm:p-5 card-enter">
      <div className="flex items-start gap-3">
        <IconTile toneName="warning" sizeName="md">
          <svg className="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </IconTile>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <p className="font-bold text-ink text-[15px]">Certificación de saldo</p>
            <CreditStatusPill status="en-proceso" />
          </div>
          <p className="text-[13px] text-ink-soft">
            Solicitada el <span className="font-figures font-semibold text-ink">11 AGO 2026</span> · llegará a tu correo en máximo <span className="font-semibold text-ink">{DIAS_HABILES}</span>.
          </p>
          <p className="text-[12px] text-muted mt-1.5">Se enviará a <span className="font-figures font-semibold text-ink">{CORREO_MASCARADO}</span></p>
        </div>
      </div>
    </div>
  )
}

interface CertificacionDeSaldoProps {
  creditoId: string
  numeroMascarado: string
  pagaduria: string
  onToast: (t: ToastPayload) => void
}

/* ── Main component ─────────────────────────────────── */
export default function CertificacionDeSaldo({ creditoId, numeroMascarado, pagaduria, onToast }: CertificacionDeSaldoProps) {
  const [estado] = useState<EstadoSolicitud>(getCertificacionEstado(creditoId))

  /* Modal flow */
  const [otpOpen, setOtpOpen] = useState(false)
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [successOpen, setSuccessOpen] = useState(false)
  const [checkAccepted, setCheckAccepted] = useState(false)
  const [sending, setSending] = useState(false)

  const hasCosto = estado === 'con-costo'
  const mesActual = 'AGO 2026'

  function openModal() {
    setCheckAccepted(false)
    setOtpOpen(true)
  }

  /* OTP verificado → paso de confirmación */
  function handleVerified() {
    setOtpOpen(false)
    setConfirmOpen(true)
  }

  function handleConfirm() {
    setSending(true)
    setTimeout(() => {
      setSending(false)
      setConfirmOpen(false)
      setSuccessOpen(true)
    }, 1000)
  }

  /* En proceso → el banner se muestra debajo del card principal (ver LibranzaDetalle). */
  if (estado === 'en-proceso') return null

  return (
    <>
      {/* ── Card ── */}
      <div className="relative overflow-hidden rounded-2xl border border-line bg-white">
        {/* Franja de acento superior */}
        <span className={`absolute inset-x-0 top-0 h-1 ${hasCosto ? 'bg-gradient-to-r from-[#FFD400] to-warning' : 'bg-gradient-to-r from-brand to-mint'}`} />

        <div className="p-4 sm:p-5 pt-5">
          {/* Encabezado con sello */}
          <div className="flex items-start gap-3.5">
            <span className="relative inline-flex items-center justify-center shrink-0 w-12 h-12 rounded-2xl bg-gradient-to-br from-brand to-brand-navy shadow-sm">
              <svg className="w-6 h-6 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.6}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
              </svg>
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p className="font-bold text-ink text-[15px] leading-tight">Certificación de saldo</p>
                {!hasCosto ? (
                  <span className="flex-shrink-0 inline-flex items-center gap-1 text-[10px] font-bold tracking-wide text-mint-text bg-mint-bg px-2 py-0.5 rounded-full">
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                    Sin costo
                  </span>
                ) : (
                  <span className="flex-shrink-0 inline-flex items-center gap-1 text-[10px] font-bold tracking-wide text-[#8A6D00] bg-[#FFD400]/20 px-2 py-0.5 rounded-full">
                    {COSTO_ADICIONAL}
                  </span>
                )}
              </div>
              <p className="text-[13px] text-muted mt-1 leading-snug">
                Documento oficial firmado con el saldo actual de tu crédito.
              </p>
            </div>
          </div>

          {/* Detalle de la solicitud */}
          <div className="rounded-xl bg-surface-alt divide-y divide-line mt-4">
            <div className="flex items-center justify-between gap-3 px-3.5 py-2.5">
              <span className="text-[12.5px] text-muted">Tiempo de entrega</span>
              <span className="text-[12.5px] font-semibold text-ink text-right">Hasta {DIAS_HABILES}</span>
            </div>
            <div className="flex items-center justify-between gap-3 px-3.5 py-2.5">
              <span className="text-[12.5px] text-muted">Formato</span>
              <span className="text-[12.5px] font-semibold text-ink text-right">PDF</span>
            </div>
            <div className="flex items-center justify-between gap-3 px-3.5 py-2.5">
              <span className="text-[12.5px] text-muted">Envío</span>
              <span className="text-[12.5px] font-semibold text-ink text-right">
                A tu correo registrado
                <span className="block font-figures text-[11.5px] font-semibold text-muted">{CORREO_MASCARADO}</span>
              </span>
            </div>
          </div>

          {hasCosto && (
            <p className="flex items-center gap-1.5 text-[11.5px] text-[#8A6D00] mt-3">
              <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Ya usaste la certificación gratuita de este mes · esta tiene costo de {COSTO_ADICIONAL}.
            </p>
          )}

          <div className="mt-4">
            <Button variant="primary" size="md" className="w-full sm:w-auto" onClick={openModal}>
              Solicitar certificación
            </Button>
          </div>
        </div>
      </div>

      {/* ── Multi-step modal ── */}
      {/* ── Paso 1: OTP (Modal OTP del KOA Design System) ── */}
      <OtpVerificationModal
        open={otpOpen}
        onClose={() => setOtpOpen(false)}
        onVerified={handleVerified}
        kicker="Certificación de saldo"
        description="Ingresa el código enviado a tu correo y celular registrado para confirmar tu solicitud"
        demoCode={DEMO_OTP}
      />

      {/* ── Paso 2: Confirmación ── */}
      {confirmOpen && createPortal(
        <div
          className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 fade-in"
          onClick={e => { if (e.target === e.currentTarget) setConfirmOpen(false) }}
        >
          <div role="dialog" aria-modal="true" className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden scale-in">
            {/* Header */}
            <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-[#F0F2F5]">
              <p className="font-bold text-[16px] text-[#2A3036]">Confirma tu solicitud</p>
              <button onClick={() => setConfirmOpen(false)} aria-label="Cerrar" className="w-8 h-8 rounded-full hover:bg-[#F0F2F5] flex items-center justify-center transition-colors cursor-pointer">
                <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            <div className="px-6 py-5">
              <div className="bg-gray-50 rounded-xl divide-y divide-[#E8ECF2] mb-4">
                <div className="flex justify-between px-4 py-3">
                  <span className="text-[13px] text-gray-500">Crédito</span>
                  <span className="font-figures text-[13px] font-semibold text-[#2A3036]">{numeroMascarado} · {pagaduria}</span>
                </div>
                <div className="flex justify-between px-4 py-3">
                  <span className="text-[13px] text-gray-500">Solicitudes en {mesActual}</span>
                  <span className="text-[13px] font-semibold text-[#2A3036]">{hasCosto ? '1 ya utilizada este mes' : '0 utilizadas'}</span>
                </div>
                <div className="flex justify-between px-4 py-3">
                  <span className="text-[13px] text-gray-500">Costo de esta solicitud</span>
                  <span className={`font-figures text-[13px] font-semibold ${hasCosto ? 'text-[#FFD400]' : 'text-[#005E3C]'}`}>
                    {hasCosto ? COSTO_ADICIONAL : 'Sin costo'}
                  </span>
                </div>
              </div>

              <p className="text-[13px] text-gray-500 mb-4">
                Te llegará a <span className="font-figures font-semibold">{CORREO_MASCARADO}</span> en máximo {DIAS_HABILES}.
              </p>

              {hasCosto && (
                <label className="flex items-start gap-3 mb-4 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={checkAccepted}
                    onChange={e => setCheckAccepted(e.target.checked)}
                    className="mt-0.5 w-4 h-4 accent-brand cursor-pointer"
                  />
                  <span className="text-[13px] text-ink">Acepto el cobro de {COSTO_ADICIONAL} por esta solicitud adicional</span>
                </label>
              )}

              <div className="flex gap-3 justify-end">
                <Button variant="ghost" size="md" onClick={() => setConfirmOpen(false)}>Cancelar</Button>
                <Button
                  variant="primary"
                  size="md"
                  loading={sending}
                  disabled={hasCosto && !checkAccepted}
                  onClick={handleConfirm}
                >
                  Confirmar solicitud
                </Button>
              </div>
            </div>
          </div>
        </div>,
        document.body,
      )}

      {/* ── Success dialog ── */}
      {successOpen && createPortal(
        <div className="fixed inset-0 bg-black/50 z-[80] flex items-center justify-center p-4 fade-in">
          <div role="dialog" aria-modal="true" className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6 text-center scale-in">
            <div className="w-14 h-14 rounded-full bg-[#00DB8E]/20 flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
            </div>
            <h3 className="font-bold text-[18px] text-[#2A3036] mb-1">Solicitud radicada</h3>
            <p className="font-figures text-[20px] font-bold text-[#2A3036] mb-2">SOL-2026-004821</p>
            <p className="text-[13px] text-gray-500 mb-6">
              Te llegará en máximo {DIAS_HABILES} a tu correo registrado <span className="font-figures font-semibold text-[#2A3036]">{CORREO_MASCARADO}</span>.
            </p>
            <div className="flex justify-center">
              <Button variant="primary" size="md" onClick={() => setSuccessOpen(false)}>Cerrar</Button>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </>
  )
}
