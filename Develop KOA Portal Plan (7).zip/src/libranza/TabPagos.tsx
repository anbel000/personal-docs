import { useState } from 'react'
import { pagosCredito4821, formatPesos } from '../data/mockData'

const PAGE = 4

export default function TabPagos() {
  const [visible, setVisible] = useState(PAGE)
  const pagos = pagosCredito4821
  const shown = pagos.slice(0, visible)
  const exhausted = visible >= pagos.length

  // Group by year for section headers
  const groups: { year: number; items: typeof pagos }[] = []
  for (const p of shown) {
    const last = groups[groups.length - 1]
    if (!last || last.year !== p.año) groups.push({ year: p.año, items: [p] })
    else last.items.push(p)
  }

  return (
    <div>
      {groups.map((group) => (
        <div key={group.year}>
          {/* Year separator */}
          <div className="flex items-center gap-2.5 mb-2.5 mt-2 first:mt-0">
            <span className="font-figures text-[10px] font-bold tracking-[0.18em] uppercase text-muted-soft">{group.year}</span>
            <div className="flex-1 h-px bg-line" />
          </div>

          {/* Payment rows */}
          <div className="mb-3 space-y-0.5">
            {group.items.map((p, i) => (
              <div
                key={p.id}
                className="group flex items-center gap-3 py-2 px-2 -mx-2 rounded-xl hover:bg-surface-alt transition-colors fade-in"
                style={{ animationDelay: `${i * 0.04}s` }}
              >
                {/* Icono de cuota recaudada */}
                <div className="w-8 h-8 rounded-lg bg-mint-bg flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-mint-text" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>

                {/* Fecha + fuente del recaudo */}
                <div className="flex-1 min-w-0">
                  <p className="font-figures text-[13px] font-semibold text-ink leading-tight truncate">
                    {p.fecha}
                  </p>
                  <p className="text-[11px] text-muted leading-tight truncate">
                    Recaudo por pagaduría · <span className="font-figures">{p.hora}</span>
                  </p>
                </div>

                {/* Amount */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <span className="font-figures text-[14px] font-bold text-ink">
                    {formatPesos(p.valor)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Load more / end */}
      <div className="flex justify-center pt-2">
        {!exhausted ? (
          <button
            onClick={() => setVisible(v => v + PAGE)}
            className="inline-flex items-center gap-1.5 text-[12px] font-bold text-mint-text hover:underline cursor-pointer py-1.5"
          >
            Ver más pagos
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        ) : (
          <p className="text-[11px] text-muted-soft py-1.5 tracking-wide">Primer pago registrado</p>
        )}
      </div>
    </div>
  )
}
