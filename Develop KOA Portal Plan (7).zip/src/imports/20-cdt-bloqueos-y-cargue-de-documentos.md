---
title: Prompt 20 — CDT, bloqueos y cargue de documentos
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 20 · CDT — bloqueos de cumplimiento y cargue de documentos

Cierra CDT. Depende de `18` y `11`.

> Hay estados en que KOA **no puede** dejar al cliente abrir ni aumentar un CDT hasta validar su información. El diseño tiene que explicar el bloqueo sin acusar a nadie.

---

## Prompt

```
TAREA
Construye los estados de bloqueo por validación de información y la
pantalla de cargue de documentos que los resuelve.

CONTEXTO
Por obligación regulatoria, KOA valida el origen de los recursos y el perfil
de riesgo de sus clientes. Cuando una validación queda pendiente, el cliente
no puede abrir un CDT nuevo ni aumentar el capital de uno existente hasta
resolverla: unas veces subiendo documentos, otras esperando que KOA lo
contacte. El cliente no hizo nada mal, y el texto tiene que dejarlo claro.

ELEMENTOS

1. Bloqueo tipo A — se resuelve con documentos
   En el espacio de CDT, en lugar del botón "Abrir CDT", un botón ancho de
   fondo rosa suave con icono de candado a la izquierda y el texto
   "Para continuar con tu CDT completa tus datos". Lleva a la pantalla de
   cargue de documentos.
   El botón flotante de abrir CDT no se muestra en este estado.

2. Bloqueo tipo B — KOA contacta al cliente
   Mismo botón ancho rosa con candado, con el texto "Estamos validando tu
   información para que puedas abrir más CDT". Al pulsarlo abre un diálogo,
   no una pantalla:
   icono de admiración en círculo, título "Hola, Andrés", y el texto
   "Nos pondremos en contacto contigo para indicarte los pasos a seguir
   para validar tu información." Un botón de cierre.
   En este estado el botón queda además atenuado.

3. Bloqueo al renovar con aumento de capital
   Si el cliente intenta guardar una renovación que aumenta el capital y la
   validación de riesgo lo bloquea, aparece un diálogo:
   icono de admiración, título "Hola, Andrés", texto "Para renovar tu CDT
   necesitamos que nos adjuntes la siguiente documentación." y un botón
   "Continuar" que lleva a la pantalla de cargue de documentos.
   La renovación no se guarda.

4. Pantalla de cargue de documentos
   - Encabezado con el logo KOA centrado.
   - Texto: "Para que puedas abrir más CDT necesitamos que nos adjuntes la
     siguiente documentación."
   - Secciones de documento, una debajo de otra. Cada sección es un recuadro
     con borde, y contiene:
     · Icono de documento a la izquierda.
     · Título de la sección y un subtítulo explicativo.
     · Una lista de ejemplos precedida por la palabra "Ejemplos:".
     · A la derecha, un botón de cargue cuyo icono cambia de estado: flecha
       de subida cuando está vacío, check cuando tiene archivos válidos,
       triángulo de advertencia cuando hay error de formato o tamaño.
     · Debajo, la lista de archivos cargados: icono de estado, nombre
       recortado a 40 caracteres, y una equis para quitarlo.
     · Enlace "Agregar otro archivo" mientras no se alcance el límite.
   - Simula tres secciones:
     "Certificado de ingresos" — subtítulo "Documento que acredite el origen
     de tus recursos" — ejemplos: certificado laboral, declaración de renta,
     extractos bancarios de los últimos tres meses.
     "Documento de identidad" — subtítulo "Cédula por ambas caras" —
     ejemplos: cédula ampliada al 150 %.
     "Soporte del origen de los recursos" — subtítulo "Documento que respalde
     de dónde provienen los fondos" — ejemplos: escritura de venta,
     certificado de cesantías, acta de reparto.
   - Solo acepta PDF. Máximo tres archivos por sección y 5 MB por archivo.
   - Mensajes: "Formato inválido, adjunta un PDF", "El archivo supera el
     máximo de 5 MB", "Olvidaste cargar este archivo" y "Límite de 3
     archivos alcanzado".
   - Cuando una sección ya se envió con éxito, muestra una insignia verde
     "Enviado correctamente", se bloquea y no permite quitar archivos.
   - Botón "Continuar" al pie, deshabilitado hasta que todas las secciones
     tengan al menos un archivo válido.

5. Estados del envío
   - Cargando: capa sobre la pantalla con el texto "Subiendo documentos".
   - Éxito: diálogo con círculo de check, el texto "Recibimos tus documentos.
     Vamos a revisarlos y cualquier novedad te llegará al correo
     registrado." y botón "Continuar".
   - Error: diálogo con título "Error", el detalle del problema y botón
     "Cerrar". Las secciones que sí se enviaron conservan su insignia de
     enviado y no se vuelven a enviar.

6. Aviso en el inicio
   Cuando existe un bloqueo, una fila en el bloque de pendientes: "Completa
   la validación de tu información", con enlace a la pantalla que
   corresponda según el tipo de bloqueo.

COMPORTAMIENTO
- Los datos simulados dejan al cliente SIN bloqueo. Deja los tres estados
  construidos y accesibles para revisarlos.
- El envío tolera fallas parciales: lo que ya se envió no se reenvía.
- Con un bloqueo activo, el flujo de abrir CDT del prompt 18 no es
  alcanzable por ningún camino.

RESTRICCIONES
- Ningún texto culpa al cliente ni sugiere que hizo algo indebido. No uses
  las palabras "rechazado", "sospechoso", "irregular" ni "incumplimiento".
- No menciones la palabra SARLAFT ni normas internas: el cliente no tiene
  por qué conocerlas.
- Solo PDF en el cargue, con el límite escrito de forma visible.
- El botón de continuar no se habilita con secciones incompletas.
- Sin emojis.
```

---

## Cómo verificar

- [ ] Existen los tres bloqueos y se pueden ver: documentos, contacto y renovación.
- [ ] Con bloqueo, el botón de abrir CDT se reemplaza y el flotante desaparece.
- [ ] El cargue acepta solo PDF, con máximo 3 archivos y 5 MB visibles.
- [ ] Una sección ya enviada se bloquea con su insignia y no se reenvía.
- [ ] `Continuar` bloqueado hasta que las tres secciones tengan archivo válido.
- [ ] Ningún texto culpa al cliente. No aparece la palabra SARLAFT.
- [ ] El pendiente del inicio lleva a la pantalla correcta según el bloqueo.
