---
title: Prompt 07 — Libranza, paz y salvo
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 07 · Libranza — paz y salvo

El único certificado a nivel de producto. Depende de `03`.

> **Advertencia de diseño.** El paso de verificación está dibujado como **genérico**, a propósito. Si lleva OTP o no es una decisión abierta que choca con ADR-0008 — ver [`alcance-funcional-libranza.md`](../../../../documentacion/00-fundamentos/alcance-funcional-libranza.md) §9.1. El prototipo deja el paso listo para llenarse cuando se resuelva.

---

## Prompt

```
TAREA
Construye el flujo de paz y salvo de Libranza, como una sección a nivel de
producto y no dentro de un crédito.

CONTEXTO
El paz y salvo certifica que un crédito quedó completamente pagado. Solo
aplica a créditos terminados, y el portal muestra únicamente créditos
activos: por eso este certificado no cuelga de ninguna tarjeta de crédito y
vive a nivel del producto Libranza. El flujo pasa por una verificación antes
de mostrar los créditos terminados, y para consultar otro crédito hay que
repetirlo completo. Es fricción deliberada.

ELEMENTOS

1. Punto de entrada
   En /libranza, bajo la lista de créditos, una tarjeta ancha aparte:
   icono de sello, título "Paz y salvo", descripción "Genera el certificado
   de un crédito que ya terminaste de pagar", y botón "Generar paz y salvo".
   Debe distinguirse visualmente de las tarjetas de crédito: es del producto,
   no de un crédito.

2. Flujo de tres pasos en pantalla completa, con indicador de progreso

   Paso 1 — Verificación
   Encabezado "Verifiquemos que eres tú" y subtítulo "Por seguridad,
   confirmamos tu identidad antes de mostrarte tus créditos terminados".
   Un contenedor centrado con borde punteado y el texto de marcador
   "Paso de verificación — pendiente de definir".
   Botón "Continuar".
   Deja este paso como un componente aislado, fácil de reemplazar.

   Paso 2 — Selección del crédito terminado
   Encabezado "Selecciona el crédito".
   Lista de filas seleccionables con un radio a la izquierda. Cada fila
   muestra exactamente tres datos y nada más:
   - Número de obligación enmascarado: "Crédito ···· 4821"
   - Monto desembolsado y periodo de vida en una sola línea:
     "$ 18.000.000 · MAR 2021 → ENE 2024"
   - Pagaduría, SOLO si el cliente tuvo créditos con más de una pagaduría.
   Botón "Ver paz y salvo", deshabilitado hasta seleccionar.
   Simula dos créditos terminados:
   ···· 4821 · $ 18.000.000 · MAR 2021 → ENE 2024 · Secretaría de Educación
   ···· 7350 · $ 4.200.000 · ENE 2019 → FEB 2022 · Alcaldía de Medellín

   Paso 3 — Certificado
   Vista previa del documento en un contenedor tipo hoja, con sombra suave
   y proporción vertical. Botones "Descargar PDF" y "Consultar otro
   crédito", que reinicia el flujo desde el paso 1.

3. Estado vacío del paso 2
   Cuando no hay créditos terminados que cumplan las condiciones:
   icono, título "Aún no tienes créditos terminados", y descripción
   "El paz y salvo se genera sobre créditos que ya terminaste de pagar.
   Cuando termines alguno, lo verás aquí." Botón "Volver a mis créditos".

COMPORTAMIENTO
- Consultar otro crédito reinicia el flujo desde el paso 1, incluida la
  verificación. No hay atajo al paso 2.
- El botón de continuar de cada paso está deshabilitado hasta cumplir su
  condición.
- Se puede salir del flujo en cualquier paso.

RESTRICCIONES
- En el paso 2 se muestran exactamente esos tres datos. No agregues saldo,
  tasa, plazo, cuotas ni plan de pagos: el saldo de un crédito terminado es
  cero y confunde.
- La pagaduría solo se muestra si hay más de una entre los créditos
  terminados del cliente.
- El estado vacío aparece DESPUÉS de la verificación: el cliente ya hizo un
  esfuerzo, así que el texto debe explicar por qué está vacío, no solo
  decir que no hay resultados.
- El paso de verificación se deja como marcador. No inventes su mecanismo.
```

---

## Cómo verificar

- [ ] La entrada está en `/libranza`, no dentro de un crédito.
- [ ] El paso 2 muestra exactamente tres datos por crédito. Sin saldo.
- [ ] `Consultar otro crédito` vuelve al **paso 1**, no al 2.
- [ ] El estado vacío explica el porqué y ofrece salida.
- [ ] El paso de verificación es un componente aislado y reemplazable.
