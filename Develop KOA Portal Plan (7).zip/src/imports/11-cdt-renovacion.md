---
title: Prompt 11 — CDT, renovación
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 11 · CDT — renovación

La única operación de CDT en este diseño. Depende de `10`.

---

## Prompt

```
TAREA
Llena la zona "Renovación" del detalle del CDT con los tres modos de
renovación y su simulador.

CONTEXTO
Al vencer, un CDT se renueva automáticamente por el mismo plazo, salvo que
el cliente indique otra cosa. Puede dejarlo así, cambiar las condiciones o
pedir que no se renueve y que el dinero vaya a su cuenta. Es la operación
más delicada del portal: define qué pasa con el dinero del cliente.

ELEMENTOS

1. Bloque con encabezado "Renovación" y una línea gris:
   "Podrás modificar esta opción hasta el 29 SEP 2026."

2. Tres opciones excluyentes, como tarjetas seleccionables apiladas, cada
   una con radio a la izquierda, título, descripción y contenido que se
   despliega al elegirla.

   Opción 1 — Renovación automática, seleccionada por defecto
   Descripción: "Al vencer, renovamos tu capital más los intereses ganados
   por el mismo plazo, con la tasa vigente ese día."
   Al estar activa despliega cuatro tarjetas pequeñas en rejilla de dos por
   dos: "NUEVO MONTO $ 26.940.300", "PLAZO 12 meses · Al vencimiento",
   "TASA E.A. 11,80 %" con la nota "Vigente hoy, sujeta a cambios", e
   "INTERESES $ 1.940.300" con la nota "Aproximados".

   Opción 2 — Modificar condiciones
   Descripción: "Cambia el monto, el plazo o la forma de pago de los
   rendimientos."
   Al estar activa despliega, en este orden:
   a. Campo de monto con símbolo $, y debajo "Monto mínimo $ 1.000.000 ·
      Monto máximo $ 500.000.000". Fuera de rango, el texto se pone rojo y
      aparece el mensaje "Ingresa un monto dentro del rango permitido".
   b. Pregunta "¿Reinvertir los rendimientos?" con opciones Sí y No.
   c. Un bloque de comparación que aparece solo si el monto cambió:
      título "Estás aumentando tu inversión" en menta o "Estás disminuyendo
      tu inversión" en ámbar, y tres filas: "CDT actual", "Diferencia" y
      "Rendimientos que se reinvierten".
   d. Selector de plazo: botones cuadrados con el número de meses arriba y
      la palabra MESES abajo. Opciones 6, 12, 18, 24, 36.
   e. Selector de periodicidad, que aparece al elegir plazo: botones en
      columna con AL VENCIMIENTO, MENSUAL, TRIMESTRAL, SEMESTRAL, ANUAL.
   f. Botón "Simular", que al pulsarse muestra un panel de resultado con
      tres bloques: "Nueva inversión", "Tasa E.A." y "Rendimientos netos",
      y bajo ellos la nota "La tasa y los rendimientos son informativos y
      se calculan con la tasa vigente hoy. Al renovar se aplica la tasa
      del día."
   g. Tras simular, el botón cambia a "Guardar renovación".

   Opción 3 — No renovar
   Descripción: "Al vencer, tu inversión y tus rendimientos se depositan en
   tu cuenta bancaria inscrita."
   Al estar activa muestra un recuadro informativo con el banco y el número
   de cuenta enmascarado, y la línea "Verifica que tu cuenta esté
   actualizada antes del vencimiento."

3. Diálogo de confirmación al guardar cualquiera de los tres cambios
   Título "Confirma el cambio", resumen de la opción elegida con sus
   condiciones, y botones "Volver" y "Confirmar cambio".
   Al confirmar, aviso emergente verde "Tu instrucción de renovación fue
   actualizada."

COMPORTAMIENTO
- Las tres opciones son excluyentes: elegir una desactiva las otras.
- El botón de simular está deshabilitado hasta que haya monto válido,
  plazo y periodicidad.
- Cambiar el monto, el plazo o la periodicidad después de simular borra el
  resultado y devuelve el botón a "Simular".
- Los selectores de plazo y periodicidad aparecen en cascada: la
  periodicidad no se muestra hasta elegir plazo.
- Todo cambio pasa por el diálogo de confirmación.

RESTRICCIONES
- Ningún cambio se aplica sin pasar por el diálogo de confirmación.
- Las notas sobre la tasa vigente y los intereses aproximados son
  obligatorias y deben quedar visibles, no en un tooltip.
- No incluyas el flujo de pago del aumento de capital: no entra en este
  diseño.
- Redacción en tuteo colombiano. Nunca "personalizá", "cambiá" ni
  "ingresá".
```

---

## Cómo verificar

- [ ] Las tres opciones son excluyentes y solo una puede estar activa.
- [ ] Simular está bloqueado hasta tener monto válido, plazo y periodicidad.
- [ ] Cambiar un dato después de simular borra el resultado.
- [ ] Las notas de tasa vigente e intereses aproximados están visibles, no en tooltip.
- [ ] No hay ni un texto en voseo.
- [ ] Ningún cambio se guarda sin diálogo de confirmación.
