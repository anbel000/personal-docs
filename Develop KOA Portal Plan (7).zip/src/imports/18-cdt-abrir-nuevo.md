---
title: Prompt 18 — CDT, abrir un CDT nuevo
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 18 · CDT — abrir un CDT nuevo desde el portal

La capacidad que faltaba entera. Depende de `10` y `13`.

> El cliente ya existe, así que **no pasa por onboarding**: simula, acepta el reglamento y paga. Todo dentro del portal.

---

## Prompt

```
TAREA
Construye el flujo para que un cliente que ya tiene productos abra un CDT
nuevo desde el portal: simulador, resultado, aceptación del reglamento y
resumen de pago.

CONTEXTO
Un cliente que ya está en el portal puede abrir otro CDT sin volver a
registrarse: KOA ya tiene sus datos. El flujo tiene tres pasos antes del
pago. El simulador le deja ver cuánto ganaría; el reglamento es obligación
legal; el resumen confirma antes de mover dinero. La tasa depende del monto
y del plazo, y puede mejorar si el cliente llegó por un referido o por una
campaña.

ELEMENTOS

1. Puntos de entrada
   - Botón "Abrir CDT" en el espacio de CDT, junto al encabezado.
   - Botón flotante fijo abajo a la izquierda, redondo, con icono, visible
     dentro del espacio de CDT.
   Los dos llevan al paso 1.

2. Paso 1 — Simulador, pantalla centrada de una columna
   - Título "Simula tu CDT Digital".
   - Campo de monto: grande, con símbolo $ y formato de miles automático.
     Marcador de posición con el monto mínimo. Debajo, la línea
     "Monto mínimo $ 1.000.000 · Monto máximo $ 500.000.000". Fuera de rango
     el borde se pone rojo y aparece el mensaje.
   - Campo de plazo: número en meses, máximo dos dígitos. Debajo,
     "Plazo entre 6 y 36 meses".
   - Lista desplegable de periodicidad de pago de rendimientos, con un icono
     de ayuda que abre un diálogo explicativo. Opciones: Al vencimiento,
     Mensual, Trimestral, Semestral, Anual.
   - Botón "Simular", ancho completo.
   - Botón secundario "Volver al portal".
   No incluyas la pregunta de si lo ayudó un asesor: el cliente ya existe y
   ese dato ya lo tiene KOA.

3. Paso 2 — Resultado de la simulación, misma pantalla
   - "INVERSIÓN" en versalitas y el monto en 32px.
   - Bloque de tasa con fondo destacado: "TASA E.A." y la tasa en grande con
     icono de ayuda. Debajo, "Tasa vigente hasta el 20/08/2026".
   - Si aplica tasa preferencial, un segundo bloque con el rótulo
     "Tasa preferencial" y, según el caso, la etiqueta "Referido" o
     "Campaña comercial", con la tasa mejorada.
   - "PLAZO" y el número de meses, con la línea "Del 14/08/2026 al
     14/08/2027".
   - "RENDIMIENTOS" y el monto, con icono de ayuda.
   - "RETENCIÓN 4 % SOBRE RENDIMIENTOS" y el monto en negativo, en rojo.
   - "INVERSIÓN + RENDIMIENTOS" y el total, destacado.
   - Enlace "Términos y condiciones del CDT Digital".
   - Párrafo gris pequeño con la advertencia de que las tasas y los valores
     son informativos y pueden cambiar.
   - Botón principal "Abrir CDT".
   - Fila con dos acciones secundarias: "Volver" con flecha, y "Compartir"
     con icono, que copia un enlace de la simulación y muestra un aviso
     emergente "Enlace copiado".
   Datos simulados: inversión $ 20.000.000, tasa 11,80 % E.A., plazo 12
   meses, rendimientos $ 2.360.000, retención $ 94.400, total $ 22.265.600.

4. Paso 3 — Reglamento y derechos
   - Título "Términos y condiciones de tu CDT Digital".
   - Dos acordeones cerrados, cada uno con su área de scroll propia y su
     enlace de descarga en PDF:
     "Reglamento del CDT" con el texto del contrato de adhesión, y
     "Derechos y obligaciones del consumidor financiero".
   - Casilla de aceptación: "Declaro que he leído y acepto los términos y
     condiciones, el Reglamento del CDT y conozco mis derechos y
     obligaciones como consumidor financiero."
   - Botón "Continuar", deshabilitado hasta marcar la casilla.
   - Si el cliente marca la casilla sin haber desplegado el reglamento,
     aparece un aviso emergente ámbar: "Te recomendamos leer el Reglamento
     de tu CDT Digital. Es fundamental para conocer los términos de tu
     inversión." El botón se habilita igual.

5. Paso 4 — Resumen de pago
   - Ilustración y el título "Llegó el momento de ser un
     #InversionistaKOA".
   - "INVERSIÓN" y el monto en grande.
   - "TASA E.A." y la tasa, con icono de ayuda.
   - "PLAZO" y los meses, con las fechas de inicio y fin.
   - Pregunta "¿Cómo deseas hacer el pago?" y debajo, en gris: "Recuerda
     actualizar tus topes en la entidad bancaria para evitar el rechazo de
     la transacción."
   - Tres botones apilados, ancho completo: "Pagar con PSE",
     "Transferencias" y "Cheque o efectivo".
   Los tres llevan a las pantallas del prompt 19.

6. Bloqueo por proceso en curso
   Si el cliente ya tiene una apertura de CDT pendiente de pago, los botones
   de entrada al flujo quedan atenuados y sin acción, con un mensaje al
   pasar el cursor: "Tienes un proceso en curso. En cuanto se confirme tu
   pago se realizará la apertura de tu CDT y podrás adquirir nuevos
   productos."

COMPORTAMIENTO
- El botón "Simular" está deshabilitado hasta que monto, plazo y
  periodicidad sean válidos.
- Cambiar cualquier dato después de simular vuelve al paso 1 y borra el
  resultado.
- El indicador de progreso muestra los cuatro pasos y en cuál está.
- Se puede salir del flujo en cualquier paso, con confirmación de descarte.
- La tasa preferencial simulada está desactivada por defecto; deja el bloque
  construido y accesible.

RESTRICCIONES
- Este flujo no pide datos personales ni de identidad: el cliente ya existe.
- No incluyas la opción de "apertura rápida" solo con PSE: desde el portal
  hay un único camino con los tres medios de pago en el paso 4.
- La retención del 4 % se muestra siempre y en negativo.
- El reglamento no se puede aceptar sin que la casilla esté marcada.
- Tasas y montos con coma decimal y punto de miles.
```

---

## Cómo verificar

- [ ] Los dos puntos de entrada llevan al simulador.
- [ ] `Simular` bloqueado hasta tener monto, plazo y periodicidad válidos.
- [ ] El resultado muestra retención del 4 % en negativo.
- [ ] Marcar la casilla sin abrir el reglamento dispara el aviso ámbar.
- [ ] El paso 4 ofrece los tres medios de pago.
- [ ] Con proceso en curso, los botones de entrada quedan atenuados con su mensaje.
- [ ] El flujo **no** pide datos personales.
- [ ] No aparece la opción de apertura rápida.
