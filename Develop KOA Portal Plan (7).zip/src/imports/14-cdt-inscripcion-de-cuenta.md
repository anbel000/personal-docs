---
title: Prompt 14 — CDT, inscripción de la cuenta de desembolso
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 14 · CDT — inscripción de la cuenta de desembolso

El flujo y **todas sus notificaciones**. Depende de `10` y `13`.

> Sin cuenta inscrita, KOA no puede pagarle al cliente ni sus rendimientos ni su capital. Por eso el portal actual insiste en cuatro lugares distintos. Este prompt construye los cuatro.

---

## Prompt

```
TAREA
Construye el flujo de inscripción de la cuenta de desembolso de un CDT y
las cuatro notificaciones que empujan al cliente a completarlo.

CONTEXTO
La cuenta de desembolso es la cuenta bancaria donde KOA le paga al cliente
los rendimientos y el capital al vencimiento. Debe estar a nombre del
cliente. Un CDT sin cuenta inscrita, o con la cuenta rechazada, no puede
pagarse: es el pendiente más grave del portal y hay que insistir en él sin
volverse molesto. Inscribirla o cambiarla exige firma electrónica, y queda
en validación hasta que un área interna la aprueba.

ELEMENTOS

1. Formulario, en el acordeón "Cuenta de desembolso" del detalle del CDT
   - Encabezado del acordeón con un punto ámbar cuando la cuenta falta o
     está rechazada.
   - Dos líneas centradas: "Cuenta donde recibirás tus rendimientos y tu
     capital" en negrita de 16px, y "Recuerda que la cuenta debe estar a tu
     nombre" en 14px.
   - Campo Banco: lista desplegable con buscador. Opciones simuladas:
     Bancolombia, Davivienda, Banco de Bogotá, BBVA Colombia, Banco Popular,
     Scotiabank Colpatria, Itaú, Nequi, Daviplata.
   - Tipo de cuenta: dos opciones, Ahorros y Corriente.
   - Número de cuenta: solo dígitos, entre 8 y 20. Mensajes propios para
     campo vacío, para menos de 8 y para más de 20.
   - Línea de estado: "Estado de la cuenta" en versalitas y a su derecha una
     StatusPill.
   - Botón de acción, cuyo texto y disponibilidad dependen del estado.

2. Los cuatro estados de la cuenta, cada uno con su color y su
   comportamiento
   - Sin inscribir: sin StatusPill. Campos vacíos y editables.
     Botón "Guardar".
   - En validación: StatusPill púrpura. Campos en solo lectura.
     Botón deshabilitado con el texto "Actualizar". Nota gris: "Estamos
     validando tu cuenta. Te avisaremos cuando quede lista."
   - Validada: StatusPill verde. Campos editables.
     Botón "Actualizar".
   - Rechazada: StatusPill roja. Campos editables. Franja roja sobre el
     formulario: "No pudimos validar esta cuenta. Verifica los datos y
     vuelve a intentarlo, o comunícate con nosotros."
     Botón "Actualizar".

3. Guardado con firma electrónica
   Al pulsar Guardar o Actualizar se abre el diálogo de firma electrónica
   con la operación "Cuenta bancaria". Al firmar, el estado pasa a "En
   validación", los campos se bloquean y aparece un aviso emergente verde:
   "Listo. El cambio de tu cuenta está en validación."

4. Notificación 1 — Modal obligatorio al entrar al portal
   Aparece dos segundos después de cargar el inicio, si hay algún CDT activo
   sin cuenta inscrita o con cuenta rechazada.
   - Icono de lápiz en cuadro, título "Hola, Andrés", y el texto "Casi
     estamos listos. Necesitamos que registres una cuenta para cada uno de
     tus CDT."
   - Una fila por CDT afectado: icono de advertencia ámbar, "CDT KOA ····
     9012 ($ 25.000.000)", y debajo "Tu CDT KOA no tiene una cuenta
     inscrita". Cada fila es clicable y lleva al detalle de ese CDT con el
     acordeón de la cuenta abierto.
   - Pie informativo con icono de tarjeta: "Recuerda que la inscripción
     exitosa de la cuenta es para que puedas recibir los rendimientos y el
     capital de tu CDT sin problemas."
   - Se puede cerrar. Vuelve a aparecer en el siguiente ingreso mientras el
     pendiente exista.

5. Notificación 2 — Aviso en la tarjeta del CDT
   En la lista de CDT, la tarjeta cuyo CDT no tiene cuenta muestra una
   franja ámbar delgada en la parte superior con el texto "Inscribe tu
   cuenta bancaria".

6. Notificación 3 — Banda de alerta en el detalle del CDT
   Sobre el encabezado del detalle, banda ámbar con icono de triángulo,
   título "Inscribe tu cuenta bancaria" y texto "Recuerda que debes
   inscribir una cuenta bancaria habilitada para recibir los recursos de tu
   CDT Digital." Se puede descartar con una equis.

7. Notificación 4 — Pendiente en el inicio
   Una fila en el bloque de pendientes del inicio: "Inscribe la cuenta de tu
   CDT ···· 9012", con enlace al detalle.

COMPORTAMIENTO
- Los datos simulados dejan el CDT ···· 9012 sin cuenta inscrita y el CDT
  ···· 5567 con cuenta Validada, para poder ver los dos caminos.
- Con la cuenta En validación no se puede editar ni volver a enviar.
- Las cuatro notificaciones desaparecen cuando la cuenta queda inscrita o
  validada.
- El aviso del detalle, una vez descartado, no reaparece en esa visita.

RESTRICCIONES
- El estado se escribe "En validación" con tilde. Los cuatro estados van en
  palabras, nunca en códigos.
- No se puede guardar sin pasar por la firma electrónica.
- El número de cuenta acepta solo dígitos: filtra cualquier otro carácter.
- El modal obligatorio nombra cada CDT afectado con su número enmascarado y
  su monto. Un aviso genérico no sirve si el cliente tiene varios CDT.
- El aviso no usa lenguaje alarmista ni bloquea la navegación.
```

---

## Cómo verificar

- [ ] Los cuatro estados existen y cambian los campos y el botón.
- [ ] Guardar abre la firma electrónica con el mensaje de cuenta bancaria.
- [ ] Tras firmar, el estado pasa a `En validación` y los campos se bloquean.
- [ ] El modal obligatorio aparece a los 2 s y lista cada CDT con monto.
- [ ] Están las cuatro notificaciones: modal, tarjeta, detalle e inicio.
- [ ] `En validación` lleva tilde.
- [ ] Con la cuenta validada, ninguna notificación aparece.
