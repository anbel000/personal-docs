---
title: Prompt 10 — CDT, portafolio
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 10 · CDT — portafolio

Solo visible en Fase 2. Depende de `01`.

---

## Prompt

```
TAREA
Construye el espacio del producto CDT: el resumen del portafolio, la lista
de CDT y el detalle de un CDT, en /cdt y /cdt/:id.

CONTEXTO
Un CDT es un certificado de depósito a término: el cliente invierte un
monto por un plazo fijo y recibe rendimientos. A diferencia de Libranza, en
CDT sí hay CDT terminados que se muestran. Este producto está disponible
para persona natural y para persona jurídica, y solo existe en la Fase 2.

ELEMENTOS

1. Resumen en /cdt
   Encabezado "Mis CDT" con subtítulo "Consulta tus inversiones y sus
   rendimientos".
   Tres KpiCard: "Inversión total $ 42.000.000", "Rendimientos
   $ 3.184.500", "Tasa ponderada 11,42 % E.A.".

2. Pestañas Activos y Terminados, con el conteo en una insignia.
   A diferencia de Libranza, aquí sí se listan los terminados.

3. Lista de CDT en tarjetas verticales
   Cada tarjeta:
   - Título "CDT" con el número enmascarado, y a la derecha StatusPill
     de estado.
   - Una insignia pequeña de renovación: "Renovación automática" en menta
     si está activa, o "Sin renovación" en gris.
   - MONTO INVERTIDO en versalitas y debajo la cifra grande en Space
     Grotesk.
   - Dos filas: "Rendimientos a la fecha" y "Vencimiento".
   - Barra de progreso del plazo transcurrido, con la etiqueta "Faltan 48
     días" a la derecha.
   - Flecha de entrada.

   Datos simulados, activos:
   CDT ···· 9012 · Activo · renovación automática · $ 25.000.000 ·
   rendimientos $ 1.940.300 · vence 30 SEP 2026 · 72 % transcurrido.
   CDT ···· 5567 · Activo · sin renovación · $ 17.000.000 ·
   rendimientos $ 1.244.200 · vence 12 DIC 2026 · 41 % transcurrido.
   Terminados:
   CDT ···· 2231 · Terminado · $ 8.000.000 · rendimientos $ 612.400 ·
   venció 15 FEB 2026.

4. Detalle en /cdt/:id
   - Enlace "Volver a mis CDT".
   - Encabezado con el número completo y botón de copiar, StatusPill a la
     derecha.
   - Bloque destacado con el monto invertido en 36px y, en fila,
     "Rendimientos a la fecha" y "Vencimiento".
   - Barra de progreso del plazo con fechas de apertura y vencimiento en
     los extremos.
   - Acordeón "Detalle del CDT", abierto: Estado, Tasa fija 11,80 % E.A.,
     Rendimientos financieros, Rendimientos a la fecha, Periodicidad de
     pago de rendimientos, Fecha de apertura, Fecha de vencimiento.
   - Acordeón "Cuenta de desembolso", cerrado: banco, tipo de cuenta y
     número enmascarado, con una StatusPill del estado de la cuenta y el
     texto explicativo "Es la cuenta donde recibirás tus rendimientos y tu
     capital al vencimiento."
   - Zona "Certificados" con dos tarjetas de descarga: "Certificado de
     depósito" y "Términos y condiciones".
   - Zona vacía reservada con el título "Renovación", que se llena en el
     prompt siguiente.

COMPORTAMIENTO
- Este espacio solo existe en Fase 2. En Fase 1 la ruta muestra el estado
  de producto próximo.
- Con persona jurídica el contenido es el mismo, sin cambios.
- La pestaña Terminados muestra las tarjetas sin barra de progreso y con
  la fecha en pasado.
- Con un solo CDT no se dibuja la lista: se entra directo al detalle.

RESTRICCIONES
- El estado del CDT se escribe siempre en palabras completas y en español:
  Activo, Terminado, Renovado, Cancelado. Nunca códigos ni la palabra
  "error".
- En la lista el número va enmascarado; en el detalle, completo.
- Las cifras de rendimientos no llevan lenguaje celebratorio ni emojis.
- No incluyas apertura de un CDT nuevo: no entra en este diseño.
```

---

## Cómo verificar

- [ ] Las pestañas `Activos` / `Terminados` funcionan y muestran conteo.
- [ ] Ningún estado se muestra como código ni como `error`.
- [ ] En Fase 1 la ruta `/cdt` muestra el estado de producto próximo.
- [ ] Con persona jurídica el contenido es idéntico.
- [ ] La zona `Renovación` queda reservada y vacía.
