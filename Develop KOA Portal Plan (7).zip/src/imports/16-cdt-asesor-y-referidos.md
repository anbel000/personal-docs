---
title: Prompt 16 — CDT, asesor y referidos
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 16 · CDT — asesor y referidos

Depende de `10` y `13`.

> Es **un solo recuadro con dos caras**: si el cliente llegó por un asesor, ve a su asesor. Si no, ve su programa de referidos. Nunca los dos.

---

## Prompt

```
TAREA
Construye el recuadro de asesor y referidos del espacio de CDT, con sus dos
caras y el flujo de activación del programa de referidos.

CONTEXTO
Un cliente de CDT puede haber llegado por un asesor comercial o por su
cuenta. Si tiene asesor, el portal le da un canal directo con esa persona.
Si no lo tiene, el portal le ofrece el programa de referidos: comparte su
código, y por cada persona nueva que abra su primer CDT usando ese código
recibe un bono. El referido, además, obtiene una tasa mejor. Activar el
programa exige aceptar términos y firmar electrónicamente.

ELEMENTOS

1. Un solo recuadro, encabezado por el título que corresponda: "Tu asesor"
   o "Referidos". Alto igual al del bloque vecino.

2. Cara A — el cliente tiene asesor
   Centrado, sobre fondo con degradado suave:
   - Código del asesor en Space Grotesk, pequeño.
   - Nombre y apellido del asesor en 18px.
   - "TU ASESOR EXPERTO" en versalitas de 10px.
   - Celular del asesor.
   - Botón verde de WhatsApp con icono y el texto "Hablemos".
   Datos simulados: código ASE-0412, Claudia Rojas, 310 555 12 34.
   El botón abre WhatsApp con un mensaje ya escrito:
   "Hola, mi nombre es Andrés Beltrán (CC 1.020.***.456). Necesito asesoría
   con mis productos KOA."

3. Cara B — el cliente ya activó su programa de referidos
   - "TU CÓDIGO REFERIDO KOA" en versalitas, en dos líneas.
   - El código en 18px y en negrita: AB4589R
   - Botón de WhatsApp "Enviar por WhatsApp", que comparte el mensaje:
     "Hola. Te comparto un dato bueno. Me uní al Plan de Referidos KOA y
     tengo un beneficio para ti. Si abres tu CDT Digital usando mi código
     AB4589R, KOA te da un 0,30 % E.A. adicional en tu tasa. Solo tienes
     que entrar a koa.co, ir a la sección CDT, simular tu CDT e ingresar mi
     código."

4. Cara C — el cliente no tiene asesor y no ha activado referidos
   - Texto centrado: "Lleva a KOA al siguiente nivel. Únete a nuestra
     comunidad de embajadores y empieza a compartir beneficios."
   - Botón "Quiero ser embajador".

5. Diálogo de activación, al pulsar "Quiero ser embajador"
   Ancho 550px.
   - Título "Programa de Referidos KOA".
   - Acordeón abierto con el título "Términos y condiciones" y, dentro, un
     área con scroll propio y el texto del programa:
     Que es un beneficio para clientes de KOA. Que participar son tres
     pasos: activarse para obtener el código, compartirlo con personas que
     aún no sean clientes, y ganar un bono por cada referido que complete la
     apertura de su primer CDT. Que los bonos van de $ 25.000 a $ 1.200.000
     según el monto y el plazo de la inversión del referido. Que los bonos
     llegan al correo registrado. Que solo aplica a clientes nuevos, es
     decir personas que nunca hayan tenido un CDT en KOA. Y que el referido
     obtiene una tasa adicional del 0,30 % sobre la tasa de su simulación.
   - Separador.
   - Casilla de aceptación: "Acepto los términos y condiciones del programa
     de referidos KOA", con el texto de los términos como enlace descargable.
   - Botón "Continuar", deshabilitado hasta marcar la casilla.

6. Firma electrónica y resultado
   Al continuar se abre el diálogo de firma electrónica con la operación
   "Referidos". Al firmar, el recuadro cambia a la cara B con el código
   recién generado y aparece un aviso emergente verde: "Bienvenido al equipo
   de Referidos KOA."

7. Estados
   - Cargando: esqueleto con el texto "Cargando información".
   - Error: fondo rojo suave, icono y el texto "Tuvimos un inconveniente al
     cargar la información. Intenta más tarde."

COMPORTAMIENTO
- Si el cliente tiene asesor se muestra la cara A y no se consulta nada de
  referidos.
- Sin asesor, se muestra la cara B si ya tiene código, o la cara C si no.
- El código de referido se arma con la primera letra del nombre, la primera
  del apellido, los últimos cuatro dígitos del documento y la letra R.
  Para Andrés Beltrán con documento terminado en 4589: AB4589R.
- El botón "Continuar" del diálogo no se habilita sin la casilla marcada.
- Los datos simulados dejan al cliente SIN asesor y SIN código, para que se
  pueda recorrer el flujo completo. Deja la cara A construida y accesible.

RESTRICCIONES
- Las tres caras nunca se muestran juntas.
- El documento del cliente va parcialmente enmascarado en el mensaje de
  WhatsApp.
- Los enlaces de WhatsApp abren en pestaña nueva.
- El beneficio del referido se escribe siempre como 0,30 % E.A., con coma
  decimal.
- Sin emojis en la interfaz. En los mensajes de WhatsApp tampoco.
```

---

## Cómo verificar

- [ ] Es un solo recuadro y solo se ve una cara a la vez.
- [ ] `Quiero ser embajador` abre el diálogo con los términos en área con scroll.
- [ ] `Continuar` está bloqueado hasta marcar la casilla.
- [ ] Tras firmar aparece el código `AB4589R` y la cara B.
- [ ] Los mensajes de WhatsApp llevan el documento enmascarado.
- [ ] La cara A existe y se puede ver.
- [ ] Existen los estados de carga y error.
