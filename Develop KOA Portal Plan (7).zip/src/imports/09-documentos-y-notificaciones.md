---
title: Prompt 09 — Documentos y notificaciones
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 09 · Documentos y notificaciones

El centro transversal que no existe hoy en ningún producto. Depende de `01` y `06`.

---

## Prompt

```
TAREA
Construye la pantalla Documentos en /documentos y el panel de
notificaciones que abre la campana del cabezote.

CONTEXTO
Documentos es un centro transversal: reúne todo lo que el cliente ha
descargado y todo lo que ha solicitado, de cualquier producto. Resuelve un
problema concreto: la certificación de saldo de Libranza llega por correo y
una segunda copia del mismo mes cuesta dinero, así que el cliente que borre
ese correo necesita un lugar donde encontrarla sin volver a pagar.

ELEMENTOS

1. Encabezado y filtros en /documentos
   Título "Documentos" y subtítulo "Todos tus certificados y solicitudes".
   Dos filas de píldoras de filtro:
   - Por estado: Todos · Disponibles · En proceso
   - Por producto: Todos · Libranza · CDT
   A la derecha, campo de búsqueda por nombre.

2. Bloque "En proceso", primero y solo si hay algo
   Tarjetas con fondo ámbar muy claro:
   icono de reloj, nombre del documento, producto y crédito de origen,
   fecha de solicitud, número de radicado en Space Grotesk, StatusPill
   "En proceso" y la línea "Te llegará a tu correo en máximo X días
   hábiles".
   Simula una: "Certificación de saldo · Libranza · Crédito ···· 7350 ·
   Solicitada el 11 AGO 2026 · SOL-2026-004821".

3. Bloque "Disponibles"
   Lista agrupada por mes, con el mes como encabezado.
   Cada fila: icono según el tipo de documento, nombre, una línea gris con
   producto y origen, fecha de emisión a la derecha, y botón de descarga.
   Simula ocho documentos mezclando Libranza y CDT:
   - Extracto mensual · Libranza · Crédito ···· 4821 · 05 AGO 2026
   - Plan de pagos · Libranza · Crédito ···· 4821 · 02 AGO 2026
   - Certificación de saldo · Libranza · Crédito ···· 4821 · 28 JUL 2026
   - Carta de condiciones · Libranza · Crédito ···· 7350 · 21 JUL 2026
   - Certificado CDT · CDT · CDT ···· 9012 · 15 JUL 2026
   - Amortización · Libranza · Crédito ···· 4821 · 10 JUL 2026
   - Extracto mensual · Libranza · Crédito ···· 4821 · 05 JUL 2026
   - Paz y salvo · Libranza · Crédito ···· 3344 · 30 JUN 2026

4. Estado vacío
   Cuando no hay documentos: icono, título "Aún no tienes documentos" y
   descripción "Los certificados que descargues o solicites quedarán
   guardados aquí."

5. Panel de notificaciones
   Se abre desde la campana del cabezote como panel deslizante desde la
   derecha, de 380px, con encabezado "Notificaciones" y enlace
   "Marcar todas como leídas".
   Cada notificación: punto menta si no está leída, icono según el tipo,
   título, una línea de detalle y la antigüedad relativa
   ("Hace 2 horas", "Ayer", "Hace 3 días").
   Simula cinco:
   - "Tu certificación de saldo está en proceso" · Hace 2 horas · no leída
   - "Descuento aplicado por $ 742.500" · Ayer · no leída
   - "Completa tu información financiera" · Hace 3 días · leída
   - "Tu extracto de julio está disponible" · Hace 6 días · leída
   - "Actualizamos nuestros términos y condiciones" · Hace 12 días · leída
   Estado vacío: "Estás al día. No tienes notificaciones nuevas."
   Al pie, enlace "Ver todas".

COMPORTAMIENTO
- Los filtros se combinan entre sí y con la búsqueda.
- El bloque "En proceso" se oculta entero si no hay solicitudes en curso.
- Al descargar, aviso emergente verde "Documento descargado".
- La campana muestra punto rojo solo cuando hay notificaciones sin leer.
- Al abrir el panel, las notificaciones no se marcan leídas automáticamente.

RESTRICCIONES
- Cada documento indica siempre de qué producto y de qué crédito o CDT
  proviene: un cliente con varios no puede distinguirlos por el nombre.
- El plazo va literal como X días hábiles: aún no está definido.
- Las solicitudes en proceso van siempre arriba de las disponibles.
- Esta pantalla no pertenece a ningún producto y debe funcionar igual con
  Libranza sola, con CDT solo o con los dos.
```

---

## Cómo verificar

- [ ] `En proceso` va arriba y desaparece si está vacío.
- [ ] Cada documento dice producto y crédito o CDT de origen.
- [ ] Los filtros de estado y producto se combinan con la búsqueda.
- [ ] La campana solo tiene punto rojo si hay sin leer.
- [ ] Abrir el panel no marca todo como leído.
- [ ] Con solo un producto activo, la pantalla sigue funcionando.
