---
title: Prompt 04 — Libranza, pagos y cuotas
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 04 · Libranza — pagos y cuotas

Llena la zona `Pagos` del detalle y agrega el plan de cuotas. Depende de `03`.

---

## Prompt

```
TAREA
Llena la zona "Pagos" del detalle del crédito de libranza y agrega junto a
ella un plan de cuotas.

CONTEXTO
Un movimiento en Libranza es únicamente un pago aplicado al crédito: nada
más entra a esta lista. Un crédito a 60 cuotas puede acumular decenas de
pagos, así que la lista debe empezar corta y crecer bajo demanda hasta el
primer pago que el cliente haya hecho.

ELEMENTOS

1. Pestañas dentro de la zona: "Pagos" y "Plan de cuotas".

2. Pestaña Pagos
   - Lista agrupada por año, con el año como encabezado pegajoso en
     versalitas grises.
   - Cinco pagos visibles al entrar.
   - Cada fila: fecha de aplicación a la izquierda en formato 15 JUL 2026;
     a la derecha, "Pago aplicado" con el valor en Space Grotesk de 15px en
     negrita; debajo del valor, en gris de 12px, "Saldo después
     $ 9.480.200". Un chevron a la derecha expande la fila.
   - Fila expandida: desglose en tres líneas con etiqueta y valor —
     "Capital $ 486.300", "Intereses $ 241.700", "Otros conceptos $ 14.500".
   - Botón "Cargar más" centrado bajo la lista, que agrega diez pagos por
     clic. Cuando ya no quedan, el botón se reemplaza por el texto gris
     "Has llegado al primer pago de este crédito".
   - Simula catorce pagos mensuales, del 15 JUN 2025 al 15 JUL 2026, con
     valores entre $ 700.000 y $ 780.000 y el saldo decreciendo.

3. Pestaña Plan de cuotas
   - Tabla en escritorio y lista de tarjetas en móvil.
   - Columnas: Cuota, Fecha, Capital, Intereses, Cuota total, Saldo.
   - Las cuotas ya pagadas en gris con un check menta; la cuota siguiente
     destacada con fondo menta al 8% y la etiqueta "Próxima"; las futuras
     en normal.
   - Muestra veinte filas y un botón "Ver plan completo".

COMPORTAMIENTO
- Al entrar, la pestaña activa es Pagos.
- "Cargar más" agrega diez y mantiene la posición de lectura.
- Las filas se expanden de forma independiente.
- El encabezado de año queda pegado arriba mientras se recorre su grupo.

RESTRICCIONES
- En la lista de pagos no entra ningún otro tipo de movimiento.
- Fechas de fila en formato 15 JUL 2026.
- La tabla del plan de cuotas hace scroll horizontal propio en pantallas
  angostas: la página nunca se desplaza en horizontal.
- Sin paginación numerada. Solo carga progresiva.
```

---

## Cómo verificar

- [ ] Arrancan 5 pagos; cada clic en `Cargar más` suma 10.
- [ ] Al agotar, el botón se reemplaza por el texto de cierre.
- [ ] Los pagos están agrupados por año con encabezado pegajoso.
- [ ] La fila expandida muestra capital, intereses y otros conceptos.
- [ ] En móvil el plan de cuotas es lista de tarjetas, no tabla comprimida.
- [ ] La página no se desplaza horizontalmente en 360 px.
