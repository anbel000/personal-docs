---
title: Prompt 05 — Libranza, certificados inmediatos
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 05 · Libranza — certificados inmediatos

Llena la zona `Certificados` del detalle: los tres directos y los extractos. Depende de `03`.

---

## Prompt

```
TAREA
Llena la zona "Certificados" del detalle del crédito de libranza con dos
grupos: certificados de descarga inmediata y extractos por mes.

CONTEXTO
Los certificados de libranza se emiten de cuatro maneras distintas. Este
prompt cubre las dos inmediatas. Las otras dos —certificación de saldo y
paz y salvo— llegan en prompts posteriores y NO van aquí.

ELEMENTOS

1. Grupo "Descarga inmediata"
   Tres tarjetas en rejilla de tres columnas en escritorio y una en móvil.
   Cada una: icono de documento en cuadro menta claro, nombre del
   certificado, una línea de descripción en gris y un botón "Descargar"
   con icono de descarga.
   - Carta de condiciones — "Las condiciones vigentes de tu crédito"
   - Plan de pagos — "El detalle de todas tus cuotas"
   - Amortización — "Cómo se distribuye cada cuota entre capital e intereses"
   Bajo el grupo, una línea gris de 12px: "Estos certificados reflejan el
   estado actual de tu crédito."

2. Grupo "Extractos"
   Una sola tarjeta más ancha:
   - Título "Extracto mensual" y descripción "Consulta el movimiento de tu
     crédito mes a mes".
   - Etiqueta "Selecciona el mes".
   - Seis botones de mes en fila, con el mes en versalitas de tres letras
     arriba y el año debajo en Space Grotesk. El seleccionado en navy
     sólido con texto blanco; los demás con borde gris. En móvil van en
     dos filas de tres.
     Meses simulados, tomando agosto de 2026 como mes actual:
     AGO 2026, JUL 2026, JUN 2026, MAY 2026, ABR 2026, MAR 2026.
   - Botón "Descargar extracto", deshabilitado hasta que haya un mes
     seleccionado.

3. Estado de descarga
   Al pulsar cualquier botón de descarga, el botón muestra un indicador de
   carga por un segundo y luego aparece un aviso emergente verde
   "Certificado descargado".

COMPORTAMIENTO
- La ventana de meses es móvil: son siempre seis opciones contando el mes
  actual hacia atrás, y cruza el cambio de año. Si el mes actual fuera
  enero de 2027, las opciones serían ENE 2027, DIC 2026, NOV 2026,
  OCT 2026, SEP 2026, AGO 2026.
- Al seleccionar un mes se habilita el botón de descarga.
- El mes seleccionado se mantiene mientras el cliente está en la pantalla.

RESTRICCIONES
- Cada botón de mes muestra SIEMPRE mes y año. Nunca solo el mes: la
  ventana cruza el año y sin el año queda ambiguo.
- Exactamente seis opciones de mes, ni una más.
- No pongas selector de calendario ni rango de fechas: son seis opciones
  fijas.
- No incluyas certificación de saldo ni paz y salvo en esta zona.
```

---

## Cómo verificar

- [ ] Hay tres tarjetas de descarga inmediata y una de extractos.
- [ ] El selector muestra **seis** botones, cada uno con **mes y año**.
- [ ] El botón de descargar extracto está deshabilitado hasta elegir mes.
- [ ] No hay calendario ni selector de rango.
- [ ] No aparecen certificación de saldo ni paz y salvo.
- [ ] En móvil los meses van en dos filas de tres.
