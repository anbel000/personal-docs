---
title: Prompt 17 — CDT, propósito, alertas y certificados
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 17 · CDT — propósito, alertas y certificados

Completa el detalle del CDT. Depende de `10`.

---

## Prompt

```
TAREA
Agrega al CDT tres cosas: el propósito de la inversión, la banda de alertas
del detalle y la descarga de certificados.

CONTEXTO
El propósito es un nombre que el cliente le pone a su inversión —"Viaje a
Cartagena", "Estudio de mi hija"— y es lo que convierte una lista de
números en algo suyo. Las alertas avisan de lo que se acerca. Y los
certificados son los dos documentos que el cliente puede necesitar para un
trámite.

ELEMENTOS

1. Propósito en la tarjeta del CDT
   - Cuando el CDT tiene propósito: se muestra como título de la tarjeta, en
     18px, por encima del número enmascarado.
   - Cuando no lo tiene: en su lugar aparece el texto "Tu inversión ya tiene
     un propósito" en 18px, seguido de dos iconos pequeños:
     un signo de pregunta en círculo, que abre el diálogo informativo, y un
     lápiz, que abre el diálogo de edición. El lápiz solo aparece si el CDT
     está activo.

2. Diálogo informativo del propósito
   Modal angosto, máximo 350px. Ilustración arriba, y el texto: "Nos encanta
   acompañarte en esto. Entra al detalle de tu CDT y dale un nombre a ese
   sueño que estamos construyendo juntos. Verlo ahí te recordará por qué
   empezaste." Un botón de cierre.

3. Diálogo de edición del propósito
   Modal angosto. Ilustración arriba, título "Dale un nuevo sentido a tu
   propósito", campo de texto de una línea con máximo 50 caracteres,
   marcador de posición "Ej: Viajar a la playa", y contador de caracteres
   restantes. Botón "Renovar mi energía", deshabilitado con el campo vacío.
   Al guardar, el diálogo se cierra, el propósito aparece en la tarjeta y en
   el detalle, y sale un aviso emergente verde "Tu propósito quedó
   guardado."

4. Propósito en el detalle del CDT
   Centrado bajo el número del CDT, en negrita, con el lápiz al lado para
   editarlo. Solo editable si el CDT está activo.

5. Banda de alertas del detalle
   Franja horizontal sobre el encabezado, con icono a la izquierda, título
   en negrita de 14px, texto de 12px y una equis para descartar.
   Tres variantes:
   - Ámbar con triángulo — próximo a vencer: "Tu CDT está próximo a vencer",
     "Si no quieres renovarlo, desactiva la renovación automática antes del
     29 SEP 2026."
   - Verde con reloj — momento de renovar: "Es el momento de renovar tu
     CDT", "Renueva y te aseguramos una de las mejores tasas del mercado."
   - Ámbar con triángulo — sin cuenta: la del prompt 14.
   Si hay más de una alerta, se apilan con la más urgente arriba.

6. Certificados del CDT
   Zona con el título "Certificados" y dos tarjetas:
   - "Certificado de depósito": descripción "El documento que acredita tu
     inversión", botón "Descargar". Cuando el certificado aún no está
     disponible, la tarjeta se atenúa, el botón se deshabilita y aparece la
     nota "Estará disponible cuando se emita tu título."
   - "Reglamento del CDT Digital": descripción "Los términos y condiciones
     de tu producto", botón "Descargar". Siempre disponible.

7. Estado de último día
   Cuando el CDT está en su último día, el encabezado del detalle pierde
   color, los acordeones quedan deshabilitados y aparece una banda gris:
   "Hoy es el último día de tu CDT. Ya no puedes modificar sus condiciones."

COMPORTAMIENTO
- El propósito se guarda sin firma electrónica: no es un dato sensible.
- El diálogo informativo del propósito no guarda nada, solo explica.
- Las alertas descartadas no reaparecen en la misma visita.
- Los datos simulados dejan el CDT ···· 9012 con el propósito "Viaje a
  Cartagena" y certificado disponible, y el CDT ···· 5567 sin propósito y
  sin certificado disponible.

RESTRICCIONES
- El propósito acepta máximo 50 caracteres y muestra el contador.
- El lápiz de edición no aparece en CDT terminados.
- El botón de descarga del certificado no disponible se ve claramente
  deshabilitado, con la razón escrita. No se oculta.
- Las alertas se pueden descartar pero no se pueden silenciar de forma
  permanente.
- Sin emojis.
```

---

## Cómo verificar

- [ ] Un CDT sin propósito muestra el texto invitación con los dos iconos.
- [ ] El campo de propósito corta en 50 caracteres y muestra el contador.
- [ ] El lápiz no aparece en un CDT terminado.
- [ ] Las tres variantes de alerta existen y se apilan por urgencia.
- [ ] El certificado no disponible se ve deshabilitado **con la razón escrita**.
- [ ] El estado de último día deshabilita los acordeones.
- [ ] Guardar el propósito **no** pide firma electrónica.
