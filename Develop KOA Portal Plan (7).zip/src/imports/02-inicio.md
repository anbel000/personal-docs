---
title: Prompt 02 — Inicio
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 02 · Inicio

Construye la ruta `/`. Depende de `01`.

---

## Prompt

```
TAREA
Construye la pantalla de inicio de Portal KOA en la ruta raíz.

CONTEXTO
Es la primera pantalla tras iniciar sesión y debe responder "¿cómo estoy?"
en menos de cinco segundos. El cliente entra pocas veces al mes. Su
contenido cambia según los productos que tenga, que dependen de la fase y
del tipo de persona seleccionados en el selector DEMO.

ELEMENTOS, en este orden vertical

1. Saludo
   "Hola, Andrés" en 24px navy, y debajo en gris de 13px
   "Última conexión: 12/08/2026 4:32 p. m."

2. Pendientes
   Lista de avisos accionables, cada uno con icono, texto y enlace.
   Simula tres: "Completa tu información financiera",
   "Tu certificación de saldo está en proceso" con la etiqueta
   "3 días hábiles restantes", y "Próximo descuento el 15 AGO 2026".
   Este bloque se oculta por completo cuando no hay pendientes.

3. Resumen
   Tarjetas KpiCard en rejilla de tres columnas en escritorio y una en móvil.
   Con Libranza: "Deuda total $ 13.680.400", "Próximo descuento $ 1.284.900
   el 15 AGO 2026", "Créditos activos 2".
   Con CDT: "Inversión total $ 42.000.000", "Rendimientos $ 3.184.500",
   "Tasa ponderada 11,42 % E.A.".
   Con los dos productos, muestra los dos grupos en filas separadas, cada
   una con un rótulo pequeño: "Mis créditos" y "Mis inversiones".

4. Mis productos
   Rejilla de ProductCard, dos columnas en escritorio.
   Libranza: "2 créditos activos", "Saldo total $ 13.680.400",
   "Próximo descuento 15 AGO 2026".
   CDT: "2 CDT activos", "Inversión $ 42.000.000",
   "Próximo vencimiento 30 SEP 2026".
   Cuenta de Ahorros: tarjeta bloqueada, contenido desenfocado detrás,
   etiqueta PRONTO, sin acción.

5. Espacio comercial
   Un solo banner ancho, con tratamiento visual distinto al de las tarjetas
   de producto para que no se confunda con información de la cuenta.
   Fondo con degradado navy, texto blanco, un botón menta.
   Rotulado de forma discreta como comunicación de KOA.
   Contenido simulado: "Conoce el nuevo CDT Digital KOA. Tasas desde
   11,50 % E.A." con el botón "Ver más".

6. Educación financiera
   Tres tarjetas de contenido con imagen, título y una línea de descripción.
   Abren en pestaña nueva. Títulos simulados:
   "Cómo leer tu plan de pagos", "Qué es una tasa efectiva anual",
   "Cinco hábitos para ordenar tus finanzas".

COMPORTAMIENTO
- El contenido reacciona al selector DEMO:
  Fase 1 + Natural  -> solo el grupo de Libranza. La tarjeta de CDT
                       aparece en estado PRONTO.
  Fase 2 + Natural  -> los dos grupos y las dos tarjetas activas.
  Fase 1 + Jurídica -> sin productos. Muestra un estado vacío que explica
                       que el canal está habilitándose para empresas y
                       ofrece contacto. Los bloques de resumen y productos
                       no se dibujan.
  Fase 2 + Jurídica -> solo CDT. Libranza no aparece en ninguna parte.
- Al hacer clic en una tarjeta de producto se navega a su ruta.
- Los pendientes navegan a la pantalla que resuelve cada uno.

RESTRICCIONES
- La deuda y la inversión nunca se suman en una sola cifra ni se muestran
  en la misma fila de tarjetas.
- El bloque de pendientes desaparece entero si está vacío. No dejes un
  recuadro vacío ni un texto de "sin pendientes".
- Un solo banner comercial. Sin carrusel automático.
- La educación financiera va separada del banner comercial y con
  tratamiento visual distinto.
- Sin lenguaje celebratorio sobre cifras de deuda.
```

---

## Cómo verificar

- [ ] Con **Fase 2 + Natural** hay dos filas de resumen rotuladas y separadas.
- [ ] Ninguna cifra suma deuda con inversión.
- [ ] Con **Fase 1 + Jurídica** no hay resumen ni productos: solo el estado vacío con contacto.
- [ ] El banner comercial no se confunde visualmente con una tarjeta de producto.
- [ ] No hay carrusel que rote solo.
- [ ] Con los pendientes vacíos, el bloque desaparece sin dejar hueco.
