---
title: Prompt 12 — Jurídica, estados y responsive
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 12 · Persona jurídica, estados y responsive

El cierre. Depende de todos los anteriores.

---

## Prompt

```
TAREA
Completa la variante de persona jurídica, los estados de excepción de todas
las pantallas y el comportamiento en móvil.

CONTEXTO
Portal KOA tiene cuatro combinaciones posibles: dos fases por dos tipos de
persona. Hasta ahora se construyó pensando en persona natural. Falta cerrar
la variante jurídica y asegurar que ninguna pantalla se rompa cuando no hay
datos, cuando están cargando o cuando algo falla. El crédito por libranza
es un producto exclusivo de personas naturales: una empresa no puede
tenerlo, y eso no es una restricción de permisos sino una característica
del producto.

ELEMENTOS

1. Variante de persona jurídica
   - En el cabezote, el nombre pasa a "Comercializadora Andina S.A.S." y el
     avatar muestra las iniciales CA.
   - En la navegación, Libranza no aparece en ninguna fase.
   - Fase 2 + Jurídica: CDT disponible con los mismos datos ya construidos.
   - Fase 1 + Jurídica: ningún producto disponible. El inicio muestra un
     estado vacío con el título "Estamos habilitando el canal para
     empresas", la descripción "Muy pronto podrás consultar tus productos
     KOA desde aquí. Mientras tanto, tu asesor comercial te acompaña." y un
     botón "Contactar a mi asesor".

2. Pantalla de producto no disponible por tipo de persona
   Si una persona jurídica llega por URL a /libranza o a cualquier ruta de
   Libranza, se muestra una pantalla informativa, NO un error de permisos:
   icono, título "El crédito por libranza es un producto para personas
   naturales", descripción "La libranza descuenta la cuota de la nómina de
   una persona, por eso no aplica a empresas. Si te interesa un producto de
   financiación para tu empresa, tu asesor comercial puede ayudarte.", y
   dos botones: "Contactar a mi asesor" y "Volver al inicio".

3. Estados de excepción en todas las pantallas ya construidas
   - Carga: esqueletos con pulso que respetan la forma del contenido final.
     Nunca un indicador giratorio centrado en una pantalla en blanco.
   - Sin datos: EmptyState con título, explicación del porqué y una acción.
   - Error de carga: icono, título "No pudimos cargar tu información",
     descripción "Vuelve a intentarlo en unos segundos. Si el problema
     continúa, comunícate con nosotros." y botón "Reintentar".
   - Producto no disponible: contenedor con borde punteado, icono y el
     texto "Este producto no está disponible en este momento", con botón
     de reintentar.

4. Comportamiento responsive, desde 360px
   - Bajo 1024px la barra lateral se convierte en cajón lateral que se abre
     desde el botón de menú y se cierra al navegar.
   - Las rejillas de tarjetas pasan a una columna.
   - Las tablas se convierten en listas de tarjetas, no en tablas
     comprimidas.
   - Los diálogos ocupan el ancho completo con márgenes de 16px.
   - El panel lateral deslizante ocupa el ancho completo en móvil.
   - Las barras fijas de guardado quedan sobre el contenido, sin taparlo.
   - Los selectores de mes y de plazo se reorganizan en dos filas.
   - Ninguna pantalla se desplaza horizontalmente.

5. Revisión final del selector de demostración
   Confirma que el control está en un único archivo, que se monta en un
   único punto y que ninguna pantalla lo dibuja ni lo importa.

COMPORTAMIENTO
- Cambiar de tipo de persona en el selector DEMO estando dentro de una
  ruta de Libranza lleva a la pantalla informativa de producto no
  disponible.
- Cambiar de fase estando en /cdt con Fase 1 lleva al estado de producto
  próximo.
- Los estados de carga se muestran durante un segundo simulado al entrar a
  cada pantalla.

RESTRICCIONES
- La pantalla de Libranza para persona jurídica no debe decir "sin acceso",
  "sin permisos" ni "no autorizado". Explica la naturaleza del producto y
  ofrece una salida comercial.
- Todo estado vacío explica el porqué. Ninguno dice solo "Sin resultados".
- Ninguna tabla se comprime en móvil: se transforma.
- Los esqueletos de carga imitan la forma del contenido real.
```

---

## Cómo verificar

- [ ] Las cuatro combinaciones de fase y tipo de persona funcionan sin romper nada.
- [ ] Jurídica en `/libranza` ve la pantalla informativa, **no** un error de permisos.
- [ ] Ningún estado vacío dice solo *"Sin resultados"*.
- [ ] En 360 px ninguna pantalla se desplaza en horizontal.
- [ ] Las tablas se transforman en listas de tarjetas.
- [ ] El selector `DEMO` sigue viviendo en un solo archivo.

---

## Después de este prompt

El prototipo está completo. Lo que queda son ajustes finos, y para eso conviene **point-and-edit** sobre el elemento antes que un *prompt* nuevo: color, tipografía y espaciado se corrigen más rápido y sin riesgo de que Make rehaga otra cosa.

Si hace falta un ajuste transversal —por ejemplo subir el tamaño mínimo de texto—, va como *prompt* corto de una sola instrucción, nunca reejecutando un prompt anterior.
