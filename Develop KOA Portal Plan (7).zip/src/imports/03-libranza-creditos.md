---
title: Prompt 03 — Libranza, créditos
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 03 · Libranza — lista y detalle de crédito

Construye `/libranza` y `/libranza/credito/:id`. Depende de `01`.

---

## Prompt

```
TAREA
Construye el espacio del producto Libranza: la lista de créditos y el
detalle de un crédito.

CONTEXTO
El crédito por libranza descuenta la cuota directamente de la nómina del
cliente a través de una pagaduría. Un cliente puede tener varios créditos,
posiblemente con pagadurías distintas. Todo en Libranza es consulta: no hay
ninguna operación que modifique el crédito. El portal muestra únicamente
créditos activos.

ELEMENTOS

1. Lista de créditos en /libranza
   Encabezado de sección "Mis créditos de libranza" con subtítulo
   "Consulta tus créditos, tus pagos y genera tus certificados".
   Fila de tres KpiCard: "Deuda total $ 13.680.400", "Próximo descuento
   $ 1.284.900", "Créditos activos 2".
   Debajo, una lista vertical de tarjetas de crédito. Sin pestañas: solo
   hay créditos activos.

2. Tarjeta de crédito
   - Título "Crédito de Libranza" seguido del número de obligación
     enmascarado con puntos y los últimos cuatro dígitos.
   - Debajo, la pagaduría en gris pequeño.
   - A la derecha del título, StatusPill de estado.
   - SALDO TOTAL en versalitas de 10px y debajo la cifra grande de 28px
     en Space Grotesk.
   - Dos filas de dato y valor: "Cuota mensual" y "Próximo descuento".
   - Barra de progreso con la etiqueta "Cuota 14 de 60" y el porcentaje
     a la derecha.
   - Flecha de entrada abajo a la derecha.

   Datos simulados:
   Crédito ···· 4821 · Secretaría de Educación · Al día ·
   saldo $ 9.480.200 · cuota $ 742.500 · próximo descuento 15 AGO 2026 ·
   cuota 14 de 60.
   Crédito ···· 7350 · Alcaldía de Medellín · Al día ·
   saldo $ 4.200.200 · cuota $ 542.400 · próximo descuento 15 AGO 2026 ·
   cuota 31 de 48.

3. Detalle del crédito en /libranza/credito/:id
   - Enlace de volver "Volver a mis créditos".
   - Encabezado con "Crédito de Libranza" y el número de obligación
     COMPLETO, con un botón de copiar al lado. La pagaduría debajo.
     StatusPill de estado a la derecha.
   - Bloque destacado con el saldo total en 36px y, en fila,
     "Cuota mensual" y "Próximo descuento".
   - Barra de progreso "Cuota 14 de 60".
   - Acordeón "Características del crédito", abierto por defecto, con filas
     de fondo alternado: Monto desembolsado $ 18.000.000, Fecha de
     desembolso 15 MAR 2021, Plazo 60 meses, Tasa 18,45 % E.A.,
     Cuotas pagadas 14, Cuotas pendientes 46, Fecha de última cuota
     15 FEB 2031, Pagaduría Secretaría de Educación.
   - Debajo, dos zonas vacías reservadas con un título cada una:
     "Pagos" y "Certificados". Se llenan en prompts posteriores.

COMPORTAMIENTO
- La tarjeta de crédito completa es clicable y lleva al detalle.
- Con un solo crédito no se dibuja la lista: se entra directamente al
  detalle de ese crédito.
- El botón de copiar el número de obligación muestra un aviso emergente
  "Número copiado".
- Si el crédito estuviera en mora, la StatusPill cambia a "En mora" en rojo
  y aparece una franja de aviso sobre el saldo. Deja el estado listo aunque
  los datos simulados estén al día.

RESTRICCIONES
- En la lista el número de obligación va enmascarado. En el detalle va
  completo.
- La pagaduría es el distintivo principal entre créditos: debe ser legible
  sin esfuerzo en la tarjeta.
- Sin pestañas de activos y terminados: en Libranza no se listan
  créditos terminados.
- El saldo es la cifra más grande de la tarjeta y del detalle.
- Sin lenguaje celebratorio.
```

---

## Cómo verificar

- [ ] En la lista, el número va enmascarado; en el detalle, completo y copiable.
- [ ] La pagaduría se lee de un vistazo en cada tarjeta.
- [ ] No hay pestañas `Activos` / `Terminados`.
- [ ] El saldo domina la jerarquía visual.
- [ ] Con un solo crédito, se entra directo al detalle.
- [ ] El estado `En mora` está construido aunque no se use con estos datos.
