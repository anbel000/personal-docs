---
title: Prompt 06 — Libranza, certificación de saldo
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 06 · Libranza — certificación de saldo

El patrón nuevo del portal: una **solicitud** con estado, plazo y costo. Depende de `03`.

---

## Prompt

```
TAREA
Agrega a la zona "Certificados" del detalle del crédito un tercer grupo: la
certificación de saldo, que no es una descarga sino una solicitud.

CONTEXTO
La certificación de saldo la resuelve una persona, no el sistema. El cliente
la solicita, espera unos días y la recibe por correo electrónico. La primera
solicitud del mes sobre un crédito es gratuita; una segunda solicitud del
mismo crédito dentro del mismo mes tiene costo. El contador se reinicia al
cambiar de mes. Es la única operación del portal de Libranza con
consecuencia económica, y el riesgo de diseño es que el cliente pague sin
darse cuenta o vuelva a solicitar porque no ve que ya lo hizo.

ELEMENTOS

1. Tarjeta "Certificación de saldo" con tres estados posibles

   Estado A — sin solicitudes este mes
   Icono, título, descripción "Documento que certifica el saldo pendiente de
   tu crédito. La emitimos de forma manual y te llega a tu correo."
   Un chip verde claro: "Primera del mes sin costo".
   Botón "Solicitar certificación".

   Estado B — solicitud en curso
   La tarjeta cambia a fondo ámbar muy claro con borde ámbar.
   StatusPill "En proceso".
   Línea "Solicitada el 11 AGO 2026".
   Línea destacada "Te llegará a tu correo en máximo X días hábiles".
   Texto gris "La enviaremos a a****s@correo.com".
   Botón secundario "Ver en Documentos". El botón de solicitar no aparece.

   Estado C — ya hubo una solicitud este mes y la nueva tiene costo
   Chip ámbar: "Esta solicitud tiene un costo de $ XX.XXX".
   Botón "Solicitar certificación" activo.

2. Diálogo de confirmación, obligatorio antes de enviar
   - Título "Confirma tu solicitud".
   - Bloque de resumen con tres filas: "Crédito · ···· 4821 · Secretaría de
     Educación", "Solicitudes de este mes · 1 de 1 sin costo utilizada",
     "Costo de esta solicitud · $ XX.XXX" o "Sin costo".
   - Línea "Te llegará a a****s@correo.com en máximo X días hábiles."
   - Cuando hay costo, una casilla obligatoria: "Entiendo que esta
     solicitud tiene un costo de $ XX.XXX". El botón de confirmar
     permanece deshabilitado hasta marcarla.
   - Botones "Cancelar" y "Confirmar solicitud".

3. Confirmación posterior
   Diálogo de éxito con icono de check menta, título "Solicitud radicada",
   número de radicado en Space Grotesk "SOL-2026-004821", el plazo, y dos
   botones: "Ver en Documentos" y "Cerrar".

COMPORTAMIENTO
- El contador de gratuitas y cobradas es POR CRÉDITO y se reinicia al
  cambiar de mes.
- Con una solicitud en proceso, la tarjeta muestra el estado B y no permite
  solicitar de nuevo sobre ese crédito.
- El diálogo siempre indica de qué crédito se trata y de qué mes es el
  conteo.
- Simula el crédito ···· 4821 en estado A y el crédito ···· 7350 en
  estado B.

RESTRICCIONES
- El aviso de costo debe decir SIEMPRE tres cosas juntas: de qué crédito,
  de qué mes y cuál solicitud. Un aviso genérico de "la segunda tiene costo"
  no sirve: el cliente tiene varios créditos.
- No se puede llegar a la solicitud sin pasar por el diálogo de
  confirmación.
- El costo y el plazo aún no están definidos: escríbelos literalmente
  como $ XX.XXX y X días hábiles, sin inventar valores.
- El correo del cliente va parcialmente enmascarado.
- Este documento no se descarga desde esta tarjeta: llega por correo y
  queda en Documentos.
```

---

## Cómo verificar

- [ ] Existen los tres estados y se pueden ver los tres.
- [ ] No hay forma de solicitar sin pasar por el diálogo.
- [ ] Con costo, la casilla es obligatoria y bloquea el botón.
- [ ] El diálogo nombra el crédito, el mes y el número de solicitud.
- [ ] `$ XX.XXX` y `X días hábiles` aparecen literales, sin valores inventados.
- [ ] Con solicitud en curso no se puede volver a solicitar sobre ese crédito.
