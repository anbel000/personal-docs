---
title: Prompt 15 — CDT, indicadores y gráficas
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 15 · CDT — indicadores y gráficas del portafolio

Completa el prompt `10`. Depende de `10`.

---

## Prompt

```
TAREA
Agrega al espacio de CDT los tres indicadores del portafolio, el panel
informativo y las gráficas del portafolio de inversión.

CONTEXTO
El cliente de CDT entra a ver cómo va su plata. Los tres indicadores
responden eso de un vistazo; las gráficas responden cómo se reparte y cómo
evoluciona. Ninguna de las cifras se calcula aquí: se muestran.

ELEMENTOS

1. Tres indicadores en fila, con icono en cuadro de color y la cifra grande
   en Space Grotesk. Alternan fondo del icono entre navy y menta.
   - Inversión total: $ 42.000.000
   - Rendimiento total: $ 3.184.500
   - Tasa ponderada: 11,42 % E.A.

2. Panel informativo, al lado de la lista de CDT
   Recuadro con fondo suave y texto de 14px:
   Título "Tus CDT activos crecen" en negrita, y una lista de tres puntos:
   "Tu inversión: $ 42.000.000", "Tus ganancias: $ 3.184.500",
   "El CDT ···· 9012 vence pronto: 30/09/2026".
   Cuando el cliente no tiene CDT activos, el panel cambia a: "Tu futuro
   financiero tiene mucho potencial. Abre un nuevo CDT y mira cómo crecen
   tus ahorros." con un botón "Abrir CDT".

3. Bloque de gráficas, en dos columnas en escritorio y una en móvil
   Encabezado de sección "Portafolio de inversión".

   Gráfica 1 — Inversiones CDT
   Dona con un segmento por CDT, con leyenda al lado que muestra el número
   de CDT enmascarado y su monto. Al pasar el cursor, tooltip oscuro con
   fondo navy, esquinas redondeadas y el monto.
   Paleta de segmentos, en este orden: #06005A, #00D09C, #3D8BF2, #F70C5B,
   #7C5DCC.
   Datos: CDT ···· 9012 → $ 25.000.000 · CDT ···· 5567 → $ 17.000.000.

   Gráfica 2 — Rendimientos
   Gráfica de línea con área, color de línea #00D18C de 3px de grosor y
   puntos marcados. Eje horizontal con las etiquetas de periodo, eje
   vertical con montos abreviados. Rejilla horizontal punteada en #E6E6E6.
   Encima de la gráfica, un grupo de dos botones de filtro: "Mensual" y
   "Anual". Mensual está activo por defecto.
   Mensual muestra los últimos seis meses: MAR a AGO de 2026, con valores
   entre $ 380.000 y $ 620.000.
   Anual muestra los últimos seis años con valores entre $ 1.200.000 y
   $ 3.184.500.
   Cuando no hay rendimientos en el periodo, la gráfica de línea se
   reemplaza por una dona de rendimientos por CDT con la misma paleta.

4. Estados de las gráficas
   - Cargando: esqueleto con la forma de la gráfica y el texto "Preparando
     tus gráficos".
   - Sin datos: EmptyState con el texto "Cuando tengas CDT activos verás
     aquí cómo se reparte tu inversión."
   - Error: icono, "No pudimos cargar tus gráficas" y botón "Reintentar".

COMPORTAMIENTO
- Cambiar entre Mensual y Anual recalcula la gráfica sin recargar la
  pantalla.
- Las gráficas se redibujan al cambiar el tamaño de la ventana.
- En móvil, las gráficas ocupan el ancho completo y la leyenda de la dona
  pasa debajo.

RESTRICCIONES
- La tasa ponderada se escribe con dos decimales y coma decimal: 11,42 %.
- Los montos sin decimales y con punto de miles.
- Los números de CDT en las leyendas van enmascarados.
- Respeta la paleta de cinco colores en el orden dado. No generes colores
  aleatorios.
- Las gráficas no llevan lenguaje celebratorio ni emojis.
```

---

## Cómo verificar

- [ ] Los tres indicadores muestran las cifras exactas en Space Grotesk.
- [ ] La dona usa la paleta en el orden dado, sin colores aleatorios.
- [ ] El filtro `Mensual` / `Anual` cambia la gráfica de línea.
- [ ] El tooltip tiene fondo navy y esquinas redondeadas.
- [ ] La tasa ponderada usa coma decimal.
- [ ] Existen los estados de carga, sin datos y error.
- [ ] En móvil la leyenda de la dona pasa debajo.
