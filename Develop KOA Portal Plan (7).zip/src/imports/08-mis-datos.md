---
title: Prompt 08 — Mis datos
version: 1.0.0
date: 2026-08-13
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 08 · Mis datos

La funcionalidad transversal que sale del producto y sube al canal. Depende de `01`.

---

## Prompt

```
TAREA
Construye la pantalla Mis datos en la ruta /mis-datos.

CONTEXTO
Es la actualización de datos del cliente y pertenece al canal, no a ningún
producto: un cliente con libranza, con CDT o con los dos entra al mismo
lugar. Hoy en el portal antiguo esta funcionalidad vive dentro de CDT, y
ese es justamente el defecto que se corrige. Mantener estos datos al día es
una obligación regulatoria, así que la pantalla debe empujar a completarlos
sin regañar.

ELEMENTOS

1. Encabezado
   Título "Mis datos" y subtítulo "Mantén tu información actualizada".

2. Barra de completitud, fija bajo el encabezado
   Barra de progreso con el porcentaje, la etiqueta "Perfil completo al 80 %"
   y, a la derecha, un enlace "Completar información financiera" que lleva
   al bloque incompleto. Cuando está al 100 %, la barra se vuelve menta y
   dice "Perfil al día".

3. Seis bloques en acordeón, dos columnas en escritorio y una en móvil.
   Cada cabecera lleva el nombre del bloque y un indicador a la derecha:
   check menta si está completo, punto ámbar si le falta algo.

   - Datos de perfil: nombres, apellidos, tipo y número de documento en
     solo lectura con fondo gris; correo electrónico y celular editables.
   - Datos de residencia: departamento, ciudad, barrio, y la dirección
     compuesta por tipo de vía, número, letra, número secundario y
     complemento, con una vista previa de la dirección armada en una
     píldora bajo los campos. Estrato como fila de seis recuadros
     seleccionables del 1 al 6.
   - Información financiera: origen de fondos, ingresos mensuales, egresos
     mensuales, activos y pasivos, todos con formato de moneda; y la
     pregunta "¿Declaras renta?" con opciones Sí y No.
   - Datos profesionales: nivel educativo, ocupación y actividad económica.
   - Exposición política (PEP): tres preguntas de Sí y No —"¿Eres
     funcionario público?", "¿Administras recursos públicos?", "¿Eres una
     persona expuesta políticamente?"— y una cuarta sobre familiares PEP
     que, al responder Sí, despliega vínculo, nombre y apellido.
   - Notificaciones y alertas: dos grupos de interruptores. "Seguridad y
     alertas" con SMS, correo y WhatsApp, marcados y bloqueados con la nota
     "Obligatorias para la seguridad de tus productos". "Comerciales" con
     SMS, correo, WhatsApp, teléfono y dirección, todos editables.

4. Barra de guardado
   Fija al pie de la pantalla, aparece solo cuando hay cambios sin guardar:
   texto "Tienes cambios sin guardar" y botones "Descartar" y
   "Guardar cambios".

5. Diálogo de confirmación al guardar
   Título "Confirma tus cambios", lista de los campos modificados con su
   valor anterior y el nuevo, y botones "Volver" y "Confirmar".

COMPORTAMIENTO
- La barra de completitud se recalcula al llenar campos.
- El enlace de la barra desplaza hasta el bloque incompleto y lo abre.
- Los campos de solo lectura no se pueden enfocar.
- Al guardar, aviso emergente verde "Tu información fue actualizada".
- La pantalla es la misma para persona natural y jurídica, pero en jurídica
  los bloques cambian: "Datos del representante legal" con nombres y
  apellidos editables, "Información de la empresa" con razón social, NIT,
  correo y celular en solo lectura, y "Notificaciones". Los bloques de
  residencia, financiera, profesional y PEP no aparecen.

RESTRICCIONES
- Esta pantalla no pertenece a ningún producto y no debe mencionar ni
  Libranza ni CDT.
- El indicador de completitud es visible y explícito. No uses un punto rojo
  como único aviso.
- Los campos de solo lectura se ven claramente distintos de los editables.
- Las notificaciones de seguridad se muestran bloqueadas con su razón.
```

---

## Cómo verificar

- [ ] La pantalla no menciona ningún producto.
- [ ] La barra de completitud es visible y su enlace abre el bloque incompleto.
- [ ] Los campos de solo lectura se distinguen a simple vista.
- [ ] Con persona jurídica cambian los bloques.
- [ ] La barra de guardado solo aparece cuando hay cambios.
- [ ] El diálogo de confirmación lista valor anterior y nuevo.
