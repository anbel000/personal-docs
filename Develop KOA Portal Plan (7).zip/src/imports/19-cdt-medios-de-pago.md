---
title: Prompt 19 — CDT, medios de pago
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 19 · CDT — medios de pago

**Un solo flujo parametrizado.** Depende de `18` y de `11`.

> El portal actual tiene **dos familias de pantallas de pago casi gemelas** —una para abrir un CDT y otra para el aumento de capital al renovar—, que comparten los textos y difieren solo en el origen del monto. Este prompt las unifica: es la corrección de diseño más grande de CDT.

---

## Prompt

```
TAREA
Construye un flujo de pago único y parametrizado, que sirva tanto para
abrir un CDT nuevo como para pagar el aumento de capital de una renovación.

CONTEXTO
KOA recibe el dinero de tres maneras: débito bancario por PSE, transferencia
a sus cuentas, o cheque y efectivo en oficina. Los dos últimos no cobran en
línea: le muestran al cliente los datos, le envían la información por correo
y esperan el comprobante. El flujo es el mismo para abrir un CDT y para
aumentar capital al renovar: lo único que cambia es de dónde viene el monto
y una regla de disponibilidad de medios.

ELEMENTOS

1. Un solo componente de flujo de pago, con dos modos:
   - Modo apertura: el monto viene de la simulación.
   - Modo aumento de capital: el monto es la diferencia entre el capital
     nuevo y el actual del CDT que se renueva.
   El encabezado de cada pantalla dice de qué se trata: "Apertura de CDT" o
   "Aumento de capital · CDT ···· 9012".

2. Pantalla PSE
   - Logo de PSE centrado arriba.
   - Título "DÉBITO BANCARIO PSE" en versalitas.
   - Campo "Concepto de pago" en solo lectura, con fondo gris.
   - Campo "Valor a pagar" en solo lectura, con símbolo $ y fondo gris.
   - Lista "Tipo de persona": Natural y Jurídica.
   - Lista "Banco" con buscador y las mismas entidades del prompt 14.
   - Línea informativa: "Una vez finalice la transacción recuerda volver a
     nuestro sitio por medio de la opción Volver al comercio."
   - Botón "Pagar con PSE".
   - Al pulsarlo, diálogo de advertencia obligatorio, no descartable con
     clic afuera: título "Atención", ilustración, y dos párrafos: "Para
     completar tu pago de forma segura, no cierres ni cambies esta ventana.
     Permanece aquí hasta que el sistema confirme que la transacción fue
     exitosa y aparezca el botón para volver al portal." y "Si abandonas el
     proceso antes, tu pago podría no registrarse correctamente."
     Botones "Cerrar" y "Continuar".

3. Pantalla Transferencia
   - Logo KOA e ilustración.
   - Título "Estos son los datos para realizar la transferencia bancaria".
   - Cuatro filas de etiqueta y valor: Entidad, Tipo de cuenta, Nombre de la
     cuenta y Tipo de documento del titular.
     Datos simulados: Bancolombia · Cuenta de ahorros · KOA Compañía de
     Financiamiento · NIT 900.***.456-1.
   - Bloque: "Una vez realices la transacción, envíanos el soporte con tus
     datos completos al siguiente correo" y el correo destacado
     OPERACIONESCDT@KOA.CO
   - Recordatorio de los datos de la operación: inversión y plazo.
   - Bloque "¿Necesitas ayuda?" con los canales de contacto.
   - Nota: "Para escoger este método de pago, pulsa Pagar y te enviaremos
     toda la información a tu correo electrónico."
   - Botones "Pagar" y "Volver".

4. Pantalla Cheque o efectivo
   Misma estructura de la de transferencia, con los datos para consignación
   y el mismo correo de soporte. Botones "Pagar" y "Volver".

5. Pantalla de carga de comprobantes
   - Logo y título: "Para que puedas convertirte en un #InversionistaKOA
     carga los comprobantes de tu transacción".
   - Subtítulo: "Recuerda que puedes hacer más de una transacción, pero
     asegúrate de hacerlas el mismo día."
   - Lista de archivos cargados, cada uno con icono de estado, nombre y una
     equis para quitarlo. Los que están subiendo muestran un indicador.
   - Zona "Toca para adjuntar" con un signo de más.
   - Nota al pie en versalitas: "TEN EN CUENTA QUE EL TAMAÑO MÁXIMO POR
     ARCHIVO ES 5 MB".
   - Acepta PDF, JPG y PNG. Varios archivos.
   - Mensajes de error por archivo: formato no permitido y tamaño excedido.
   - Botones "Cargar" y "Cambiar medio de pago".

6. Pantalla de éxito de la carga
   Círculo con check verde grande, título "Cargaste de manera exitosa los
   documentos", y tres párrafos: que se revisarán los comprobantes y que
   cualquier novedad llegará al correo registrado; que el proceso puede
   demorar según el ingreso de los recursos; y que el único correo de
   contacto es OPERACIONESCDT@KOA.CO. Una línea final: "Recuerda revisar la
   carpeta de spam." Botón "Salir".

7. Pantalla de error de transacción
   Ilustración, título "Transacción no exitosa" y el mensaje según el caso:
   - "El monto de la transacción excede el límite establecido para la
     apertura de tu CDT."
   - "Se presentó un inconveniente en la transacción. Intenta más tarde o
     comunícate con nosotros."
   - "La entidad financiera no puede ser contactada. Selecciona otra o
     intenta más tarde."
   - "Este medio de pago no está disponible para tu operación. Regresa al
     resumen y paga con PSE."
   Recuadro de contacto con "¿Necesitas ayuda?" y los canales. Botón
   "Volver".

COMPORTAMIENTO
- En modo aumento de capital, si ya hay un pago pendiente por transferencia
  o cheque, los botones de transferencia y cheque quedan atenuados y solo
  queda PSE. Muestra la razón: "Tienes un pago pendiente por confirmar."
- En modo apertura los tres medios están siempre disponibles.
- El diálogo de advertencia de PSE es obligatorio y no se puede saltar.
- El botón "Cargar" está deshabilitado hasta que haya al menos un archivo
  válido.
- Al terminar cualquier camino, el cliente vuelve al portal.

RESTRICCIONES
- No dupliques pantallas por modo: un solo componente con dos modos.
- El correo OPERACIONESCDT@KOA.CO se escribe siempre en versalitas y
  destacado. Es el único canal de soporte de pagos.
- Los campos de concepto y valor son de solo lectura y se ven así.
- Los mensajes de error son los cuatro dados, no inventes otros.
- Sin emojis.
```

---

## Cómo verificar

- [ ] Es **un** componente con dos modos, no dos juegos de pantallas.
- [ ] El encabezado dice si es apertura o aumento de capital, con el CDT.
- [ ] El diálogo de advertencia de PSE no se puede saltar.
- [ ] En modo aumento con pago pendiente, solo queda PSE **con la razón escrita**.
- [ ] La carga acepta PDF, JPG y PNG, varios archivos, con límite de 5 MB.
- [ ] Están los cuatro mensajes de error de transacción.
- [ ] El correo de soporte aparece destacado en las tres pantallas donde va.
