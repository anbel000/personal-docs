---
title: Prompt 13 — Firma electrónica (OTP)
version: 1.0.0
date: 2026-08-14
author: Andrés Ricardo Beltrán Sarta
estado: Vigente
---

# 13 · Firma electrónica (OTP)

Componente transversal. **Base de los prompts `14`, `16`, `18` y `19`.** Depende de `01`.

> El portal actual llama **firma electrónica** al OTP de cada operación sensible. No es el segundo factor del inicio de sesión: es una confirmación por operación, con un mensaje distinto según lo que se esté firmando.

---

## Prompt

```
TAREA
Construye el diálogo de firma electrónica como componente reutilizable, y
un mecanismo para invocarlo desde cualquier operación indicando qué se
está firmando.

CONTEXTO
En KOA, toda operación que cambia algo sensible de un producto exige una
firma electrónica: un código de seis dígitos que llega por SMS al celular
registrado del cliente. El mensaje del diálogo cambia según la operación,
porque el cliente debe entender exactamente qué está autorizando. Tras
agotar los intentos, la firma se bloquea 24 horas.

ELEMENTOS

1. Diálogo modal centrado, ancho máximo 550px, con botón de cierre arriba
   a la derecha.

2. Encabezado
   Título en dos líneas centradas: "Validación de Seguridad" en 20px con
   peso normal, y debajo "#SeguridadKOA" en negrita.

3. Destino del código
   Línea "Ingresa el código de 6 dígitos enviado a tu celular" y debajo, en
   negrita y centrado, el celular parcialmente enmascarado: "300 *** 45 89".

4. Mensaje de la operación
   Párrafo de 14px que cambia según la operación que se está firmando.
   Construye los ocho textos:
   - Renovación de CDT: "Para formalizar la renovación de tu CDT Digital
     necesitamos tu firma electrónica. Este proceso incluye la validación de
     tus datos y la aceptación de las nuevas condiciones asociadas a la
     renovación."
   - Cuenta bancaria: "Para formalizar la actualización de tu cuenta
     bancaria vinculada al CDT Digital requerimos tu firma electrónica. Este
     proceso garantiza la validación de la nueva cuenta y la seguridad de la
     operación."
   - Celular: "Para formalizar la actualización de tu número de celular
     asociado al CDT Digital requerimos tu firma electrónica."
   - Correo: "Para formalizar la actualización de tu correo electrónico
     asociado al CDT Digital requerimos tu firma electrónica."
   - Contraseña: "Para formalizar la actualización de tu contraseña
     requerimos tu firma electrónica."
   - Datos personales: "Para formalizar la actualización de tus datos
     personales requerimos tu firma electrónica."
   - Apertura de CDT: "Estás a un paso de crear tu CDT Digital. Para
     completar la apertura solo necesitamos tu firma electrónica."
   - Referidos: "Estás a un paso de activar tu perfil de Referido KOA. Para
     completar el registro solo necesitamos tu firma electrónica."

5. Campo de código
   Etiqueta "Ingresa el código" en negrita y centrada.
   Seis casillas separadas, una por dígito, solo numéricas, con avance
   automático al escribir y retroceso al borrar. Foco inicial en la primera.

6. Vigencia del código
   Barra de progreso delgada bajo las casillas que se va vaciando durante
   el tiempo de vigencia.

7. Pie de reenvío y intentos
   Fila con dos mitades:
   - Izquierda: "Reenviar en 01:59" con cuenta regresiva. Al llegar a cero,
     se reemplaza por el enlace "Reenviar código".
   - Derecha: "2 intentos restantes".

8. Botón "Continuar" ancho completo, deshabilitado hasta completar los seis
   dígitos.

9. Estados de error
   - Código incorrecto: mensaje rojo bajo la barra "El código ingresado no
     es correcto. Verifica e intenta de nuevo." Las casillas se marcan en
     rojo y se limpian. El contador de intentos baja.
   - Intentos agotados: el diálogo cambia por completo. Icono de
     advertencia, título "Validación sin éxito", texto "El proceso de firma
     electrónica no ha sido exitoso. Te invitamos a intentarlo de nuevo en
     24 horas.", línea "Gracias por utilizar nuestros servicios" y un
     número de atención. El botón "Continuar" queda deshabilitado y el
     enlace de reenvío desaparece.

10. Éxito
    El diálogo se cierra y la operación que lo invocó continúa. Aviso
    emergente verde con el mensaje propio de esa operación.

COMPORTAMIENTO
- El diálogo se invoca pasándole la operación; el mensaje y el texto de
  éxito salen de ahí.
- El código correcto simulado es 123456. Cualquier otro cuenta como error.
- Tres intentos. Al tercero fallido, estado de bloqueo.
- Cerrar el diálogo cancela la operación: nada se guarda.
- La cuenta regresiva de reenvío arranca en 2 minutos.

RESTRICCIONES
- El mensaje de la operación es obligatorio: nunca un texto genérico.
- El celular va siempre enmascarado.
- Los seis dígitos son solo numéricos. No se pega texto con letras.
- El botón no se habilita con el código incompleto.
- Este diálogo no se usa para el inicio de sesión: es por operación.
```

---

## Cómo verificar

- [ ] El mensaje cambia según la operación, y están los ocho.
- [ ] `123456` pasa; otro código resta un intento.
- [ ] Al tercer fallo aparece el estado de bloqueo de 24 h y desaparece el reenvío.
- [ ] La barra de vigencia se vacía y el contador de reenvío llega a cero.
- [ ] Cerrar el diálogo cancela la operación sin guardar nada.
- [ ] El celular está enmascarado.
