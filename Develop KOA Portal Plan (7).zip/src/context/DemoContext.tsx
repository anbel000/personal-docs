import { createContext, useContext, useState, type ReactNode } from 'react'

export type PersonType = 'natural' | 'juridica'
export type Productos = 'ambos' | 'solo-libranza' | 'solo-cdt' | 'ninguno'

interface DemoState {
  personType: PersonType
  productos: Productos
  pendientes: boolean
  setPersonType: (p: PersonType) => void
  setProductos: (p: Productos) => void
  setPendientes: (v: boolean) => void
}

const DemoContext = createContext<DemoState>({
  personType: 'natural',
  productos: 'ambos',
  pendientes: true,
  setPersonType: () => {},
  setProductos: () => {},
  setPendientes: () => {},
})

function load<T>(key: string, fallback: T, valid: T[]): T {
  const v = localStorage.getItem(key) as T
  return valid.includes(v) ? v : fallback
}

export function DemoProvider({ children }: { children: ReactNode }) {
  const [personType, setPersonTypeState] = useState<PersonType>(() =>
    load('demoPersonType', 'natural' as PersonType, ['natural', 'juridica'] as PersonType[])
  )
  const [productos, setProductosState] = useState<Productos>(() => {
    const p = load('demoPersonType', 'natural' as PersonType, ['natural', 'juridica'] as PersonType[])
    const stored = load('demoProductos', 'ambos' as Productos, ['ambos', 'solo-libranza', 'solo-cdt', 'ninguno'] as Productos[])
    // Juridica cannot have libranza — auto-correct on load
    if (p === 'juridica' && (stored === 'solo-libranza' || stored === 'ambos')) return 'solo-cdt'
    return stored
  })
  const [pendientes, setPendientesState] = useState<boolean>(
    () => localStorage.getItem('demoPendientes') !== 'false'
  )

  const setPersonType = (p: PersonType) => {
    setPersonTypeState(p)
    localStorage.setItem('demoPersonType', p)
    if (p === 'juridica') {
      setProductosState(prev => {
        if (prev === 'solo-libranza' || prev === 'ambos') {
          localStorage.setItem('demoProductos', 'solo-cdt')
          return 'solo-cdt'
        }
        return prev
      })
    }
  }
  const setProductos = (p: Productos) => {
    setProductosState(p)
    localStorage.setItem('demoProductos', p)
  }
  const setPendientes = (v: boolean) => {
    setPendientesState(v)
    localStorage.setItem('demoPendientes', String(v))
  }

  return (
    <DemoContext.Provider value={{ personType, productos, pendientes, setPersonType, setProductos, setPendientes }}>
      {children}
    </DemoContext.Provider>
  )
}

export function useDemoContext() {
  return useContext(DemoContext)
}
