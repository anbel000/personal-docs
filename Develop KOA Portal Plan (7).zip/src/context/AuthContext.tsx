import { createContext, useContext, type ReactNode } from 'react'

interface AuthCtx {
  logout: () => void
}

const AuthContext = createContext<AuthCtx>({ logout: () => {} })

export function AuthProvider({ children, onLogout }: { children: ReactNode; onLogout: () => void }) {
  return <AuthContext.Provider value={{ logout: onLogout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
