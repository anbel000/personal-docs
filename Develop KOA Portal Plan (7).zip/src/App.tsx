import { useEffect, useRef, useState } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { DemoProvider, useDemoContext, type PersonType } from './context/DemoContext'
import { AuthProvider } from './context/AuthContext'
import TopNav from './components/TopNav'
import BottomNav from './components/BottomNav'
import DemoSelector from './components/DemoSelector'
import Home from './pages/Home'
import Libranza from './pages/Libranza'
import LibranzaDetalle from './pages/LibranzaDetalle'
import MisDatos from './pages/MisDatos'
import CDT from './pages/CDT'
import CDTDetalle from './pages/CDTDetalle'
import CDTAbrir from './pages/CDTAbrir'
import MediosDePago from './pages/MediosDePago'
import LibranzaGuard from './components/LibranzaGuard'
import Seguridad from './pages/Seguridad'
import Contactanos from './pages/Contactanos'
import EducacionFinanciera from './pages/EducacionFinanciera'
import Login from './pages/Login'
import Componentes from './pages/Componentes'
import TrustFooter from './components/TrustFooter'
import WelcomeBanner from './components/WelcomeBanner'
import welcomeBanner from './imports/Koa_Portal_Banner_1600x900_1__1_.svg'

function Layout() {
  const mainRef = useRef<HTMLElement>(null)
  const { pathname } = useLocation()
  // Banner de bienvenida: se muestra una vez apenas se monta el portal (login).
  const [welcomeOpen, setWelcomeOpen] = useState(true)

  // Al cambiar de ruta, reiniciar el scroll para que la nueva pantalla siempre
  // se muestre desde arriba (no herede la posición de scroll de la anterior).
  // Se cubre el contenedor principal y la ventana, y se repite en el siguiente
  // frame por si el contenido nuevo restaura la posición al montarse.
  useEffect(() => {
    const reset = () => {
      if (mainRef.current) mainRef.current.scrollTop = 0
      window.scrollTo(0, 0)
      document.documentElement.scrollTop = 0
      document.body.scrollTop = 0
    }
    reset()
    const raf = requestAnimationFrame(reset)
    return () => cancelAnimationFrame(raf)
  }, [pathname])

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <TopNav />
      <main ref={mainRef} className="flex-1 overflow-y-auto scrollable pb-20 md:pb-0">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-7">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/libranza" element={<LibranzaGuard><Libranza /></LibranzaGuard>} />
            <Route path="/libranza/credito/:id" element={<LibranzaGuard><LibranzaDetalle /></LibranzaGuard>} />
            <Route path="/cdt" element={<CDT />} />
            <Route path="/cdt/abrir" element={<CDTAbrir />} />
            <Route path="/cdt/:id" element={<CDTDetalle />} />
            <Route path="/cdt/:id/medios-de-pago" element={<MediosDePago modo="apertura" monto={5000000} />} />
            <Route path="/mis-datos" element={<MisDatos />} />
            <Route path="/seguridad" element={<Seguridad />} />
            <Route path="/contactanos" element={<Contactanos />} />
            <Route path="/educacion-financiera" element={<EducacionFinanciera />} />
          </Routes>
        </div>
        <TrustFooter />
      </main>
      <BottomNav />
      <DemoSelector />
      <WelcomeBanner open={welcomeOpen} onClose={() => setWelcomeOpen(false)} image={welcomeBanner} imageAlt="Banner de bienvenida al Portal KOA" />
    </div>
  )
}

function AppContent() {
  const { setPersonType } = useDemoContext()
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  function handleLogin(pt: PersonType) {
    setPersonType(pt)
    setIsLoggedIn(true)
  }

  return (
    <Routes>
      <Route path="/componentes" element={
        <div className="min-h-screen bg-white">
          <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-sm border-b border-[#E8ECF2] px-4 sm:px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#06005A] flex items-center justify-center">
                <svg className="w-4 h-4 text-[#00DB8E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h8M4 18h8" />
                </svg>
              </div>
              <div>
                <p className="font-black text-[#06005A] text-[14px] leading-none">KOA Design System</p>
                <p className="text-[10px] text-gray-400 font-semibold mt-0.5">Recursos del portal · v1.0</p>
              </div>
            </div>
            <span className="text-[9px] font-black tracking-[0.18em] uppercase bg-[#06005A] text-white px-2.5 py-[5px] rounded-full">Portal KOA</span>
          </div>
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
            <Componentes />
          </div>
        </div>
      } />
      <Route path="*" element={
        !isLoggedIn
          ? <Login onLogin={handleLogin} />
          : (
            <AuthProvider onLogout={() => setIsLoggedIn(false)}>
              <Layout />
            </AuthProvider>
          )
      } />
    </Routes>
  )
}

export default function App() {
  return (
    <DemoProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </DemoProvider>
  )
}

