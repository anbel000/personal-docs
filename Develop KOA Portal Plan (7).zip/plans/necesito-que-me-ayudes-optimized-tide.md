# Igualar la altura de los 3 pasos del formulario de solicitud de crédito de libranza

## Contexto

El formulario `SolicitudCreditoLibranza.tsx` (que se muestra en la sección Libranza cuando
el usuario no tiene crédito, p. ej. Demo = "Solo CDT") es un card de dos columnas: un rail de
marca a la izquierda (navy) y un panel de formulario a la derecha con un `Stepper` de 3 pasos:

1. **Perfil** — 3 tarjetas de perfil + callout de WhatsApp.
2. **Tu entidad y tus datos** — nombres/apellidos + buscador de entidad (`PagaduriaCombo`) + tipo de pensión/contrato.
3. **Contacto** — correo/celular + canal de contacto + autorización.

**Problema:** los tres pasos tienen alturas ligeramente distintas. Como la altura del card es
`max(alto del rail, alto del contenido del paso)`, los pasos cuyo contenido supera la altura de
referencia hacen crecer el card y provocan la sensación de "salto" entre pasos y scroll en
monitores/portátiles.

**Objetivo:** que los 3 pasos conserven **exactamente la misma altura vertical**, tomando el
**paso 3 como altura de referencia** (es la que se quiere conservar siempre). Se ajustan los
pasos 1 y 2 para que no la superen ni queden más cortos. Además, en el paso 2 se elimina el texto
de ayuda "Escribe para buscar entre las entidades con convenio".

## Enfoque

El panel de formulario ya usa `flex flex-col` con `lg:min-h-[430px]`, y cada paso es un
`div.flex.flex-col.flex-1` con los botones en `mt-auto`. Con este patrón, **si el contenido de
cada paso es ≤ la altura del panel, todos los pasos se renderizan exactamente a esa altura**
(los botones se anclan abajo y el espacio sobrante se reparte arriba). La igualdad se rompe solo
cuando algún paso desborda esa altura.

Por tanto el plan es:
1. Fijar la altura del panel a la que produce el **paso 3** (referencia).
2. **Compactar** los pasos 1 y 2 para que su contenido quepa dentro de esa altura sin desbordar.
3. Verificar que ningún paso supere la referencia (si el paso 3 real resulta mayor/menor a
   `430px`, ajustar el `lg:min-h-[…]` al alto natural del paso 3).

Archivo único a modificar: `src/libranza/SolicitudCreditoLibranza.tsx`.

## Cambios

### 1. Eliminar el texto de ayuda del buscador de entidad (paso 2)
En `PagaduriaCombo` (label `Entidad que te paga`, ~línea 191-194) quitar el `<span>` con
"Escribe para buscar entre las entidades con convenio", dejando solo el label. Ahorra alto y
limpia el paso 2.

### 2. Ajustar el paso 1 (Perfil) para reducir espacios
Reducir la densidad para que su contenido iguale (no supere) al paso 3:
- Encabezado `mb-5 → mb-4`.
- Tarjetas de perfil: padding `p-4 → p-3.5`, ícono `w-10 h-10 mb-3 → w-9 h-9 mb-2.5`.
- Callout de WhatsApp: `py-3.5 → py-2.5`, `gap-3.5 → gap-3`, tile `w-10 h-10 → w-9 h-9`
  (ícono `w-5 h-5 → w-4 h-4`), separación `mt-5 → mt-4`.
- Los botones ya están en `mt-auto`, así que el sobrante se reparte y el paso llena la altura.

### 3. Ajustar el paso 2 (Tu entidad y tus datos) para igualar al paso 3
El paso 2 ya quedó en 2 filas (`nombres`/`apellidos` y `PagaduriaCombo`/`tipo`) dentro de un
`grid sm:grid-cols-2 gap-x-4 gap-y-3`. Tras quitar el texto de ayuda:
- Confirmar que el `PagaduriaCombo` a media columna no aprieta el buscador; si aprieta, dejarlo a
  ancho completo (`sm:col-span-2`) con el `tipo` debajo, compensando con el espaciado para no crecer.
- Alinear el espaciado del bloque (heading `mb-4`, `gap-y-3`) con el del paso 3 para que el alto
  natural coincida.

### 4. Fijar la altura de referencia (paso 3)
Mantener `lg:min-h-[430px]` en el panel de formulario. Tras compactar 1 y 2, verificar
visualmente contra el paso 3; si el paso 3 real es un poco mayor o menor, ajustar ese valor al
alto natural del paso 3 para que los tres pasos queden idénticos sin scroll.

## Restricciones

- Solo cambios **visuales/estructurales**: no se altera ninguna funcionalidad, validación ni el
  flujo de envío. Los campos y sus validaciones permanecen (nombres/apellidos validados en el
  paso 2, contacto en el paso 3).
- No modificar el KOA DS (`src/index.css`, `src/components/ui`, `src/components/koa`); solo
  consumirlo. Usar tokens existentes.
- Comillas dobles en strings con apóstrofes; export default.

## Verificación

1. `npx tsc --noEmit 2>&1 | grep -c "error TS"` debe seguir en **10** (baseline).
2. Purgar caché de Vite: `rm -rf node_modules/.vite node_modules/.vite-temp` y `touch` el archivo.
3. En el preview (Demo = "Solo CDT", persona natural → sección Libranza), recorrer los 3 pasos y
   confirmar que el card **no cambia de altura** al avanzar/retroceder y que no aparece scroll en
   viewport de portátil. Verificar que el paso 2 ya no muestra el texto de ayuda del buscador y
   que el buscador de entidades sigue funcionando (filtrado + "Mi entidad no está en la lista").
</content>
