# Portal KOA — Construction Plan

## Context

Portal KOA is the self-service digital channel for clients of KOA Compañía de Financiamiento, a Colombian financial institution. The portal lets clients view their Libranza (payroll-deducted) loans, download certificates, manage personal data, and access documents — all in Spanish with Colombian tuteo.

The current `src/App.tsx` is a blank animated canvas. This plan replaces it with a full multi-screen React Router application. All 9 specification files (00–09) have been read. The brand aesthetic is **explicitly specified** (navy/mint, Montserrat/Space Grotesk), so the aesthetic-stance creative direction is overridden in favor of exact brand compliance.

---

## Design Tokens (src/index.css)

Add Google Fonts imports **before** `@import 'tailwindcss'` — then add `@theme` block:

```css
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
@import 'tailwindcss';

@theme {
  --color-navy-start: #0A1F44;
  --color-navy-end: #06005A;
  --color-mint: #00D18C;
  --color-mint-text: #007A54;
  --color-app-bg: #F9FAFB;
  --color-border: #E5E7EB;
  --color-success: #10B981;
  --color-warning: #F59E0B;
  --color-error: #EF4444;
  --color-info: #3B82F6;
  --font-sans: 'Montserrat', sans-serif;
  --font-mono: 'Space Grotesk', sans-serif;
  --radius-card: 16px;
  --radius-control: 12px;
}
```

Set `font-family: 'Montserrat', sans-serif` as default body font on `html`. All numeric/money/date values use `font-family: 'Space Grotesk', sans-serif` via a utility class `.font-figures`.

---

## File Structure

```
src/
  App.tsx                        ← Replace: router + layout shell
  index.css                      ← Extend: fonts + tokens
  main.tsx                       ← Unchanged

  context/
    DemoContext.tsx               ← fase (1|2) + personType (natural|juridica)

  data/
    mockData.ts                   ← All simulated data, no data inside components

  components/
    # Base design system
    StatusPill.tsx
    KpiCard.tsx
    ProductCard.tsx
    EmptyState.tsx
    SectionHeader.tsx
    Btn.tsx
    FilterChips.tsx
    LoadingSkeleton.tsx
    SidePanel.tsx

    # Shell
    Sidebar.tsx
    AppHeader.tsx
    Breadcrumb.tsx
    DemoSelector.tsx
    NotificationsPanel.tsx

  pages/
    Home.tsx
    Libranza.tsx
    LibranzaDetalle.tsx
    MisDatos.tsx
    Documentos.tsx
    # Stubs (placeholder with route name):
    CDT.tsx  CDTDetalle.tsx  Seguridad.tsx  Contactanos.tsx  EducacionFinanciera.tsx

  libranza/
    CreditoCard.tsx
    CreditoDetalle.tsx
    TabPagos.tsx
    TabPlanCuotas.tsx
    CertificadosInmediatos.tsx
    CertificacionDeSaldo.tsx
    PazYSalvoFlow.tsx
    VerificacionStep.tsx          ← Isolated placeholder, replaceable
```

---

## Build Steps (sequential by dependency)

### Step 1 — Foundation

**`src/index.css`**: Add Google Fonts @import before all other statements. Add `@theme` block with all brand tokens.

**`src/context/DemoContext.tsx`**: React context with `fase: 1|2` and `personType: 'natural'|'juridica'`. Exports `useDemoContext()`. State persists to `localStorage`.

**`src/data/mockData.ts`**: Export all simulated data used across all screens:
- `clienteNatural`: Andrés Beltrán, 2 Libranza credits (4821 + 7350), 2 CDTs
- `clienteJuridico`: Comercializadora Andina S.A.S., 1 CDT
- Credit 4821: saldo $9.480.200, cuota $742.500, prox descuento 15 AGO 2026, cuota 14/60, pagaduría Secretaría de Educación, monto desembolsado $18.000.000, fecha 15 MAR 2021, tasa 18,45% EA, 14 pagos históricos Jun 2025–Jul 2026
- Credit 7350: saldo $4.200.200, cuota $542.400, prox descuento 15 AGO 2026, cuota 31/48, pagaduría Alcaldía de Medellín
- Créditos terminados para paz y salvo: ···· 4821 ($18.000.000, MAR 2021→ENE 2024) y ···· 7350 ($4.200.000, ENE 2019→FEB 2022)
- 14 monthly payments for credit 4821 with decreasing balance
- Full 60-cuota installment plan for credit 4821
- 8 documents for Documentos screen
- 5 notifications
- 3 pending items for Home

**Install**: `react-router-dom` (if not already in package.json)

---

### Step 2 — Base Design System Components

One component per file. No data imports from mockData.

**`StatusPill.tsx`**: Pill with colored dot. Variants: `activo` (mint), `en-mora` (red), `al-dia` (green), `pendiente` (amber), `en-proceso` (amber), `resuelto` (blue), `terminado` (gray), `proximo` (blue), `error` (red). Full border-radius, 10px text in Montserrat.

**`KpiCard.tsx`**: Props: `icon`, `label` (Montserrat), `value` (Space Grotesk 28-36px), `chip?`. Icon in colored square (rounded-lg). Entry animation: opacity 0→1 + translateY 14px→0, 0.35s, cubic-bezier(0.22,1,0.36,1).

**`ProductCard.tsx`**: Props: `name`, `icon`, `stats[]`, `href`, `locked?`. Locked variant: content blurred behind `PRONTO` label, no `onClick`. Hover: shadow-md + translateY(-1px). 16px radius, white bg, border-border.

**`EmptyState.tsx`**: Props: `icon`, `title`, `description`, `action?`. Icon in rounded-xl colored square.

**`SectionHeader.tsx`**: Props: `title` (24px navy), `subtitle?`, `actions?` (right-aligned).

**`Btn.tsx`**: Variants: `primary` (navy bg, white text), `mint` (mint bg, #007A54 text), `secondary` (white bg, navy border), `ghost` (transparent, navy text). Sizes: `sm`, `md`, `lg`. 12px radius. 150ms color transitions.

**`FilterChips.tsx`**: Props: `options[]`, `value`, `onChange`. Active chip: navy solid bg + white text. Others: gray border. 12px radius.

**`LoadingSkeleton.tsx`**: Animated shimmer div. Props: `className`.

**`SidePanel.tsx`**: Slides in from right. Props: `open`, `onClose`, `title`, `width?` (default 380px). Backdrop overlay, exit animation.

---

### Step 3 — Shell

**`Sidebar.tsx`**:
- Background: `linear-gradient(to bottom, #0A1F44, #06005A)`, width 256px expanded / 60px collapsed
- `localStorage.getItem('sidebarCollapsed')` to persist state
- Below 1024px: off-canvas drawer triggered by header hamburger; not persistent
- Nav groups in 9px versalitas + wide letter-spacing: PRINCIPAL, MIS PRODUCTOS, MI CUENTA, AYUDA
- Items with icon + label. Active: mint bg at 12% opacity + 2px mint left border strip
- PRONTO items: 35% opacity, no click, inline "PRONTO" badge in 9px versalitas
- Libranza hidden entirely when `personType === 'juridica'` (not disabled — removed from array)
- CDT shown as PRONTO when `fase === 1`
- Cuenta de Ahorros always PRONTO
- Footer: "Vigilado Superintendencia Financiera de Colombia" + "Fogafin" in 10px gray/white text

**`AppHeader.tsx`**:
- Fixed 64px white header
- Left: hamburger (mobile) + KOA logo/wordmark
- Center: greeting "Hola, Andrés" (navy) + "Última conexión 12/08/2026 4:32 p. m." (13px gray)
- Right: notification bell (with red dot if unread notifications), help icon, avatar (navy square rounded, mint initials)
- Avatar dropdown: Mi perfil, Seguridad, Cerrar sesión
- Bell opens NotificationsPanel

**`Breadcrumb.tsx`**: White bar under header (not fixed). Renders current route hierarchy in 13px. Home > Libranza > Crédito ···· 4821 style.

**`DemoSelector.tsx`**: Fixed bottom-right, z-50. Small card with "DEMO" badge + two toggles: Fase 1/Fase 2 and Natural/Jurídica. Reads/writes DemoContext. Mounted once in App.tsx layout.

**`NotificationsPanel.tsx`**: SidePanel variant. 380px. "Notificaciones" title + "Marcar todas como leídas" link. 5 notifications from mockData. Unread dot (mint). Relative timestamps. "Ver todas" footer link → /documentos.

---

### Step 4 — App.tsx (Router + Layout)

Replace the placeholder with:
```tsx
<DemoProvider>
  <BrowserRouter>
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <AppHeader />
        <Breadcrumb />
        <main className="flex-1 overflow-y-auto bg-[#F9FAFB] p-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/libranza" element={<Libranza />} />
            <Route path="/libranza/credito/:id" element={<LibranzaDetalle />} />
            ...stubs...
          </Routes>
        </main>
      </div>
    </div>
    <DemoSelector />
  </BrowserRouter>
</DemoProvider>
```

---

### Step 5 — Home Screen (`src/pages/Home.tsx`)

Reads `useDemoContext()`. Renders in this vertical order:

1. **Saludo**: "Hola, Andrés" 24px navy, "Última conexión: 12/08/2026 4:32 p. m." 13px gray
2. **Pendientes** (conditional): 3 items from mockData — accionables with icons and links. Hidden completely when `pendientes.length === 0`.
3. **Resumen KpiCards** (conditional by demoState):
   - Fase 1 + Natural: 3 Libranza cards ("Deuda total $13.680.400", "Próximo descuento $1.284.900 el 15 AGO 2026", "Créditos activos 2")
   - Fase 2 + Natural: 2 rows — "Mis créditos" (Libranza cards) + "Mis inversiones" (CDT cards). Never mixed.
   - Jurídica F1: nothing
   - Fase 2 + Jurídica: CDT row only
4. **Mis productos** (grid 2 cols desktop): ProductCards for visible products; CDT locked in F1+Natural; Cuenta de Ahorros always locked.
5. **Banner comercial**: navy gradient wide banner, white text, mint CTA button. Clearly distinct from product cards. "Conoce el nuevo CDT Digital KOA. Tasas desde 11,50 % E.A." — "Ver más"
6. **Educación financiera**: 3 content cards with image (Unsplash), title, 1-line description, opens new tab.
7. **EmptyState** for Jurídica F1: explains channel is enabling for empresas, offers contact link.

---

### Step 6 — Libranza Screens

#### `src/pages/Libranza.tsx`
- SectionHeader "Mis créditos de libranza" + subtitle
- 3 KpiCards row
- If 1 credit: redirect to `/libranza/credito/4821` directly
- If 2+ credits: render list of CreditoCard components (each fully clickable → detail)
- Below the list: PazYSalvo entry card (visually distinct — product level, not credit level). Stamp icon, "Paz y salvo", description, "Generar paz y salvo" button → triggers PazYSalvoFlow modal/overlay

#### `src/libranza/CreditoCard.tsx`
- Shows masked obligation number (···· 4821)
- Pagaduría in gray-small (primary distinguisher)
- StatusPill top-right
- SALDO TOTAL in 10px versalitas, cifra 28px Space Grotesk
- 2 data rows (cuota mensual, próximo descuento) in Space Grotesk values
- Progress bar with "Cuota 14 de 60" label + % right
- Arrow bottom-right
- Full card click = navigate to detail
- Hover: shadow + translateY(-1px)

#### `src/pages/LibranzaDetalle.tsx`
- "Volver a mis créditos" back link
- Credit header: full obligation number + copy button (toast "Número copiado"), pagaduría, StatusPill
- If en mora: amber warning strip above balance
- Highlighted block: 36px balance, cuota mensual, próximo descuento row
- Progress bar "Cuota 14 de 60"
- Accordion "Características del crédito" (open by default): 8 data rows alternating bg
- "Pagos" zone → TabPagos + TabPlanCuotas (tabs)
- "Certificados" zone → CertificadosInmediatos + CertificacionDeSaldo

#### `src/libranza/TabPagos.tsx`
- 5 payments visible on entry
- Grouped by year with sticky year header (versalitas gray)
- Each row: date left (15 JUL 2026), "Pago aplicado" + value right (Space Grotesk 15px bold), "Saldo después $X" below in 12px gray, chevron right expands
- Expanded: Capital, Intereses, Otros conceptos breakdown
- "Cargar más" adds 10; when exhausted → gray text "Has llegado al primer pago de este crédito"
- 14 payments from mockData (Jun 2025 → Jul 2026)

#### `src/libranza/TabPlanCuotas.tsx`
- Desktop: table with columns Cuota, Fecha, Capital, Intereses, Cuota total, Saldo (all Space Grotesk values)
- Paid rows: gray + mint check. Next row: mint-8% bg + "Próxima" badge. Future: normal.
- Mobile: cards instead of table
- "Ver plan completo" button shows all 60
- `overflow-x-auto` on table wrapper; page never scrolls horizontally

#### `src/libranza/CertificadosInmediatos.tsx`
- "Descarga inmediata" group: 3 cards (Carta de condiciones, Plan de pagos, Amortización). Each: mint-light icon square, name, gray description, "Descargar" button. Click → 1s loading → green toast.
- Footer line 12px gray.
- "Extractos" group: 1 wider card. 6 month buttons (month in versalitas + year in Space Grotesk). Selected: navy solid. "Descargar extracto" disabled until month selected. Months: AGO 2026…MAR 2026 (6 months back from current). Mobile: 2 rows of 3.

#### `src/libranza/CertificacionDeSaldo.tsx`
- State A (credit 4821): green chip "Primera del mes sin costo", "Solicitar certificación" button → confirmation dialog
- State B (credit 7350): amber bg card, "En proceso" pill, "Solicitada el 11 AGO 2026", "máximo X días hábiles", masked email "a****s@correo.com", secondary "Ver en Documentos" — no request button
- State C: amber chip with "$XX.XXX" cost, button enabled
- Confirmation dialog: credit ID, month count, cost, masked email, mandatory checkbox when cost present, "Confirmar solicitud" disabled until checked if cost
- Success dialog: mint check, "SOL-2026-004821" in Space Grotesk, "Ver en Documentos" + "Cerrar"

#### `src/libranza/PazYSalvoFlow.tsx`
- Full-screen overlay (or dedicated route segment) with progress indicator (step 1/2/3)
- **Step 1** — VerificacionStep: dashed border container "Paso de verificación — pendiente de definir". Isolated component. "Continuar" button.
- **Step 2** — Radio list of 2 terminated credits. Each row: masked number, amount + period, pagaduría (shown since >1 pagaduría). "Ver paz y salvo" disabled until selection. Empty state after verification if no credits.
- **Step 3** — Document preview in white card (paper proportion, soft shadow). "Descargar PDF" + "Consultar otro crédito" (resets to step 1).
- "Consultar otro crédito" goes to step 1, never step 2.

#### `src/libranza/VerificacionStep.tsx`
- Isolated, self-contained. Dashed border container. Replacement-ready.

---

### Step 7 — Mis datos (`src/pages/MisDatos.tsx`)

- SectionHeader "Mis datos" + "Mantén tu información actualizada"
- Completeness bar (fixed under header): progress bar + "Perfil completo al 80 %" + link "Completar información financiera" scrolls to + opens incomplete block. At 100%: mint bar + "Perfil al día".
- 6 accordion blocks (2-col desktop, 1-col mobile). Each header: block name + mint check or amber dot indicator.
  1. Datos de perfil: nombres/apellidos/tipo doc/num doc = readonly gray bg; email + celular = editable
  2. Datos de residencia: departamento, ciudad, barrio, address composer (tipo vía + número + letra + num secundario + complemento) with assembled address pill preview; estrato 1–6 as 6 clickable squares
  3. Información financiera: 5 currency fields + "¿Declaras renta?" Sí/No toggle
  4. Datos profesionales: nivel educativo, ocupación, actividad económica (selects)
  5. Exposición política PEP: 3 Yes/No questions + conditional family PEP sub-form on 4th
  6. Notificaciones: security group (locked toggles + reason note) + commercial group (editable toggles)
- Save bar (fixed bottom, visible only with unsaved changes): "Tienes cambios sin guardar" + "Descartar" + "Guardar cambios"
- Confirmation dialog: list changed fields with old → new values. "Volver" + "Confirmar". On confirm: green toast "Tu información fue actualizada".
- `personType === 'juridica'`: show only "Datos del representante legal" (editable names), "Información de la empresa" (readonly), "Notificaciones". Other blocks hidden.

---

### Step 8 — Documentos (`src/pages/Documentos.tsx`)

- SectionHeader "Documentos" + "Todos tus certificados y solicitudes"
- Filter row 1 (FilterChips): Todos · Disponibles · En proceso
- Filter row 2 (FilterChips): Todos · Libranza · CDT
- Search input (right-aligned)
- **"En proceso" block** (only if items exist): amber-tinted cards. 1 simulated item: Certificación de saldo · Libranza · Crédito ···· 7350 · 11 AGO 2026 · SOL-2026-004821.
- **"Disponibles" block**: grouped by month (month as header). 8 docs from mockData. Each row: type icon, name, product + origin line (gray), date right, download button. Click → green toast.
- EmptyState if filtered to zero.
- Filters combine; search on name field.

**NotificationsPanel** (in `src/components/NotificationsPanel.tsx`): Used in AppHeader bell click. 5 notifications. Unread dot. Relative time. "Marcar todas como leídas" link. "Ver todas" → /documentos. Bell red dot disappears when `hasUnread === false`. Opening panel doesn't auto-mark-read.

---

### Step 9 — Stub Pages

Each of these renders a simple placeholder with route name and a brief description (no lorem ipsum):
- `CDT.tsx` → `/cdt`
- `CDTDetalle.tsx` → `/cdt/:id`
- `Seguridad.tsx` → `/seguridad`
- `Contactanos.tsx` → `/contactanos`
- `EducacionFinanciera.tsx` → `/educacion-financiera`

---

## Animation System

- Card entry: `opacity: 0 → 1`, `translateY: 14px → 0`, duration 0.35s, `cubic-bezier(0.22, 1, 0.36, 1)`. Stagger siblings by 0.05s using `animationDelay`.
- Color transitions: 150ms on all interactive elements.
- Only the live-status dot pulses (CSS `animate-pulse`). Nothing else pulses.
- SidePanel slide: `translateX(100%) → 0` on open.
- Scrollbars hidden by default; use `scrollbar-thin` on hover.

---

## Key Rules to Enforce Everywhere

- Every monetary amount, percentage, date numeric, and obligation number → `font-family: 'Space Grotesk'`
- Every label, title, body text → `font-family: 'Montserrat'`
- Sidebar is the only dark surface. All other surfaces are white or #F9FAFB.
- `deuda` and `inversión` sums are never combined, never in the same KpiCard row.
- `En mora` state: always visible, always red, never muted.
- Colombian Spanish: "ingresa", never "ingresá". No emojis.
- Empty states always explain WHY and offer an action.
- `$ XX.XXX` and `X días hábiles` appear literally where values are undefined.
- Libranza is excluded entirely from navigation when `personType === 'juridica'`.

---

## Verification Checklist

After implementation, verify:
- [ ] Sidebar collapses to 60px, persists state across navigation, becomes drawer below 1024px
- [ ] "Cuenta de Ahorros" always PRONTO; "CDT" PRONTO in Fase 1
- [ ] Fase 2 + Jurídica: Libranza entirely absent from nav
- [ ] Every visible number uses Space Grotesk; every label uses Montserrat
- [ ] Regulatory seals in sidebar footer
- [ ] DemoSelector floating bottom-right, mounted once only
- [ ] Home reacts to all 4 DEMO states without mixing debt+investment KPIs
- [ ] Libranza list: masked numbers; detail: full number + copy → toast
- [ ] Pagos: 5 initial → +10 per "Cargar más" → terminal text
- [ ] Plan de cuotas: horizontal scroll on its own wrapper, not the page
- [ ] 6 month buttons each showing month + year
- [ ] CertificaciónDeSaldo: 3 states, dialog mandatory, cost checkbox blocks confirm
- [ ] PazYSalvo: "Consultar otro" → step 1, not step 2
- [ ] MisDatos: save bar only when dirty; jurídica shows different blocks
- [ ] Documentos filters combine; "En proceso" above "Disponibles"
- [ ] Bell red dot state driven by unread count; panel open ≠ auto-mark-read
- [ ] App renders correctly at 360px width
