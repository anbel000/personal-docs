# Project Brief — [Nombre del Proyecto]

> **Cómo usar este archivo**
> Copia este archivo a la raíz de tu workspace con el nombre de tu proyecto (ej: `mi-proyecto.md`).
> Llena cada sección con la información que tienes. No necesitas tenerlo todo completo — Claude usará
> lo que hay y preguntará por lo que falte antes de generar specs.
> Luego ejecuta `/bootstrap mi-proyecto.md` desde dentro de `spec-driven-framework/`.

---

## 1. Identidad del proyecto

**Nombre**: <!-- Nombre corto, sin espacios preferiblemente kebab-case -->
**Versión inicial**: 0.1.0
**Idioma principal de las specs**: es <!-- es | en -->
**Fecha estimada de inicio**: <!-- YYYY-MM-DD -->

## 2. Problema que resuelve

<!-- 2-5 oraciones. Qué problema existe hoy, quién lo sufre, por qué importa resolverlo ahora. -->

## 3. Solución propuesta

<!-- Descripción de la solución a alto nivel. No especificaciones técnicas todavía. -->

## 4. Usuarios objetivo

<!-- Lista los segmentos de usuarios. Para cada uno: quiénes son, qué necesitan, cuántos hay. -->

| Segmento | Descripción | Necesidad principal |
|----------|-------------|---------------------|
|          |             |                     |
|          |             |                     |

## 5. Funcionalidades clave (must-have)

<!-- Lista las 5-10 funcionalidades que DEBEN estar en v1 para que el producto sea útil. -->

1.
2.
3.
4.
5.

## 6. Funcionalidades deseadas (nice-to-have)

<!-- Lo que vendría en v2 o después. -->

1.
2.
3.

## 7. Stack tecnológico

<!-- Si tienes preferencias o restricciones, indícalas. Si no, escribe "libre" y Claude recomendará. -->

| Capa | Tecnología preferida | Restricción |
|------|---------------------|-------------|
| Frontend | | |
| Backend | | |
| Base de datos | | |
| Infraestructura | | |
| Mobile (si aplica) | | |

## 8. Integraciones externas

<!-- APIs, servicios de terceros, sistemas legados con los que debe conectarse. -->

| Sistema | Tipo (REST/GraphQL/SDK/etc.) | Propósito |
|---------|------------------------------|-----------|
|         |                              |           |

## 9. Modelo de datos (preliminar)

<!-- Las entidades principales del dominio. No necesitas el schema completo — solo los nombres y relaciones clave. -->

**Entidades principales**:
-
-
-

**Relaciones clave** (opcional):
<!-- ej: "Un usuario tiene muchas órdenes; una orden tiene muchos items" -->

## 10. Requisitos de seguridad y cumplimiento

<!-- Marca los que aplican y agrega notas específicas. -->

- [ ] Autenticación de usuarios (login/logout/registro)
- [ ] Roles y permisos (RBAC)
- [ ] GDPR / protección de datos personales
- [ ] PCI DSS (pagos con tarjeta)
- [ ] SOC 2 / ISO 27001
- [ ] Habeas Data (Colombia)
- [ ] Otro: ___

**Notas de cumplimiento**:

## 11. Restricciones del proyecto

| Dimensión | Valor |
|-----------|-------|
| Equipo de desarrollo | <!-- nro de personas y roles --> |
| Presupuesto aproximado | <!-- rango o "no definido" --> |
| Plazo para v1 | <!-- fecha o duración --> |
| Infraestructura preferida | <!-- cloud provider, on-premise, etc. --> |

## 12. Hardware / IoT (si aplica)

<!-- Si el proyecto involucra hardware físico, sensores, dispositivos embebidos, etc. -->

- [ ] No aplica
- [ ] Sí aplica — describir:

## 13. Contexto adicional

<!-- Cualquier información relevante que no encaje arriba: competencia, referencias, decisiones ya tomadas, etc. -->

## 14. Stakeholders

| Rol | Nombre (opcional) | Área de decisión |
|-----|-------------------|-----------------|
| Sponsor / dueño del negocio | | |
| Product Manager | | |
| Tech Lead | | |
| Usuario representativo | | |
