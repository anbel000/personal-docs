#!/bin/bash
# Git pre-commit hook: verifica que cambios de código incluyan actualizaciones de specs.
# Instalación automática vía: bash .claude/hooks/setup-git-hooks.sh
# Override puntual: SPEC_SYNC_HOOK=off git commit ...
# Modo estricto (bloquea): SPEC_SYNC_STRICT=1 git commit ...

set -e

# Opt-out por variable de entorno
if [ "${SPEC_SYNC_HOOK}" = "off" ]; then
  exit 0
fi

YELLOW='\033[1;33m'
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Archivos de código y contratos staged
CODE_CHANGED=$(git diff --cached --name-only | grep -E "^(packages|src)/.*\.(ts|js|py|go|java|rb|rs)$" || true)
CONTRACTS_CHANGED=$(git diff --cached --name-only | grep -E "^contracts/.*\.(yaml|yml|json|sql)$" || true)

if [ -z "$CODE_CHANGED" ] && [ -z "$CONTRACTS_CHANGED" ]; then
  exit 0
fi

# Specs staged
SPECS_STAGED=$(git diff --cached --name-only | grep -E "^specs/.*\.md$" || true)

DRIFT_FILES=""

# Por cada archivo de código, buscar headers de trazabilidad y verificar si la spec está staged
for file in $CODE_CHANGED; do
  if [ ! -f "$file" ]; then continue; fi

  # Extraer specs referenciadas en headers del archivo (// para TS/JS, # para Python/Go/Ruby/Rust)
  REFERENCED_SPECS=$(grep -E "(// |# )(Generated from|Spec|Contract):" "$file" 2>/dev/null | \
    grep -oE "specs/[^,# ]+" || true)

  for spec in $REFERENCED_SPECS; do
    # Normalizar: quitar fragmento #REQ-xxx si tiene
    spec_path=$(echo "$spec" | cut -d'#' -f1)
    if [ ! -f "$spec_path" ]; then continue; fi

    # Verificar si la spec está staged
    if echo "$SPECS_STAGED" | grep -q "^$spec_path$" 2>/dev/null; then
      continue  # OK — spec staged
    fi

    DRIFT_FILES="$DRIFT_FILES\n  $file → $spec_path"
  done
done

# Check: specs aprobadas staged no deben contener [PENDIENTE]
APPROVED_WITH_PENDIENTE=""
SPECS_STAGED_LIST=$(git diff --cached --name-only | grep -E "^specs/.*\.md$" || true)
for file in $SPECS_STAGED_LIST; do
  if [ ! -f "$file" ]; then continue; fi
  FILE_STATUS=$(grep -m1 "^status:" "$file" 2>/dev/null | awk '{print $2}' | tr -d '"' || true)
  if [ "$FILE_STATUS" = "approved" ]; then
    COUNT=$(grep -c "\[PENDIENTE" "$file" 2>/dev/null || echo 0)
    if [ "$COUNT" -gt "0" ]; then
      APPROVED_WITH_PENDIENTE="$APPROVED_WITH_PENDIENTE\n  $file — $COUNT [PENDIENTE] en spec aprobada"
    fi
  fi
done

if [ -n "$APPROVED_WITH_PENDIENTE" ]; then
  echo -e "${RED}❌ SPEC APROBADA CON [PENDIENTE]:${NC}"
  echo -e "$APPROVED_WITH_PENDIENTE"
  echo ""
  echo "Las specs con status=approved no deben contener [PENDIENTE]."
  echo "Opciones:"
  echo "  1. Completar el contenido y quitar [PENDIENTE] antes de commitear"
  echo "  2. Cambiar status a 'review' si el dominio no está listo para aprobar"
  echo "     /grill-spec [dominio]  para completar [PENDIENTE] de forma guiada"
  exit 1
fi

if [ -z "$DRIFT_FILES" ]; then
  exit 0
fi

echo -e "${YELLOW}⚠️  SPEC SYNC — archivos de código staged sin sus specs actualizadas:${NC}"
echo -e "$DRIFT_FILES"
echo ""
echo -e "${YELLOW}Opciones:${NC}"
echo "  1. Actualizar las specs listadas y hacer git add sobre ellas"
echo "  2. Si el cambio no modifica comportamiento observable (refactor/tipos), omitir:"
echo "     SPEC_SYNC_HOOK=off git commit ..."
echo "  3. En deploy, /predeploy --strict detectará el drift restante"
echo ""

if [ "${SPEC_SYNC_STRICT}" = "1" ]; then
  echo -e "${RED}❌ SPEC_SYNC_STRICT=1 — commit bloqueado hasta que las specs estén staged${NC}"
  exit 1
fi

echo -e "${YELLOW}⚠️  Advertencia no bloqueante — commit permitido. El drift quedará registrado en /predeploy.${NC}"
exit 0
