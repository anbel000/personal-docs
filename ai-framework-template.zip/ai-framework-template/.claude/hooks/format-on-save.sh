#!/bin/bash
# Hook: PostToolUse(Write|Edit) — auto-formatea archivos TS/JS/Python tras cada edición
FILE=$(python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get('tool_input', {}).get('file_path', ''))
except Exception:
    print('format-on-save: no se pudo leer el JSON de stdin del hook', file=sys.stderr)
    sys.exit(2)
")
if [ $? -ne 0 ]; then
  exit 0  # Error de parsing — no bloquear el hook de formato
fi

[ -z "$FILE" ] && exit 0

EXT="${FILE##*.}"
case "$EXT" in
  ts|tsx|js|jsx)
    npx prettier --write "$FILE" --log-level silent 2>/dev/null || true
    ;;
  py)
    python3 -m black "$FILE" -q 2>/dev/null || true
    ;;
esac
exit 0
