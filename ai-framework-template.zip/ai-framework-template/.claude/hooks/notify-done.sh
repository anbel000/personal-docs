#!/bin/bash
# Hook: Stop — notificación cuando Claude termina + registro en memory/agent-log.md
# MEJORA-037: Registra timestamp de fin y calcula duración desde SESSION_START_AT si existe

SESSION_END=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%dT%H:%M:%SZ")
SESSION_DATE=$(date -u +"%Y-%m-%d" 2>/dev/null || date +"%Y-%m-%d")
SESSION_END_EPOCH=$(date -u +%s 2>/dev/null || echo "0")

# Calcular duración si existe la variable de inicio (set por el usuario o por un Pre hook futuro)
DURATION=""
if [ -n "${SESSION_START_EPOCH:-}" ] && [ "$SESSION_END_EPOCH" != "0" ]; then
    ELAPSED=$((SESSION_END_EPOCH - SESSION_START_EPOCH))
    MINUTES=$((ELAPSED / 60))
    SECONDS_REM=$((ELAPSED % 60))
    DURATION=" (${MINUTES}m${SECONDS_REM}s)"
fi

# ─── 1. Notificación de escritorio (Windows) ───────────────────────────────
if command -v powershell.exe &>/dev/null 2>&1; then
    powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -Command "
      Add-Type -AssemblyName System.Windows.Forms
      \$n = New-Object System.Windows.Forms.NotifyIcon
      \$n.Icon = [System.Drawing.SystemIcons]::Information
      \$n.BalloonTipTitle = 'Claude Code'
      \$n.BalloonTipText = 'Tarea completada'
      \$n.Visible = \$true
      \$n.ShowBalloonTip(4000)
      Start-Sleep -Seconds 5
      \$n.Dispose()
    " &
fi

# ─── 2. Registro en memory/agent-log.md ────────────────────────────────────
PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_LOG="$PROJECT_ROOT/memory/agent-log.md"

# Solo registrar si el directorio memory/ existe
if [ ! -d "$PROJECT_ROOT/memory" ]; then
    exit 0
fi

# Inicializar el log si no existe
if [ ! -f "$AGENT_LOG" ]; then
    cat > "$AGENT_LOG" << 'HEADER'
---
name: agent-log
description: Registro de ejecuciones de agentes del framework. Auto-actualizado por hook notify-done.sh.
metadata:
  type: project
---

# Agent Log

| Fecha | Comando / Actividad | Estado | Notas |
|-------|---------------------|--------|-------|
HEADER
fi

# Detectar qué comandos/agentes se invocaron en la sesión
# (lectura simplificada del historial reciente de git si existe)
RECENT_CHANGES=""
if git rev-parse --git-dir &>/dev/null 2>&1; then
    RECENT_CHANGES=$(git diff --name-only HEAD 2>/dev/null | \
        grep -E '^(specs/|contracts/|src/|packages/)' | head -5 | tr '\n' ', ' | sed 's/,$//')
fi

if [ -n "$RECENT_CHANGES" ]; then
    ENTRY="| $SESSION_DATE | sesión Stop${DURATION} | completada | Archivos: $RECENT_CHANGES |"
else
    ENTRY="| $SESSION_DATE | sesión Stop${DURATION} | completada | Sin cambios en specs/código |"
fi

# Insertar después del header de tabla
if grep -q "^| Fecha |" "$AGENT_LOG"; then
    TMPFILE=$(mktemp)
    awk -v entry="$ENTRY" '
        /^\| Fecha \|/ { print; getline; print; print entry; next }
        { print }
    ' "$AGENT_LOG" > "$TMPFILE" && mv "$TMPFILE" "$AGENT_LOG"
else
    echo "$ENTRY" >> "$AGENT_LOG"
fi

exit 0
