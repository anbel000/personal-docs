#!/bin/bash
# Hook: PostToolUse(Write|Edit) — valida frontmatter de specs modificadas
# Se ejecuta automáticamente después de cada Write o Edit en specs/ y contratos.
#
# Verifica que las specs tienen frontmatter válido y consistente.
# Si detecta un problema, emite advertencia (NO bloquea — es informacional).

# Leer stdin (contexto del tool use desde Claude Code)
INPUT=$(cat)

# Extraer el file_path del tool use
PYTHON_CMD=""
for _py in python3 python py; do
    if command -v "$_py" &>/dev/null 2>&1; then
        if "$_py" -c "import sys; assert sys.version_info >= (3, 6)" &>/dev/null 2>&1; then
            PYTHON_CMD="$_py"
            break
        fi
    fi
done

if [ -n "$PYTHON_CMD" ]; then
    FILE_PATH=$(printf '%s' "$INPUT" | "$PYTHON_CMD" -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get('tool_input', {}).get('file_path', ''))
except Exception:
    pass
" 2>/dev/null || true)
else
    FILE_PATH=$(printf '%s' "$INPUT" | \
        grep -oE '"file_path"[[:space:]]*:[[:space:]]*"[^"]*"' 2>/dev/null | \
        head -1 | \
        sed 's/.*"file_path"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/' 2>/dev/null || true)
fi

# Solo validar archivos .md en specs/
if [ -z "$FILE_PATH" ]; then
    exit 0
fi

# Normalizar ruta para comparación (convertir backslashes de Windows)
FILE_PATH_NORM=$(echo "$FILE_PATH" | tr '\\' '/')

# Verificar que es un archivo de spec (en specs/ y es .md)
if ! echo "$FILE_PATH_NORM" | grep -qE '/specs/.*\.md$'; then
    exit 0
fi

# Verificar que el archivo existe
if [ ! -f "$FILE_PATH" ]; then
    exit 0
fi

WARNINGS=()

# ─── Validación 1: ¿Tiene frontmatter? ──────────────────────────────────────
FIRST_LINE=$(head -1 "$FILE_PATH" 2>/dev/null || true)
if [ "$FIRST_LINE" != "---" ]; then
    WARNINGS+=("SIN FRONTMATTER: $FILE_PATH_NORM")
fi

# ─── Validación 2: ¿Tiene campo status? ─────────────────────────────────────
if ! grep -q "^status:" "$FILE_PATH" 2>/dev/null; then
    WARNINGS+=("CAMPO FALTANTE: 'status' no encontrado en frontmatter de $FILE_PATH_NORM")
fi

# ─── Validación 3: ¿status tiene valor válido? ──────────────────────────────
STATUS_VALUE=$(grep "^status:" "$FILE_PATH" 2>/dev/null | head -1 | sed 's/status:[[:space:]]*//' | tr -d '"' | tr -d "'" | tr -d ' ')
if [ -n "$STATUS_VALUE" ]; then
    case "$STATUS_VALUE" in
        draft|review|approved) ;;  # Valores válidos
        *)
            WARNINGS+=("STATUS INVÁLIDO: '$STATUS_VALUE' no es un valor válido (usar: draft, review, approved) en $FILE_PATH_NORM")
            ;;
    esac
fi

# ─── Validación 4: ¿approved sin approved_at? ───────────────────────────────
if [ "$STATUS_VALUE" = "approved" ]; then
    if ! grep -q "^approved_at:" "$FILE_PATH" 2>/dev/null && \
       ! grep -q "^approved_by:" "$FILE_PATH" 2>/dev/null; then
        WARNINGS+=("APROBACIÓN INCOMPLETA: status=approved pero sin 'approved_at'/'approved_by' en $FILE_PATH_NORM")
    fi
fi

# ─── Validación 5: ¿Tiene last_updated? ─────────────────────────────────────
if ! grep -q "^last_updated:" "$FILE_PATH" 2>/dev/null; then
    WARNINGS+=("CAMPO FALTANTE: 'last_updated' no encontrado en frontmatter de $FILE_PATH_NORM")
fi

# ─── Output de advertencias ─────────────────────────────────────────────────
if [ ${#WARNINGS[@]} -gt 0 ]; then
    echo "⚠️  validate-frontmatter: advertencias en specs editadas:" >&2
    for WARNING in "${WARNINGS[@]}"; do
        echo "   → $WARNING" >&2
    done
    echo "   Usa /validate freshness para verificar frescura de specs aprobadas." >&2
fi

# Siempre exit 0 — este hook es informacional, no bloqueante
exit 0
