#!/bin/bash
# Hook: post-commit — registra cambios en specs/contratos en memory/spec-changelog.md
# Se activa automáticamente después de cada git commit.
# Instalación: se copia a .git/hooks/post-commit por setup-git-hooks.sh

set -euo pipefail

PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"
if [ -z "$PROJECT_ROOT" ]; then
    exit 0
fi

CHANGELOG="$PROJECT_ROOT/memory/spec-changelog.md"
COMMIT_HASH=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
COMMIT_MSG=$(git log -1 --pretty=format:"%s" 2>/dev/null || echo "")
COMMIT_AUTHOR=$(git log -1 --pretty=format:"%an" 2>/dev/null || echo "unknown")
COMMIT_DATE=$(date -u +"%Y-%m-%d" 2>/dev/null || date +"%Y-%m-%d")

# Detectar archivos de specs y contratos modificados en el último commit
CHANGED_SPECS=$(git diff-tree --no-commit-id -r --name-only HEAD 2>/dev/null | \
    grep -E '^(specs/|contracts/|spec-manifest\.yaml)' | head -20 || true)

# Si no hay cambios en specs/contratos, no hay nada que registrar
if [ -z "$CHANGED_SPECS" ]; then
    exit 0
fi

# Asegurar que el directorio memory/ existe
mkdir -p "$PROJECT_ROOT/memory"

# Inicializar el changelog si no existe
if [ ! -f "$CHANGELOG" ]; then
    cat > "$CHANGELOG" << 'HEADER'
---
name: spec-changelog
description: Historial de cambios en specs y contratos del proyecto. Auto-actualizado por hook post-commit.
metadata:
  type: project
---

# Spec Changelog

Registro de cambios en specs y contratos. Generado automáticamente por `.claude/hooks/post-commit-changelog.sh`.

| Fecha | Commit | Tipo | Dominio/Archivo | Autor | Descripción |
|-------|--------|------|-----------------|-------|-------------|
HEADER
fi

# Clasificar el tipo de cambio (approved/modified/created/deleted)
# Por defecto: modified — el hook de /approve lo cambiará a 'approved' si aplica
CHANGE_TYPE="modified"

# Detectar si el commit incluye aprobación de specs
if echo "$COMMIT_MSG" | grep -qiE "(approv|aprobad|status.*approved)"; then
    CHANGE_TYPE="approved"
fi

# Detectar si es creación de specs nuevas
if git diff-tree --no-commit-id -r --diff-filter=A --name-only HEAD 2>/dev/null | \
   grep -qE '^(specs/|contracts/)'; then
    CHANGE_TYPE="created"
fi

# Detectar si es eliminación de specs
if git diff-tree --no-commit-id -r --diff-filter=D --name-only HEAD 2>/dev/null | \
   grep -qE '^(specs/|contracts/)'; then
    CHANGE_TYPE="deleted"
fi

# Extraer el dominio principal del primer archivo modificado
FIRST_FILE=$(echo "$CHANGED_SPECS" | head -1)
DOMAIN=$(echo "$FIRST_FILE" | sed 's|specs/[0-9]*-\([^/]*\)/.*|\1|' | \
         sed 's|contracts/\([^/]*\)/.*|\1-contract|' | \
         sed 's|spec-manifest\.yaml|manifest|')

# Contar archivos modificados para el summary
FILE_COUNT=$(echo "$CHANGED_SPECS" | wc -l | tr -d ' ')
if [ "$FILE_COUNT" -eq 1 ]; then
    FILE_SUMMARY="$FIRST_FILE"
else
    FILE_SUMMARY="$FIRST_FILE (+$((FILE_COUNT - 1)) más)"
fi

# Truncar el mensaje de commit a 60 caracteres
COMMIT_MSG_SHORT=$(echo "$COMMIT_MSG" | cut -c1-60)

# Añadir la entrada al changelog (después del header de tabla)
# Usamos una línea temporal y luego la insertamos
ENTRY="| $COMMIT_DATE | \`$COMMIT_HASH\` | $CHANGE_TYPE | $DOMAIN | $COMMIT_AUTHOR | $COMMIT_MSG_SHORT |"

# Insertar la nueva entrada como primera fila de datos (después del header de tabla)
# Buscar la línea del header de tabla y añadir después
if grep -q "^| Fecha |" "$CHANGELOG"; then
    # Crear archivo temporal con la nueva línea insertada
    TMPFILE=$(mktemp)
    awk -v entry="$ENTRY" '
        /^\| Fecha \|/ { print; getline; print; print entry; next }
        { print }
    ' "$CHANGELOG" > "$TMPFILE"
    mv "$TMPFILE" "$CHANGELOG"
else
    # Si no hay tabla aún, solo añadir al final
    echo "$ENTRY" >> "$CHANGELOG"
fi

# Mantener el changelog en máximo 200 entradas (evitar crecimiento infinito)
LINE_COUNT=$(wc -l < "$CHANGELOG")
if [ "$LINE_COUNT" -gt 220 ]; then
    # Conservar el header + las primeras 200 entradas de datos
    HEADER_LINES=$(grep -n "^| Fecha |" "$CHANGELOG" | head -1 | cut -d: -f1)
    if [ -n "$HEADER_LINES" ]; then
        KEEP_UNTIL=$((HEADER_LINES + 201))  # header + separador + 200 entradas
        TMPFILE=$(mktemp)
        head -"$KEEP_UNTIL" "$CHANGELOG" > "$TMPFILE"
        echo "" >> "$TMPFILE"
        echo "*(Entradas anteriores archivadas — ver git log)*" >> "$TMPFILE"
        mv "$TMPFILE" "$CHANGELOG"
    fi
fi

exit 0
