#!/bin/bash
# Hook: PreToolUse(Bash) — bloquea comandos destructivos antes de ejecutarlos
# Portable: Windows (Git Bash), macOS, Linux

# Leer stdin PRIMERO antes de cualquier otra operación
INPUT=$(cat)

# ─── Detección portable de Python 3 (Windows + Linux + macOS) ───────────────
PYTHON_CMD=""
for _py in python3 python py; do
    if command -v "$_py" &>/dev/null 2>&1; then
        if "$_py" -c "import sys; assert sys.version_info >= (3, 6)" &>/dev/null 2>&1; then
            PYTHON_CMD="$_py"
            break
        fi
    fi
done

# ─── Parsear el JSON de entrada ──────────────────────────────────────────────
if [ -n "$PYTHON_CMD" ]; then
    COMMAND=$(printf '%s' "$INPUT" | "$PYTHON_CMD" -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get('tool_input', {}).get('command', ''))
except Exception:
    sys.stderr.write('validate-bash: fallo al parsear input JSON\n')
    sys.exit(2)
")
    PARSE_EXIT=$?
else
    # Fallback bash puro (Windows sin Python disponible)
    # Extracción mínima del campo "command" via grep/sed
    PARSE_EXIT=0
    COMMAND=$(printf '%s' "$INPUT" | \
        grep -oE '"command"[[:space:]]*:[[:space:]]*"[^"]*"' 2>/dev/null | \
        head -1 | \
        sed 's/.*"command"[[:space:]]*:[[:space:]]*"\([^"]*\)"/\1/' 2>/dev/null || true)
fi

# Si el parse falló, bloquear por seguridad
if [ "$PARSE_EXIT" -ne 0 ]; then
    echo "❌ validate-bash: input inválido — bloqueado por seguridad" >&2
    exit 2
fi

[ -z "$COMMAND" ] && exit 0

block() {
    echo "❌ Comando bloqueado: patrón destructivo detectado → '$COMMAND'" >&2
    echo "   Ejecútalo manualmente en la terminal si realmente lo necesitas." >&2
    exit 2
}

# rm recursivo+forzado apuntando a paths peligrosos — todas las variantes de flags:
#   rm -rf /        rm -r -f /      rm -Rf *
#   rm --recursive --force /        rm --force --recursive ./*
if echo "$COMMAND" | grep -qiE 'rm[[:space:]]'; then
    HAS_R=false; HAS_F=false; HAS_DANGER=false
    echo "$COMMAND" | grep -qiE -- '-[a-zA-Z]*[rR]|--recursive' && HAS_R=true
    echo "$COMMAND" | grep -qiE -- '-[a-zA-Z]*f|--force'        && HAS_F=true
    echo "$COMMAND" | grep -qiE -- '[[:space:]](\/?[[:space:]]*$|\/\*|\.\/?[[:space:]]*$|\.\?\*[[:space:]]*$)' && HAS_DANGER=true
    $HAS_R && $HAS_F && $HAS_DANGER && block
fi

# Otros patrones destructivos
DESTRUCTIVE_PATTERNS=(
    'DROP[[:space:]]+DATABASE'
    'DROP[[:space:]]+TABLE[[:space:]]'
    'mkfs\.'
    'dd[[:space:]]+if='
    '>[[:space:]]*/dev/sd'
)

for PATTERN in "${DESTRUCTIVE_PATTERNS[@]}"; do
    echo "$COMMAND" | grep -qiE "$PATTERN" && block
done

exit 0
