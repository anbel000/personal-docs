# setup-git-hooks.ps1
# Instala los git hooks del Spec-Driven Framework en el repositorio actual.
# Uso (desde la raiz del proyecto): .\.claude\hooks\setup-git-hooks.ps1
#
# Requiere Git for Windows (incluye bash.exe en C:\Program Files\Git\bin\bash.exe)
# Descarga: https://git-scm.com/download/win

$ErrorActionPreference = "Stop"

# Verificar que estamos en un repositorio git
if (-not (Test-Path ".git")) {
    Write-Error "No se encontro .git/ — ejecuta este script desde la raiz del repositorio"
    exit 1
}

# Buscar bash.exe de Git for Windows en ubicaciones comunes
$BashCandidates = @(
    "$env:ProgramFiles\Git\bin\bash.exe",
    "${env:ProgramFiles(x86)}\Git\bin\bash.exe",
    "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe",
    "$env:USERPROFILE\scoop\apps\git\current\bin\bash.exe"
)

$BashExe = $null
foreach ($candidate in $BashCandidates) {
    if (Test-Path $candidate) {
        $BashExe = $candidate
        break
    }
}

# Fallback: buscar bash en el PATH del sistema
if (-not $BashExe) {
    try {
        $found = Get-Command bash -ErrorAction Stop
        $BashExe = $found.Source
    } catch {
        Write-Error @"
bash.exe no encontrado. Instala Git for Windows:
  https://git-scm.com/download/win

Luego vuelve a ejecutar este script.
"@
        exit 1
    }
}

Write-Host "Usando bash: $BashExe"
Write-Host "Instalando git hooks del Spec-Driven Framework..."
Write-Host ""

# Ejecutar el script bash original
& $BashExe ".claude/hooks/setup-git-hooks.sh"
$exitCode = $LASTEXITCODE

if ($exitCode -eq 0) {
    Write-Host ""
    Write-Host "Git hooks instalados correctamente." -ForegroundColor Green
    Write-Host ""
    Write-Host "Consejo: Para omitir spec-sync puntualmente:" -ForegroundColor Yellow
    Write-Host "  `$env:SPEC_SYNC_HOOK='off'; git commit ...; Remove-Item env:SPEC_SYNC_HOOK" -ForegroundColor Yellow
} else {
    Write-Error "La instalacion fallo con codigo $exitCode"
    exit $exitCode
}
