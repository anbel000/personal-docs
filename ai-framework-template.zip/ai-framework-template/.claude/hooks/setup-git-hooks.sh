#!/bin/bash
# Instala los git hooks del framework en el repositorio actual.
# Uso (Linux / macOS / Git Bash): bash .claude/hooks/setup-git-hooks.sh
# Uso (Windows PowerShell):       .\.claude\hooks\setup-git-hooks.ps1

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "🔧 Instalando git hooks del Spec-Driven Framework..."

# Verificar que estamos en un repositorio git
if [ ! -d ".git" ]; then
  echo -e "${RED}❌ No se encontró .git/ — ejecuta este script desde la raíz del repositorio${NC}"
  exit 1
fi

HOOKS_DIR=".git/hooks"
SOURCE_DIR=".claude/hooks"

# Instalar pre-commit (combina spec-validate + spec-sync)
# Genera un hook compuesto que ejecuta ambos scripts en secuencia
cat > "$HOOKS_DIR/pre-commit" << 'HOOK'
#!/bin/bash
# Hook pre-commit compuesto: validación YAML/JSON + spec-sync check

# Parte 1: Validación básica de specs y contratos (YAML/JSON/frontmatter)
bash "$(git rev-parse --show-toplevel)/.claude/hooks/pre-commit-validate.sh"

# Parte 2: Spec sync — verifica que código staged incluya sus specs
bash "$(git rev-parse --show-toplevel)/.claude/hooks/pre-commit-spec-sync.sh"
HOOK
chmod +x "$HOOKS_DIR/pre-commit"
echo -e "${GREEN}✅ pre-commit instalado → valida specs/contratos + spec-sync check${NC}"

# Instalar pre-push (si existe)
if [ -f "$SOURCE_DIR/pre-push-validate.sh" ]; then
  cp "$SOURCE_DIR/pre-push-validate.sh" "$HOOKS_DIR/pre-push"
  chmod +x "$HOOKS_DIR/pre-push"
  echo -e "${GREEN}✅ pre-push instalado${NC}"
fi

# Instalar post-commit (changelog automático de specs)
if [ -f "$SOURCE_DIR/post-commit-changelog.sh" ]; then
  cp "$SOURCE_DIR/post-commit-changelog.sh" "$HOOKS_DIR/post-commit"
  chmod +x "$HOOKS_DIR/post-commit"
  echo -e "${GREEN}✅ post-commit instalado → auto-actualiza memory/spec-changelog.md${NC}"
fi

echo ""
echo -e "${GREEN}🎉 Git hooks instalados correctamente.${NC}"
echo ""
echo "Hooks activos:"
ls -la "$HOOKS_DIR/" | grep -v "^total" | grep -v "\.sample$" | grep -v "^d" | sed 's/^/   /'
echo ""
echo -e "${YELLOW}💡 Para desinstalar: rm .git/hooks/pre-commit${NC}"
echo -e "${YELLOW}💡 Para omitir spec-sync puntualmente: SPEC_SYNC_HOOK=off git commit ...${NC}"
echo -e "${YELLOW}💡 Para modo estricto (bloquea si hay drift): SPEC_SYNC_STRICT=1 git commit ...${NC}"
