#!/bin/bash
# Git pre-commit hook que valida specs modificadas antes de commitear.
# Instalación: bash .claude/hooks/setup-git-hooks.sh

set -e

# Colores
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo "🔍 Validando specs antes del commit..."

# Detectar archivos de specs modificados en el staging area
SPECS_CHANGED=$(git diff --cached --name-only | grep "^specs/" || true)
CONTRACTS_CHANGED=$(git diff --cached --name-only | grep "^contracts/" || true)

if [ -z "$SPECS_CHANGED" ] && [ -z "$CONTRACTS_CHANGED" ]; then
  echo -e "${GREEN}✅ No hay specs ni contratos modificados — commit OK${NC}"
  exit 0
fi

# Mostrar qué cambió
if [ -n "$SPECS_CHANGED" ]; then
  echo -e "${YELLOW}📋 Specs modificadas:${NC}"
  echo "$SPECS_CHANGED" | sed 's/^/   /'
fi

if [ -n "$CONTRACTS_CHANGED" ]; then
  echo -e "${YELLOW}📄 Contratos modificados:${NC}"
  echo "$CONTRACTS_CHANGED" | sed 's/^/   /'
fi

# Verificaciones básicas de consistencia (sin requerir Claude)

# 1. Verificar que los archivos YAML son válidos
for file in $CONTRACTS_CHANGED; do
  if [[ "$file" == *.yaml ]] || [[ "$file" == *.yml ]]; then
    if command -v python3 &>/dev/null; then
      python3 -c "import yaml, sys; yaml.safe_load(open(sys.argv[1]))" "$file" 2>/dev/null || {
        echo -e "${RED}❌ YAML inválido: $file${NC}"
        exit 1
      }
    fi
  fi
done

# 2. Verificar que los archivos JSON son válidos
for file in $CONTRACTS_CHANGED; do
  if [[ "$file" == *.json ]]; then
    if command -v python3 &>/dev/null; then
      python3 -c "import json, sys; json.load(open(sys.argv[1]))" "$file" 2>/dev/null || {
        echo -e "${RED}❌ JSON inválido: $file${NC}"
        exit 1
      }
    fi
  fi
done

# 3. Advertir (sin bloquear) si una spec no tiene frontmatter YAML
for file in $SPECS_CHANGED; do
  if [[ "$file" == *.md ]]; then
    first_line=$(head -1 "$file" 2>/dev/null || echo "")
    if [ "$first_line" != "---" ]; then
      echo -e "${YELLOW}⚠️  Sin frontmatter YAML: $file${NC}"
      echo "   Considera agregar --- title/status/date al inicio del archivo."
    fi
  fi
done

echo -e "${GREEN}✅ Validaciones básicas OK — commit permitido${NC}"
echo -e "${YELLOW}💡 Tip: ejecuta /validate all para una validación completa de consistencia${NC}"

exit 0
