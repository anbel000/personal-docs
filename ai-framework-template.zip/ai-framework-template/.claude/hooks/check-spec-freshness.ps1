# Hook PostToolUse(Write|Edit): alerta si una spec aprobada está próxima a expirar
# Llamado por settings.json con el path del archivo editado como primer argumento
param([string]$FilePath)

# Solo procesar archivos de specs markdown
if ($FilePath -notmatch 'specs[/\\].*\.md$') { exit 0 }
if (-not (Test-Path $FilePath)) { exit 0 }

$content = Get-Content $FilePath -Raw -ErrorAction SilentlyContinue
if (-not $content) { exit 0 }

# Extraer status y expires del frontmatter
$statusMatch = [regex]::Match($content, '(?m)^status:\s*(.+)$')
$expiresMatch = [regex]::Match($content, '(?m)^expires:\s*(.+)$')

if (-not $statusMatch.Success) { exit 0 }

$status = $statusMatch.Groups[1].Value.Trim().Trim('"')
if ($status -ne 'approved') { exit 0 }

if (-not $expiresMatch.Success) { exit 0 }

$expiresStr = $expiresMatch.Groups[1].Value.Trim().Trim('"')

try {
    $expiresDate = [datetime]::ParseExact($expiresStr, 'yyyy-MM-dd', $null)
    $today = [datetime]::Today
    $days = ($expiresDate - $today).Days

    $dominio = ($FilePath -replace '.*specs[/\\][0-9]+-([^/\\]+)[/\\].*', '$1')

    if ($days -lt 0) {
        Write-Host "🔴 SPEC EXPIRADA: $FilePath expiró hace $(-$days) días ($expiresStr)"
        Write-Host "   Acción requerida: /review $dominio antes de continuar"
    } elseif ($days -lt 30) {
        Write-Host "⏰ FRESCURA: $FilePath expira en $days días ($expiresStr)"
        Write-Host "   Acción sugerida: /review $dominio para renovar aprobación"
    }
} catch {
    # Formato de fecha inválido — ignorar silenciosamente
    exit 0
}
