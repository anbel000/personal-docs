#!/usr/bin/env bash
# Hook PostToolUse(Write|Edit): alerta si una spec aprobada está próxima a expirar
# Llamado por settings.json con el path del archivo editado como $1

FILE="${1}"

# Solo procesar archivos de specs markdown
if [[ "$FILE" != *"specs/"*".md" ]]; then
  exit 0
fi

# Verificar que el archivo existe
if [[ ! -f "$FILE" ]]; then
  exit 0
fi

STATUS=$(grep -m1 "^status:" "$FILE" 2>/dev/null | awk '{print $2}' | tr -d '"')
EXPIRES=$(grep -m1 "^expires:" "$FILE" 2>/dev/null | awk '{print $2}' | tr -d '"')

# Solo procesar specs aprobadas con campo expires
if [[ "$STATUS" != "approved" || -z "$EXPIRES" ]]; then
  exit 0
fi

# Calcular días hasta expiración (compatible Linux y macOS)
if date -d "$EXPIRES" +%s &>/dev/null 2>&1; then
  # Linux
  EXPIRE_TS=$(date -d "$EXPIRES" +%s)
else
  # macOS / BSD
  EXPIRE_TS=$(date -j -f "%Y-%m-%d" "$EXPIRES" +%s 2>/dev/null)
fi

if [[ -z "$EXPIRE_TS" ]]; then
  exit 0
fi

NOW_TS=$(date +%s)
DAYS=$(( (EXPIRE_TS - NOW_TS) / 86400 ))

if (( DAYS < 0 )); then
  echo "🔴 SPEC EXPIRADA: ${FILE} expiró hace $((-DAYS)) días (${EXPIRES})"
  echo "   Acción requerida: /review $(dirname $FILE | sed 's|.*specs/[0-9]*-||') antes de continuar"
elif (( DAYS < 30 )); then
  echo "⏰ FRESCURA: ${FILE} expira en ${DAYS} días (${EXPIRES})"
  echo "   Acción sugerida: /review $(dirname $FILE | sed 's|.*specs/[0-9]*-||') para renovar aprobación"
fi
