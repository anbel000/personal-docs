#!/bin/bash
# Hook de auto-rebuild del grafo de conocimiento.
# Se ejecuta después de cada Write o Edit en specs/ o contracts/.
# Llamado desde settings.json PostToolUse hook.

# El archivo modificado viene como env var CLAUDE_FILE_PATHS (separado por newlines)
# o como primer argumento.

MODIFIED_FILE="${1:-${CLAUDE_FILE_PATHS:-}}"
PROJECT_ROOT="$(pwd)"

# Solo reconstruir si el archivo modificado está en una ubicación relevante
should_rebuild() {
  local file="$1"
  [[ "$file" == */specs/* ]] || \
  [[ "$file" == */contracts/* ]] || \
  [[ "$file" == */.claude/agents/* ]] || \
  [[ "$file" == */.claude/commands/* ]] || \
  [[ "$file" == */.claude/rules/* ]] || \
  [[ "$file" == */memory/* ]] || \
  [[ "$file" == */MEMORY.md ]] || \
  [[ "$file" == */CLAUDE.md ]] || \
  [[ "$file" == */spec-manifest.yaml ]]
}

# Si el archivo no es relevante, salir silenciosamente
if [ -n "$MODIFIED_FILE" ] && ! should_rebuild "$MODIFIED_FILE"; then
  exit 0
fi

# Verificar que graphify está disponible
if ! command -v graphify &>/dev/null && ! python -m graphify --version &>/dev/null 2>&1; then
  # Graphify no está instalado — salir silenciosamente (no bloquear el flujo)
  exit 0
fi

# Crear directorio de output si no existe
mkdir -p "$PROJECT_ROOT/graphify-out/wiki"

# Reconstrucción incremental (solo archivos cambiados)
# --update: solo re-procesa lo que cambió desde el último build
# Timeout de 60s para no bloquear el flujo de trabajo

if [ -f "$PROJECT_ROOT/graphify-out/graph.json" ]; then
  # Ya existe un grafo — modo incremental
  timeout 60 python -m graphify update "$PROJECT_ROOT" \
    --config "$PROJECT_ROOT/graphify/.graphify.yml" \
    --quiet 2>>"$PROJECT_ROOT/graphify-out/rebuild.log" &
  # Correr en background para no bloquear
else
  # Primera vez — build completo también en background
  timeout 120 python -m graphify update "$PROJECT_ROOT" \
    --config "$PROJECT_ROOT/graphify/.graphify.yml" \
    --quiet 2>>"$PROJECT_ROOT/graphify-out/rebuild.log" &
fi

# No esperar — el grafo se actualiza asíncronamente
# El hook sale inmediatamente para no bloquear el Write/Edit
exit 0
