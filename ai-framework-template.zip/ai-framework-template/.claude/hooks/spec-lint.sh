#!/usr/bin/env bash
# spec-lint.sh — Validaciones estructurales de specs SIN LLM
# Uso: bash .claude/hooks/spec-lint.sh [--strict] [--json]
# Exit 0: sin errores. Exit 1: errores encontrados.
# Compatible con GitHub Actions, GitLab CI, Jenkins, etc.

set -euo pipefail

STRICT=false
JSON_OUTPUT=false
ERRORS=0
WARNINGS=0
REPORT=()

for arg in "$@"; do
  case "$arg" in
    --strict) STRICT=true ;;
    --json) JSON_OUTPUT=true ;;
  esac
done

PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$PROJECT_ROOT"

# ─── Helpers ─────────────────────────────────────────────────────────────────

error() {
  ERRORS=$((ERRORS + 1))
  REPORT+=("[ERROR] $1")
}

warn() {
  WARNINGS=$((WARNINGS + 1))
  REPORT+=("[WARN]  $1")
}

ok() {
  REPORT+=("[OK]    $1")
}

# ─── Check 1: spec-manifest.yaml existe y es YAML válido ─────────────────────

if [ ! -f "spec-manifest.yaml" ]; then
  error "spec-manifest.yaml no encontrado en la raíz del proyecto"
else
  # Validar YAML — intentar con python, fallback a ruby o node
  YAML_VALID=false
  if command -v python3 &>/dev/null; then
    if python3 -c "import yaml; yaml.safe_load(open('spec-manifest.yaml'))" 2>/dev/null; then
      YAML_VALID=true
    fi
  elif command -v python &>/dev/null; then
    if python -c "import yaml; yaml.safe_load(open('spec-manifest.yaml'))" 2>/dev/null; then
      YAML_VALID=true
    fi
  elif command -v ruby &>/dev/null; then
    if ruby -e "require 'yaml'; YAML.load_file('spec-manifest.yaml')" 2>/dev/null; then
      YAML_VALID=true
    fi
  elif command -v node &>/dev/null; then
    if node -e "require('js-yaml').load(require('fs').readFileSync('spec-manifest.yaml','utf8'))" 2>/dev/null; then
      YAML_VALID=true
    fi
  else
    # Sin parser disponible: validar mínimamente con grep
    if grep -q "^project:" spec-manifest.yaml 2>/dev/null; then
      YAML_VALID=true
    fi
  fi

  if $YAML_VALID; then
    ok "spec-manifest.yaml: YAML válido"
  else
    error "spec-manifest.yaml: YAML inválido (error de sintaxis)"
  fi
fi

# ─── Check 2: Specs declaradas en el manifest existen como archivos ───────────

if [ -f "spec-manifest.yaml" ] && [ -d "specs/" ]; then
  # Extraer nombres de dominio del manifest (líneas con "  nombre:" bajo domains:)
  DOMAINS=$(grep -A 200 "^domains:" spec-manifest.yaml 2>/dev/null | grep "^  [a-z]" | sed 's/://g' | tr -d ' ' || true)
  DOMAIN_COUNT=0
  DOMAIN_MISSING=0

  while IFS= read -r domain; do
    [ -z "$domain" ] && continue
    DOMAIN_COUNT=$((DOMAIN_COUNT + 1))
    # Buscar el directorio que corresponde al dominio (formato NN-nombre)
    DOMAIN_DIR=$(find specs/ -maxdepth 1 -type d -name "*${domain}*" 2>/dev/null | head -1)
    if [ -z "$DOMAIN_DIR" ]; then
      warn "Dominio '${domain}' en manifest sin directorio en specs/"
      DOMAIN_MISSING=$((DOMAIN_MISSING + 1))
    fi
  done <<< "$DOMAINS"

  if [ "$DOMAIN_MISSING" -eq 0 ] && [ "$DOMAIN_COUNT" -gt 0 ]; then
    ok "specs/: todos los ${DOMAIN_COUNT} dominios del manifest tienen directorio"
  fi
fi

# ─── Check 3: Frontmatter de specs ───────────────────────────────────────────

SPEC_COUNT=0
SPEC_NO_FRONTMATTER=0
SPEC_NO_STATUS=0
SPEC_INVALID_STATUS=0
SPEC_APPROVED_NO_AT=0
SPEC_NO_UPDATED=0
SPEC_APPROVED_PENDIENTE=0
VALID_STATUSES="draft review approved deprecated"

while IFS= read -r -d '' spec_file; do
  SPEC_COUNT=$((SPEC_COUNT + 1))
  CONTENT=$(cat "$spec_file" 2>/dev/null || true)

  # ¿Tiene frontmatter?
  if ! echo "$CONTENT" | grep -q "^---"; then
    warn "${spec_file}: sin frontmatter YAML"
    SPEC_NO_FRONTMATTER=$((SPEC_NO_FRONTMATTER + 1))
    continue
  fi

  # Extraer status
  STATUS=$(echo "$CONTENT" | grep "^status:" | head -1 | sed 's/status: *//;s/ *$//' || true)

  if [ -z "$STATUS" ]; then
    warn "${spec_file}: campo 'status' faltante en frontmatter"
    SPEC_NO_STATUS=$((SPEC_NO_STATUS + 1))
    continue
  fi

  # Validar que status sea un valor conocido
  VALID=false
  for vs in $VALID_STATUSES; do
    [ "$STATUS" = "$vs" ] && VALID=true && break
  done
  if ! $VALID; then
    warn "${spec_file}: status='${STATUS}' no es válido. Valores permitidos: ${VALID_STATUSES}"
    SPEC_INVALID_STATUS=$((SPEC_INVALID_STATUS + 1))
  fi

  # Si approved: debe tener approved_at y last_updated
  if [ "$STATUS" = "approved" ]; then
    if ! echo "$CONTENT" | grep -q "^approved_at:"; then
      error "${spec_file}: status=approved pero falta campo 'approved_at'"
      SPEC_APPROVED_NO_AT=$((SPEC_APPROVED_NO_AT + 1))
    fi

    if ! echo "$CONTENT" | grep -q "^last_updated:"; then
      warn "${spec_file}: status=approved pero falta campo 'last_updated'"
      SPEC_NO_UPDATED=$((SPEC_NO_UPDATED + 1))
    fi

    # Specs aprobadas no deben tener [PENDIENTE]
    PENDIENTE_COUNT=$(grep -c "\[PENDIENTE" "$spec_file" 2>/dev/null || true)
    if [ "$PENDIENTE_COUNT" -gt 0 ]; then
      error "${spec_file}: status=approved con ${PENDIENTE_COUNT} [PENDIENTE] (no permitido en specs aprobadas)"
      SPEC_APPROVED_PENDIENTE=$((SPEC_APPROVED_PENDIENTE + 1))
    fi
  fi

done < <(find specs/ -name "*.md" -print0 2>/dev/null)

if [ "$SPEC_COUNT" -gt 0 ]; then
  ISSUES=$((SPEC_NO_FRONTMATTER + SPEC_NO_STATUS + SPEC_INVALID_STATUS + SPEC_APPROVED_NO_AT + SPEC_APPROVED_PENDIENTE))
  if [ "$ISSUES" -eq 0 ]; then
    ok "specs/: ${SPEC_COUNT} specs con frontmatter válido"
  fi
fi

# ─── Check 4: Contratos OpenAPI son YAML válidos ──────────────────────────────

if [ -d "contracts/api/" ]; then
  API_COUNT=0
  API_INVALID=0
  while IFS= read -r -d '' yaml_file; do
    API_COUNT=$((API_COUNT + 1))
    VALID=false
    if command -v python3 &>/dev/null; then
      if python3 -c "import yaml; yaml.safe_load(open('$yaml_file'))" 2>/dev/null; then
        VALID=true
      fi
    elif command -v python &>/dev/null; then
      if python -c "import yaml; yaml.safe_load(open('$yaml_file'))" 2>/dev/null; then
        VALID=true
      fi
    else
      # Sin parser: comprobar que tiene openapi: y paths:
      if grep -q "^openapi:" "$yaml_file" 2>/dev/null; then
        VALID=true
      fi
    fi
    if ! $VALID; then
      error "contracts/api/$(basename $yaml_file): YAML inválido"
      API_INVALID=$((API_INVALID + 1))
    fi
  done < <(find contracts/api/ -name "*.yaml" -o -name "*.yml" -print0 2>/dev/null | tr '\n' '\0')
  if [ "$API_COUNT" -gt 0 ] && [ "$API_INVALID" -eq 0 ]; then
    ok "contracts/api/: ${API_COUNT} contratos OpenAPI con YAML válido"
  fi
fi

# ─── Check 5: Contratos JSON Schema son JSON válidos ─────────────────────────

if [ -d "contracts/schemas/" ]; then
  SCHEMA_COUNT=0
  SCHEMA_INVALID=0
  while IFS= read -r -d '' json_file; do
    SCHEMA_COUNT=$((SCHEMA_COUNT + 1))
    VALID=false
    if command -v python3 &>/dev/null; then
      if python3 -c "import json; json.load(open('$json_file'))" 2>/dev/null; then
        VALID=true
      fi
    elif command -v python &>/dev/null; then
      if python -c "import json; json.load(open('$json_file'))" 2>/dev/null; then
        VALID=true
      fi
    elif command -v node &>/dev/null; then
      if node -e "JSON.parse(require('fs').readFileSync('$json_file','utf8'))" 2>/dev/null; then
        VALID=true
      fi
    else
      # Sin parser: verificar que empieza con {
      if [ "$(head -c1 "$json_file")" = "{" ]; then
        VALID=true
      fi
    fi
    if ! $VALID; then
      error "contracts/schemas/$(basename $json_file): JSON inválido"
      SCHEMA_INVALID=$((SCHEMA_INVALID + 1))
    fi
  done < <(find contracts/schemas/ -name "*.json" -print0 2>/dev/null)
  if [ "$SCHEMA_COUNT" -gt 0 ] && [ "$SCHEMA_INVALID" -eq 0 ]; then
    ok "contracts/schemas/: ${SCHEMA_COUNT} JSON Schemas válidos"
  fi
fi

# ─── Check 6: DDL básico ─────────────────────────────────────────────────────

if [ -d "contracts/ddl/" ]; then
  DDL_COUNT=0
  DDL_ISSUES=0
  while IFS= read -r -d '' sql_file; do
    DDL_COUNT=$((DDL_COUNT + 1))
    # Verificar que cada CREATE TABLE tiene su cierre );
    CREATES=$(grep -c "CREATE TABLE" "$sql_file" 2>/dev/null || true)
    CLOSINGS=$(grep -c "^);" "$sql_file" 2>/dev/null || true)
    if [ "$CREATES" -gt 0 ] && [ "$CLOSINGS" -lt "$CREATES" ]; then
      error "contracts/ddl/$(basename $sql_file): ${CREATES} CREATE TABLE pero solo ${CLOSINGS} cierres ');"
      DDL_ISSUES=$((DDL_ISSUES + 1))
    fi
  done < <(find contracts/ddl/ -name "*.sql" -print0 2>/dev/null)
  if [ "$DDL_COUNT" -gt 0 ] && [ "$DDL_ISSUES" -eq 0 ]; then
    ok "contracts/ddl/: ${DDL_COUNT} archivos DDL con sintaxis básica válida"
  fi
fi

# ─── Salida ───────────────────────────────────────────────────────────────────

if $JSON_OUTPUT; then
  echo "{"
  echo "  \"errors\": $ERRORS,"
  echo "  \"warnings\": $WARNINGS,"
  echo "  \"specs_checked\": $SPEC_COUNT,"
  echo "  \"items\": ["
  FIRST=true
  for item in "${REPORT[@]}"; do
    $FIRST || echo ","
    printf '    "%s"' "$item"
    FIRST=false
  done
  echo ""
  echo "  ]"
  echo "}"
else
  echo "════════════════════════════════════════════"
  echo "  SPEC LINT — $(basename "$PROJECT_ROOT")"
  echo "════════════════════════════════════════════"
  for item in "${REPORT[@]}"; do
    echo "  $item"
  done
  echo "────────────────────────────────────────────"
  echo "  Errores:    $ERRORS"
  echo "  Warnings:   $WARNINGS"
  echo "  Specs:      $SPEC_COUNT"
  echo "════════════════════════════════════════════"
  if [ "$ERRORS" -gt 0 ]; then
    echo "  RESULTADO: FALLO ($ERRORS errores)"
  elif [ "$WARNINGS" -gt 0 ]; then
    echo "  RESULTADO: ADVERTENCIAS ($WARNINGS warnings)"
  else
    echo "  RESULTADO: OK"
  fi
  echo "════════════════════════════════════════════"
fi

# En modo --strict, warnings también causan exit 1
if [ "$ERRORS" -gt 0 ]; then
  exit 1
elif $STRICT && [ "$WARNINGS" -gt 0 ]; then
  exit 1
else
  exit 0
fi
