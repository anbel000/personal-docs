---
name: agents-registry
description: Registro de agentes especializados del framework. Complementa los agentes en .claude/agents/ con agentes de uso menos frecuente.
---

# Agents Registry

Catálogo de agentes especializados disponibles en el framework. Los agentes en este directorio no forman parte del flujo principal (`/build`, `/generate`) — son invocados manualmente o por comandos específicos.

## Estructura

```
.claude/agents-registry/
├── README.md               ← este archivo
├── spec-auditor.md         ← auditoría profunda de un dominio completo
├── migration-planner.md    ← planifica migraciones de contratos con breaking changes
├── onboarding-guide.md     ← genera documentación de onboarding personalizada
├── compliance-checker.md   ← verifica cumplimiento de normas (GDPR, SOC2, HIPAA)
└── contract-tester.md      ← verifica compatibilidad consumer-provider (Pact/Prism)
```

## Diferencia con `.claude/agents/`

| `.claude/agents/` | `.claude/agents-registry/` |
|-------------------|---------------------------|
| Agentes del ciclo principal | Agentes especializados / bajo demanda |
| Invocados por `/build`, `/generate`, `/validate` | Invocados por comandos específicos o manualmente |
| Siempre copiados por `/bootstrap` | Siempre copiados por `/bootstrap` (forman parte del proyecto generado) |

## Cómo usar un agente del registry

Para invocar un agente del registry directamente:

```
# En una sesión de Claude Code, pedirle que actúe como el agente:
"Actúa como el agente spec-auditor y audita el dominio producto"

# Si necesitas añadirlo a un proyecto existente (no generado por /bootstrap),
# usa Read + Write — NUNCA cp (cp graba rutas absolutas en settings.local.json):
# 1. Lee .claude/agents-registry/spec-auditor.md del framework
# 2. Escríbelo en tu-proyecto/.claude/agents/spec-auditor.md con Write
```

## Agentes disponibles

| Agente | Propósito | Invocado por |
|--------|-----------|-------------|
| [spec-auditor](spec-auditor.md) | Auditoría profunda de un dominio | Manual |
| [migration-planner](migration-planner.md) | Planificación de migraciones de contratos | Manual |
| [onboarding-guide](onboarding-guide.md) | Documentación de onboarding personalizada | `/onboard` |
| [compliance-checker](compliance-checker.md) | Verificación de cumplimiento normativo | Manual |
| [contract-tester](contract-tester.md) | Verifica compatibilidad consumer-provider (Pact/Prism) | `/contract test` |
