#!/usr/bin/env python3
"""
auto_label_communities.py — Asigna labels semanticos a las comunidades de graph.json
basandose en los source_file de los nodos de cada comunidad (sin llamadas a LLM).

Uso (desde la raiz del proyecto):
    python .claude/skills/graphify-specs/auto_label_communities.py [graphify-out/graph.json]

Produce:
    graphify-out/.graphify_labels.json   (sobreescribe si existe)
"""

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

# Mapeo carpeta -> label semantico
# El orden importa: primero las rutas mas especificas
FOLDER_LABELS = [
    ("specs/01-negocio",      "Negocio & Vision"),
    ("specs/02-producto",     "Producto & Requisitos"),
    ("specs/03-diseno",       "Diseno & UX"),
    ("specs/04-arquitectura", "Arquitectura del Sistema"),
    ("specs/05-datos",        "Modelo de Datos"),
    ("specs/06-seguridad",    "Seguridad & Privacidad"),
    ("specs/07-infra",        "Infraestructura & Deploy"),
    ("specs/08-calidad",      "Calidad & Tests"),
    ("specs/09-operaciones",  "Operaciones & Runbooks"),
    ("specs/10-legal",        "Legal & Compliance"),
    ("specs/11-hardware",     "Hardware & Dispositivos"),
    ("contracts/api",         "Contratos OpenAPI"),
    ("contracts/ddl",         "Contratos DDL"),
    ("contracts/schemas",     "JSON Schemas"),
    ("docs/adr",              "ADRs — Decisiones"),
    ("ejemplos",              "Ejemplos & Referencia"),
    ("specs",                 "Specs"),
    ("contracts",             "Contratos"),
    ("docs",                  "Documentacion"),
    ("src",                   "Codigo Fuente"),
    ("tests",                 "Tests"),
    (".",                     "Raiz del Proyecto"),
]

def file_label(source_file: str) -> str:
    sf = source_file.replace("\\", "/")
    for prefix, label in FOLDER_LABELS:
        prefix_norm = prefix.replace("\\", "/")
        if sf.startswith(prefix_norm + "/") or sf == prefix_norm:
            return label
    return "Proyecto"

def main():
    graph_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("graphify-out/graph.json")
    out_dir = graph_path.parent

    with open(graph_path, encoding="utf-8") as f:
        g = json.load(f)

    nodes = g.get("nodes", [])

    # Agrupar nodos por community id
    community_votes: dict[int, Counter] = defaultdict(Counter)
    for n in nodes:
        comm = n.get("community")
        sf = n.get("source_file", "")
        if comm is None or not sf:
            continue
        label = file_label(sf)
        community_votes[int(comm)][label] += 1

    if not community_votes:
        print("No se encontraron comunidades en graph.json")
        sys.exit(1)

    # Asignar label por mayoria; desempate: nombre mas especifico (mas largo)
    labels: dict[str, str] = {}
    used: Counter = Counter()

    for comm_id in sorted(community_votes.keys()):
        votes = community_votes[comm_id]
        # Ordenar por votos desc, luego por longitud del label desc (mas especifico primero)
        winner = max(votes.keys(), key=lambda l: (votes[l], len(l)))
        count = used[winner]
        if count > 0:
            # Desambiguar: agregar sufijo B, C, D...
            suffix = chr(ord("B") + count - 1)
            final_label = f"{winner} {suffix}"
        else:
            final_label = winner
        labels[str(comm_id)] = final_label
        used[winner] += 1

    # Escribir
    out_path = out_dir / ".graphify_labels.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(labels, f, ensure_ascii=False, indent=2)

    print(f"Labels generados: {len(labels)} comunidades")
    for cid in sorted(labels.keys(), key=int):
        n_nodes = sum(community_votes[int(cid)].values())
        print(f"  [{cid:>3}] {labels[cid]:40s} ({n_nodes} nodos)")
    print(f"\nEscrito: {out_path}")

if __name__ == "__main__":
    main()
