#!/usr/bin/env python3
"""
collapse_to_files.py — Colapsa graph.json granular a 1 nodo por archivo
y extrae referencias cruzadas reales desde el contenido de los archivos.

Detecta:
  - [[wikilinks]] en Markdown
  - $ref en JSON/YAML (rutas relativas)
  - Menciones de IDs formales: REQ-FUNC-*, SEC-*, HU-*, ADR-*, GAP-*
  - Imports y requires relativos en JS/TS/Python

Uso (desde la raíz del proyecto):
    python .claude/skills/graphify-specs/collapse_to_files.py [graphify-out/graph.json]

Produce:
    graphify-out/graph.file-level.json
    graphify-out/.graphify_labels.file-level.json
    graphify-out/obsidian-files/   (vault Obsidian 1 nota por archivo)
"""

import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────────

FOLDER_LABELS = {
    "specs/01-negocio":     "Negocio & Vision",
    "specs/02-producto":    "Producto & Requisitos",
    "specs/03-diseno":      "Diseno & UX",
    "specs/04-arquitectura":"Arquitectura del Sistema",
    "specs/05-datos":       "Modelo de Datos",
    "specs/06-seguridad":   "Seguridad & Privacidad",
    "specs/07-infra":       "Infraestructura & Deploy",
    "specs/08-calidad":     "Calidad & Tests",
    "specs/09-operaciones": "Operaciones & Runbooks",
    "specs/10-legal":       "Legal & Compliance",
    "specs/11-hardware":    "Hardware & Dispositivos",
    "contracts/api":        "Contratos OpenAPI",
    "contracts/ddl":        "Contratos DDL",
    "contracts/schemas":    "JSON Schemas",
    "docs/adr":             "ADRs — Decisiones",
    "ejemplos":             "Ejemplos & Referencia",
}

# Patrones de IDs formales → en qué archivos viven esos IDs
# Heurística: si un archivo menciona REQ-FUNC-003 y otro archivo LO DEFINE,
# hay un edge entre ambos. Simplificado: si A menciona X y B define X → edge A→B.
FORMAL_ID_RE = re.compile(
    r'\b(REQ-FUNC-\d+|REQ-NFUNC-\d+|SEC-[A-Z]+-\d+|HU-\d+|ADR-\d+|GAP-\d+|STRIDE-[A-Z]+-\d+)\b'
)

def folder_label(source_file: str) -> str:
    sf = source_file.replace("\\", "/")
    for prefix, label in FOLDER_LABELS.items():
        if sf.startswith(prefix):
            return label
    parts = sf.split("/")
    return parts[0] if parts else "Sin categoria"

# ── Extraer referencias cruzadas desde archivos ───────────────────────────────

def extract_cross_refs(project_root: Path, all_files: list[str]) -> dict[str, set[str]]:
    """
    Devuelve {source_file: {target_file, ...}} con referencias cruzadas reales.
    """
    # Índice de stems → source_file (para resolver [[wikilinks]])
    stem_to_file: dict[str, str] = {}
    for sf in all_files:
        stem = Path(sf).stem.lower()
        stem_to_file[stem] = sf
        # También por basename completo
        stem_to_file[Path(sf).name.lower()] = sf

    # Índice de IDs formales definidos en cada archivo
    # Un ID "está definido" en un archivo si aparece como heading o en YAML/frontmatter
    id_defined_in: dict[str, str] = {}  # "REQ-FUNC-003" → "specs/02-producto/requerimientos.md"
    id_heading_re = re.compile(r'^#+\s+(REQ-FUNC-\d+|SEC-[A-Z]+-\d+|HU-\d+|ADR-\d+|GAP-\d+)', re.MULTILINE)
    id_yaml_re = re.compile(r'^(?:id|adr_id|req_id):\s*([A-Z][A-Z0-9-]+)', re.MULTILINE)

    for sf in all_files:
        fpath = project_root / sf
        if not fpath.exists():
            continue
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for m in id_heading_re.finditer(content):
            id_defined_in.setdefault(m.group(1), sf)
        for m in id_yaml_re.finditer(content):
            id_defined_in.setdefault(m.group(1), sf)

    refs: dict[str, set[str]] = defaultdict(set)

    for sf in all_files:
        fpath = project_root / sf
        if not fpath.exists():
            continue
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        ext = fpath.suffix.lower()

        # [[wikilinks]] en Markdown
        if ext in (".md", ".mdx"):
            for m in re.finditer(r'\[\[([^\]|#]+)', content):
                target_raw = m.group(1).strip().lower()
                # Puede ser "nombre-archivo" o "Titulo del archivo"
                target_slug = re.sub(r'[^a-z0-9]+', '-', target_raw).strip('-')
                for stem, tgt_sf in stem_to_file.items():
                    if stem == target_raw or stem == target_slug or target_raw in stem:
                        if tgt_sf != sf:
                            refs[sf].add(tgt_sf)

        # $ref en JSON/YAML → rutas relativas
        if ext in (".json", ".yaml", ".yml"):
            for m in re.finditer(r'\$ref["\']?\s*:\s*["\']([^"\'#]+)', content):
                ref_path = m.group(1).strip()
                if ref_path.startswith(".") or "/" in ref_path:
                    resolved = (fpath.parent / ref_path).resolve()
                    for tgt_sf in all_files:
                        if (project_root / tgt_sf).resolve() == resolved:
                            refs[sf].add(tgt_sf)

        # IDs formales mencionados (pero no definidos aquí)
        for m in FORMAL_ID_RE.finditer(content):
            formal_id = m.group(1)
            defined_in = id_defined_in.get(formal_id)
            if defined_in and defined_in != sf:
                refs[sf].add(defined_in)

        # imports relativos JS/TS/Python (ligero)
        if ext in (".ts", ".tsx", ".js", ".jsx"):
            for m in re.finditer(r'from\s+["\'](\./[^"\']+|\.\.\/[^"\']+)', content):
                rel = m.group(1)
                resolved = (fpath.parent / rel).resolve()
                for tgt_sf in all_files:
                    p = project_root / tgt_sf
                    if p.resolve() == resolved or str(p.resolve()).startswith(str(resolved)):
                        refs[sf].add(tgt_sf)

        if ext == ".py":
            for m in re.finditer(r'from\s+(\.+\w[\w.]*)\s+import', content):
                # Solo imports relativos — no mapear a archivo sin más contexto
                pass

    return refs

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    graph_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("graphify-out/graph.json")
    out_dir = graph_path.parent
    project_root = graph_path.parent.parent  # graphify-out/ está en la raíz del proyecto

    with open(graph_path, encoding="utf-8") as f:
        g = json.load(f)

    nodes = g.get("nodes", [])

    # Detectar archivos únicos
    file_nodes: dict[str, dict] = {}
    for n in nodes:
        sf = n.get("source_file", "")
        if not sf:
            continue
        loc = n.get("source_location", "")
        label_val = n.get("label", "")
        basename = os.path.basename(sf)
        if (loc == "L1" or label_val == basename) and sf not in file_nodes:
            file_nodes[sf] = {
                "id": sf.replace("/", "_").replace("\\", "_").replace(".", "_"),
                "label": basename,
                "source_file": sf,
                "community": folder_label(sf),
            }

    # Fallback si no se detectaron nodos L1
    if not file_nodes:
        for n in nodes:
            sf = n.get("source_file", "")
            if sf and sf not in file_nodes:
                basename = os.path.basename(sf)
                file_nodes[sf] = {
                    "id": sf.replace("/", "_").replace("\\", "_").replace(".", "_"),
                    "label": basename,
                    "source_file": sf,
                    "community": folder_label(sf),
                }

    all_files = list(file_nodes.keys())
    print(f"Archivos detectados: {len(all_files)}")

    # Extraer referencias cruzadas reales desde contenido
    print("Extrayendo referencias cruzadas...")
    cross_refs = extract_cross_refs(project_root, all_files)

    # Construir edges
    edge_set: set[tuple[str, str]] = set()
    for src_sf, targets in cross_refs.items():
        for tgt_sf in targets:
            if src_sf in file_nodes and tgt_sf in file_nodes:
                edge_set.add((src_sf, tgt_sf))

    file_edges = [
        {
            "source": file_nodes[src]["id"],
            "target": file_nodes[tgt]["id"],
            "weight": 1.0,
            "relation": "references",
        }
        for src, tgt in sorted(edge_set)
    ]

    print(f"Edges entre archivos: {len(file_edges)}")

    # Asignar community como int
    labels = sorted(set(n["community"] for n in file_nodes.values()))
    label_to_int = {l: i for i, l in enumerate(labels)}
    for n in file_nodes.values():
        n["community_label"] = n["community"]
        n["community"] = label_to_int[n["community"]]

    # Escribir graph.file-level.json
    file_graph = {
        "nodes": list(file_nodes.values()),
        "edges": file_edges,
        "metadata": {
            "collapsed_from": str(graph_path),
            "file_count": len(file_nodes),
            "edge_count": len(file_edges),
        },
    }
    out_graph = out_dir / "graph.file-level.json"
    with open(out_graph, "w", encoding="utf-8") as f:
        json.dump(file_graph, f, ensure_ascii=False, indent=2)
    print(f"Escrito: {out_graph}")

    # Escribir labels
    labels_out = {str(v): k for k, v in label_to_int.items()}
    out_labels = out_dir / ".graphify_labels.file-level.json"
    with open(out_labels, "w", encoding="utf-8") as f:
        json.dump(labels_out, f, ensure_ascii=False, indent=2)
    print(f"Escrito: {out_labels}")

    # ── Vault Obsidian file-level ─────────────────────────────────────────────
    obsidian_dir = out_dir / "obsidian-files"
    obsidian_dir.mkdir(exist_ok=True)

    # Vecinos salientes
    neighbors_out: dict[str, list[str]] = defaultdict(list)
    neighbors_in: dict[str, list[str]] = defaultdict(list)
    for src_sf, tgt_sf in edge_set:
        neighbors_out[src_sf].append(tgt_sf)
        neighbors_in[tgt_sf].append(src_sf)

    for sf, node in file_nodes.items():
        basename = node["label"]
        stem = Path(basename).stem
        community_label = node["community_label"]
        out_links = sorted(neighbors_out.get(sf, []))
        in_links = sorted(neighbors_in.get(sf, []))

        lines = [
            "---",
            f"source_file: {sf}",
            f"community: {community_label}",
            f"out_degree: {len(out_links)}",
            f"in_degree: {len(in_links)}",
            "---",
            "",
            f"# {stem}",
            "",
            f"**Archivo:** `{sf}`  ",
            f"**Dominio:** {community_label}  ",
            f"**Salientes:** {len(out_links)} · **Entrantes:** {len(in_links)}",
            "",
        ]

        if out_links:
            lines += ["## Referencias a", ""]
            for tgt_sf in out_links:
                lines.append(f"- [[{Path(tgt_sf).stem}]]")
            lines.append("")

        if in_links:
            lines += ["## Referenciado por", ""]
            for src_sf in in_links:
                lines.append(f"- [[{Path(src_sf).stem}]]")
            lines.append("")

        note_path = obsidian_dir / f"{stem}.md"
        with open(note_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    # Nota índice
    by_community: dict[str, list[str]] = defaultdict(list)
    for sf, n in file_nodes.items():
        by_community[n["community_label"]].append(n["label"])

    index_lines = [
        "# Knowledge Graph — File Level",
        "",
        "> 1 nodo por archivo — para navegación humana en Obsidian.",
        "> Para Claude Code (ahorro tokens): usa `graphify query ... --graph graphify-out/graph.json`",
        "",
        f"**{len(file_nodes)} archivos · {len(file_edges)} conexiones**",
        "",
        "## Archivos por dominio",
        "",
    ]
    for comm in sorted(by_community.keys()):
        index_lines.append(f"### {comm}")
        for fname in sorted(by_community[comm]):
            stem = Path(fname).stem
            index_lines.append(f"- [[{stem}]]")
        index_lines.append("")

    with open(obsidian_dir / "index.md", "w", encoding="utf-8") as f:
        f.write("\n".join(index_lines))

    print(f"Vault Obsidian file-level: {obsidian_dir}/ ({len(file_nodes)} notas)")
    print()
    print("Para navegar a ojo: abre graphify-out/obsidian-files/ en Obsidian")
    print("Para ahorrar tokens: graphify query 'X' --graph graphify-out/graph.json --budget 3000")


if __name__ == "__main__":
    main()
