---
name: graphify-specs
description: >
  Construye y mantiene el grafo de conocimiento de un proyecto spec-driven usando extracción
  AST pura — cero llamadas LLM externas, cero costo de tokens. Un único graphify-out/ en la
  raíz del proyecto conecta todos los archivos de specs/, contracts/, docs/adr/ y cualquier
  otra subcarpeta. Communities con nombres semánticos auto-generados desde la estructura de
  carpetas. Soporta rebuild completo e incremental. Trigger: /graphify-specs.
---

# Skill: /graphify-specs

Construye el grafo de conocimiento del proyecto activo con **un solo comando** desde la raíz — sin llamadas a LLMs externos, sin costo de tokens, sin graphify-out en subcarpetas.

Produce dos capas de output:

| Capa | Archivo | Para quién | Cómo se usa |
|------|---------|-----------|-------------|
| **Granular** (844 nodos) | `graph.json` | Claude Code | `graphify query/path/explain` → chunks de 2k tokens, no archivos enteros |
| **File-level** (1 nodo/archivo) | `obsidian-files/` | Humano | Vault Obsidian con Graph View limpio |

## Cuándo usar

- Al terminar `/bootstrap` de un proyecto nuevo (primer grafo)
- Al agregar o modificar specs, contratos o ADRs
- Para consultar diseño sin abrir archivos
- Cuando `GEMINI_API_KEY` no está disponible

## Pre-condiciones

```bash
python -m graphify --version 2>/dev/null || pip install graphify
```

---

## Modos de uso

```
/graphify-specs             # Rebuild completo (granular + file-level)
/graphify-specs --update    # Solo re-extrae archivos modificados (incremental)
/graphify-specs --query "X" # Consulta BFS al grafo sin reconstruir
/graphify-specs --path "A" "B"  # Ruta entre dos nodos
/graphify-specs --explain "X"   # Explica un nodo y sus vecinos
```

---

## Flujo — Rebuild completo

### Paso 1 — Posicionarse en la raíz del proyecto

El proyecto activo es el directorio que contiene `spec-manifest.yaml` o `specs/`. Todos los comandos corren desde ahí.

### Paso 2 — Crear `.graphifyignore` si no existe

```
node_modules/
dist/
build/
.git/
graphify-out/
data/
*.log
*.lock
```

Sintaxis `.gitignore`. Excluye artefactos generados y el propio directorio de output.

### Paso 3 — Extracción AST

```bash
python -m graphify update .
```

`graphify update` es puro AST (tree-sitter) — sin LLM, sin costo. Escanea recursivamente desde `.`, respeta `.graphifyignore`, escribe en `./graphify-out/`:

```
graphify-out/
├── graph.json        ← grafo granular (nodos + edges + comunidades numéricas)
├── graph.html        ← visualización interactiva en browser
├── GRAPH_REPORT.md   ← comunidades, god nodes, gaps detectados
├── manifest.json     ← estado de archivos (habilita incremental)
└── cache/            ← SHA256 por archivo
```

> **Un solo graphify-out/ en la raíz. Nunca en subcarpetas.**

### Paso 4 — Labels semánticos de comunidades (automático)

`graphify update` asigna IDs numéricos a las comunidades. El siguiente script los nombra
automáticamente desde la carpeta `source_file` de cada nodo — sin LLM:

```bash
python .claude/skills/graphify-specs/auto_label_communities.py graphify-out/graph.json
```

Escribe `graphify-out/.graphify_labels.json` con nombres como:
`"Seguridad & Privacidad"`, `"JSON Schemas"`, `"Producto & Requisitos"`, `"ADRs — Decisiones"`, etc.

Si una carpeta tiene muchos nodos y el clustering la divide en varias comunidades, el script
las desambigua automáticamente (`"JSON Schemas B"`, `"JSON Schemas C"`, ...).

**Tabla de labels por carpeta del framework Spec-Driven:**

| Carpeta | Label |
|---------|-------|
| `specs/01-negocio/` | Negocio & Vision |
| `specs/02-producto/` | Producto & Requisitos |
| `specs/03-diseno/` | Diseno & UX |
| `specs/04-arquitectura/` | Arquitectura del Sistema |
| `specs/05-datos/` | Modelo de Datos |
| `specs/06-seguridad/` | Seguridad & Privacidad |
| `specs/07-infra/` | Infraestructura & Deploy |
| `specs/08-calidad/` | Calidad & Tests |
| `specs/09-operaciones/` | Operaciones & Runbooks |
| `specs/10-legal/` | Legal & Compliance |
| `specs/11-hardware/` | Hardware & Dispositivos |
| `contracts/api/` | Contratos OpenAPI |
| `contracts/ddl/` | Contratos DDL |
| `contracts/schemas/` | JSON Schemas |
| `docs/adr/` | ADRs — Decisiones |
| `ejemplos/` | Ejemplos & Referencia |
| raíz / sin match | Proyecto |

### Paso 5 — Export vault Obsidian granular (opcional)

```bash
PYTHONIOENCODING=utf-8 python -m graphify export obsidian
```

Produce `graphify-out/obsidian/` — 1 nota por nodo. Útil para navegar el grafo completo con búsqueda de texto en Obsidian.

### Paso 5b — Arreglar wikilinks rotos (obligatorio si usas Obsidian)

`GRAPH_REPORT.md` (generado por graphify) contiene wikilinks tipo `[[_COMMUNITY_Community 0]]`
que **no existen** como notas. Al hacer clic en Obsidian, se crean archivos `.md` vacíos en
la raíz del vault. Para evitarlo:

```bash
python .claude/skills/graphify-specs/fix_obsidian_links.py graphify-out/graph.json
```

Genera en `graphify-out/obsidian/`:
- `_COMMUNITY_Community {id}.md` (54 notas) — para los wikilinks de `GRAPH_REPORT.md`
- `{label semántico}.md` — para los wikilinks de `wiki/index.md` (e.g. `Seguridad & Privacidad.md`)

Cada nota lista los archivos miembro como `[[wikilinks]]` que sí resuelven.

Adicionalmente configura `graphify-out/.obsidian/app.json` + `obsidian/.obsidian/app.json`:
```json
{ "newFileLocation": "folder", "newFileFolderPath": "_orphans" }
```
Cualquier wikilink que quede sin resolver creará la nota en `_orphans/`, no en la raíz.

**Si ya tienes archivos `.md` vacíos en la raíz:** bórralos manualmente; son los que Obsidian
creó antes de esta corrección.

### Paso 6 — Export file-level para Obsidian humano

```bash
python .claude/skills/graphify-specs/collapse_to_files.py graphify-out/graph.json
```

Colapsa el grafo granular a 1 nodo por archivo. Detecta referencias cruzadas reales desde
el contenido de los archivos: `[[wikilinks]]`, `$ref`, IDs formales (`REQ-FUNC-*`, `SEC-*`,
`HU-*`, `ADR-*`).

Produce:
- `graphify-out/graph.file-level.json` — 1 nodo por archivo, edges = refs cruzadas
- `graphify-out/.graphify_labels.file-level.json` — comunidades por carpeta
- `graphify-out/obsidian-files/` — vault Obsidian con `[[wikilinks]]`, 1 nota por archivo

**Abrir `graphify-out/obsidian-files/` en Obsidian → Graph View limpio (~50 puntos).**

### Paso 7 — Generar `graphify-out/wiki/index.md`

`export wiki` requiere `.graphify_analysis.json` (solo generado con LLM). Como esta skill
es zero-LLM, Claude genera el index manualmente desde `GRAPH_REPORT.md`:

```markdown
# Knowledge Graph — {nombre-proyecto}

> Generado por /graphify-specs (AST puro — sin costo LLM).
> Un único graphify-out/ en la raíz conecta todos los archivos del proyecto recursivamente.
> Visualización interactiva: graphify-out/graph.html
> Vault Obsidian (file-level): graphify-out/obsidian-files/

**{N} nodos · {M} edges · {K} comunidades · {F} archivos**
Costo LLM: **0 tokens**

---

## God Nodes
(abstracciones más conectadas)

| Nodo | Conexiones |
|------|-----------|
| `{nombre}` | {N} |
...

---

## Comunidades
(ordenadas por tamaño)

| # | Comunidad | Nodos |
|---|-----------|-------|
| {id} | [[{Label}]] | {N} |
...

---

## Navegación por dominio

### Negocio & Producto
- [[{archivo}]] — descripción breve

...

---

## Consultas al grafo (sin costo)

```bash
python -m graphify query "concepto" --graph graphify-out/graph.json --budget 3000
python -m graphify path "A" "B" --graph graphify-out/graph.json
python -m graphify explain "X" --graph graphify-out/graph.json
```
```

### Paso 7b — Inyectar badges de madurez en el wiki (MEJORA-036)

Si `spec-manifest.yaml` existe y tiene dominios con `maturity` y `approved_at`, el index.md puede incluir el estado de aprobación de cada spec.

Al generar `wiki/index.md`, leer `spec-manifest.yaml` y añadir en cada sección de dominio:

```markdown
## Producto & Requisitos
> Status: ✅ APPROVED (por @pm-jsmith el 2026-05-29 · expira 2026-08-27) · Maturity: 95/100
> [PENDIENTE]: 1 menor restante

- [[specs/02-producto/requerimientos.md]] — Requerimientos funcionales y no funcionales
- [[specs/02-producto/historias-usuario.md]] — HU-001 a HU-015
...
```

Badges por estado:

| Status | Badge |
|--------|-------|
| `approved` | `✅ APPROVED (por {approved_by} el {approved_at} · expira {expires})` |
| `review` | `🔄 EN REVISIÓN — listo para /review y /approve` |
| `draft` | `📝 DRAFT — {N} [PENDIENTE] sin completar` |
| `deprecated` | `🗑️ DEPRECATED` |

Si `maturity_score` existe en el manifest, añadir `· Maturity: {score}/100`.

Contar `[PENDIENTE]` de las specs del dominio con grep y mostrar el número.

### Paso 8 — Reportar al usuario

```
Grafo actualizado (AST puro — 0 tokens LLM)

  {N} nodos granulares · {M} edges · {K} comunidades nombradas
  {F} archivos · {E} conexiones cruzadas entre archivos
  Un solo graphify-out/ en la raíz del proyecto

Comunidades principales:
  - {Label} ({N} nodos)
  ...

God nodes:
  - {nombre} ({N} conexiones)
  ...

Gaps: {N} nodos aislados (sin referencias cruzadas)

Para Claude Code (ahorra tokens):
  graphify query "X" --graph graphify-out/graph.json --budget 3000

Para humanos (Obsidian):
  Abre graphify-out/obsidian-files/ como vault en Obsidian

Wiki:          graphify-out/wiki/index.md
Visualización: graphify-out/graph.html
```

---

## Flujo — Incremental (`--update`)

```bash
python -m graphify update .
python .claude/skills/graphify-specs/auto_label_communities.py graphify-out/graph.json
python .claude/skills/graphify-specs/collapse_to_files.py graphify-out/graph.json
```

El cache en `graphify-out/cache/` garantiza que solo se re-procesa lo que cambió.

---

## Flujo — Consultas al grafo

Sin reconstruir. Cero costo adicional:

```bash
# BFS desde un concepto — devuelve chunks exactos (~2k tokens)
python -m graphify query "autenticacion webhook" \
  --graph graphify-out/graph.json --budget 3000

# Ruta más corta entre dos nodos
python -m graphify path "requerimientos.md" "omi-webhook.yaml" \
  --graph graphify-out/graph.json

# Explica un nodo y sus vecinos directos
python -m graphify explain "SEC-AUTH-004" \
  --graph graphify-out/graph.json
```

---

## Scripts incluidos en la skill

| Script | Qué hace |
|--------|----------|
| `auto_label_communities.py` | Nombra comunidades desde carpetas — sin LLM |
| `collapse_to_files.py` | Colapsa grafo a 1 nodo/archivo + vault Obsidian |
| `fix_obsidian_links.py` | Genera notas de comunidad para resolver wikilinks rotos en GRAPH_REPORT.md |

Estos tres scripts están en `spec-driven-framework/.claude/skills/graphify-specs/`.
Correr siempre desde la raíz del **proyecto activo**, no del framework.

---

## Limitaciones vs `/graphify` con LLM

| Capacidad | `/graphify-specs` (AST) | `/graphify` (LLM) |
|-----------|------------------------|-------------------|
| Relaciones explícitas (wikilinks, $ref, IDs) | ✅ | ✅ |
| Relaciones semánticas inferidas | ❌ | ✅ |
| Labels de comunidades | ✅ Por carpeta (auto) | ✅ Por contenido |
| Costo tokens externos | ✅ Cero | ❌ Por chunk |
| Velocidad | ✅ Muy rápida | ❌ Rate-limited |
| Funciona offline | ✅ | ❌ |

---

## Reglas de integridad

- **Nunca** crear graphify-out en subcarpetas como paso intermedio.
- **Siempre** correr desde la raíz del proyecto.
- **No modificar** `.graphify.yml` del proyecto si existe — es configuración del producto.
- **`.graphifyignore`** es el único mecanismo de filtrado; usar sintaxis `.gitignore`.
- **`PYTHONIOENCODING=utf-8`** obligatorio en Windows para evitar `UnicodeEncodeError`.

## Qué vault abrir en Obsidian

**No abrir** `graphify-out/` raíz como vault — mezcla `GRAPH_REPORT.md` con `obsidian/` y genera confusión.

| Vault | Para qué | Graph View |
|-------|----------|------------|
| `graphify-out/obsidian/` | Explorar 844 nodos granulares + mapas por comunidad | ~844 puntos |
| `graphify-out/obsidian-files/` | Navegar archivos, 1 nodo por archivo | ~50 puntos |

Correr siempre `fix_obsidian_links.py` después de cada `graphify export obsidian` para que
los wikilinks de `GRAPH_REPORT.md` resuelvan sin crear archivos huérfanos.

## Comandos relacionados

- [[graphify]] — versión completa con LLM (relaciones semánticas)
- [[validate]] — valida consistencia de specs
- [[navigator]] — navega `graphify-out/wiki/index.md` para responder preguntas de diseño
- [[explain]] — usa el wiki generado como prerrequisito para responder preguntas sobre artefactos
- [[predeploy]] — usa graphify-specs como alternativa al rebuild del wiki en su Paso 2
- [[graphify-first]] — regla que instruye a los agentes a consultar el output de esta skill antes de hacer Glob/Grep masivos
