#!/usr/bin/env python3
"""
fix_obsidian_links.py — Genera las notas faltantes en obsidian/ para que los
wikilinks de GRAPH_REPORT.md y wiki/index.md no creen archivos huerfanos.

Causa raiz: graphify genera GRAPH_REPORT.md con [[_COMMUNITY_Community N]] pero
nunca crea esas notas. Al hacer clic en Obsidian, se crean notas vacias en la raiz.

Este script:
  1. Genera graphify-out/obsidian/_COMMUNITY_Community {id}.md  (una por comunidad)
  2. Genera graphify-out/obsidian/{label semantico}.md           (alias por nombre)
  3. Configura graphify-out/.obsidian/app.json para que huerfanos vayan a _orphans/
  4. Crea graphify-out/_orphans/ como red de seguridad

Uso (desde la raiz del proyecto):
    python .claude/skills/graphify-specs/fix_obsidian_links.py [graphify-out/graph.json]
"""

import json
import os
import sys
from collections import defaultdict
from pathlib import Path


def main():
    graph_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("graphify-out/graph.json")
    out_dir = graph_path.parent
    obsidian_dir = out_dir / "obsidian"

    if not obsidian_dir.exists():
        print(f"AVISO: {obsidian_dir} no existe. Corre primero 'graphify export obsidian'.")
        sys.exit(1)

    # Cargar grafo
    with open(graph_path, encoding="utf-8") as f:
        g = json.load(f)

    nodes = g.get("nodes", [])

    # Cargar labels semanticos
    labels_path = out_dir / ".graphify_labels.json"
    labels: dict[str, str] = {}
    if labels_path.exists():
        with open(labels_path, encoding="utf-8") as f:
            labels = json.load(f)

    # Agrupar nodos por community id
    community_nodes: dict[int, list[dict]] = defaultdict(list)
    for n in nodes:
        comm = n.get("community")
        if comm is not None:
            community_nodes[int(comm)].append(n)

    created = 0
    alias_created = 0
    label_notes_created = set()

    for comm_id in sorted(community_nodes.keys()):
        members = community_nodes[comm_id]
        sem_label = labels.get(str(comm_id), f"Community {comm_id}")

        # Listar archivos unicos en esta comunidad
        source_files = sorted(set(
            n.get("source_file", "").replace("\\", "/")
            for n in members
            if n.get("source_file")
        ))

        # Lista de nodos miembro como wikilinks (top 20 por grado)
        node_labels = [n.get("label", n.get("id", "")) for n in members[:30]]

        # --- Nota tipo _COMMUNITY_Community N.md (la que referencia GRAPH_REPORT) ---
        note_name = f"_COMMUNITY_Community {comm_id}.md"
        note_path = obsidian_dir / note_name

        lines = [
            f"# Comunidad {comm_id} — {sem_label}",
            "",
            f"**{len(members)} nodos** en {len(source_files)} archivos",
            "",
        ]
        if source_files:
            lines += ["## Archivos", ""]
            for sf in source_files:
                stem = Path(sf).stem
                lines.append(f"- [[{stem}]]")
            lines.append("")

        if node_labels:
            lines += ["## Nodos principales", ""]
            for lbl in node_labels[:15]:
                lines.append(f"- {lbl}")
            lines.append("")

        with open(note_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        created += 1

        # --- Nota alias por label semantico (para wiki/index.md) ---
        # Solo una nota por label base (sin sufijo B/C/D)
        label_stem = sem_label
        label_note_path = obsidian_dir / f"{label_stem}.md"

        if label_stem not in label_notes_created and not label_note_path.exists():
            alias_lines = [
                f"# {label_stem}",
                "",
                f"> Alias de la comunidad {comm_id}.",
                "",
                f"[[_COMMUNITY_Community {comm_id}]]",
                "",
            ]
            with open(label_note_path, "w", encoding="utf-8") as f:
                f.write("\n".join(alias_lines))
            label_notes_created.add(label_stem)
            alias_created += 1

    print(f"Notas _COMMUNITY_ generadas: {created}")
    print(f"Notas alias por label semantico: {alias_created}")

    # --- Configurar Obsidian: huerfanos a _orphans/ ---
    # Aplica a graphify-out/.obsidian/ (si el vault es graphify-out/)
    # y a graphify-out/obsidian/.obsidian/ (si el vault es obsidian/)
    for vault_dir in [out_dir, obsidian_dir, out_dir / "obsidian-files"]:
        if not vault_dir.exists():
            continue
        obs_config_dir = vault_dir / ".obsidian"
        obs_config_dir.mkdir(exist_ok=True)

        app_json_path = obs_config_dir / "app.json"
        # Leer config existente si hay, para no sobreescribir otras opciones
        app_config = {}
        if app_json_path.exists():
            try:
                with open(app_json_path, encoding="utf-8") as f:
                    app_config = json.load(f)
            except Exception:
                pass

        app_config["newFileLocation"] = "folder"
        app_config["newFileFolderPath"] = "_orphans"

        with open(app_json_path, "w", encoding="utf-8") as f:
            json.dump(app_config, f, ensure_ascii=False, indent=2)

        # Crear carpeta _orphans dentro del vault
        orphans_dir = vault_dir / "_orphans"
        orphans_dir.mkdir(exist_ok=True)
        keep = orphans_dir / ".gitkeep"
        if not keep.exists():
            keep.touch()

    print(f"Configurado .obsidian/app.json en {out_dir.name}/, obsidian/, obsidian-files/")
    print("  -> nuevos archivos huerfanos iran a _orphans/ en lugar de la raiz del vault")
    print()
    print("Listo. Los wikilinks de GRAPH_REPORT.md y wiki/index.md ya resuelven.")
    print("Si tienes archivos .md vacios en la raiz del vault, puedes borrarlos manualmente.")


if __name__ == "__main__":
    main()
