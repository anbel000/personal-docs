---
name: grill-me
description: >
  Interview the user relentlessly about a plan or design until reaching shared
  understanding, resolving each branch of the decision tree one decision at a time.
  For each question, provide YOUR recommended answer so the user can confirm or redirect.
  Ask questions ONE AT A TIME — never in bulk. If a question can be answered by
  exploring the codebase or existing files, explore first instead of asking.
  Use when user says "grill me", "grílame", "stress-test this", "hazme preguntas",
  "entrevístame", or wants to be interrogated about a plan or idea.
---

Interview me relentlessly about every aspect of this plan until we reach a shared understanding. Walk down each branch of the decision tree, resolving dependencies between decisions one-by-one.

For each question:
- Ask it clearly and concisely
- Provide YOUR recommended answer with a brief justification
- Wait for my response before asking the next question

Ask the questions one at a time. Never ask two questions at once.

If a question can be answered by exploring the codebase or existing project files, explore them instead of asking me.

## Criterio de terminación

La entrevista termina cuando **todas las secciones del área bajo análisis tienen una respuesta o un `[PENDIENTE: razón]` documentado**. No termines por agotamiento de preguntas — termina cuando el modelo de decisión está completo.

Al terminar, sintetiza en 3-5 líneas lo que quedó decidido, lo que quedó pendiente y el próximo paso concreto.

## Patrones de manejo de respuestas

### Respuesta vaga o incompleta
Si el usuario responde vagamente ("lo que tú veas", "no sé", "algo así"):
1. Repreguntar una vez con un ejemplo concreto del dominio: *"¿Algo como X o más como Y?"*
2. Si sigue vaga: aceptar la respuesta, documentar como `[PENDIENTE: {descripción de qué falta}]` y continuar

### Respuesta que contradice algo anterior
Si la nueva respuesta contradice una decisión anterior:
1. Señalar explícitamente: *"Esto contradice lo que dijiste antes sobre [X]. ¿Cuál tiene prioridad?"*
2. Esperar resolución antes de continuar — no asumir cuál prevalece

### Respuesta "técnica" en área de negocio
Si el usuario menciona tecnología antes de definir el problema: *"Antes de decidir el stack, ¿cuál es el problema que resuelve?"*

### El usuario pregunta en lugar de responder
Si el usuario hace una pregunta en lugar de responder: responder la pregunta concisamente y luego retomar la entrevista desde donde se pausó.

## Ejemplos de secuencias

**Pregunta de identidad:**
> *¿Cómo se llama el proyecto?*
> Mi recomendación: un nombre corto en español que refleje el dominio (ej: "credify" para una app de créditos).

[usuario: "FinTrack"]

→ Registrar: nombre = "FinTrack". Siguiente pregunta del árbol de dependencias.

---

**Pregunta con respuesta vaga:**
> *¿Cuál es el problema principal que resuelve FinTrack?*
> Mi recomendación: enmarcarlo desde el dolor del usuario (ej: "Los freelancers pierden 3h/semana rastreando gastos en hojas de cálculo").

[usuario: "ayuda a la gente con sus finanzas"]

→ *Eso es un poco amplio. ¿El foco es más en rastreo de gastos, planificación de presupuesto, o análisis de inversiones?*

[usuario: "gastos y presupuesto"]

→ Registrar: problema = rastreo de gastos y planificación de presupuesto para [segmento pendiente].

## Composition with /grill-brief

Este skill es el motor de `/grill-brief`. Cuando se invoca via `/grill-brief`, las preguntas siguen la estructura de `project-brief-template.md` en este orden de dependencias:

```
IDENTIDAD → PROBLEMA → SOLUCIÓN → USUARIOS →
MUST-HAVES → NICE-TO-HAVE → STACK → INTEGRACIONES →
MODELO DATOS → SEGURIDAD → RESTRICCIONES → STAKEHOLDERS →
HARDWARE (confirmar N/A si no aplica) → CONTEXTO
```

Cuando se invoca standalone (`/grill-me`), aplicar al plan o diseño que está en contexto.

## Composition with /grill-spec

Cuando se invoca para completar `[PENDIENTE]` de un dominio específico, las preguntas se generan desde los placeholders encontrados en las specs — no desde el template del brief. El orden de preguntas respeta dependencias: preguntar primero lo que otros gaps necesitan como prerequisito.

## Comandos relacionados

- **Motor de**: [[grill-brief]] · [[grill-spec]] — este skill ejecuta la lógica de entrevista de ambos comandos
- **Contexto de entrada**: specs del dominio (cuando se invoca desde [[grill-spec]]) · brief template (cuando se invoca desde [[grill-brief]])
