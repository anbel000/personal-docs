---
name: security-patterns
description: "Patrones de seguridad obligatorios. Se activa al generar middleware, autenticación, o cualquier endpoint expuesto."
globs: ["src/middleware/**", "src/controllers/**", "src/auth/**", "infra/**"]
---

# Patrones de Seguridad

## Autenticación

- JWT con expiración corta (15 min access, 7d refresh) — salvo que la spec diga otro valor
- Tokens en httpOnly cookies (web) o Authorization header (API)
- Refresh token rotation obligatoria
- Logout invalida el token en servidor (blacklist o revocación)

### Refresh Token Store — In-Memory vs Redis

**Patrón MVP (single-instance)**: guardar JTIs válidos en un `Map<userId, Set<jti>>` en memoria del proceso. Simple, cero dependencias adicionales.

```typescript
// Limitación: se pierde al reiniciar el container; no escala a múltiples instancias
class RefreshTokenStore {
  private readonly store = new Map<string, Set<string>>();
  // ...
}
```

**Cuándo migrar a Redis**:
- El servicio tiene más de 1 réplica (Railway, Kubernetes)
- Los reinicios frecuentes causan logout masivo de usuarios
- El número de usuarios activos supera ~10k sesiones concurrentes

**Migración**: reemplazar `Map` por `ioredis` con `SET userId:jti 1 EX 604800`. La interfaz del store no cambia.

## Autorización

- RBAC como mínimo — roles y permisos definidos en [[requisitos]]
- Middleware de autorización ANTES del controller
- Principio de mínimo privilegio: negar todo por defecto, permitir explícitamente
- Nunca confiar en roles enviados por el cliente

## Input Validation

- Validar TODO input: body, query params, headers, path params
- Sanitizar HTML/SQL antes de procesar
- Límites de tamaño en uploads y payloads
- Rate limiting por IP y por usuario autenticado

## Webhooks sin firma HMAC — Shared Secret en Path

Algunas plataformas IoT y SaaS (ej: Omi.m, ciertos servicios de telemetría) **no firman** sus requests con HMAC. En estos casos, el patrón de autenticación es un **UUID secreto embebido en el path** de la URL.

```
POST /webhooks/{provider}/{secret-uuid}
```

### Trade-offs
- **Ventaja**: simple de implementar, no requiere verificación criptográfica
- **Riesgo**: la URL completa es equivalente a una credencial — debe tratarse como un secreto
- **Rotación**: rotar el secreto desconecta el dispositivo físico; hacerlo solo cuando el secreto esté comprometido

### Implementación
```typescript
// El secret está en el path, validado contra el registro del paciente/dispositivo
@Get('/webhooks/:provider/:secret')
async handleWebhook(@Param('secret') secret: string) {
  const device = await this.deviceService.findBySecret(secret);
  if (!device) throw new UnauthorizedException('INVALID_SECRET');
  // procesar...
}
```

### Cuándo usar
- El proveedor no soporta HMAC ni firma de requests
- El dispositivo IoT no tiene capacidad de computación criptográfica
- Siempre documentar en un ADR por qué no se usa HMAC (decisión arquitectónica no obvia)

> **NUNCA rotar el secreto solo para leer su valor actual.** Usar un endpoint `GET /{resource}/webhook-url` protegido con JWT admin para obtener la URL sin rotar.

## Headers de Seguridad

Los siguientes headers son obligatorios en toda respuesta:

```
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: default-src 'self'
X-XSS-Protection: 0 (depender de CSP, no de este header legacy)
Referrer-Policy: strict-origin-when-cross-origin
```

### CSP connect-src — usar origin, no path completo

**Gotcha crítico**: Chrome no trata `connect-src https://api.example.com/api/v1` como prefijo de ruta. Solo permite requests exactamente a esa URL, bloqueando `/api/v1/auth/login`, `/api/v1/users`, etc.

**Incorrecto** (bloquea subdirectorios en Chrome):
```
Content-Security-Policy: connect-src 'self' https://api.example.com/api/v1
```

**Correcto** (permite todos los paths del origen):
```
Content-Security-Policy: connect-src 'self' https://api.example.com
```

En Next.js con `NEXT_PUBLIC_API_URL`:
```javascript
// next.config.mjs
const apiOrigin = (() => {
  try { return new URL(process.env.NEXT_PUBLIC_API_URL ?? '').origin; }
  catch { return ''; }
})();
`connect-src 'self' ${apiOrigin}`
```

## Secrets

- Cero secrets en código — usar variables de entorno o vault (según infra spec)
- Archivos `.env` en `.gitignore` — siempre
- Proveer `.env.example` con claves sin valores reales

## Logging de Auditoría

- Registrar: quién, qué, cuándo, desde dónde, resultado (éxito/fallo)
- NUNCA loguear passwords, tokens, PII en texto plano
- Nivel mínimo de log para producción: `warn`
- Eventos críticos (login, cambio de permisos, borrado) siempre se loguean

## Dependencias

- No instalar paquetes sin verificar: mantenimiento activo, sin CVEs conocidos
- Usar lockfiles (`package-lock.json`, `poetry.lock`)
- Auditar dependencias en CI: `npm audit`, `pip-audit`, `trivy` (configurar en [[cicd]])

## Reglas que valida

- **Agentes que la aplican**: [[implementer]] · [[devops]] · [[security-reviewer]] (valida cumplimiento) · [[iot-engineer]] · [[data-engineer]]
- **Reglas complementarias**: [[api-patterns]] (headers, validación) · [[coding-conventions]]
- **Specs de referencia**: [[requisitos]] (controles SEC-*) · [[threat-model]] (amenazas STRIDE) · [[cumplimiento]] (regulaciones) · [[privacidad]] (datos personales)
