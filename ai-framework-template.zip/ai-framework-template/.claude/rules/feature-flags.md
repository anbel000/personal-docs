---
name: feature-flags
description: "Política de feature flags como ciudadanos de primera clase: todo flag en producción debe tener spec y kill date."
---

# Regla: Feature Flags como ciudadanos de primera clase

## Política

Todo feature flag activo en código productivo DEBE tener una entrada en specs con los siguientes campos obligatorios:

```yaml
# Ejemplo de entrada en specs/{dominio}/feature-flags.md
- name: new-checkout-flow
  owner: "@pm-jsmith"
  default_value: off        # on | off
  rollout: gradual          # gradual | all | none
  kill_date: "2026-08-01"   # fecha límite para eliminar el flag del código
  linked_req: REQ-FUNC-042  # requerimiento que este flag habilita/protege
  description: "Nuevo flujo de checkout A/B — reemplaza al actual cuando llegue al 100%"
```

## Dónde documentar los flags

- Crear `specs/{dominio}/feature-flags.md` en el dominio que introduce el flag
- Si el flag afecta múltiples dominios, documentarlo en `specs/02-producto/feature-flags.md`
- Actualizar en el **mismo commit** que introduce el flag en el código

## Severidades en `/validate drift`

| Situación | Severidad |
|-----------|-----------|
| Flag en código sin entrada en specs | MEDIA |
| Flag con `kill_date` ya vencida aún en código | ALTA |
| Flag en specs sin ninguna referencia en código | INFO (posible flag obsoleto) |
| Flag sin `kill_date` definida | MEDIA |

## Excepciones

- Flags de configuración de infraestructura (no de producto) — gestionados en `specs/07-infra/`
- Flags temporales de debugging — duración máxima 7 días, luego pasan a ser ALTA

## Integración con /flags

El comando `/flags` automatiza:
- `/flags list` — inventario flags código vs specs
- `/flags validate` — detecta drift (regla en /validate drift Nivel 5)
- `/flags create` — crea entrada de spec desde template
- `/flags deprecate` — marca flag para eliminación + genera ADR
- `/flags clean` — lista flags vencidos que aún están en código

## Reglas que valida

- **Agentes que la aplican**: [[implementer]] · [[product]] · [[analyst]] (detecta flag drift en Nivel 5 de /validate drift)
- **Reglas complementarias**: [[spec-sync]] (el flag y su spec van en el mismo commit) · [[coding-conventions]]
- **Comandos relacionados**: [[flags]] · [[validate]] (Nivel 5 detecta flag drift)
