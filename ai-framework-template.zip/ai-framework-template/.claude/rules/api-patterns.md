---
name: api-patterns
description: "Patrones para implementación de APIs REST y contratos. Se activa al generar controllers, routes o middleware."
globs: ["src/controllers/**", "src/routes/**", "src/middleware/**", "contracts/api/**"]
---

# Patrones de API

## Estructura de endpoint

Cada endpoint sigue este flujo:

```
Request → Middleware(auth, validation) → Controller → Service → Repository → Response
```

- **Controller**: solo orquesta — no contiene lógica de negocio
- **Service**: toda la lógica de negocio vive aquí
- **Repository**: único punto de acceso a datos

## Naming de rutas

- Recursos en plural: `/users`, `/orders`, `/products`
- IDs en la ruta: `/users/:id`, `/orders/:orderId/items/:itemId`
- Acciones no-CRUD como sub-recurso: `POST /users/:id/activate`
- Query params para filtros: `GET /orders?status=pending&page=1`

## Respuestas

Formato estándar para todas las respuestas:

```json
{
  "data": {},
  "meta": { "page": 1, "totalPages": 10, "totalItems": 95 },
  "errors": []
}
```

- Éxito: `data` con el recurso, `errors` vacío
- Error: `data` null, `errors` con array de `{ code, message, field? }`
- HTTP codes: 200 (ok), 201 (created), 204 (no content), 400 (bad request), 401 (unauthorized), 403 (forbidden), 404 (not found), 422 (validation), 500 (server error)

## Validación

- Input validation en el middleware, ANTES del controller
- Usar el JSON Schema de [[example.json|contracts/schemas/]] como fuente de verdad
- Nunca confiar en datos del cliente — validar todo en el servidor

## Versionado

- Versión en la URL: `/api/v1/users`
- Header `X-API-Version` como alternativa para clientes internos

## Contratos OpenAPI

- Todo endpoint público DEBE tener su definición en [[example.yaml|contracts/api/]]
- El contrato OpenAPI es la fuente de verdad — el código se genera/valida contra él
- Si el código diverge del contrato, el código está mal (no el contrato)

## Reglas que valida

- **Agentes que la aplican**: [[architect]] · [[implementer]] · [[security-reviewer]]
- **Reglas complementarias**: [[coding-conventions]] · [[security-patterns]]
- **Specs de referencia**: [[integraciones]] (define las APIs) · [[requisitos]] (seguridad de API)
- **Contratos**: [[example.yaml|OpenAPI example]] · [[example.json|JSON Schema example]]
