---
name: tasks-discipline
description: "Disciplina de uso de TodoWrite: cuándo crear tasks, ciclo correcto (1 in_progress a la vez, completed inmediato), antipatrones y control verbal."
---

# Regla: Disciplina de Tasks en sesiones de codificación

## Cuándo crear tasks

Crea una lista de tasks cuando la tarea tiene **3 o más pasos discretos**:
- Trabajo multi-archivo (ej: DTO + service + controller + test + migración)
- El usuario da una lista numerada o separada por comas
- Estás en plan mode y el plan fue aprobado
- Refactor que toca módulos distintos

## Cuándo NO crear tasks

No crees tasks para:
- Preguntas conversacionales o explicaciones
- Un fix de 1-2 líneas o un rename trivial
- Exploración o research sin acción concreta
- Trabajo que cabe en un solo `Edit` o `Write`

> Si dudas, pregúntate: ¿tiene 3+ pasos que el usuario querría ver progresar? Si no → sin tasks.

## Ciclo correcto de vida

```
pending → in_progress → completed
```

Reglas duras:
- **Solo 1 task `in_progress` a la vez.** Eso es lo que rinde la rueda visual al usuario.
- **Marca `completed` inmediatamente** al terminar cada tarea. No en batch al final del turno.
- **Nunca marques `completed` si**: tests fallan, implementación parcial, errores sin resolver.
- Si estás bloqueado → mantén `in_progress` y crea una task hija que describa el bloqueo.

## Forma correcta del subject

- **Imperativo + verbo + sustantivo**: "Crear DTO de request para /alerts", "Añadir guard PatientOwner al endpoint"
- **Mínimo ~15 caracteres** — si es más corto, probablemente es micro-task que no merece ser task
- **`activeForm` en gerundio** cuando aplique: "Creando DTO de request"

❌ Mal: "fix", "test", "endpoint", "hacer X"
✅ Bien: "Implementar servicio AlertsService con evaluación de umbrales"

## Dependencias (`addBlockedBy` / `addBlocks`)

Úsalas solo cuando hay **orden estricto real**. Si las tareas son independientes, no añadas dependencias — solo genera ruido.

```
TaskCreate("Migrar schema Postgres")     → id=1
TaskCreate("Generar cliente Prisma")     → id=2  addBlockedBy=[1]
TaskCreate("Implementar repositorio")   → id=3  addBlockedBy=[2]
```

## Cómo el developer manipula las tasks a voluntad

La API de tasks la usa Claude, pero TÚ la controlas mediante instrucciones:

| Quieres... | Di... |
|------------|-------|
| Ver el panel | "muéstrame las tasks" / "¿qué queda pendiente?" |
| Agregar una nueva | "añade un task para actualizar el README" |
| Eliminar una | "quita el task de migración, ya lo hice" |
| Reordenar | "reordena: primero el contrato, luego el código" |
| Aprobar paso a paso | "no avances hasta que apruebe cada task" |
| Forzar la lista antes de empezar | "crea tasks para todo lo que vas a tocar antes de codificar" |

## Lo que NO sobrevive a la sesión

Las tasks **mueren al cerrar Claude Code**. No son persistencia entre sesiones.

Para retomar el trabajo mañana → usa un **plan file** o escribe en **MEMORY**. Ver regla `sesiones.md`.

## Reglas que valida

- **Agentes que la aplican**: todos — protocolo global de tasks en sesiones de codificación
- **Reglas complementarias**: [[sesiones]] — protocolo de persistencia entre sesiones y ahorro de tokens
