---
name: sesiones
description: "Protocolo de persistencia entre sesiones y ahorro de tokens. Uso de --continue, --resume, /clear, /compact, graphify-first y subagentes."
---

# Regla: Protocolo de sesiones y ahorro de tokens

## Persistencia entre sesiones

| Mecanismo | Cuándo usar |
|-----------|------------|
| `claude --continue` | Reanudar la última sesión de este directorio |
| `claude --resume` | Elegir entre sesiones recientes (UI selector) |
| Plan files (`~/.claude/plans/*.md`) | Trabajo grande que tomará varias sesiones — activar con Shift+Tab x2 |
| `MEMORY.md` + `memory/` | Datos que sobreviven a `/clear` y al cambio de máquina |

**Antes de apagar:** si hay una tarea no trivial en curso, escribir el siguiente paso concreto en un plan file o pedirle a Claude "recuerda que...". `--continue` recupera el chat pero el contexto compactado pierde detalle.

## Higiene de contexto durante la sesión

| Acción | Cuándo | Efecto |
|--------|--------|--------|
| `/clear` | Cambio de tarea no relacionada | Borra contexto, mantiene CLAUDE.md y MEMORY |
| `/compact <instrucción>` | Misma tarea, contexto muy largo | Resume conservando solo lo relevante |
| (nada) | Tareas cortas y conectadas | Compactado automático cerca del límite |

**Antipatrón:** arrastrar 30+ archivos leídos al cambiar de módulo — mejor `/clear` y releer solo los 2-3 relevantes.

## Lectura barata — graphify-first (ver regla graphify-first.md)

```bash
# En vez de leer 5 archivos (~15k tokens):
python -m graphify query "<intención>" --graph graphify-out/graph.json --budget 3000
# devuelve ~2k tokens relevantes
```

Abrir archivos completos solo si el resultado del grafo es insuficiente.

## Aislar contexto con subagentes

Los subagentes tienen su propia ventana de contexto — lo que leen no entra al contexto principal.

| Tarea | Subagente |
|-------|-----------|
| "¿Dónde está X?" | `Explore` |
| Navegar wiki del proyecto | `navigator` |
| Auditoría de seguridad | `security-reviewer` |
| Diseñar arquitectura | `Plan` |

**Regla:** si responder requiere leer >3 archivos, delegar a Explore con instrucciones específicas y pedir reporte `<200 palabras`.

## Effort por tipo de tarea (API: parámetro `effort`)

Cuando el framework se usa vía API directa (no Claude Code CLI), configurar `effort` por tipo de agente:

| Agente | Modelo | Effort recomendado | Razón |
|--------|--------|--------------------|-------|
| bootstrapper | opus | xhigh | Tarea más crítica: genera el proyecto completo |
| architect | opus | xhigh | Decisiones de diseño de alto impacto e irreversibles |
| implementer | sonnet | high | Lógica de negocio requiere precisión y completitud |
| data-engineer | sonnet | high | Esquemas y migraciones tienen consecuencias persistentes |
| security-reviewer | sonnet | high | Auditoría requiere razonamiento cuidadoso y exhaustivo |
| analyst (niveles 4-5) | sonnet | high | Trazabilidad y drift requieren razonamiento profundo |
| analyst (niveles 1-3) | sonnet | medium | Validaciones estructurales son deterministas |
| qa | haiku | medium | Genera tests desde plantillas conocidas |
| navigator | haiku | low | Solo navega el grafo pre-computado — no razona |

En **Claude Code CLI**, el effort no se configura por agente. Se controla con:
- `/fast` — activa Opus en modo rápido para la sesión actual
- `settings.json` — configuración compartida del equipo

## Reglas que valida

- **Agentes que la aplican**: todos — protocolo global de sesiones y gestión de contexto
- **Reglas complementarias**: [[graphify-first]] (lectura barata vía grafo) · [[tasks-discipline]] (ciclo de tasks dentro de la sesión)
- **Persistencia**: `MEMORY.md` + `memory/` (datos que sobreviven entre sesiones · ver `## Persistencia entre sesiones`)
