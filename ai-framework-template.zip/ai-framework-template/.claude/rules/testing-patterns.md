---
name: testing-patterns
description: "Patrones de testing y estructura de tests. Se activa al generar cualquier archivo de test."
globs: ["tests/**", "**/*.test.ts", "**/*.test.js", "**/*_test.py"]
---

# Patrones de Testing

## Pirámide de tests

```
        /  E2E  \          ← pocos, lentos, flujos críticos
       / Integration \     ← moderados, endpoints + DB
      /    Unit Tests   \  ← muchos, rápidos, lógica pura
```

## Estructura de directorios

```
tests/
├── unit/           # Tests de funciones y clases aisladas
├── integration/    # Tests con DB real y servicios
├── e2e/            # Tests de flujo completo (Cypress/Playwright)
├── acceptance/     # Tests generados desde Gherkin
├── a11y/           # Tests de accesibilidad
├── contracts/      # Tests de contrato de API
├── config/         # Configuración compartida de tests
└── fixtures/       # Datos de prueba reutilizables
```

## Convenciones de naming

- El nombre del test SIEMPRE incluye el ID de la historia o requerimiento:
  - `test_HU001_usuario_puede_registrarse`
  - `describe('REQ-FUNC-003: Procesamiento de pagos')`
- Patrón AAA: Arrange → Act → Assert (una sección clara para cada uno)

## Datos de prueba

- Fixtures en archivos dedicados — nunca hardcoded en el test
- Factories para datos dinámicos (usando faker o similar)
- Cada test limpia su estado — independencia total entre tests

## Trazabilidad

- Cada escenario Gherkin en la spec = exactamente 1 test en `tests/acceptance/`
- La cobertura mínima la define [[estrategia]]
- Los tests de contrato validan contra los archivos en [[example.yaml|contracts/api/]]

## Reglas de generación

- Al generar un test, el agente DEBE citar la spec fuente en un comentario:
  ```typescript
  // Spec: specs/02-producto/historias-usuario.md#HU-001
  // Escenario: Usuario registra cuenta con email válido
  ```
- Si una spec no tiene criterios de aceptación Gherkin, reportar como gap — no inventar tests

## Contract Testing (Consumer-Driven)

Los tests de contrato verifican que los consumidores de una API son compatibles con lo que el proveedor implementa:

- **Cuándo usar Pact**: APIs con consumers externos (microservicios, apps móviles, terceros). Genera archivos `.pact.json` que el proveedor puede verificar de forma independiente.
- **Cuándo usar Prism**: Verificación local rápida contra el contrato OpenAPI sin un proveedor real ejecutándose. Ideal para CI en PR.
- **Ubicación de tests**: `tests/contracts/{recurso}.pact.ts` o `tests/contracts/{recurso}.contract.test.ts`
- **Regla**: todo contrato en `contracts/api/` con consumers externos DEBE tener al menos un Pact consumer test

```typescript
// tests/contracts/users.pact.ts
// Spec: contracts/api/users.yaml — consumer: mobile-app
import { PactV3 } from '@pact-foundation/pact';

const provider = new PactV3({ consumer: 'mobile-app', provider: 'api-service' });

describe('GET /users/:id', () => {
  it('returns user data', () => {
    return provider.addInteraction({...}).executeTest(async (mockServer) => {
      // test against mockServer.url
    });
  });
});
```

El agente [[contract-tester]] automatiza la generación y ejecución de estos tests.

## Performance Testing

Los tests de carga validan los SLOs definidos en `specs/08-calidad/performance.md`:
- **Ubicación**: `tests/performance/{recurso}.k6.js` / `{recurso}_load_test.py`
- **Regla**: cada SLO con endpoint definido DEBE tener al menos 1 test de carga
- **Herramientas**: k6 (TypeScript/Node), locust (Python), artillery (alternativa)

El agente [[performance-engineer]] automatiza la generación desde SLOs.

## Reglas que valida

- **Agentes que la aplican**: [[qa]] · [[implementer]] (tests unitarios) · [[designer]] · [[product]] · [[performance-engineer]] (tests de carga desde SLOs) · [[contract-tester]] (tests de contrato consumer-provider)
- **Reglas complementarias**: [[coding-conventions]] (naming de archivos test)
- **Specs de referencia**: [[estrategia]] (pirámide y cobertura) · [[criterios-aceptacion]] (DoD) · [[historias-usuario]] (escenarios Gherkin) · [[accesibilidad]] (tests a11y)
