---
name: coding-conventions
description: "Convenciones de código por lenguaje. Se activa al generar cualquier archivo de código fuente."
globs: ["src/**/*.ts", "src/**/*.py", "src/**/*.sql"]
---

# Convenciones de Código

## TypeScript / JavaScript

- Usar `strict: true` en tsconfig
- Funciones puras donde sea posible; side effects explícitos
- Naming: `camelCase` para variables/funciones, `PascalCase` para tipos/clases/interfaces
- Imports absolutos con alias `@/` apuntando a `src/`
- No usar `any` — usar `unknown` + type guards si el tipo es dinámico
- Archivos de barrel (`index.ts`) solo en la raíz de cada módulo
- Preferir `interface` sobre `type` para objetos; `type` para uniones y utilidades

## Python

- Typing obligatorio en firmas de funciones (`def fn(x: int) -> str:`)
- Naming: `snake_case` para variables/funciones, `PascalCase` para clases
- Docstrings en formato Google para toda función pública
- Usar `dataclass` o `pydantic.BaseModel` para DTOs — nunca dicts sin tipado
- Imports agrupados: stdlib → third-party → local (separados por línea en blanco)

## SQL

- Keywords en MAYÚSCULAS (`SELECT`, `FROM`, `WHERE`)
- Nombres de tablas en `snake_case` singular (`user`, `order_item`)
- Nombres de columnas en `snake_case`
- Siempre incluir `NOT NULL` explícitamente o documentar por qué es nullable
- Prefijos para constraints: `pk_`, `fk_`, `uq_`, `idx_`, `chk_`

## Estructura de archivos

- 1 componente/clase/módulo por archivo
- Nombre del archivo = nombre de la exportación principal en kebab-case
  - `user-service.ts` exporta `UserService`
  - `order_repository.py` exporta `OrderRepository`
- Tests colocados junto al código: `user-service.test.ts`, `order_repository_test.py` (ver [[testing-patterns]])

## Reglas que valida

- **Agentes que la aplican**: [[architect]] · [[implementer]] · [[data-engineer]] · [[qa]] · [[designer]] · [[iot-engineer]] · [[devops]]
- **Reglas complementarias**: [[api-patterns]] · [[testing-patterns]] · [[security-patterns]] · [[feature-flags]]
- **Specs de referencia**: [[stack]] (define lenguajes y frameworks) · [[arquitectura]] (define estructura de componentes)
