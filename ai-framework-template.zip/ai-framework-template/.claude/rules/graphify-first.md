---
name: graphify-first
description: "Los agentes consultan el conectoma ANTES de Read/Glob/Grep masivos para ahorrar tokens"
---

# Regla: Graphify First — consultar el conectoma antes de leer archivos

## Política

Antes de hacer `Read`, `Glob` o `Grep` extensivos para entender el contexto de
una tarea, **consultar el conectoma de graphify**:

```bash
# Si graphify-out/graph.json no existe → ejecutar /graphify primero

python -m graphify query "<intención>" --graph graphify-out/graph.json --budget 3000
python -m graphify path "<archivo-origen>" "<archivo-destino>" --graph graphify-out/graph.json
python -m graphify explain "<símbolo>" --graph graphify-out/graph.json
```

El conectoma devuelve ~2k tokens relevantes en lugar de leer ~15k.
Solo abrir archivos completos si el resultado del query es insuficiente.

## Aplica a

`implementer` · `architect` · `data-engineer` · `product` · `designer` · `iot-engineer` · `qa` · `devops` · `security-reviewer` · `analyst` · `performance-engineer` · `reviewer`

## Excepciones

- **`navigator`**: aplica graphify por diseño.
- **`bootstrapper`**: trabaja antes de que exista el grafo.
- Tareas de una sola línea con archivo objetivo ya conocido.

## Output útil de graphify-out/

```
graphify-out/wiki/index.md          ← nodo raíz, leer primero
graphify-out/wiki/_COMMUNITY_*.md   ← nodos por comunidad temática
graphify-out/GRAPH_REPORT.md        ← resumen del grafo
```

## Por qué

El grafo pre-computado conecta specs ↔ contracts ↔ código ↔ agentes.
Consultarlo primero evita leer 10-20 archivos cuando el contexto cabe en 2k tokens.
En sesiones largas el ahorro es de 60-80% de tokens.

## Reglas que valida

- **Agentes que la aplican**: [[analyst]] · [[architect]] · [[implementer]] · [[data-engineer]] · [[product]] · [[designer]] · [[iot-engineer]] · [[qa]] · [[devops]] · [[security-reviewer]] · [[performance-engineer]] · [[reviewer]]
- **Reglas complementarias**: [[sesiones]] (higiene de contexto y ahorro de tokens)
- **Herramienta**: `graphify-out/graph.json` — generado por [[graphify]] o [[graphify-specs]]
