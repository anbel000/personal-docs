---
name: spec-sync
description: "Política de sincronización code↔spec↔wiki. Todo cambio de código destinado a deploy actualiza las specs y contratos referenciados en el mismo commit."
---

# Regla: Sincronización code ↔ spec ↔ wiki

## Política

Todo cambio de código destinado a deploy DEBE incluir, en el mismo PR/commit:
1. Actualización de las specs que describen el comportamiento modificado
2. Mención explícita en el mensaje de commit de qué specs cambiaron
3. (En deploy) Refresh del grafo de specs vía `/graphify-specs --update`

## Ámbito

Aplica a cambios en:
- `packages/**/src/` — lógica de negocio, endpoints, servicios (todo lenguaje)
- `src/` — monolitos
- `contracts/api/`, `contracts/schemas/`, `contracts/ddl/` — contratos formales
- Infraestructura productiva: `infra/`, `.github/workflows/`, `Dockerfile`, `docker-compose*.yml`

## Excepciones (NO requieren update de spec)

- Refactor puro sin cambio de comportamiento observable (renombrado de variable, extracción de función con misma firma)
- Fix de tipos / lint sin cambio semántico
- Tests añadidos sin cambiar el código bajo prueba
- Comentarios / docs internos del repo que no sean specs
- Cambios en `dev-dependencies` o herramientas de build sin impacto en comportamiento productivo

## Pasos obligatorios al hacer un cambio de código

1. Leer el header del archivo modificado: `// Generated from: ...` / `// Spec: ...` / `// Contract: ...`
2. Abrir cada spec referenciada y verificar que sigue describiendo el comportamiento real
3. Si hay drift → actualizar la spec en el mismo cambio
4. Si el cambio introduce comportamiento no descrito en ninguna spec → preguntar al humano antes de inventar la spec
5. Antes de deploy: `/predeploy` debe completar sin errores

## Corrección de drift — corregir en lote, no de a poco

Cuando se detecta drift código↔spec (por `/validate`, `/analyze` o inspección manual):

1. Correr `/validate all` primero para inventariar **todos** los gaps
2. Correr `/analyze` para detectar gaps adicionales que validate no cubra
3. Corregir **todo** en un solo agente y un solo commit
4. No corregir parcialmente y dejar items sueltos — genera más commits de "fix olvidado" y dificulta la trazabilidad

**Por qué:** Corregir en lotes produce commits limpios con contexto completo y evita que el proyecto quede en estado de drift parcial entre commits.

## Cómo identificar specs afectadas

Buscar estas referencias en los archivos modificados:

```bash
# En TypeScript/JavaScript
grep -r "// Generated from:" packages/src/ contracts/
grep -r "// Spec:" packages/src/ contracts/
grep -r "// Contract:" packages/src/ contracts/

# En Python
grep -r "# Generated from:" src/ contracts/
grep -r "# Spec:" src/ contracts/
```

Si el archivo no tiene headers de trazabilidad, buscar por nombre de clase/función en las specs:

```bash
python -m graphify query "{nombre_clase_o_funcionalidad}" \
  --graph graphify-out/graph.json --budget 2000
```

## Colaboración en ramas (multi-desarrollador)

Cuando más de un desarrollador trabaja simultáneamente en specs de distintos dominios, pueden surgir conflictos en merge. Esta sección define las convenciones para minimizarlos.

### Estrategia de ramas para specs

```
main
├── feat/negocio-vision          ← 1 dominio por rama cuando sea posible
├── feat/producto-hu-001-007     ← puede incluir rango de historias
└── feat/datos-modelo-v2         ← cambios de contrato en rama propia
```

**Regla de oro para specs**: una rama por dominio activo. Si dos personas editan `specs/02-producto/` simultáneamente, los conflictos de merge en Markdown son difíciles de resolver correctamente.

### Qué hacer cuando hay conflictos de merge en specs

1. **NO usar** `git checkout --ours` o `git checkout --theirs` — perderás cambios de specs
2. Resolver manualmente: ambos autores leen el conflicto y acuerdan la versión final
3. Tras resolver, ejecutar `/validate [dominio]` para confirmar que no hay inconsistencias
4. Si el conflicto involucra contratos formales (`contracts/`), ejecutar `/contract validate all`

### Contrato de colaboración

Antes de empezar a editar un dominio:
1. Verificar en el tablero/chat del equipo que nadie más está en ese dominio
2. Crear una rama específica: `git checkout -b feat/{dominio}-{descripcion-corta}`
3. Al terminar, hacer PR con `/validate [dominio]` pasando como evidencia
4. El aprobador ejecuta `/review [dominio]` antes de mergear

### Detección de conflictos latentes con `owners`

Los campos `owners` en `spec-manifest.yaml` ayudan a identificar quién notificar cuando un dominio cambia:

```yaml
producto:
  owners: ["@pm-jsmith", "pm@empresa.com"]
```

Cuando el hook `post-commit-changelog.sh` detecta cambios en un dominio con owners, puede (configuración futura) enviar notificación. Por ahora, el campo es informacional para el equipo.

## Wiki de specs

`graphify-out/` se regenera **bajo demanda** con `/graphify-specs`. En deploy, `/predeploy` lo refresca automáticamente como paso final. NO regenerar manualmente en cada commit — el grafo se desactualiza solo de forma incremental y el rebuild es rápido en deploy.

## En el mensaje de commit

Incluir qué specs se actualizaron:

```
feat(wiki): lazy init, backlinks en entity files, auto-update index.md

Specs: specs/02-producto/requerimientos.md (REQ-FUNC-002)
       specs/05-datos/flujos.md (Flujo 1)
       contracts/api/omi-webhook.yaml (discarded behavior)
```

## Integración en CI/CD

`/predeploy --strict` falla con exit code != 0 si detecta drift. Añadir al pipeline antes del deploy real:

```yaml
- name: Spec sync check
  run: claude --headless -p "/predeploy --strict"
```

## Comandos relacionados

- [[validate]] — detecta drift (Nivel 5)
- [[predeploy]] — orquesta el chequeo + refresh wiki (obligatorio en deploy)
- [[build]] — pipeline completo que invoca predeploy
- [[graphify-specs]] — regenera grafo de specs (sin LLM, sin costo)
- [[generate]] — el código generado por /generate debe mantenerse sincronizado con las specs; esta regla define la política de sync
- [[contract]] — gestiona archivos en contracts/ que están en el Ámbito de esta regla; todo cambio de contrato orientado a deploy debe acompañarse de update de spec

## Reglas que valida

- **Agentes que la aplican**: [[implementer]] · [[data-engineer]] · [[architect]] · [[product]] · [[designer]] · [[iot-engineer]] · [[qa]] · [[devops]]
- **Reglas complementarias**: [[coding-conventions]] · [[api-patterns]]
- **Specs de referencia**: [[spec-manifest]] (mapa de specs del proyecto)
