---
name: spec-changelog
description: "Consulta el historial de cambios de specs filtrado por dominio, fecha o tipo. Uso: /spec-changelog [dominio]"
---

# Comando: /spec-changelog

**Argumentos**: `$ARGUMENTS`

Interfaz de consulta sobre `memory/spec-changelog.md`. Permite filtrar el historial de cambios por dominio, tipo de cambio o rango de fechas, sin tener que abrir el archivo manualmente.

## Uso

```
/spec-changelog                         # Últimos 10 cambios en todo el proyecto
/spec-changelog producto                # Solo cambios en el dominio producto
/spec-changelog seguridad               # Solo cambios en el dominio seguridad
/spec-changelog --since 2026-05-01      # Cambios desde una fecha (ISO 8601)
/spec-changelog --until 2026-05-31      # Cambios hasta una fecha
/spec-changelog --type approved         # Solo aprobaciones de dominios
/spec-changelog --type modified         # Solo modificaciones
/spec-changelog --type created          # Solo specs nuevas
/spec-changelog --author @pm-jsmith     # Cambios de un autor específico
/spec-changelog --last 20               # Últimos N cambios
```

## Prerequisito

`memory/spec-changelog.md` debe existir y estar poblado por el hook `post-commit-changelog.sh`. Si está vacío, ejecutar:

```bash
bash .claude/hooks/setup-git-hooks.sh    # Instala el hook post-commit
# Luego hacer un commit en specs/ para generar la primera entrada
```

## Output

```
📋 Spec Changelog — producto (últimos 5 cambios)
─────────────────────────────────────────────────────────────────────────
Fecha       | Commit  | Tipo      | Autor          | Descripción
─────────────────────────────────────────────────────────────────────────
2026-05-29  | a3f2b1c | approved  | PM @jsmith     | Aprobado tras resolución HU-007
2026-05-27  | d8e1a2f | modified  | Dev @ana       | Agrega criterios Gherkin a HU-012
2026-05-25  | c5b3e4d | created   | PM @jsmith     | Agrega historias HU-010 a HU-015
2026-05-20  | a1c2d3e | modified  | Dev @carlos    | Refina requerimientos REQ-FUNC-007
2026-05-15  | b2d4f5e | created   | Dev @ana       | Spec inicial del dominio producto
─────────────────────────────────────────────────────────────────────────
Total: 5 cambios mostrados (28 en historial completo)

Para ver más: /spec-changelog producto --last 20
```

## Tipos de cambio

| Tipo | Descripción |
|------|-------------|
| `created` | Spec nueva creada |
| `modified` | Spec existente modificada |
| `approved` | Spec marcada como `status: approved` |
| `deprecated` | Spec marcada como `status: deprecated` |
| `deleted` | Spec eliminada del proyecto |

## Estadísticas

Con `--stats`, muestra métricas agregadas:

```
/spec-changelog --stats
─────────────────────────────────────────────────
Dominio más activo:    producto (47 cambios)
Autor más activo:      @ana (23 commits con cambios en specs)
Última aprobación:     seguridad (2026-05-20, por @sec-lead)
Tiempo hasta aprobar:  producto → 18 días desde primera edición
─────────────────────────────────────────────────
```

<examples>
  <example>
    <input>/spec-changelog producto</input>
    <output>
📋 Spec Changelog — producto (últimos 5 cambios)
─────────────────────────────────────────────────────────────────────────
Fecha       | Commit  | Tipo      | Autor          | Descripción
─────────────────────────────────────────────────────────────────────────
2026-05-29  | a3f2b1c | approved  | PM @jsmith     | Aprobado tras resolución HU-007
2026-05-27  | d8e1a2f | modified  | Dev @ana       | Agrega criterios Gherkin a HU-012
2026-05-25  | c5b3e4d | created   | PM @jsmith     | Agrega historias HU-010 a HU-015
2026-05-20  | a1c2d3e | modified  | Dev @carlos    | Refina requerimientos REQ-FUNC-007
2026-05-15  | b2d4f5e | created   | Dev @ana       | Spec inicial del dominio producto
─────────────────────────────────────────────────────────────────────────
Total: 5 cambios mostrados (28 en historial completo)

Para ver más: /spec-changelog producto --last 20
    </output>
  </example>
  <example>
    <input>/spec-changelog --type approved --since 2026-05-01</input>
    <output>
📋 Spec Changelog — aprobaciones desde 2026-05-01
─────────────────────────────────────────────────────────────────────────
Fecha       | Commit  | Dominio       | Autor          | Notas
─────────────────────────────────────────────────────────────────────────
2026-05-29  | a3f2b1c | producto      | PM @jsmith     | 0 blockers en review
2026-05-27  | f2a1b3c | infraestructura| @devops-maria | Tras ajuste de SLOs
2026-05-25  | e4c3d2b | calidad       | PM @jsmith     | Cobertura ≥ 80% confirmada
2026-05-20  | d3b2a1c | operaciones   | PM @jsmith     | Runbooks completados
2026-05-10  | c2a3b4d | arquitectura  | @carlos        | ADR-003 incluido
2026-05-05  | b1c2d3e | negocio       | PM @jsmith     | Vision alineada con stakeholders
─────────────────────────────────────────────────────────────────────────
Total: 6 aprobaciones en el período

Dominios aún no aprobados: diseno, seguridad, legal, hardware
    </output>
  </example>
</examples>

## Comandos relacionados

- [[validate|/validate freshness]] — verifica si las specs aprobadas siguen vigentes
- [[spec-health]] — tendencia histórica de la salud del proyecto (usa este changelog)
- [[approve]] — crea una nueva entrada de tipo `approved` en el changelog
- [[sync-issues]] — sincronizar con Linear/GitHub los cambios de requerimientos detectados en el changelog
