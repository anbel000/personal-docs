---
name: grill-brief
description: "Construye el brief de un proyecto nuevo mediante entrevista guiada (metodología grill-me). Una pregunta a la vez, con recomendación incluida. Al terminar, escribe el brief a ../{nombre-proyecto}.md. Uso: /grill-brief"
---

# Comando: /grill-brief

Construye el `project-brief-template.md` de un proyecto nuevo mediante entrevista incesante. En vez de pedirte que llenes un formulario, te hago preguntas una a la vez — cada una con mi recomendación — y al final escribo el brief completo.

## Uso

```
/grill-brief
```

No necesita argumentos. La entrevista comienza de inmediato.

## Metodología (grill-me)

- **Una pregunta a la vez** — nunca en bulk
- **Cada pregunta incluye mi recomendación** con justificación breve
- **Las respuestas condicionan las siguientes preguntas** — si dices "es B2B SaaS", las preguntas de stack e infraestructura se adaptan
- **Si una respuesta es ambigua**, repregunto antes de continuar
- **Si el usuario no sabe algo**, marco `[PENDIENTE: descripción de qué falta]` en el brief y continúo

## Orden de preguntas (dependencias respetadas)

El orden no es el del template — es el que resuelve dependencias:

```
1. IDENTIDAD     → nombre, versión, idioma
2. PROBLEMA      → qué problema, para quién, por qué importa ahora
3. SOLUCIÓN      → qué hace el producto (alto nivel)
4. USUARIOS      → segmentos, necesidades, tamaños
5. MUST-HAVES    → funcionalidades obligatorias para v1
6. NICE-TO-HAVE  → funcionalidades deseadas para v2+
7. STACK         → tecnologías (o "libre" → yo recomiendo)
8. INTEGRACIONES → sistemas externos que debe conectar
9. MODELO DATOS  → entidades principales y relaciones clave
10. SEGURIDAD    → controles aplicables (auth, RBAC, compliance)
11. RESTRICCIONES → equipo, presupuesto, plazo
12. STAKEHOLDERS → quién decide qué
13. HARDWARE     → ¿aplica? si no, confirmar N/A y saltar
14. CONTEXTO     → cualquier cosa que no encajó arriba
```

## Reglas de la entrevista

- Si una sección no aplica (ej: hardware en SaaS puro), preguntar explícitamente: *"¿Confirmamos que hardware es N/A para este proyecto?"* antes de saltarla
- Si el usuario da una respuesta muy vaga en una sección crítica (problema, must-haves, modelo de datos), repregunto con: *"¿Puedes ser más específico? Por ejemplo: [ejemplo concreto del dominio]"*
- No inventar nombres de entidades, funcionalidades, ni integraciones que el usuario no mencionó
- Si el usuario dice "no sé" en algo técnico (stack, arquitectura), dar una recomendación concreta con razón y pedir confirmación

## Output al finalizar

Al terminar todas las secciones:

1. **Escribir** el brief poblado a `../{nombre-proyecto}.md` usando el formato exacto de `project-brief-template.md`

2. **Generar plan de dominios**: analizar el brief para determinar qué dominios requieren más atención, cuáles pueden estar completos desde el primer día y cuáles son opcionales:

```
📐 PLAN DE DOMINIOS SUGERIDO — {nombre-proyecto}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Dominio          | Prioridad | Razón
─────────────────|-----------|──────────────────────────────────────────
negocio          | ALTA      | Definido completamente en el brief
producto         | ALTA      | 7 must-haves identificados
arquitectura     | ALTA      | Stack elegido: Next.js + FastAPI + PostgreSQL
datos            | ALTA      | 5 entidades con relaciones claras
seguridad        | MEDIA     | Auth OAuth mencionado, requiere diseño
infra            | MEDIA     | Railway mencionado, config pendiente
calidad          | MEDIA     | Criterios de aceptación a derivar de HU
operaciones      | BAJA      | Definir tras MVP
diseno           | BAJA      | Pendiente de wireframes del usuario
legal            | OPCIONAL  | GDPR: 1 campo PII identificado
hardware         | N/A       | Confirmado N/A por el usuario

Orden recomendado de edición de specs:
  1. negocio → completo desde el brief (0 [PENDIENTE] esperados)
  2. producto → must-haves claros, nice-to-haves pendientes
  3. arquitectura + datos → juntos (bloquean generación)
  4. seguridad → JWT + RBAC básico
  5. infra → tras decidir entorno de deploy
  6. calidad + diseno → tras tener los flujos
  7. operaciones + legal → pueden esperar

Perfiles de /bootstrap disponibles para este proyecto:
  Recomendado: /bootstrap ../{nombre-proyecto}.md --profile saas
  Alternativa: /bootstrap ../{nombre-proyecto}.md --profile minimal (MVP rápido)
```

3. **Reportar** un resumen de la entrevista:

```
✅ Brief completado: ../{nombre-proyecto}.md

📋 Resumen:
   - Funcionalidades must-have: N
   - Entidades de datos: N
   - Integraciones externas: N
   - Controles de seguridad marcados: [lista]
   - Secciones N/A: [lista]

⚠️  Pendientes (campos sin respuesta):
   - [lista de [PENDIENTE: ...] marcados]

🚀 Siguiente paso:
   /bootstrap ../{nombre-proyecto}.md [--profile <recomendado>]
```

4. **No ejecutar** `/bootstrap` automáticamente — el usuario debe revisarlo primero

## Ejemplo de las primeras preguntas

> **[1/14 · Identidad]**
> ¿Cómo se llama el proyecto?
>
> Mi recomendación: usa un nombre corto en kebab-case, descriptivo del dominio principal. Ejemplos: `gestor-creditos`, `marketplace-servicios`, `plataforma-educativa`. Si tienes nombre comercial con espacios, conviértelo: "Excel Credit" → `excel-credit`.

---

> **[2/14 · Problema]**
> Describe en 2-3 oraciones el problema concreto que resuelves: quién lo sufre, por qué existe hoy, y qué les cuesta no tenerlo resuelto.
>
> Mi recomendación: estructura como: *"Hoy, [audiencia] sufre [problema] porque [causa raíz]. Esto les cuesta [impacto concreto: tiempo / dinero / riesgo]."*

## Ejemplo de sesión

<examples>
  <example>
    <input>/grill-brief</input>
    <output>
¡Empezamos! Te haré preguntas una a la vez para construir el brief completo.

**[1/14 · Identidad]**
¿Cómo se llama el proyecto?

Mi recomendación: un nombre corto en kebab-case que refleje el dominio. Ej: `gestor-creditos`, `fintrack-app`, `plataforma-educativa`.

[usuario: "FinTrack"]

---

**[2/14 · Problema]**
¿Cuál es el problema concreto que resuelve FinTrack?

Mi recomendación: "Los freelancers gastan 2-3h/semana rastreando gastos en hojas de cálculo que se desactualizan. Esto les impide ver su situación fiscal real en tiempo real."

¿El foco es rastreo de gastos, planificación de presupuesto, o ambos?

[usuario: "rastreo de gastos y presupuesto mensual para freelancers"]

---

**[3/14 · Solución]** ...

[... entrevista continúa por 14 secciones ...]

---

✅ Brief completado: ../fintrack/fintrack.md

📋 Resumen:
   - Funcionalidades must-have: 6 (registro de gastos, categorías, presupuesto mensual, reportes, exportar CSV, multi-moneda)
   - Entidades de datos: 4 (Usuario, Gasto, Categoría, PresupuestoMensual)
   - Integraciones externas: 1 (Google OAuth)
   - Secciones N/A: hardware

⚠️  Pendientes (2):
   - Región de hosting no definida → [PENDIENTE]
   - SLOs de respuesta no definidos → [PENDIENTE]

🚀 Siguiente paso:
   /bootstrap ../fintrack/fintrack.md --profile saas
    </output>
  </example>
</examples>

## Agente que ejecuta

- Ninguno — el propio Claude conduce la entrevista y escribe el brief directamente

## Comandos relacionados

- **Skill subyacente**: [[grill-me]] — metodología de entrevista incesante con recomendaciones por pregunta
- [[bootstrap]] — siguiente paso después de tener el brief listo
- [[grill-spec]] — completar [PENDIENTE] del proyecto generado por bootstrap, dominio a dominio
- [[validate]] — valida el proyecto generado por bootstrap
