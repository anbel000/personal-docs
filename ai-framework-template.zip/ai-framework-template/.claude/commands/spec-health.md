---
name: spec-health
description: "Dashboard de tendencia histórica de salud del proyecto basado en spec-changelog y agent-log. Uso: /spec-health"
---

# Comando: /spec-health

**Argumentos**: `$ARGUMENTS`

Muestra la evolución de la salud del proyecto a lo largo del tiempo. A diferencia de `/status` (estado actual) y `/analyze` (diagnóstico puntual), `/spec-health` muestra **tendencias**: si el proyecto está mejorando, estancado o retrocediendo en completitud de specs.

## Uso

```
/spec-health              # Tendencia de las últimas 4 semanas
/spec-health --weeks 8    # Últimas 8 semanas
/spec-health --all        # Todo el historial disponible
/spec-health --sparkline  # Formato compacto con sparklines ASCII (ideal para resúmenes)
```

## Fuentes de datos

Lee y cruza información de:
1. `memory/spec-changelog.md` — aprobaciones, creaciones, modificaciones de specs
2. `memory/agent-log.md` — sesiones de trabajo y comandos ejecutados
3. `spec-manifest.yaml` — estado actual de dominios (maturity, owners)
4. `docs/build-state.json` (si existe) — últimos resultados de `/build`

## Output

```
📈 SPEC HEALTH TREND — {nombre-proyecto}
══════════════════════════════════════════════════════════════════
Período: 2026-05-01 → 2026-05-29 (4 semanas)

Semana      | Aprobados | [PENDIENTE] | Build  | Velocidad
──────────────────────────────────────────────────────────────────
May 01-07   | 2/11      | 187         | ❌     | —
May 08-14   | 4/11      | 134         | ⚠️     | +2 dom/sem
May 15-21   | 5/11      | 89          | ⚠️     | +1 dom/sem
May 22-29   | 8/11      | 23          | ✅     | +3 dom/sem

TENDENCIA: ⬆️ MEJORANDO
  Dominios aprobados: 2 → 8 (+6 en 4 semanas)
  [PENDIENTE] totales: 187 → 23 (-164, -87%)
  Build status: ❌ → ✅

PROYECCIÓN (al ritmo actual):
  Todos los dominios aprobados: ~1 semana
  [PENDIENTE] < 5: ~3 días

══════════════════════════════════════════════════════════════════

DOMINIOS POR ESTADO ACTUAL:
  ✅ Aprobados (8):   negocio, producto, arquitectura, datos, seguridad,
                      infraestructura, calidad, operaciones
  🔄 En revisión (2): diseno, legal
  📝 Draft (1):       hardware

HITOS recientes:
  2026-05-29  ✅ seguridad aprobado
  2026-05-27  ✅ infraestructura aprobado
  2026-05-25  ✅ calidad aprobado
  2026-05-20  ✅ operaciones aprobado

══════════════════════════════════════════════════════════════════
```

## Modo `--sparkline`

Variante compacta que representa 4 semanas de datos en una sola línea de caracteres ASCII. Útil para incluir en reportes cortos o en el output de `/status`.

```
📈 SPEC HEALTH TREND — crm-startup
══════════════════════════════════════════════════════════════════
Dominios aprobados (4 semanas):  ▂▄▅█  2 → 8  ⬆️ +300%
[PENDIENTE] totales (4 semanas): █▆▄▂  187 → 23  ⬇️ -87%
Build status (4 semanas):        ✗✗⚠✅
```

Los caracteres `▁▂▃▄▅▆▇█` representan el valor de cada semana normalizado al rango min-max del período (▁=mínimo, █=máximo). Build status usa ✗ (fallo), ⚠ (warning) y ✅ (ok).

## Interpretación de tendencias

| Señal | Significado | Acción sugerida |
|-------|-------------|----------------|
| ⬆️ MEJORANDO | Dominios aprobados aumentan, [PENDIENTE] decrece | Continuar el ritmo |
| ➡️ ESTABLE | Sin cambios en 2+ semanas | Revisar bloqueos — ¿quién falta aprobar? |
| ⬇️ RETROCEDIENDO | Aprobados disminuyen (rollbacks) o [PENDIENTE] crece | Investigar causa |
| ❓ INSUFICIENTE | Menos de 2 semanas de historial | Volver a revisar en 1-2 semanas |

## Prerequisitos

Para que `/spec-health` tenga datos suficientes:
1. `memory/spec-changelog.md` con al menos 2 semanas de entradas (auto-actualizado por `post-commit-changelog.sh`)
2. Al menos 1 dominio aprobado (via `/approve [dominio]`)

Sin datos suficientes, muestra el estado actual y advierte que el historial es insuficiente para tendencias.

<examples>
  <example>
    <input>/spec-health</input>
    <output>
📈 SPEC HEALTH TREND — fintrack
══════════════════════════════════════════════════════════════════
Período: 2026-05-01 → 2026-05-29 (4 semanas)

Semana      | Aprobados | [PENDIENTE] | Build  | Velocidad
──────────────────────────────────────────────────────────────────
May 01-07   | 2/11      | 187         | ❌     | —
May 08-14   | 4/11      | 134         | ⚠️     | +2 dom/sem
May 15-21   | 5/11      | 89          | ⚠️     | +1 dom/sem
May 22-29   | 8/11      | 23          | ✅     | +3 dom/sem

TENDENCIA: ⬆️ MEJORANDO
  Dominios aprobados: 2 → 8 (+6 en 4 semanas)
  [PENDIENTE] totales: 187 → 23 (-164, -87%)
  Build status: ❌ → ✅

PROYECCIÓN (al ritmo actual):
  Todos los dominios aprobados: ~1 semana
  [PENDIENTE] < 5: ~3 días

══════════════════════════════════════════════════════════════════

DOMINIOS POR ESTADO ACTUAL:
  ✅ Aprobados (8):   negocio, producto, arquitectura, datos, seguridad,
                      infraestructura, calidad, operaciones
  🔄 En revisión (2): diseno, legal
  📝 Draft (1):       hardware

HITOS recientes:
  2026-05-29  ✅ seguridad aprobado (por @sec-lead)
  2026-05-27  ✅ infraestructura aprobado (por @devops-maria)
  2026-05-25  ✅ calidad aprobado (por @pm-jsmith)
  2026-05-20  ✅ operaciones aprobado (por @pm-jsmith)

══════════════════════════════════════════════════════════════════
    </output>
  </example>
  <example>
    <input>/spec-health --weeks 2</input>
    <output>
📈 SPEC HEALTH TREND — fintrack
══════════════════════════════════════════════════════════════════
Período: 2026-05-15 → 2026-05-29 (2 semanas)

Semana      | Aprobados | [PENDIENTE] | Build  | Velocidad
──────────────────────────────────────────────────────────────────
May 15-21   | 5/11      | 89          | ⚠️     | —
May 22-29   | 8/11      | 23          | ✅     | +3 dom/sem

TENDENCIA: ⬆️ MEJORANDO
  Período insuficiente para proyección sólida — volver a revisar en 2 semanas.
══════════════════════════════════════════════════════════════════
    </output>
  </example>
</examples>

## Comandos relacionados

- [[status]] — estado actual del proyecto (snapshot puntual)
- [[analyze]] — diagnóstico detallado del estado actual
- [[spec-changelog]] — historial completo de cambios
- [[approve]] — avanza el estado de un dominio
