---
name: repair
description: "Auto-corrige referencias unidireccionales y wikilinks rotos en el framework. Uso: /repair [--fix] [--scope all|commands|agents|rules]"
---

# Comando: /repair

**Argumentos**: `$ARGUMENTS`

Detecta y corrige automáticamente gaps de integridad en los archivos del framework `.claude/`: referencias unidireccionales entre wikilinks y wikilinks que apuntan a archivos inexistentes.

> **Relación con `/doctor`**: `/doctor` detecta todos los tipos de problemas del framework. `/repair` resuelve específicamente los checks 5 (wikilinks rotos, reporta sin corregir) y 6 (bidireccionalidad, corrige con `--fix`). Ejecutar `/doctor --fix` delega automáticamente a `/repair`.

## Uso

```
/repair                          # Dry-run: muestra qué corregiría sin aplicar cambios
/repair --fix                    # Aplica todas las correcciones de bidireccionalidad
/repair --fix --scope agents     # Solo corrige en .claude/agents/*.md
/repair --fix --scope commands   # Solo corrige en .claude/commands/*.md
/repair --fix --scope rules      # Solo corrige en .claude/rules/*.md
/repair --target <archivo>       # Scope de un solo archivo (dry-run o --fix)
```

Por defecto opera en **dry-run** — no modifica nada. Requiere `--fix` explícito para aplicar cambios.

## Qué corrige

### Tipo 1 — Referencias unidireccionales (corregible con --fix)

Para cada caso donde archivo A referencia `[[B]]` pero B no referencia `[[A]]`:

1. Determina el tipo del archivo B (agente / comando / regla / agente-registry)
2. Determina la sección correcta donde añadir la referencia de retorno:

| Tipo de archivo B | Sección de retorno |
|-------------------|-------------------|
| Agente (`.claude/agents/`) | `**Agentes relacionados**:` o `**Comandos que lo invocan**:` (según el tipo de A) |
| Comando (`.claude/commands/`) | `## Comandos relacionados` |
| Regla (`.claude/rules/`) | `## Reglas que valida` → subsección `**Agentes que la aplican**:` |
| Registry (`.claude/agents-registry/`) | `**Comandos que lo invocan**:` |

3. Infiere el texto de la referencia de retorno a partir del contexto donde A menciona B
4. Aplica el Edit añadiendo la referencia al final de la sección correspondiente

### Tipo 2 — Wikilinks rotos (solo reporta, sin corrección automática)

Para cada `[[nombre]]` sin archivo correspondiente en `.claude/`:
- Reporta: archivo fuente, wikilink roto
- No corrige automáticamente — requiere decisión humana (crear el archivo o eliminar la referencia)
- Sugiere la acción más probable según contexto

## Output (dry-run, sin --fix)

```
REPAIR REPORT — dry-run
══════════════════════════════════════════════════════════════════
Wikilinks rotos:      0  (requieren decisión manual)
Referencias uni-dir:  3  (corregibles con --fix)

  [1] .claude/commands/analyze.md → [[graphify]]
      AÑADIR en .claude/commands/graphify.md → ## Comandos relacionados:
      - [[analyze]] — análisis de gaps complementario al grafo (graphify-out/ como contexto)

  [2] .claude/commands/validate.md → [[graphify]]
      AÑADIR en .claude/commands/graphify.md → ## Comandos relacionados:
      - [[validate]] — valida consistencia de specs usando el grafo para detectar referencias rotas

  [3] .claude/commands/contract.md → [[analyst]]
      AÑADIR en .claude/agents/analyst.md → **Comandos que lo invocan**:
      · [[contract]]

Ejecutar /repair --fix para aplicar los 3 cambios.
```

## Output (--fix aplicado)

```
REPAIR REPORT — aplicado
══════════════════════════════════════════════════════════════════
Wikilinks rotos:      0
Referencias uni-dir:  3 → 0  (3 corregidas)

  [FIXED] .claude/commands/graphify.md → añadido [[analyze]] en Comandos relacionados
  [FIXED] .claude/commands/graphify.md → añadido [[validate]] en Comandos relacionados
  [FIXED] .claude/agents/analyst.md    → añadido [[contract]] en Comandos que lo invocan

Framework: ✅ 0 referencias unidireccionales pendientes
Ejecutar /doctor para verificar el estado completo del framework.
```

## Qué NO corrige

- Wikilinks rotos (sin archivo objetivo) — decisión humana requerida
- Gaps de estructura de agentes (secciones faltantes) — editar manualmente
- Inconsistencias semánticas entre specs — usar `/validate`
- Entrada faltante en tabla de CLAUDE.md — editar manualmente

## Agente que ejecuta

El propio Claude con permisos de lectura y edición (Read, Edit, Glob, Grep). Modifica únicamente los archivos indicados en el reporte.

<examples>
  <example>
    <input>/repair --dry-run</input>
    <output>
REPAIR REPORT — dry-run
══════════════════════════════════════════════════════════════════
Wikilinks rotos:      0
Referencias uni-dir:  0

Framework: ✅ Sin referencias unidireccionales pendientes
    </output>
  </example>
  <example>
    <input>/repair --fix --scope commands</input>
    <output>
REPAIR REPORT — scope: commands
══════════════════════════════════════════════════════════════════
Wikilinks rotos:      0
Referencias uni-dir:  2 → 0  (2 corregidas)

  [FIXED] .claude/commands/graphify.md → añadido [[analyze]] en Comandos relacionados
  [FIXED] .claude/commands/graphify.md → añadido [[validate]] en Comandos relacionados

Framework (scope commands): ✅ OK
Nota: otros scopes no verificados — ejecutar /repair sin --scope para revisión completa.
    </output>
  </example>
</examples>

## Comandos relacionados

- [[doctor]] — detecta todos los gaps del framework (estructura + bidireccionalidad + consistencia)
- [[analyze]] — diagnóstico profundo del proyecto (specs y código)
- [[validate]] — validación de specs y contratos del proyecto
