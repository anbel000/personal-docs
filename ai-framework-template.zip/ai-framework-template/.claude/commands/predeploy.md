---
name: predeploy
description: "Chequeo obligatorio antes de deploy: drift detection entre código y specs + refresh del grafo de specs. Uso: /predeploy"
---

# Comando: /predeploy

**Argumentos**: `$ARGUMENTS`

Chequeo obligatorio antes de cada deploy productivo. Detecta drift código↔spec y refresca la wiki de specs.

## Uso

```
/predeploy              # Drift check + refresh wiki + report (strict por default)
/predeploy --warn-only  # Solo advierte sin fallar (para CI no bloqueante)
/predeploy --skip-wiki  # Solo drift check, sin refresh del grafo
```

## Cuándo ejecutar

- Antes de todo `railway up`, `kubectl apply`, `terraform apply`, merge a `main`/`master`
- Al final de `/build` (invocado automáticamente)
- Manualmente cuando se quiere verificar estado actual

## Pipeline interno

```
┌─────────────────────────┐
│  1. DRIFT DETECTION     │  ── grep headers en código → abrir specs referenciadas
│  (validate Nivel 5)     │  ── comparar comportamiento descrito vs implementado
└──────────┬──────────────┘
           │  Si hay drift → reportar + FALLAR (strict) o ADVERTIR (warn-only)
           ▼
┌─────────────────────────┐
│  2. REFRESH WIKI SPECS  │  ── python -m graphify update . --config graphify/.graphify.yml
│  /graphify --update     │  ── incremental (solo archivos modificados)
└──────────┬──────────────┘
           │
           ▼
┌──────────────────────────────────────┐
│  2.5 SBOM (opcional)                 │  ── solo si sbom_enabled: true en spec-manifest.yaml
│  /sbom generate --format spdx        │  ── genera docs/sbom.spdx.json con componentes + licencias
└──────────────────────────────────────┘
           │
           ▼
┌─────────────────────────┐
│  3. REPORTE FINAL       │
└─────────────────────────┘
```

## Paso 1 — Drift Detection (Nivel 5 de /validate)

Para cada archivo de código modificado desde el último deploy:

1. Leer headers `// Generated from:`, `// Spec:`, `// Contract:` del archivo
2. Abrir la spec referenciada
3. Comparar: ¿sigue describiendo el comportamiento real?

Señales de drift a detectar:
- Nuevos parámetros en una función que no están documentados en la spec
- Ramas de ejecución (if/else) que la spec no menciona
- Nuevos efectos secundarios (escritura a FS, llamadas externas) no en la spec
- Firmas de función/endpoint que divergen del contrato OpenAPI referenciado
- Entidades de datos cuyos campos no están en el DDL/schema referenciado

## Paso 2 — Refresh de wiki de specs

```bash
python -m graphify update . --config graphify/.graphify.yml
python .claude/skills/graphify-specs/auto_label_communities.py graphify-out/graph.json
python .claude/skills/graphify-specs/collapse_to_files.py graphify-out/graph.json
```

Si graphify no está instalado, reportar como warning pero no fallar — el drift check es el bloqueante obligatorio.

## Paso 3 — Reporte final

```
╔══════════════════════════════════════════════════╗
║  PRE-DEPLOY SPEC SYNC REPORT                    ║
╠══════════════════════════════════════════════════╣
║  Proyecto: [nombre]                             ║
║  Fecha: [timestamp]                             ║
╠══════════════════════════════════════════════════╣
║  ✅ Drift: 0 archivos con drift detectado       ║
║  ✅ Wiki: graphify-out/ actualizado             ║
║     N nodos · M edges                           ║
╚══════════════════════════════════════════════════╝

DEPLOY: AUTORIZADO
```

O si hay drift:

```
╔══════════════════════════════════════════════════╗
║  PRE-DEPLOY SPEC SYNC REPORT                    ║
╠══════════════════════════════════════════════════╣
║  ❌ Drift detectado en 2 archivos               ║
╚══════════════════════════════════════════════════╝

DRIFT:
  [ALTO] wiki.service.ts → specs/05-datos/flujos.md (Flujo 1)
    → extractAndStoreEntities acepta transcriptSegments pero la spec no lo menciona
  [MEDIO] webhooks.service.ts → specs/02-producto/requerimientos.md (REQ-FUNC-001)
    → rama discarded=true no está documentada

DEPLOY: BLOQUEADO — corrige el drift antes de deployar
```

## Salida de exit code

- `0` — sin drift, deploy autorizado
- `1` — drift detectado (strict mode) o error interno

## Integración CI/CD

```yaml
# .github/workflows/predeploy.yml
jobs:
  spec-sync:
    steps:
      - name: Spec sync check
        run: claude -p "/predeploy --strict"
```

Para proyectos sin Claude CLI en CI, usar el script standalone:

```bash
bash .claude/hooks/pre-commit-spec-sync.sh --full
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/predeploy</input>
    <output>
╔══════════════════════════════════════════════════╗
║  PRE-DEPLOY SPEC SYNC REPORT                    ║
╠══════════════════════════════════════════════════╣
║  Proyecto: crm-startup                          ║
║  Fecha: 2026-05-29T18:00:00Z                    ║
╠══════════════════════════════════════════════════╣
║  ✅ Drift: 0 archivos con drift detectado       ║
║  ✅ Wiki: graphify-out/ actualizado             ║
║     248 nodos · 847 edges                       ║
╚══════════════════════════════════════════════════╝

DEPLOY: AUTORIZADO
    </output>
  </example>
  <example>
    <input>/predeploy</input>
    <output>
╔══════════════════════════════════════════════════╗
║  PRE-DEPLOY SPEC SYNC REPORT                    ║
╠══════════════════════════════════════════════════╣
║  ❌ Drift detectado en 1 archivo                ║
╚══════════════════════════════════════════════════╝

DRIFT:
  [ALTO] src/auth/users.service.ts → specs/06-seguridad/requisitos.md (SEC-AUTH-003)
    → refreshToken() invalida el JTI del token anterior — spec no lo documenta
    → Actualizar specs/06-seguridad/requisitos.md#SEC-AUTH-003 con el comportamiento real

DEPLOY: BLOQUEADO — corrige el drift antes de deployar
  Opción: actualizar la spec en el mismo commit y re-ejecutar /predeploy
    </output>
  </example>
</examples>

## Pre-condiciones

- `spec-manifest.yaml` presente en raíz del proyecto
- `graphify` instalado (para refresh de wiki; drift check funciona sin él)
- Working tree limpio (recomendado) o staged changes conocidos

## Override de emergencia

Para deployar con drift conocido y documentado:

```bash
SPEC_SYNC_OVERRIDE="REQ explicado en ADR-0042" /predeploy --warn-only
```

Siempre registrar el override en el ADR correspondiente.

## Agente que ejecuta

Invoca al agente [[analyst]] en modo drift para el Paso 1 (Nivel 5 — detección de divergencias código↔spec).

## Comandos relacionados

- [[spec-sync]] — regla que este comando enforces
- [[validate]] — validación completa de specs (incluye Niveles 1-4)
- [[graphify]] — reconstruir el grafo manualmente cuando el Paso 2 de /predeploy falla
- [[graphify-specs]] — rebuild manual del grafo (alternativa zero-LLM)
- [[build]] — pipeline completo que invoca /predeploy
- [[sbom]] — genera el SBOM en el paso 2.5 del pipeline si `sbom_enabled: true` en spec-manifest.yaml
