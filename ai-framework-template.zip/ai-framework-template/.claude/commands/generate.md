---
name: generate
description: "Genera código a partir de specs y contratos. Uso: /generate [dominio] o /generate all"
---

# Comando: /generate

**Argumentos**: `$ARGUMENTS`

Genera artefactos de código a partir de las especificaciones y contratos formales.

## Uso

```
/generate [dominio]         # Genera artefactos de un dominio específico
/generate all               # Genera todos los artefactos del proyecto
/generate all --diff        # Solo regenera artefactos cuyas specs cambiaron desde el último generate
/generate all --parallel    # Habilita generación paralela de dominios independientes
/generate [dominio] --force # Fuerza regeneración aunque la spec no haya cambiado
```

Dominios válidos: `negocio`, `producto`, `diseno`, `arquitectura`, `datos`, `seguridad`, `infra`, `calidad`, `operaciones`, `legal`, `hardware`

## Flujo de ejecución

1. **Leer [[spec-manifest]]** para determinar qué specs existen y qué agentes invocar
2. **Validar pre-condiciones**: verificar que las specs del dominio existen y no están vacías
3. **Leer contratos** (`contracts/`) relevantes al dominio — estos tienen prioridad sobre la prosa
4. **Invocar al agente** correspondiente según el manifest
5. **Generar los artefactos** listados en `generates:` del manifest
6. **Reportar** qué se generó y qué quedó pendiente

## Orden de generación (cuando es `all`)

El orden respeta dependencias entre dominios:

```
Fase A (secuencial — establece fundamentos):
  1. arquitectura  → scaffolding del proyecto      (agente: architect)
  2. datos         → modelos, migraciones           (agente: data-engineer)

Fase B (paralela — dominios independientes entre sí):
  3a. seguridad    → middleware de auth/authz        (agente: implementer)
  3b. diseno       → componentes UI, rutas, theme    (agente: designer)
  [requieren arquitectura + datos; no dependen entre sí]

Fase C (paralela — consumen los anteriores):
  4a. producto     → controllers, services           (agente: implementer)
  4b. legal        → middleware de privacidad (GDPR) (agente: implementer)
  [requieren seguridad; no dependen entre sí]

Fase D (paralela — validación y operaciones):
  5a. calidad      → tests                           (agente: qa)
  5b. infra        → IaC, CI/CD, monitoreo           (agente: devops)
  5c. operaciones  → scripts de deploy, runbooks     (agente: devops)
  5d. hardware     → clientes MQTT, device mgmt      (agente: iot-engineer)  [opcional]
```

> Con `--parallel`, las fases B, C y D ejecutan múltiples agentes simultáneamente.
> Sin `--parallel`, se ejecutan secuencialmente (comportamiento por defecto — más predecible).

**Formato de progreso por subagente** (cuando se consolida al terminar `--parallel`):
```
[arquitectura] ✅  8 archivos · 0 errores
[datos]        ✅ 12 archivos · 0 errores
[seguridad]    ⚠️   4 archivos · 1 advertencia — specs/06-seguridad/threat-model.md: 2 [PENDIENTE]
[diseno]       ✅ 15 archivos · 0 errores
[producto]     ❌  0 archivos · BLOQUEADO — specs/02-producto/requerimientos.md vacío
```

Cada subagente DEBE reportar en este formato para que el consolidador pueda armar el output final.

## Modo incremental (`--diff`)

Con `--diff`, el comando solo regenera artefactos cuyas specs fuente cambiaron:

1. Leer `docs/build-state.json` → `steps.generate.completed_at` (timestamp del último generate)
2. Comparar con `git log --since={timestamp} -- specs/ contracts/` para detectar qué cambió
3. Solo invocar los agentes de los dominios con cambios detectados
4. Si no existe `build-state.json` → generar todo (equivale a `--force`)

**Output de `--diff`:**
```
⚡ Modo incremental activado
   Último generate: 2026-05-28T10:22:00Z

   Cambios detectados:
   ✅ specs/05-datos/modelo.md    → regenerando datos/
   ✅ contracts/api/users.yaml    → regenerando src/integrations/
   ⏭  specs/04-arquitectura/      → sin cambios, omitido
   ⏭  specs/06-seguridad/        → sin cambios, omitido

   Generando 2 de 10 dominios...
```

## Detección de ediciones manuales (fingerprinting)

Antes de sobrescribir cualquier archivo generado previamente, el agente verifica si fue modificado manualmente. El mecanismo usa un hash SHA256 del contenido generado:

**Al generar un archivo nuevo:**
```
// Generated from: specs/04-arquitectura/arquitectura.md
// Contract: contracts/api/users.yaml
// Generated-hash: a3f2b1c4d5e6f7  ← SHA256 del contenido al momento de generación
// Do not edit manually — regenerate with /generate arquitectura
```

**Al regenerar un archivo existente:**
1. Leer el `Generated-hash` del encabezado del archivo actual
2. Calcular el hash del contenido actual (sin el header)
3. Si los hashes difieren → el archivo fue editado manualmente:
   ```
   ⚠️  src/auth/users.service.ts fue modificado manualmente
      SHA256 generado:  a3f2b1c4
      SHA256 actual:    e9f1d2c3  (12 líneas cambiadas)

   Opciones:
     [s] Sobreescribir (perder cambios manuales)
     [N] Mantener el archivo actual (omitir este dominio)
     [d] Ver diff de cambios manuales
   ```
4. Si los hashes coinciden → sobrescribir sin preguntar (no hubo edición manual)

Sin el flag `--fingerprint` o si el archivo no tiene `Generated-hash`, el comportamiento es el actual (sobrescribir directo).

## Reglas

- NUNCA generar código si la spec fuente está vacía o es solo plantilla
- Si un contrato formal existe en `contracts/`, usarlo como fuente de verdad
- Si faltan specs que bloquean la generación, reportar como gap y continuar con lo que se pueda
- Cada archivo generado incluye un comentario header con la spec fuente y el hash de generación
- Con `--fingerprint`, preguntar antes de sobrescribir archivos con ediciones manuales detectadas

## Output al completar

```
✅ Generación completada

   Fase A: 2 dominios (secuencial)
     ✅ arquitectura  → 8 archivos generados
     ✅ datos         → 12 archivos generados

   Fase B: 2 dominios (paralelo)
     ✅ seguridad     → 4 archivos generados
     ✅ diseno        → 15 archivos generados

   Fase C: 2 dominios (paralelo)
     ✅ producto      → 11 archivos generados
     ✅ legal         → 2 archivos generados

   Fase D: 3 dominios (paralelo)
     ✅ calidad       → 28 tests generados
     ✅ infra         → 6 archivos generados
     ⚠️  hardware     → OMITIDO (optional: true, sin specs)

   Total: 86 archivos generados · 0 errores · 1 advertencia

GAPS detectados:
   - specs/07-infra/sla-slo.md: 5 [PENDIENTE] — infra no generada completamente
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/generate datos</input>
    <output>
Leyendo contracts/ddl/001_initial_schema.sql...
Leyendo contracts/schemas/user.json...
Invocando agente data-engineer...

✅ Generación completada — datos

  migrations/001_initial_schema.sql  — 4 tablas: user, order, order_item, payment
  migrations/002_add_audit_fields.sql — created_at, updated_at
  src/models/user.model.ts           — Spec: contracts/ddl/001_initial_schema.sql#user
  src/models/order.model.ts          — Spec: contracts/ddl/001_initial_schema.sql#order
  src/repositories/user.repository.ts
  src/repositories/order.repository.ts
  src/seeds/01_users.seed.ts

  Total: 7 archivos generados · 0 errores

⚠️  GAPS detectados:
  - modelo.md menciona campo `payment_status` en Order
    pero no existe en el DDL → agregar al DDL antes de regenerar
    </output>
  </example>
</examples>

## Cuándo usar `--parallel` vs secuencial

| Situación | Recomendación |
|-----------|---------------|
| Primera generación del proyecto | Secuencial (detecta errores más claramente) |
| Rebuild completo tras muchos cambios | `--parallel` (más rápido) |
| Solo cambió un dominio | `/generate [dominio]` (más específico) |
| Cambios en múltiples dominios | `--diff` (solo lo necesario) |
| CI/CD pipeline | `--diff --parallel` (óptimo en velocidad) |

## Comandos relacionados

- **Agentes que invoca**: [[architect]] · [[implementer]] · [[data-engineer]] · [[designer]] · [[iot-engineer]] · [[qa]] · [[devops]]
- **Mapeo completo**: [[spec-manifest]]
- [[validate]] — ejecutar antes de generar
- [[build]] — pipeline completo que incluye /generate
- [[analyze]] — diagnóstico de gaps
- [[contract]] — gestión de contratos formales
- **Regla relacionada**: [[spec-sync]] — el código generado debe sincronizarse con las specs referenciadas
