---
name: graphify
description: "Reconstruye el conectoma de archivos del proyecto como un wiki multienlazado navegable por IA y Obsidian. Uso: /graphify [--update|--watch|--full]"
---

# Comando: /graphify

**Argumentos**: `$ARGUMENTS`

Construye o actualiza el grafo de conocimiento del proyecto — un wiki de archivos interconectados donde cada spec, contrato, agente y comando se convierte en un nodo con relaciones explícitas hacia los demás. El resultado es navegable por IA (vía `graphify-out/wiki/`) y por humanos (vía Obsidian).

## Uso

```
/graphify              # Reconstruye el wiki completo del proyecto
/graphify --update     # Solo re-procesa archivos modificados desde el último build
/graphify --watch      # Modo continuo: reconstruye automáticamente al detectar cambios
/graphify --full       # Rebuild profundo con inferencia de relaciones implícitas
/graphify --query "X"  # Busca en el grafo sin reconstruir
/graphify --path "A" "B"  # Encuentra la conexión entre dos archivos/conceptos
/graphify --federated  # Procesa múltiples repos configurados en .graphify.yml y genera grafo federado en graphify-out/federated/
```

## Pre-condiciones

Verificar que graphify está instalado:

```bash
python -m graphify --version 2>/dev/null || pip install graphifyy
```

Si no está disponible, reportar instrucciones de instalación y detener.

## Flujo de ejecución

### Modo `--update` (default tras un edit)

```
1. Detectar qué archivos cambiaron desde graphify-out/cache/
2. Re-extraer solo esos archivos
3. Merge al grafo existente en graphify-out/graph.json
4. Regenerar wiki/index.md y los nodos afectados
5. Reportar: N nodos actualizados, M relaciones nuevas detectadas
```

### Modo `/graphify` (rebuild completo)

```
1. Correr: python -m graphify update . --config graphify/.graphify.yml
2. Output destino: graphify-out/ (según `output.dir` en `.graphify.yml`)
3. Reportar resumen del grafo generado
```

### Modo `--full` (análisis profundo)

```
1. Correr: python -m graphify update . --config graphify/.graphify.yml --mode deep
2. Incluye: relaciones INFERRED y AMBIGUOUS además de EXTRACTED
3. Ideal para correr en CI o antes de un release
```

## Qué produce

```
graphify-out/
├── wiki/
│   ├── index.md              ← PUNTO DE ENTRADA para la IA y humanos
│   ├── _COMMUNITY_negocio.md ← Vista de cada cluster de archivos relacionados
│   ├── _COMMUNITY_datos.md
│   ├── _COMMUNITY_seguridad.md
│   ├── ... (un _COMMUNITY_ por dominio detectado)
│   ├── vision.md             ← Un nodo por archivo del proyecto
│   ├── requerimientos.md
│   ├── arquitectura.md
│   ├── bootstrapper.md
│   └── ... (todos los archivos como nodos)
├── graph.json                ← Grafo completo para consultas programáticas
├── graph.html                ← Visualización interactiva en browser
├── graph.svg                 ← Imagen estática del grafo
├── GRAPH_REPORT.md           ← Reporte: nodos centrales, sorpresas, gaps
└── cache/                    ← Cache SHA256 por archivo (habilita --update incremental)
```

## Navegación por IA

Cuando Claude necesita entender el proyecto o encontrar un archivo, debe:

1. **Leer `graphify-out/wiki/index.md`** — punto de entrada con mapa del proyecto
2. **Seguir los `[[wikilinks]]`** hacia los nodos relevantes
3. **Usar `_COMMUNITY_*.md`** para entender agrupaciones temáticas

Esto es **más eficiente** que Glob/Grep porque el grafo ya tiene las relaciones pre-computadas.

## Modo `--federated` (multi-repo)

Para proyectos distribuidos en múltiples repos, genera un grafo federado que conecta specs entre repos:

```
1. Lee la sección `repos:` en `graphify/.graphify.yml`
2. Procesa cada repo con su prefijo configurado
3. Detecta wikilinks cross-repo (formato `[[prefix:archivo]]`)
4. Genera `graphify-out/federated/graph.json` con nodos de todos los repos
5. Reporta: N repos procesados, M cross-repo connections detectadas
```

Sintaxis de wikilink cross-repo: `[[api:specs/producto/requerimientos]]` donde `api:` es el prefijo configurado para ese repo. Ver sección de multi-repo en `graphify/GRAPHIFY.md`.

## Configuración

El comportamiento se controla en `graphify/.graphify.yml` (no en la raíz — el config vive dentro del directorio `graphify/`).

## Integración con Obsidian

El directorio `graphify-out/wiki/` puede abrirse directamente como vault de Obsidian:

1. Abrir Obsidian → "Open folder as vault"
2. Seleccionar `graphify-out/wiki/`
3. El grafo de relaciones aparece en el Graph View
4. Los colores de comunidad están pre-configurados en `.obsidian/graph.json`

## Reportes del grafo

Después de cada build, reportar:

```
📊 Grafo actualizado: {N} nodos · {M} relaciones

🏘️  Comunidades detectadas:
   - negocio (N nodos): vision, stakeholders, propuesta-valor
   - producto (N nodos): requerimientos, historias-usuario, ...
   - arquitectura (N nodos): arquitectura, stack, ADR-0001, ...

⭐ Nodos centrales ("god nodes" — más conectados):
   - requerimientos.md (grado: 23)
   - arquitectura.md (grado: 19)
   - spec-manifest.yaml (grado: 15)

⚠️  Gaps detectados por el grafo:
   - N archivos sin conexiones (nodos huérfanos)
   - M specs referenciadas en el manifest pero sin archivo físico

📄 Reporte completo: graphify-out/GRAPH_REPORT.md
🌐 Visualización: graphify-out/graph.html
```

<examples>
  <example>
    <input>/graphify</input>
    <output>
Corriendo: python -m graphify update . --config graphify/.graphify.yml
Procesando 248 archivos...

📊 Grafo actualizado: 248 nodos · 847 relaciones

🏘️  Comunidades detectadas:
   - negocio       (14 nodos): vision, stakeholders, propuesta-valor, restricciones...
   - producto      (31 nodos): requerimientos, historias-usuario, flujos, roadmap...
   - arquitectura  (22 nodos): arquitectura, stack, ADR-0001, ADR-0002, ADR-0003...
   - datos         (18 nodos): modelo, flujos-datos, gobernanza, DDL migrations...
   - seguridad     (19 nodos): requisitos, threat-model, cumplimiento, privacidad...
   - infraestructura(16 nodos): infraestructura, cicd, sla-slo, monitoring...
   - calidad       (20 nodos): estrategia, historias-aceptacion, accesibilidad...
   - agentes       (47 nodos): bootstrapper, architect, implementer, qa, devops...
   - comandos      (28 nodos): bootstrap, generate, validate, review, approve...

⭐ Nodos centrales (más conectados):
   - specs/02-producto/requerimientos.md  (grado: 47)
   - specs/04-arquitectura/arquitectura.md (grado: 38)
   - .claude/CLAUDE.md                    (grado: 31)
   - spec-manifest.yaml                   (grado: 28)

⚠️  Gaps detectados:
   - 3 nodos huérfanos (sin conexiones): specs/09-legal/gdpr.md,
     specs/10-hardware/hardware.md, docs/adr/0003-template.md
   - 1 spec referenciada en manifest sin archivo: specs/03-diseno/ux-research.md

📄 Reporte completo: graphify-out/GRAPH_REPORT.md
🌐 Visualización:    graphify-out/graph.html
    </output>
  </example>
</examples>

## Comandos relacionados

- [[navigator]] — usa el wiki generado para responder preguntas sobre el proyecto
- [[explain]] — usa el wiki generado como prerrequisito para responder preguntas sobre artefactos
- [[predeploy]] — invoca `/graphify --update` en su Paso 2 (refresh incremental del wiki)
- [[graphify-specs]] — alternativa AST pura (zero LLM, zero tokens) cuando no hay API key disponible
- [[analyze]] — análisis de gaps en specs (complementario al grafo)
- [[validate]] — valida consistencia de specs (usa el grafo para detectar referencias rotas)
- [[graphify-first]] — regla que instruye a los agentes a consultar el output de este comando antes de hacer Glob/Grep masivos
- [[graphifyllm]] — configura el modelo LLM usado por este comando en cada build
