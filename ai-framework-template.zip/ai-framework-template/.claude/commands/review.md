---
name: review
description: "Revisión de calidad de specs antes de aprobar: claridad, completitud semántica, consistencia interna. Uso: /review <dominio>"
---

# Comando: /review

**Argumentos**: `$ARGUMENTS`

Ejecuta una revisión de calidad de las specs de un dominio antes de aprobarlas. Es el equivalente a un pull request review, pero aplicado a especificaciones. Detecta problemas que la validación técnica (`/validate`) no cubre: requerimientos vagos, Gherkin incompleto, terminología inconsistente, contratos sin ejemplos.

> **Diferencia con `/validate`**: `/validate` verifica estructura y consistencia técnica (¿existe el archivo? ¿coinciden los campos?). `/review` evalúa calidad semántica (¿se puede implementar correctamente? ¿lo entendería alguien nuevo?).

## Uso

```
/review negocio              # Revisa el dominio negocio
/review producto             # Revisa el dominio producto
/review all                  # Revisa todos los dominios (tarda más)
/review producto --quick     # Solo blockers, sin sugerencias opcionales
/review producto --checklist # Output en formato checklist para el autor
```

## Pre-condiciones

El comando requiere que el dominio haya pasado primero `/validate [dominio]` sin errores ALTA. Si hay errores de validación, detiene la revisión y pide que se corrijan primero.

## Flujo de ejecución

```
1. Verificar que /validate [dominio] no reporta errores ALTA
   ↓
2. Invocar agente [[reviewer]] con el contenido del dominio
   ↓
3. El reviewer analiza 6 dimensiones:
   - Claridad de requerimientos
   - Completitud funcional (happy path + error path)
   - Consistencia interna del dominio
   - Calidad de contratos formales
   - Legibilidad para nuevos miembros
   - **Golden Rule**: ¿Podría un desarrollador nuevo implementar cada requerimiento sin hacer preguntas al equipo? Si hay ambigüedad que requeriría clarificación, reportar como BLOCKER.
   ↓
4. Producir reporte con issues clasificados:
   - BLOCKER: debe resolverse antes de /approve
   - SUGGESTION: opcional pero recomendado
   ↓
5. Emitir veredicto final:
   - APROBAR
   - APROBAR CON OBSERVACIONES
   - NECESITA CAMBIOS
   - RECHAZAR
```

## Output estándar

```
╔══════════════════════════════════════════════╗
║  SPEC REVIEW REPORT                         ║
║  Dominio: producto                          ║
║  Fecha: 2026-05-29                          ║
╠══════════════════════════════════════════════╣
║  Specs:    5 archivos                       ║
║  Contratos: 3 archivos                      ║
╠══════════════════════════════════════════════╣
║  Issues:                                    ║
║  🔴 1 BLOCKER                               ║
║  🟡 3 SUGGESTIONS                           ║
╠══════════════════════════════════════════════╣
║  VEREDICTO: NECESITA CAMBIOS               ║
╚══════════════════════════════════════════════╝

BLOCKERS (deben resolverse antes de /approve):
  historias-usuario.md#HU-007
  → Criterio Gherkin incompleto: falta cláusula "Then"
  → Sin escenario de error para registro fallido

SUGGESTIONS (opcionales):
  requerimientos.md#REQ-FUNC-004
  → "responder en tiempo razonable" no es verificable
  → Recomendación: definir SLO (ej: P95 < 200ms)

  modelo.md
  → Campo 'status' sin valores válidos documentados

  contracts/api/products.yaml
  → Endpoints sin ejemplos en response body

POSITIVOS:
  ✅ Todos los Must-Have tienen Gherkin completo (happy + error)
  ✅ Terminología consistente en el dominio

Próximo paso: corregir el BLOCKER y ejecutar /approve producto
```

## Output en `--checklist`

```markdown
## Checklist de revisión — producto

### Blockers (obligatorio resolver)
- [ ] historias-usuario.md#HU-007: Completar cláusula Then del Gherkin
- [ ] historias-usuario.md#HU-007: Agregar escenario de error

### Suggestions (opcional)
- [ ] requerimientos.md#REQ-FUNC-004: Convertir "tiempo razonable" a SLO concreto
- [ ] modelo.md: Documentar valores válidos de campo 'status'
- [ ] contracts/api/products.yaml: Agregar ejemplos a responses
```

## Flujo en equipo

```
Autor edita specs
       ↓
/validate [dominio]    ← verifica estructura y consistencia técnica
       ↓
/review [dominio]      ← verifica calidad semántica
       ↓
Si APROBAR/APROBAR CON OBSERVACIONES:
/approve [dominio]     ← marca como aprobado
       ↓
Si NECESITA CAMBIOS:
→ autor corrige → vuelve a /review
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/review producto</input>
    <output>
╔══════════════════════════════════════════════╗
║  SPEC REVIEW REPORT                         ║
║  Dominio: producto                          ║
║  Fecha: 2026-05-29                          ║
╠══════════════════════════════════════════════╣
║  Specs:    5 archivos                       ║
║  Contratos: 2 archivos                      ║
╠══════════════════════════════════════════════╣
║  Issues:                                    ║
║  🔴 1 BLOCKER                               ║
║  🟡 2 SUGGESTIONS                           ║
╠══════════════════════════════════════════════╣
║  VEREDICTO: NECESITA CAMBIOS               ║
╚══════════════════════════════════════════════╝

BLOCKERS:
  historias-usuario.md#HU-007
  → Gherkin: falta cláusula "Then" en escenario de login con 2FA
  → Golden Rule: un desarrollador nuevo no sabría qué responder el server cuando el 2FA es correcto

SUGGESTIONS:
  requerimientos.md#REQ-FUNC-003
  → "responder rápido" no es verificable → convertir a SLO (ej: P95 < 200ms)

  contracts/api/orders.yaml
  → Endpoint POST /orders sin ejemplo en response body → añadir ejemplo concreto

POSITIVOS:
  ✅ Todos los Must-Have tienen happy path + escenario de error
  ✅ Terminología consistente: "usuario" en todos los archivos del dominio

Próximo paso: corregir BLOCKER → /approve producto
    </output>
  </example>
</examples>

## Agente que ejecuta

Invoca al agente [[reviewer]] con permisos de solo lectura.

## Comandos relacionados

- [[validate]] — ejecutar primero (pre-condición de /review)
- [[approve]] — ejecutar después si el veredicto es APROBAR o APROBAR CON OBSERVACIONES
- [[grill-spec]] — completar specs cuando el veredicto es NECESITA CAMBIOS (retomar [PENDIENTE] del dominio)
- [[analyze]] — dashboard de estado general del proyecto
- [[status]] — health check rápido que muestra dominios pendientes de revisión
- [[contract]] — revisar la calidad y sincronización de los contratos formales es parte del /review de un dominio
- [[compliance-checker]] — auditoría normativa (GDPR/SOC2/HIPAA/PCI-DSS) que puede preceder o complementar la revisión de calidad de specs de seguridad/legal
- [[spec-auditor]] — auditoría profunda del dominio que puede preceder /review (diagnóstico exhaustivo en una sola pasada — alternativa a /validate para inicio de dominio)
