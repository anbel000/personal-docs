---
name: explain
description: "Explica cualquier artefacto del proyecto (archivo, ID de requerimiento, contrato) usando el conectoma. Uso: /explain [archivo|ID]"
---

# Comando: /explain

**Argumentos**: `$ARGUMENTS`

Punto de entrada único para entender cualquier artefacto del proyecto. Usa el conectoma de graphify para navegar las relaciones entre specs, contratos, código y tests, y produce un resumen contextualizado en segundos.

## Uso

```
/explain src/auth/users.service.ts     # ¿Qué hace este archivo? ¿Qué specs lo respaldan?
/explain REQ-FUNC-003                  # ¿Dónde está implementado? ¿Qué tests lo cubren?
/explain HU-007                        # ¿Qué pruebas cubre? ¿Qué componente lo implementa?
/explain contracts/api/users.yaml      # ¿Quién genera código de este contrato?
/explain specs/05-datos/modelo.md      # ¿Qué código depende de este modelo?
/explain UserService                   # Busca la clase/función en specs y código
/explain SEC-AUTH-001                  # ¿Dónde está implementado este control de seguridad?
/explain REQ-FUNC-003 --interactive    # Explicación seguida de preguntas de profundización
```

## Modo `--interactive`

Con `--interactive`, `/explain` da la explicación inicial del artefacto y luego ofrece profundizar en aspectos específicos, uno a la vez:

```
/explain REQ-FUNC-003 --interactive

📋 REQ-FUNC-003 — Recuperación de contraseña
  [explicación estándar]

¿Qué aspecto quieres profundizar?
  a) implementación — cómo está implementado el código
  b) dependencias — qué otros artefactos lo usan o de qué depende
  c) por qué existe — contexto de negocio y decisiones de diseño
  d) cómo modificarlo — qué cambiarías y qué impacto tendría
```

El usuario elige una opción (o escribe su propia pregunta) y `/explain` responde en detalle. Luego repite el menú hasta que el usuario escribe "listo" o "exit".

Motor: mismo mecanismo de una-pregunta-a-la-vez que [[grill-me]].

## Flujo de ejecución

```
1. Si graphify-out/graph.json existe:
   → python -m graphify query "{argumento}" --graph graphify-out/graph.json --budget 3000
   → Seguir wikilinks desde el nodo encontrado
2. Si no existe el grafo:
   → Grep por el argumento en specs/, src/, contracts/
3. Construir el mapa de relaciones del artefacto
4. Mostrar el reporte en la estructura estándar
```

## Output estándar

```
📄 src/auth/users.service.ts
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Spec fuente:   specs/06-seguridad/requisitos.md#SEC-AUTH-001
  Requerimiento: REQ-FUNC-001 — Autenticación de usuarios
  Historia:      HU-001 — Usuario inicia sesión con email y contraseña
  Contrato:      contracts/api/auth.yaml (POST /auth/login, POST /auth/refresh)
  Depende de:    src/models/user.entity.ts (entidad)
                 src/infrastructure/jwt.service.ts (utilidad)
  Lo usan:       src/auth/auth.controller.ts
                 tests/integration/auth.test.ts
  Maturity:      seguridad → approved (por @sec-lead el 2026-04-01, expira 2026-07-01)
  Tests:         tests/integration/auth.test.ts → test_HU001_login_exitoso
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

```
📋 REQ-FUNC-003 — Recuperación de contraseña
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Definido en:   specs/02-producto/requerimientos.md
  Prioridad:     Must-Have
  Historias:     HU-005 (usuario solicita reset)
                 HU-006 (usuario usa token de reset)
  Implementado:  src/auth/password-reset.service.ts
  Test:          tests/acceptance/test_HU005_reset_password.ts
  Contrato:      contracts/api/auth.yaml (POST /auth/password-reset)
  Estado:        ✅ Implementado y trazado
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## Cuándo usar vs otras herramientas

| Tarea | Herramienta correcta |
|-------|---------------------|
| Entender qué hace un artefacto | `/explain` |
| Ver el estado de todo el proyecto | `/status` |
| Diagnóstico profundo de completitud | `/analyze` |
| Navegar el wiki del conectoma | `/navigator` (agente) |
| Buscar texto en archivos | Grep directo |

## Prerequisito

El conectoma debe estar construido para que `/explain` sea rápido y preciso:
```
/graphify         ← construir conectoma con LLM (inferencia semántica, ~2 min)
/graphify-specs   ← alternativa zero-LLM (AST puro, zero tokens, funciona offline)
```

Sin el grafo, `/explain` hace búsquedas con Grep (funciona, pero más lento y menos preciso).

<examples>
  <example>
    <input>/explain REQ-FUNC-003</input>
    <output>
📋 REQ-FUNC-003 — Recuperación de contraseña
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Definido en:   specs/02-producto/requerimientos.md (línea 78)
  Prioridad:     Must-Have
  Historias:     HU-005 — Usuario solicita link de reset
                 HU-006 — Usuario usa token de reset para cambiar contraseña
  Implementado:  src/auth/password-reset.service.ts
  Tests:         tests/acceptance/test_HU005_solicitud_reset.ts
                 tests/acceptance/test_HU006_uso_token_reset.ts
  Contrato:      contracts/api/auth.yaml
                   POST /api/v1/auth/password-reset
                   POST /api/v1/auth/password-reset/confirm
  Estado:        ✅ Implementado y trazado
  Dominio:       seguridad → approved (por @sec-lead el 2026-05-01)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    </output>
  </example>
  <example>
    <input>/explain src/orders/order.service.ts</input>
    <output>
📄 src/orders/order.service.ts
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Spec fuente:   specs/02-producto/historias-usuario.md
                   HU-012 (crear orden)
                   HU-013 (cancelar orden)
                   HU-014 (listar órdenes del usuario)
  Requerimientos: REQ-FUNC-008, REQ-FUNC-009
  Contrato:      contracts/api/orders.yaml
                   POST /api/v1/orders
                   DELETE /api/v1/orders/{id}
                   GET /api/v1/orders
  Depende de:    src/orders/order.repository.ts
                 src/notifications/notification.service.ts
  Lo usan:       src/orders/order.controller.ts
                 tests/integration/orders.test.ts
  Tests:         tests/acceptance/test_HU012_crear_orden.ts
                 tests/integration/orders.test.ts (3 casos)
  Drift:         ✅ Sin drift detectado (última validación: hoy)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    </output>
  </example>
</examples>

## Agente que ejecuta

- [[navigator]] — navega el conectoma para responder la pregunta

## Comandos relacionados

- [[status]] — estado global del proyecto
- [[analyze]] — diagnóstico profundo
- [[graphify]] — prerrequisito para que /explain sea rápido y preciso
- [[graphify-specs]] — alternativa zero-LLM como prerrequisito (AST puro, sin tokens, funciona offline)
- **Regla relacionada**: [[graphify-first]] — consultar el conectoma antes de búsquedas brutas
