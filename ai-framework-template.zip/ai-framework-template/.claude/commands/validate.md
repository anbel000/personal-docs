---
name: validate
description: "Valida la completitud y consistencia de las specs. Uso: /validate [dominio] o /validate all"
---

# Comando: /validate

**Argumentos**: `$ARGUMENTS`

Ejecuta validaciones de completitud, consistencia y trazabilidad sobre las especificaciones.

## Uso

```
/validate [dominio]              # Valida un dominio específico
/validate all                    # Valida todo el proyecto (Niveles 1-4)
/validate all --parallel         # Valida con subagentes por dominio en paralelo
/validate all --profile quick    # Solo Niveles 1 y 1.5 (estructura + frescura)
/validate all --profile pre-commit  # Niveles 1-3
/validate all --profile pre-merge   # Niveles 1-4 (sin drift)
/validate all --profile pre-deploy  # Niveles 1-5 (completo, como predeploy)
/validate contracts              # Valida solo los contratos formales
/validate traceability           # Genera matriz de trazabilidad y persiste docs/traceability-matrix.md
/validate drift                  # Nivel 5: detecta divergencias código ↔ spec (invocado por /predeploy)
/validate freshness              # Solo Nivel 1.5: verifica frescura de specs aprobadas
/validate freshness --notify 30  # Reporta specs que expirarán en los próximos 30 días
/validate freshness --all        # Estado completo de todas las specs aprobadas
/validate [dominio] --fix        # Valida y auto-corrige gaps de severidad MEDIA o INFO
/validate all --fix              # Valida todo el proyecto y auto-corrige donde sea seguro
```

### Perfiles de validación (`--profile`)

| Perfil | Niveles | Cuándo usar |
|--------|---------|-------------|
| `quick` | 1, 1.5 | Revisión rápida, antes de empezar a editar |
| `pre-commit` | 1-3 | Hook de pre-commit (sin LLM intensivo) |
| `pre-merge` | 1-4 | Revisión en PR antes de mergear |
| `pre-deploy` | 1-5 | Validación completa antes de deploy (igual a `/predeploy`) |

Sin `--profile`, el default es **Niveles 1-4** (sin drift, ya que requiere mucho contexto).

### Modo paralelo (`--parallel`)

```
/validate all --parallel
```

Lanza un subagente independiente por dominio. Cada subagente recibe las specs y contratos de su dominio y corre los niveles 1-4. Los reportes se consolidan al final.

- **Cuándo usar**: proyectos con 6+ dominios donde la validación secuencial tarda varios minutos
- **No usar con**: `--profile pre-deploy` (el Nivel 5 requiere visión completa del proyecto)

**Formato de progreso por subagente** (reporte compacto al consolidar):
```
[negocio]    ✅ OK          — 0 gaps
[producto]   ❌ BLOQUEANTE  — 3 gaps (ALTA: 2, MEDIA: 1, INFO: 0)
[datos]      ⚠️  ADVERTENCIAS — 1 gap  (ALTA: 0, MEDIA: 1, INFO: 0)
[seguridad]  ✅ OK          — 0 gaps
[infra]      ⚠️  ADVERTENCIAS — 1 gap  (ALTA: 0, MEDIA: 0, INFO: 1)
```

Cada subagente DEBE usar exactamente este formato para que el consolidador los pueda agregar.

### Modo corrección automática (`--fix`)

Cuando se pasa `--fix`, el agente [[analyst]] aplica correcciones automáticas inmediatamente después de reportar cada gap de severidad MEDIA o INFO:

| Gap auto-corregible | Acción |
|---------------------|--------|
| Spec `status: approved` sin campo `last_updated` | Inserta `last_updated: <fecha-actual>` en frontmatter |
| Spec `status: approved` sin campo `expires` | Inserta `expires: <fecha+90d>` en frontmatter |
| Sección de spec con solo encabezado y sin contenido | Añade `[PENDIENTE: completar esta sección]` |

Qué **NO** corrige automáticamente (requiere humano):
- Gaps de severidad ALTA
- Breaking changes en contratos
- Conflictos entre specs de distintos dominios
- Specs aprobadas con `[PENDIENTE]` (regresionar a `status: review` es decisión humana)

Cada corrección aplicada se reporta con `[FIXED]` en el output:
```
  [FIXED] specs/06-seguridad/requisitos.md → añadido last_updated: 2026-05-31
  [FIXED] specs/07-infra/infraestructura.md → añadido expires: 2026-08-29
```

## Validaciones por nivel

### Nivel 1 — Estructura (¿existen los archivos?)

- Todas las specs listadas en [[spec-manifest]] existen como archivos
- Ningún archivo de spec está vacío o solo contiene la plantilla sin rellenar
- Los contratos referenciados en el manifest existen en `contracts/`

### Nivel 1.5 — Frescura de specs aprobadas

Para toda spec con `status: approved` en el frontmatter:

1. Verificar `last_updated` en el frontmatter
2. Si `last_updated` tiene más de 90 días Y el código asociado tiene commits recientes en los últimos 30 días:
   - `[SEV: INFO]` — Spec aprobada con posible drift por tiempo — recomendar re-validar
3. Si el frontmatter incluye `expires:` y la fecha ya pasó:
   - `[SEV: MEDIA]` — Spec aprobada expirada — cambiar status a `review` y notificar

> El campo opcional `expires: "YYYY-MM-DD"` puede añadirse al frontmatter de cualquier spec. El comando `/approve` lo calcula automáticamente sumando 90 días a la fecha de aprobación.

**Con `--notify N`** — reporta también specs que expirarán en los próximos N días:

```
⏰ PRÓXIMAS A EXPIRAR (< 30 días):
   [INFO] producto/historias-usuario.md — expira 2026-06-12 (en 14 días)
   [INFO] arquitectura/arquitectura.md  — expira 2026-06-18 (en 20 días)

Acción: /review [dominio] antes de que expiren para renovar la aprobación.
```

**Con `--all`** — muestra estado completo de todas las specs aprobadas (no solo las problemáticas).

### Nivel 2 — Completitud (¿están completas?)

- Cada objetivo de negocio tiene al menos 1 requerimiento funcional mapeado
- Cada requerimiento Must-Have tiene al menos 1 historia de usuario
- Cada historia tiene criterios de aceptación en formato Gherkin
- El stack tecnológico cubre frontend, backend, base de datos y hosting
- El threat model cubre todos los componentes del diagrama de arquitectura
- **Specs con `status: approved` NO deben contener `[PENDIENTE]`**:
  - Si se encuentra `[PENDIENTE]` en una spec aprobada → `[SEV: ALTA]` — Spec aprobada con contenido incompleto — regresionar a `status: review`
  - Aplica también a filas de tabla vacías (`| | | | |`) y comentarios sin rellenar (`<!-- ... -->` sin contenido real)

### Nivel 3 — Consistencia (¿se contradicen?)

- Los campos del [[modelo]] de datos coinciden con los [[example.json|JSON Schemas]] en `contracts/schemas/`
- Los endpoints de [[integraciones]] coinciden con los [[example.yaml|OpenAPI]] en `contracts/api/`
- El [[example.sql|DDL]] en `contracts/ddl/` coincide con el [[modelo]]
- Los nombres de servicios en arquitectura coinciden con los de infraestructura y CI/CD
- Los SLOs de monitoreo coinciden con los definidos en sla-slo.md

> Para verificación profunda de compatibilidad **consumer-provider** más allá de la consistencia sintáctica (garantizar que los consumers reales pueden consumir el provider), usar [[contract-tester]] con `--pact` (tests de contrato generables) o `--prism` (mock del contrato para correr acceptance tests). Invocable con `/contract test <archivo>`.

### Nivel 3.5 — Campos en prosa vs contratos

Para cada dominio con contratos formales (datos, seguridad, arquitectura):

1. Extraer todos los nombres de campos citados en backticks en la prosa de las specs:
   - Regex: `` `[a-z_][a-z0-9_]*` `` — captura nombres como `user_id`, `created_at`, `email`
2. Para cada campo extraído, verificar que existe en al menos uno de:
   - El DDL del dominio (`contracts/ddl/*.sql`)
   - El JSON Schema (`contracts/schemas/*.json`)
   - El contrato OpenAPI (`contracts/api/*.yaml`)
3. Si un campo aparece en la prosa pero en ningún contrato:
   - `[SEV: MEDIA]` — Campo `{nombre}` documentado en specs/{dominio}/... pero sin contrato formal

> Esto captura cuando alguien escribe en `modelo.md` "el campo `verified_at` indica..." pero se olvida de agregar la columna al DDL.

### Nivel 3.6 — Backward compatibility de contratos (requiere git)

Cuando los contratos en `contracts/` han cambiado respecto al commit anterior:

1. Obtener la versión anterior del contrato: `git show HEAD~1:contracts/api/{nombre}.yaml`
2. Comparar contra la versión actual
3. Detectar cambios **BREAKING**:
   - Endpoint removido o renombrado → `[SEV: ALTA]` BREAKING CHANGE
   - Campo `required` eliminado de request body → `[SEV: ALTA]` BREAKING CHANGE
   - Tipo de campo cambiado (string → integer, etc.) → `[SEV: ALTA]` BREAKING CHANGE
   - Código HTTP de respuesta exitosa cambiado (200 → 201, etc.) → `[SEV: MEDIA]` BREAKING CHANGE
4. Detectar cambios **NON-BREAKING** (solo advertencia):
   - Campo opcional añadido
   - Endpoint nuevo añadido
   - Descripción actualizada
5. Si hay cambios BREAKING sin bumping de versión en el path (`/api/v1/` vs `/api/v2/`):
   - `[SEV: ALTA]` — Breaking change en contrato sin versionar — considera `/api/v2/` o documentar en ADR

> Esta validación solo corre si git está disponible y hay historial. Si es el primer commit, se omite.

### Nivel 4 — Trazabilidad (¿se conecta todo?)

Matriz completa: Objetivo → Requerimiento → Historia → Test → Componente

**Con `/validate traceability`**, además de mostrar en consola, **persiste la matriz en `docs/traceability-matrix.md`**:

```markdown
# Traceability Matrix — {proyecto}
> Generada por /validate traceability el {fecha}

| Objetivo | REQ-FUNC | Historia | Test | Componente |
|----------|----------|---------|------|------------|
| OBJ-001 | REQ-FUNC-001 | HU-001 | test_HU001_registro | src/auth/users.service.ts |

## Gaps detectados
| Tipo | ID | Descripción |
|------|-----|-------------|
| Sin test | HU-007 | Historia sin test de aceptación |

## Cobertura: {N}% ({n}/{total} historias con test)
```

El archivo se sobreescribe en cada ejecución — siempre muestra el estado actual.

### Nivel 5 — Drift Detection (¿el código refleja las specs?)

Activado por `/validate drift` o automáticamente en `/predeploy`.

El agente [[analyst]] en modo drift inspecciona el código fuente completo (`src/`, `packages/*/src/`, `lib/`, `app/`) y lo compara contra specs y contratos.

**Con headers de trazabilidad** (`// Generated from:`, `// Spec:`, `// Contract:`, `# Generated from:`, `# Spec:`, `# Contract:`):
- Localiza la spec o contrato referenciado directamente
- Compara endpoints, campos, códigos HTTP, reglas de negocio y efectos secundarios

**Sin headers de trazabilidad** (fallback automático):
- Extrae nombres de clases, funciones públicas y rutas del archivo
- Busca cobertura en specs via grep + graphify query
- Si hay cobertura implícita → OK, recomienda agregar header
- Si no hay cobertura → **código huérfano**, drift MEDIA

**Detecta en ambos casos:**
- Campos / parámetros en código que no existen en ningún contrato → ALTA
- Endpoints sin definición OpenAPI → ALTA
- Guards de autenticación que no coinciden con requisitos de seguridad → ALTA
- Código sin ninguna spec que lo respalde → MEDIA
- Specs Must-Have sin ninguna implementación encontrada → INFO

Veredicto: BLOQUEANTE (hay items ALTA) · ADVERTENCIAS (solo MEDIA) · OK

Uso: `/validate drift` — ejecuta solo Nivel 5

## Output

```
╔══════════════════════════════════════════════╗
║  SPEC-DRIVEN VALIDATION REPORT              ║
╠══════════════════════════════════════════════╣
║  Dominio: [nombre]                          ║
║  Fecha: [timestamp]                         ║
╠══════════════════════════════════════════════╣
║  ✅ Estructura    [N/N archivos presentes]  ║
║  ✅ Frescura      [N specs, 0 expiradas]    ║
║  ⚠️  Completitud  [N gaps encontrados]      ║
║  ❌ Consistencia  [N conflictos]            ║
║  ⚠️  Prosa↔Contr. [N campos sin contrato]   ║
║  ✅ Compat. API   [sin breaking changes]    ║
║  📊 Trazabilidad  [N% cobertura]            ║
╚══════════════════════════════════════════════╝

GAPS:
  - [SEV: ALTA]  specs/01-negocio/vision.md: status=approved pero contiene 3 [PENDIENTE]
  - [SEV: ALTA]  REQ-FUNC-003 no tiene historia de usuario asociada
  - [SEV: MEDIA] Endpoint POST /orders no tiene definición OpenAPI
  - [SEV: MEDIA] Campo `verified_at` en modelo.md sin DDL correspondiente
  - [SEV: INFO]  specs/06-seguridad/requisitos.md aprobada hace 95 días — revisar frescura

CONFLICTOS:
  - Campo "user.email" es VARCHAR(100) en DDL pero maxLength:255 en JSON Schema

BREAKING CHANGES:
  - contracts/api/orders.yaml: campo 'status' removido de required[] (era obligatorio)
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/validate producto</input>
    <output>
    ╔══════════════════════════════════════════════╗
    ║  SPEC-DRIVEN VALIDATION REPORT              ║
    ╠══════════════════════════════════════════════╣
    ║  Dominio: producto                          ║
    ║  Fecha: 2026-05-29                          ║
    ╠══════════════════════════════════════════════╣
    ║  ✅ Estructura    [4/4 archivos presentes]  ║
    ║  ✅ Frescura      [1 aprobada, 0 expiradas] ║
    ║  ❌ Completitud   [2 gaps]                  ║
    ║  ✅ Consistencia  [sin conflictos]           ║
    ╚══════════════════════════════════════════════╝

    GAPS:
      - [ALTA]  historias-usuario.md: status=approved con 2 [PENDIENTE]
      - [ALTA]  REQ-FUNC-003 sin historia de usuario

    VEREDICTO: BLOQUEANTE — resolver antes de /approve
    </output>
  </example>
  <example>
    <input>/validate all --parallel</input>
    <output>
    Lanzando subagentes paralelos para 5 dominios...
    
    [negocio]   ✅ OK — 0 gaps
    [producto]  ❌ BLOQUEANTE — 2 gaps ALTA
    [datos]     ⚠️  ADVERTENCIAS — 1 gap MEDIA
    [seguridad] ✅ OK — 0 gaps
    [infra]     ⚠️  ADVERTENCIAS — 1 campo sin contrato

    RESUMEN CONSOLIDADO:
      1 dominio BLOQUEANTE (producto) — debe resolverse antes de /approve
      2 dominios con ADVERTENCIAS — revisar pero no bloquean
      2 dominios OK

    Acción requerida: /grill-spec producto
    </output>
  </example>
</examples>

## Agente que ejecuta

Este comando invoca al agente [[analyst]] con permisos de solo lectura.

## Comandos relacionados

- [[generate]] — ejecutar después de validar
- [[build]] — pipeline completo que incluye /validate
- [[predeploy]] — Nivel 5 drift
- [[analyze]] — dashboard de estado de specs, sin leer código
- [[approve]] — marcar dominio como aprobado tras validación exitosa
- [[migration-planner]] — cuando el Nivel 3.6 detecta breaking changes en contratos
- [[spec-changelog]] — historial de aprobaciones y cambios detectado por /validate freshness
- [[review]] — revisión de calidad semántica (siguiente paso tras /validate, antes de /approve)
- [[grill-spec]] — ejecuta /validate automáticamente al terminar la entrevista de completitud de specs
- [[contract]] — gestión y validación formal de contratos (los Niveles 3, 3.5, 3.6 de /validate validan los contratos del proyecto)
- [[contract-tester]] — verificación consumer-provider más profunda que el Nivel 3 (Pact/Prism); invocar con `/contract test` cuando se detectan gaps de compatibilidad
- [[compliance-checker]] — verificar cumplimiento normativo (GDPR/SOC2/HIPAA/PCI-DSS) tras /validate en dominios de seguridad o legal
- [[sbom]] — inventario de dependencias; /validate reporta ausencia de SBOM como gap INFO si hay requisitos regulatorios activos
- [[spec-auditor]] — auditoría exhaustiva del dominio; usa /validate como paso de re-verificación tras las correcciones que identifica
- [[sync-issues]] — sincronizar REQ-FUNC con sistemas externos cuando /validate confirma que están completos
- **Regla relacionada**: [[spec-sync]] — política code↔spec
- **Referencia central**: [[spec-manifest]]
