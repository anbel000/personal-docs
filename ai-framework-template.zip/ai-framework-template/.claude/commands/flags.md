---
name: flags
description: "Gestión de feature flags como ciudadanos de primera clase: inventario, validación drift, creación y deprecación. Uso: /flags <subcomando>"
---

# Comando: /flags

**Argumentos**: `$ARGUMENTS`

Gestiona feature flags como artefactos de primera clase del framework. Aplica la regla [[feature-flags]]: todo flag en código productivo debe tener spec con `kill_date` y `linked_req`.

## Uso

```
/flags list                 # Inventario: flags en código vs flags en specs
/flags validate             # Detecta drift flags código↔spec (severidades ALTA/MEDIA/INFO)
/flags create <nombre>      # Crea entrada de spec desde template interactivo
/flags deprecate <nombre>   # Marca flag para eliminación + genera ADR
/flags clean                # Lista flags con kill_date vencida que aún están en código
```

## Subcomandos en detalle

### `list`

Escanea el código fuente (`src/`, `packages/`, `lib/`) buscando patrones de feature flag:
- TypeScript/JavaScript: `featureFlag('nombre')`, `isEnabled('nombre')`, `flags.get('nombre')`, `if (FF_NOMBRE)`
- Python: `feature_flag('nombre')`, `is_enabled('nombre')`, `FLAGS.get('nombre')`
- Variables de entorno con prefix `FF_`: `process.env.FF_NOMBRE`, `os.getenv('FF_NOMBRE')`

Luego cruza contra `specs/**/feature-flags.md` y reporta:

```
FLAGS INVENTORY — mi-proyecto
══════════════════════════════════════════════
En código:  7 flags detectados
En specs:   5 flags documentados
Drift ALTA: 1  (kill_date vencida)
Drift MEDIA: 2  (sin spec)
INFO:        1  (en specs, no en código)

Flags en código sin spec (MEDIA):
  ⚠️  dark-mode-v2           src/ui/theme.ts:47
  ⚠️  ai-suggestions-beta   packages/backend/src/features.ts:12

Flags con kill_date vencida (ALTA):
  🔴 new-checkout-flow       kill_date: 2026-03-01 (hace 61 días) — specs/02-producto/feature-flags.md

En specs sin código (INFO):
  ℹ️  legacy-api-bridge       sin referencia en código — posible flag obsoleto

Flags OK (5):
  ✅ new-dashboard-ui         kill_date: 2026-07-15  — specs/02-producto/feature-flags.md
  ✅ payment-v2               kill_date: 2026-08-01  — specs/02-producto/feature-flags.md
  [...]
```

### `validate`

Equivalente a `/flags list` pero integrado con el sistema de severidades de `/validate`. Devuelve los mismos resultados en el formato estándar de gaps para ser incluido en reportes de `/validate drift`.

### `create <nombre>`

Crea una entrada de spec para el flag en `specs/02-producto/feature-flags.md` (o el dominio especificado):

```
Creando spec para flag: dark-mode-v2
  owner [PENDIENTE]: 
  default_value (on/off) [off]: 
  rollout (gradual/all/none) [gradual]: 
  kill_date (YYYY-MM-DD) [PENDIENTE]: 
  linked_req (REQ-FUNC-XXX) [PENDIENTE]: 
  description: 
```

Con `--quick`: crea el template con todos los campos [PENDIENTE] sin preguntas interactivas.

### `deprecate <nombre>`

Inicia el flujo formal de deprecación de un flag:

1. Marca el flag como `status: deprecated` en la spec
2. Genera `docs/adr/NNNN-deprecation-flag-{nombre}.md` con:
   - Razón para eliminar el flag
   - Fecha límite sugerida: `kill_date` o +2 semanas si ya venció
   - Lista de archivos donde aparece el flag en código
3. Muestra la lista de refs en código para guiar la eliminación manual

```
/flags deprecate new-checkout-flow

Iniciando deprecación de 'new-checkout-flow':
  ✅ Marcado como deprecated en specs/02-producto/feature-flags.md
  ✅ ADR-0007-deprecation-flag-new-checkout-flow.md generado
  
  Referencias en código a eliminar (3 archivos):
    src/checkout/flow.ts:23    — if (featureFlag('new-checkout-flow'))
    src/checkout/flow.ts:89    — const isNew = flags.get('new-checkout-flow')
    packages/frontend/app/cart/page.tsx:15
  
  Fecha límite sugerida: 2026-06-14 (2 semanas desde hoy)
```

### `clean`

Lista todos los flags con `kill_date` ya vencida que siguen referenciados en código:

```
FLAGS VENCIDOS — pendientes de eliminación
══════════════════════════════════════════════
  🔴 new-checkout-flow   Venció: 2026-03-01 (hace 61 días)
     Owner: @pm-jsmith
     Refs: 3 archivos (ver /flags deprecate new-checkout-flow)

  🔴 old-search-ui       Venció: 2026-04-15 (hace 46 días)
     Owner: @dev-maria
     Refs: 1 archivo

Total: 2 flags vencidos — ejecutar /flags deprecate <nombre> para cada uno
```

## Agente que ejecuta

El propio Claude con permisos de lectura y escritura (Read, Write, Edit, Glob, Grep).

## Regla aplicada

Ver [[feature-flags]] — política completa de feature flags como ciudadanos de primera clase.

## Comandos relacionados

- [[feature-flags]] — regla completa de política de feature flags que este comando enforces
- [[validate]] — el Nivel 5 de /validate drift incluye detección de flag drift (severidad ALTA/MEDIA)
- [[analyze]] — /analyze reporta el conteo de flags sin spec como parte del estado del proyecto
- [[spec-sync]] — los flags nuevos y sus specs van en el mismo commit
- [[contract]] — para flags que cambian el comportamiento de la API, crear ADR con /contract bump
