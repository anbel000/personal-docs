---
name: graphifyllm
description: "Configura el modelo LLM del extractor semántico de graphify. Sin args: lista modelos. Con arg: cambia modelo. Uso: /graphifyllm [modelo|on|off]"
---

# Comando: /graphifyllm

**Argumentos**: `$ARGUMENTS`

Gestiona el modelo LLM que usa el extractor semántico de graphify para inferir
relaciones entre nodos del conectoma.

## Uso

```
/graphifyllm                              # Lista modelos disponibles y el actual
/graphifyllm claude-haiku-4-5-20251001    # Setea Haiku (default, barato)
/graphifyllm claude-sonnet-4-6            # Setea Sonnet (mejor calidad, ~5x caro)
/graphifyllm claude-opus-4-7              # Setea Opus (máxima calidad, ~25x caro)
/graphifyllm off                          # Modo AST puro — cero tokens LLM
/graphifyllm on                           # Vuelve a modo LLM con el modelo guardado
```

## Comportamiento

- **Sin argumentos**: Lee `graphify/llm.config.yml`, imprime la lista de modelos
  disponibles con el actual marcado y el costo relativo de cada uno.
- **Con modelo**: Valida que esté en `available_models`, edita el campo `model:`
  en `graphify/llm.config.yml` y confirma. **No re-ejecuta `/graphify`.**
- **`off`**: Setea `enabled: false`. El próximo `/graphify` usará solo AST.
- **`on`**: Setea `enabled: true`, reactiva el modelo guardado.

## Cuándo cambiar de modelo

| Situación | Modelo recomendado |
|-----------|-------------------|
| Uso cotidiano | Haiku (default) |
| Relaciones semánticas complejas | Sonnet |
| Revisión profunda pre-release | Opus |
| CI/CD o reconstrucción frecuente | `off` (AST puro) |

## Config editada

`graphify/llm.config.yml` — el comando `/graphify` lo lee antes de invocar el extractor.
Cambiar el modelo solo actualiza la config; aplica en el próximo `/graphify`.

<examples>
  <example>
    <input>/graphifyllm</input>
    <output>
Leyendo graphify/llm.config.yml...

Modelo actual: claude-haiku-4-5-20251001 ✅ ACTIVO

Modelos disponibles:
  claude-haiku-4-5-20251001    (default · ~$0.001/build · velocidad: alta)
  claude-sonnet-4-6            (~$0.005/build · calidad: alta)
  claude-opus-4-7              (~$0.025/build · calidad: máxima)
  off                          (AST puro · $0/build · sin inferencia semántica)

Para cambiar: /graphifyllm <modelo>
    </output>
  </example>
  <example>
    <input>/graphifyllm off</input>
    <output>
graphify/llm.config.yml actualizado:
  enabled: false   (anterior: true)
  model:   claude-haiku-4-5-20251001   (guardado para cuando reactives con /graphifyllm on)

Modo AST puro activado. El próximo /graphify no consumirá tokens LLM.
Ideal para: CI/CD, rebuilds frecuentes, proyectos donde el grafo de imports es suficiente.

Para reactivar: /graphifyllm on
    </output>
  </example>
</examples>

## Comandos relacionados

- [[graphify]] — comando cuya configuración LLM gestiona este comando
- [[graphify-specs]] — alternativa zero-LLM que produce el mismo wiki sin configuración LLM
- **Config**: `graphify/llm.config.yml`
- **Guía completa**: `graphify/GRAPHIFY.md`
