---
name: sync-issues
description: "Sincroniza requerimientos (REQ-FUNC) con issues en Linear o GitHub Issues via MCP. Uso: /sync-issues [dominio] [--to|--from] [platform]"
---

# Comando: /sync-issues

**Argumentos**: `$ARGUMENTS`

Sincroniza los requerimientos funcionales (`REQ-FUNC-NNN`) del proyecto con el tracker de issues del equipo (Linear o GitHub Issues). Elimina la duplicación manual de tickets.

**Requiere MCP configurado** — ver sección de configuración.

## Uso

```
/sync-issues                                 # Lista divergencias sin cambiar nada
/sync-issues producto --to github            # Crea/actualiza issues en GitHub desde REQ-FUNC del dominio
/sync-issues producto --to linear            # Crea/actualiza issues en Linear
/sync-issues producto --from github          # Importa issues de GitHub como REQ-FUNC en specs
/sync-issues all --to github                 # Sincroniza todos los dominios
/sync-issues producto --to github --dry-run  # Muestra qué crearía/actualizaría sin hacer nada
```

## Qué sincroniza

| Campo en spec | Campo en GitHub Issue | Campo en Linear |
|---------------|----------------------|-----------------|
| ID (REQ-FUNC-001) | Title prefix `[REQ-FUNC-001]` | Title prefix + Label |
| Nombre | Issue title | Issue title |
| Descripción | Issue body (sección "Descripción") | Issue description |
| Prioridad (Must/Should/Could) | Label (`priority:must`, etc.) | Priority field |
| `status: approved` del dominio | Label `spec:approved` | Status field |
| Criterio de aceptación | Issue body (sección "Criterios") | Sub-issues o checklist |

## Flujo `--to` (spec → tracker)

```
1. Leer specs/NN-{dominio}/requerimientos.md
2. Extraer todos los REQ-FUNC-NNN
3. Para cada REQ-FUNC:
   a. Buscar issue existente con el ID en el título
   b. Si no existe → crear nuevo issue
   c. Si existe y hay diferencias → actualizar (body, labels, prioridad)
   d. Si ya está sincronizado → saltar
4. Reportar: N creados, N actualizados, N sincronizados
```

## Flujo `--from` (tracker → spec)

```
1. Leer issues del tracker con label `spec-driven` o en el proyecto configurado
2. Para cada issue:
   a. Verificar si ya existe un REQ-FUNC-NNN en las specs
   b. Si no existe → generar el siguiente ID (REQ-FUNC-NNN+1) y añadir a requerimientos.md
   c. Si existe → actualizar descripción si el issue fue modificado
3. Reportar: N importados, N actualizados, N ignorados
```

## Configuración MCP

Para usar este comando, necesitas MCP configurado en `.claude/mcp.json`:

**GitHub Issues:**
```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

**Linear:**
```json
{
  "mcpServers": {
    "linear": {
      "command": "npx",
      "args": ["-y", "@linear/mcp-server"],
      "env": {
        "LINEAR_API_KEY": "${LINEAR_API_KEY}"
      }
    }
  }
}
```

Variables de entorno en `.env.local` (nunca commitear):
```
GITHUB_TOKEN=ghp_...
LINEAR_API_KEY=lin_api_...
```

## Modo `--dry-run`

```
DRY-RUN: /sync-issues producto --to github
────────────────────────────────────────────
Issues a crear (2):
  → [REQ-FUNC-005] Recuperación de contraseña
  → [REQ-FUNC-008] Exportación de datos en CSV

Issues a actualizar (1):
  → [REQ-FUNC-003] Registro de usuario  (descripción cambió)

Issues ya sincronizados (5): REQ-FUNC-001, 002, 004, 006, 007

Para ejecutar: /sync-issues producto --to github (sin --dry-run)
```

## Reglas

- Este comando NUNCA borra issues en el tracker — solo crea y actualiza
- Los cambios en el tracker NO sobreescriben specs automáticamente (requiere `--from` explícito)
- Sin MCP configurado, el comando explica qué necesita y no intenta conectarse
- El campo `expires` de specs aprobadas se sincroniza como fecha de revisión en el tracker

<examples>
  <example>
    <input>/sync-issues producto --to github --dry-run</input>
    <output>
DRY-RUN: /sync-issues producto --to github
────────────────────────────────────────────
Leyendo specs/02-producto/requerimientos.md → 12 REQ-FUNC encontrados
Consultando GitHub Issues (repo: org/fintrack)...

Issues a crear (3):
  → [REQ-FUNC-005] Recuperación de contraseña
  → [REQ-FUNC-008] Exportación de datos en CSV
  → [REQ-FUNC-011] Notificaciones de presupuesto excedido

Issues a actualizar (2):
  → [REQ-FUNC-003] Registro de usuario       (descripción actualizada en specs)
  → [REQ-FUNC-007] Categorización de gastos  (criterios Gherkin añadidos)

Issues ya sincronizados (7): REQ-FUNC-001, 002, 004, 006, 009, 010, 012

Para ejecutar: /sync-issues producto --to github
    </output>
  </example>
  <example>
    <input>/sync-issues producto --to github</input>
    <output>
Sincronizando specs/02-producto/requerimientos.md → GitHub Issues...

✅ Issues creados (3):
   #47 — [REQ-FUNC-005] Recuperación de contraseña
   #48 — [REQ-FUNC-008] Exportación de datos en CSV
   #49 — [REQ-FUNC-011] Notificaciones de presupuesto excedido

✅ Issues actualizados (2):
   #12 — [REQ-FUNC-003] Registro de usuario
   #31 — [REQ-FUNC-007] Categorización de gastos

➡️  Issues ya sincronizados (7): sin cambios

Total: 3 creados · 2 actualizados · 7 sin cambios
    </output>
  </example>
</examples>

## Comandos relacionados

- [[analyze]] — para ver el estado de requerimientos antes de sincronizar
- [[validate]] — para confirmar que los REQ-FUNC están completos antes de exportar
- [[spec-changelog]] — para ver historial de cambios en requerimientos
