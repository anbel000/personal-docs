---
name: build
description: "Pipeline completo: valida specs → genera código → ejecuta tests. Uso: /build [--resume] [--skip-tests] [--dry-run]"
---

# Comando: /build

**Argumentos**: `$ARGUMENTS`

Ejecuta el pipeline completo de construcción del proyecto desde las specs.

## Uso

```
/build                  # Pipeline completo desde el inicio
/build --resume         # Retoma desde el último paso completado (lee docs/build-state.json)
/build --dry-run        # Solo muestra qué haría, sin generar archivos
/build --skip-tests     # Genera código pero no ejecuta tests (omite paso 3)
/build --skip-predeploy # Omite drift check (solo para entornos de desarrollo)
```

## Pipeline de ejecución

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌─────────────┐    ┌──────────────┐
│  1. VALIDATE │───▶│  2. GENERATE │───▶│  3. TEST    │───▶│  4. PREDEPLOY│───▶│  5. DASHBOARD│
│  /validate   │    │  /generate   │    │  ejecutar   │    │  drift check │    │  spec-dash + │
│  all         │    │  all         │    │  tests      │    │  + wiki sync │    │  build-state │
└─────────────┘    └──────────────┘    └─────────────┘    └─────────────┘    └──────────────┘
       │                   │                  │                   │                   │
   Si hay gaps         Si hay specs       Si hay tests       Si hay drift →      Siempre
   críticos →          vacías →           fallidos →         PARAR               genera
   PARAR               ADVERTIR           ADVERTIR                               artefactos
```

### Paso 1: Validate

- Ejecuta [[validate|/validate all]]
- Si hay errores de severidad CRÍTICA → detener pipeline
- Si hay warnings → continuar con advertencia
- Persiste resultado en `docs/build-state.json` → `steps.validate`

### Paso 2: Generate

- Ejecuta [[generate|/generate all]] en el orden de dependencias
- Registra cada archivo generado/modificado
- Persiste resultado en `docs/build-state.json` → `steps.generate`

### Paso 3: Test

- Ejecuta los tests generados: unit → integration → e2e
- Reporta cobertura y fallos
- Persiste resultado en `docs/build-state.json` → `steps.test`

### Paso 4: Predeploy

- Ejecuta [[predeploy|/predeploy --strict]]
- Drift detection: compara código modificado contra sus specs referenciadas
- Si hay drift → detener pipeline — actualizar specs antes de deployar
- Refresh del grafo de specs (ver [[predeploy]] para el flujo exacto)
- Persiste resultado en `docs/build-state.json` → `steps.predeploy`

### Paso 5: Dashboard

Genera dos artefactos:

**`docs/build-report.md`** — reporte técnico para el equipo:
- Timestamp del build
- Specs procesadas y su estado
- Archivos generados (con diff si es rebuild)
- Resultados de tests
- Estado de drift (specs sincronizadas o pendientes)
- Gaps pendientes y recomendaciones

**`docs/spec-dashboard.md`** — dashboard de estado para stakeholders:
- Completitud por dominio (barra visual con %)
- Estado de contratos formales (presentes / válidos / sincronizados)
- Resumen de tests (total / pasando / fallando / cobertura)
- Última build exitosa (timestamp + quién ejecutó)
- PRs en progreso relacionados con specs

Persiste resultado final en `docs/build-state.json` → `steps.dashboard` + `build.status`.

## Mecanismo de resume (`--resume`)

Cuando se pasa `--resume`, el comando:

1. Lee `docs/build-state.json`
2. Identifica el último paso con `status: "completed"`
3. Salta todos los pasos anteriores (ya completados)
4. Retoma desde el primer paso con `status: "failed"` o `status: "pending"`
5. Si no existe `build-state.json` → inicia desde el principio

```json
// docs/build-state.json (estructura)
{
  "build": {
    "id": "build-20260529-143022",
    "started_at": "2026-05-29T14:30:22Z",
    "status": "in_progress",
    "triggered_by": "manual"
  },
  "steps": {
    "validate": {
      "status": "completed",
      "completed_at": "2026-05-29T14:31:05Z",
      "summary": "Niveles 1-4 OK, 2 warnings nivel 3.5",
      "errors": []
    },
    "generate": {
      "status": "completed",
      "completed_at": "2026-05-29T14:35:18Z",
      "summary": "42 archivos generados, 3 actualizados",
      "errors": []
    },
    "test": {
      "status": "failed",
      "completed_at": "2026-05-29T14:40:02Z",
      "summary": "28/30 tests pasaron, 2 fallaron",
      "errors": ["tests/integration/auth.test.ts:45 — timeout"]
    },
    "predeploy": {
      "status": "pending",
      "completed_at": null,
      "summary": null,
      "errors": []
    },
    "dashboard": {
      "status": "pending",
      "completed_at": null,
      "summary": null,
      "errors": []
    }
  }
}
```

## Formato de `docs/spec-dashboard.md`

```markdown
# Spec Dashboard — {nombre-proyecto}

> Generado por `/build` el {timestamp}. Última build exitosa: {fecha}.

## Estado por dominio

| Dominio       | Completitud | Contratos | Aprobado por  | Últ. cambio |
|---------------|-------------|-----------|---------------|-------------|
| negocio       | ████████░░ 80% | N/A    | Business Owner | 2026-05-28 |
| producto      | █████████░ 90% | ✅ 3/3  | PM             | 2026-05-27 |
| arquitectura  | ██████████100% | ✅ 2/2  | Tech Lead      | 2026-05-26 |
| datos         | ████████░░ 80% | ✅ 4/4  | Data Arch      | 2026-05-25 |
| seguridad     | ██████████100% | ✅ 1/1  | CISO           | 2026-05-24 |
| infra         | ████████░░ 75% | N/A    | SRE Lead       | 2026-05-20 |

## Estado de tests

- Total: 30 | Pasando: 28 | Fallando: 2 | Cobertura: 87%

## Próximas acciones

1. Corregir 2 tests fallidos en `tests/integration/auth.test.ts`
2. Completar 5 [PENDIENTE] en `specs/07-infra/sla-slo.md`
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/build</input>
    <output>
🔨 BUILD — crm-startup — 2026-05-29T18:00:00Z

Paso 1/5: /validate all
  ✅ Niveles 1-4 OK · 1 advertencia (campo `verified_at` sin DDL — MEDIA)

Paso 2/5: /generate all
  ✅ arquitectura  →  8 archivos
  ✅ datos         → 12 archivos
  ✅ seguridad     →  4 archivos
  ✅ producto      → 11 archivos
  ✅ calidad       → 28 tests
  ✅ infra         →  6 archivos

Paso 3/5: Tests
  ✅ 28/28 tests pasaron · cobertura: 89%

Paso 4/5: /predeploy
  ✅ Sin drift detectado · graphify-out/ actualizado (248 nodos)

Paso 5/5: Dashboard
  ✅ docs/build-report.md generado
  ✅ docs/spec-dashboard.md actualizado

BUILD COMPLETADA ✅
  69 archivos generados · 0 errores · 1 advertencia
  docs/build-state.json actualizado
    </output>
  </example>
  <example>
    <input>/build --resume</input>
    <output>
🔨 BUILD RESUME — crm-startup

Leyendo docs/build-state.json...
  ✅ validate: completado (2026-05-29T14:31:05Z)
  ✅ generate: completado (2026-05-29T14:35:18Z)
  ❌ test: fallido — retomando desde aquí

Paso 3/5: Tests (retomado)
  tests/integration/auth.test.ts — 2 tests fallidos
    auth.test.ts:45 — timeout en POST /auth/refresh

Corrigiendo... (usuario resuelve el test)

  ✅ 30/30 tests pasaron

Paso 4/5: /predeploy ✅
Paso 5/5: Dashboard ✅

BUILD COMPLETADA ✅
    </output>
  </example>
</examples>

## Pre-condiciones

- [[spec-manifest]] debe existir
- Al menos [[arquitectura]] y [[modelo]] deben tener contenido real (no solo plantilla)
- Los contratos en `contracts/` deben ser válidos (YAML/JSON/SQL parseable)

## Agentes involucrados

Invoca secuencialmente: [[analyst]] → [[architect]] → [[data-engineer]] → [[product]] → [[designer]] → [[iot-engineer]] → [[implementer]] → [[qa]] → [[devops]] → [[security-reviewer]]

## Comandos relacionados

- **Comandos que orquesta**: [[validate]] (paso 1) · [[generate]] (paso 2) · [[predeploy]] (paso 4)
- [[analyze]] — diagnóstico sin generar código
- [[status]] — health check rápido
- **Regla relacionada**: [[spec-sync]] — política code↔spec
- **Artefactos**: `docs/build-report.md` · `docs/spec-dashboard.md` · `docs/build-state.json`
