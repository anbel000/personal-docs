---
name: onboard
description: "Genera una guía de onboarding para nuevos miembros del equipo basada en las specs actuales. Uso: /onboard [rol]"
---

# Comando: /onboard

**Argumentos**: `$ARGUMENTS`

Genera una guía de onboarding personalizada para nuevos miembros del equipo, derivada del estado actual de las specs del proyecto.

## Uso

```
/onboard                    # Guía general para cualquier rol
/onboard dev                # Guía para desarrolladores
/onboard qa                 # Guía para QA engineers
/onboard pm                 # Guía para Product Managers
/onboard design             # Guía para diseñadores
/onboard ops                # Guía para DevOps/SRE
```

## Qué produce

Un archivo `docs/onboarding/onboarding-{rol}-{fecha}.md` con:

### Para cualquier rol (sección común)

1. **¿Qué es este proyecto?** — Resumen de 3 párrafos derivado de `specs/01-negocio/vision.md`
2. **¿Quiénes son los usuarios?** — De `specs/02-producto/` y `stakeholders.md`
3. **¿Cuál es la arquitectura?** — Diagrama textual de `specs/04-arquitectura/arquitectura.md`
4. **¿Cómo está organizado el repositorio?** — Árbol de directorios con descripción de cada carpeta
5. **¿Quién es quién?** — Tabla de stakeholders con contacto (si está en specs)
6. **Glosario del dominio** — Términos de negocio extraídos de las specs

### Para `dev`

7. Setup del entorno de desarrollo (de `specs/04-arquitectura/stack.md`)
8. Cómo correr el proyecto localmente
9. Flujo de contribución: branches, commits, PRs
10. Convenciones de código activas (`rules/coding-conventions.md`)
11. Cómo correr tests
12. Los 5 endpoints más importantes (de `contracts/api/`)
13. El modelo de datos explicado (de `specs/05-datos/modelo.md`)
14. Decisiones arquitectónicas clave (ADRs en `docs/adr/`)

### Para `qa`

7. Estrategia de testing del proyecto (`specs/08-calidad/estrategia.md`)
8. Cómo correr la suite de tests
9. Criterios de aceptación vigentes
10. Mapa de historias de usuario → tests de aceptación
11. Ambientes disponibles y cómo acceder a ellos

### Para `pm`

7. Roadmap actual (`specs/02-producto/roadmap.md`)
8. Estado de requerimientos (must-have completados vs. pendientes)
9. Métricas de éxito del producto (`specs/01-negocio/vision.md`)
10. Proceso de cambio de specs: cómo proponer, quién aprueba

### Para `design`

7. Design system del proyecto (`specs/03-diseno/design-system.md`)
8. Paleta de colores, tipografía y design tokens vigentes
9. Componentes UI existentes y sus estados
10. Flujos de usuario principales (de `specs/02-producto/flujos.md`)
11. Estándares de accesibilidad aplicados (`specs/08-calidad/accesibilidad.md`)
12. Patrones y anti-patrones de UI/UX establecidos en el proyecto

### Para `ops`

7. Infraestructura actual (`specs/07-infra/infraestructura.md`)
8. Pipeline CI/CD y cómo funciona
9. Runbook de operaciones comunes
10. SLAs/SLOs vigentes
11. Cómo hacer deploy a cada ambiente
12. Cómo investigar incidentes

## Flujo de ejecución

```
1. Leer spec-manifest.yaml → entender qué specs existen
2. Leer specs relevantes según el rol solicitado
3. Sintetizar una guía estructurada y narrativa (no solo links)
4. Incluir secciones "¿Qué hacer el primer día / primera semana?"
5. Escribir el archivo en docs/onboarding/
6. Reportar ubicación del archivo generado
```

## Reglas

- La guía debe poder leerse sin abrir ningún otro archivo — es self-contained
- Si una spec referenciada no existe o está vacía, incluir un placeholder claro: `[Esta sección está pendiente de documentar]`
- El tono es conversacional, no formal — está escrito para alguien nuevo
- Siempre incluir una sección "¿A quién preguntar?" con los stakeholders relevantes
- La guía tiene fecha de generación en el header — invitar a regenerarla cada sprint

## Agente que ejecuta

- [[onboarding-guide]] (`agents-registry/onboarding-guide.md`) — agente especializado en onboarding, adapta el contenido según el rol y genera `docs/onboarding/{rol}.md`

<examples>
  <example>
    <input>/onboard dev</input>
    <output>
Leyendo spec-manifest.yaml → 11 dominios, 8 aprobados
Leyendo specs/01-negocio/vision.md, specs/04-arquitectura/stack.md,
        specs/05-datos/modelo.md, contracts/api/ (3 archivos), docs/adr/ (4 ADRs)

Generando docs/onboarding/onboarding-dev-2026-05-29.md...

✅ Guía generada: docs/onboarding/onboarding-dev-2026-05-29.md

── VISTA PREVIA ───────────────────────────────────────────────
# Guía de Onboarding — Desarrollador
Generada el 2026-05-29 | Proyecto: fintrack

## ¿Qué es este proyecto?
FinTrack es una plataforma de rastreo de gastos y presupuesto mensual para
freelancers. Permite categorizar gastos, definir límites por categoría y
generar reportes exportables en CSV...

## Setup del entorno (primer día)
1. Clonar repo: git clone ...
2. Instalar deps: npm install (Node 20) + pip install -r requirements.txt (Python 3.11)
3. Copiar env: cp .env.example .env.local
4. Levantar DB: docker-compose up -d postgres
5. Correr migraciones: npm run db:migrate
6. Levantar dev: npm run dev

Stack activo: Next.js 14 (frontend) + FastAPI (backend) + PostgreSQL 15

## Los 5 endpoints más importantes
  POST /api/v1/auth/login         — autenticación
  GET  /api/v1/expenses           — listar gastos del usuario
  POST /api/v1/expenses           — registrar gasto
  GET  /api/v1/budgets/monthly    — resumen del mes
  GET  /api/v1/reports/export     — exportar CSV

## Modelo de datos (resumen)
  Usuario → N Gasto (con categoría)
  Usuario → N PresupuestoMensual (1 por mes por usuario)
  Gasto   → 1 Categoría

## Tu primera semana
  Día 1: leer esta guía + correr el proyecto localmente
  Día 2: leer specs/02-producto/ (historias de usuario)
  Día 3: abrir un PR pequeño (fix de test o mejora de tipos)
  Semana: empezar con issue #12 (filtros en listado de gastos)

## ¿A quién preguntar?
  Arquitectura: @carlos (lead backend)
  Producto/HU:  @pm-jsmith
  Deploy/infra: @devops-maria
──────────────────────────────────────────────────────────────
    </output>
  </example>
</examples>

## Comandos relacionados

- [[bootstrap]] — el proyecto generado por bootstrap es el que onboard documenta
- [[analyze]] — para ver el estado de completitud de specs antes de onboard
- [[validate]] — para asegurar que las specs están consistentes
- [[onboarding-guide]] — agente que genera la guía de onboarding personalizada por rol
