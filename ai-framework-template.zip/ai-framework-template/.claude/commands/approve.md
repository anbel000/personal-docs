---
name: approve
description: "Marca un dominio como aprobado en sus specs (status: approved). Uso: /approve <dominio>"
---

# Comando: /approve

**Argumentos**: `$ARGUMENTS`

Marca todas las specs de un dominio como `status: approved` en su frontmatter, registra la aprobación en el changelog y bloquea ediciones no autorizadas en `/validate`.

## Uso

```
/approve negocio            # Aprueba todas las specs del dominio negocio
/approve producto           # Aprueba el dominio de producto
/approve all                # Aprueba todos los dominios sin specs bloqueantes
/approve negocio --rollback # Revierte a status: review (des-aprueba)
/approve negocio --dry-run  # Muestra qué cambiaría sin aplicar
```

## Pre-condiciones

Antes de aprobar, el comando verifica automáticamente:

1. **Sin `[PENDIENTE]`**: ningún archivo del dominio contiene el placeholder `[PENDIENTE]`
   - Si hay `[PENDIENTE]` → rechaza la aprobación con lista de ocurrencias
2. **Sin gaps críticos**: `/validate [dominio]` no reporta errores de severidad ALTA
   - Si hay gaps → muestra los gaps y solicita confirmación explícita del usuario
3. **Contratos sincronizados**: si el dominio tiene contratos formales, están en sync con la prosa
   - Si hay desync de Nivel 3 → rechaza la aprobación

Si alguna pre-condición falla, reporta qué falta y detiene el proceso.

## Qué hace al aprobar

Para cada spec del dominio:

1. **Actualiza el frontmatter**:
   ```yaml
   # Antes:
   status: review
   last_updated: "2026-05-15"

   # Después:
   status: approved
   last_updated: "2026-05-29"
   approved_by: "Tech Lead"      # quién ejecutó /approve
   approved_at: "2026-05-29"
   expires: "2026-08-27"         # +90 días automático (configurable)
   ```

2. **Registra en el changelog** (`memory/spec-changelog.md`):
   ```
   2026-05-29 | approved | arquitectura | Tech Lead | "Aprobada tras revisión de ADR-0001"
   ```

3. **Actualiza `spec-manifest.yaml`** → campo `maturity` del dominio:
   ```yaml
   arquitectura:
     maturity: approved       # era: review
     approved_at: "2026-05-29"
     approved_by: "Tech Lead"
   ```

4. **Actualiza `docs/spec-dashboard.md`** si existe — refleja el nuevo estado

## Campos de frontmatter por estado

| Campo | draft | review | approved |
|-------|-------|--------|----------|
| `status` | draft | review | approved |
| `last_updated` | fecha de creación | fecha de última edición | fecha de aprobación |
| `approved_by` | — | — | nombre/rol del aprobador |
| `approved_at` | — | — | fecha de aprobación |
| `expires` | — | — | `approved_at + 90d` |

## Modo `--dry-run`

Con `--dry-run`, el comando ejecuta todas las verificaciones de pre-condiciones y luego muestra exactamente qué cambiaría en cada spec y en `spec-manifest.yaml`, **sin escribir ningún archivo**:

```
DRY-RUN: /approve arquitectura
────────────────────────────────────────────
Pre-condiciones: ✅ OK

Cambios que se aplicarían:
  specs/04-arquitectura/arquitectura.md
    - status: review → approved
    + approved_by: "Tech Lead"
    + approved_at: "2026-05-29"
    + expires: "2026-08-27"

  specs/04-arquitectura/stack.md
    (idéntico)

  spec-manifest.yaml
    - arquitectura.maturity: review → approved

  memory/spec-changelog.md
    + nueva entrada de aprobación

Para ejecutar: /approve arquitectura (sin --dry-run)
```

## Flujo de aprobación en equipo

```
1. Autor crea/edita specs → status: draft
2. Autor pide revisión   → status: review  (edición manual del frontmatter)
3. Revisor valida        → /validate [dominio]  (sin errores ALTA)
4. Aprobador ejecuta     → /approve [dominio]   (solo si pre-condiciones OK)
5. /validate freshness   → monitorea caducidad (>90 días)
```

## Caducidad automática (`expires`)

El campo `expires` se calcula como `approved_at + 90 días`. Si la fecha pasa:

- `/validate freshness` reporta `[SEV: MEDIA]` — Spec aprobada expirada
- El dominio revierte a `status: review` automáticamente
- Requiere nueva aprobación explícita

Para cambiar el período de caducidad (por proyecto):
```yaml
# spec-manifest.yaml
project:
  approval_ttl_days: 180   # default: 90
```

## Output

```
╔══════════════════════════════════════════╗
║  APROBACIÓN DE DOMINIO                  ║
║  Dominio: arquitectura                  ║
║  Fecha: 2026-05-29                      ║
╠══════════════════════════════════════════╣
║  Pre-condiciones:                       ║
║  ✅ Sin [PENDIENTE] en ningún archivo   ║
║  ✅ /validate arquitectura — sin ALTA   ║
║  ✅ Contratos sincronizados (2/2)       ║
╠══════════════════════════════════════════╣
║  Aprobando 3 specs:                     ║
║  ✅ arquitectura.md → status: approved  ║
║  ✅ stack.md        → status: approved  ║
║  ✅ integraciones.md → status: approved ║
╠══════════════════════════════════════════╣
║  Changelog actualizado                  ║
║  spec-manifest.yaml actualizado         ║
║  Expira: 2026-08-27                     ║
╚══════════════════════════════════════════╝
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/approve arquitectura</input>
    <output>
╔══════════════════════════════════════════════╗
║  APROBACIÓN DE DOMINIO                      ║
║  Dominio: arquitectura                      ║
║  Fecha: 2026-05-29                          ║
╠══════════════════════════════════════════════╣
║  Pre-condiciones:                           ║
║  ✅ Sin [PENDIENTE] en ningún archivo       ║
║  ✅ /validate arquitectura — sin ALTA       ║
║  ✅ Contratos sincronizados (2/2)           ║
╠══════════════════════════════════════════════╣
║  Aprobando 3 specs:                         ║
║  ✅ arquitectura.md → status: approved      ║
║  ✅ stack.md        → status: approved      ║
║  ✅ integraciones.md → status: approved     ║
╠══════════════════════════════════════════════╣
║  Changelog actualizado                      ║
║  spec-manifest.yaml actualizado             ║
║  Expira: 2026-08-27                         ║
╚══════════════════════════════════════════════╝
    </output>
  </example>
  <example>
    <input>/approve producto</input>
    <output>
❌ APROBACIÓN BLOQUEADA — dominio: producto

Pre-condiciones fallidas:
  1. specs/02-producto/historias-usuario.md contiene 2 [PENDIENTE]:
     - línea 45: HU-007 criterios de aceptación [PENDIENTE]
     - línea 89: HU-012 escenario de error [PENDIENTE]

Acción requerida: completar los [PENDIENTE] antes de /approve
  Sugerencia: /grill-spec producto (entrevista guiada)
    </output>
  </example>
</examples>

## Agente que ejecuta

El propio Claude (no delega a subagente) — edita frontmatter de specs y actualiza `spec-manifest.yaml`.

## Comandos relacionados

- [[validate]] — ejecutar antes de aprobar para asegurar calidad
- [[validate|/validate freshness]] — monitorear caducidad de aprobaciones
- [[analyze]] — dashboard de estado por dominio (incluye aprobados)
- [[status]] — health check rápido que muestra dominios aprobados vs pendientes
- [[review]] — revisión de cambios antes de aprobar
- [[grill-spec]] — completa los [PENDIENTE] del dominio que bloquean la aprobación
- [[spec-changelog]] — ver el historial de aprobaciones registradas por /approve
- [[spec-health]] — ver la tendencia histórica de dominios aprobados (cada /approve añade un hito)
- [[contract]] — verifica que los contratos del dominio estén sincronizados con las specs antes de aprobar
- [[migration-planner]] — planifica la migración de contratos con breaking changes que bloquean la aprobación del dominio
- [[compliance-checker]] — verificar cumplimiento normativo (GDPR/SOC2/HIPAA/PCI-DSS) previo a la aprobación de dominios de seguridad o legal
- [[spec-auditor]] — diagnóstico profundo del dominio con score de madurez que puede preceder la aprobación formal
- **Referencia central**: [[spec-manifest]] — actualizado por /approve con el nuevo estado de madurez
