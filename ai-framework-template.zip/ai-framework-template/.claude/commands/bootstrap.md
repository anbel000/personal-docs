---
name: bootstrap
description: "Genera un proyecto spec-driven completo a partir de un brief genérico. Uso: /bootstrap <ruta-al-brief>"
---

# Comando: /bootstrap

**Argumentos**: `$ARGUMENTS`

Transforma un archivo de descripción genérica de proyecto en un proyecto spec-driven completamente estructurado con specs pobladas, contratos iniciales y configuración lista para `/generate`.

## Uso

```
/bootstrap <ruta-al-brief> [opciones]
```

**Ejemplos:**
```
/bootstrap ../mi-startup.md
/bootstrap ../briefs/app-creditos.md
/bootstrap ./project-brief-template.md           ← para probar con el template en blanco
/bootstrap ../mi-startup.md --profile saas       ← plantillas preconfiguradas para SaaS
/bootstrap ../mi-startup.md --profile iot        ← incluye hardware/IoT por defecto
/bootstrap ../mi-startup.md --skip legal,hardware ← omite dominios opcionales
/bootstrap ../mi-startup.md --profile minimal    ← solo negocio+producto+arquitectura
```

## Pre-condiciones

Antes de ejecutar, verifica:

1. El archivo brief existe en la ruta especificada
2. El brief tiene al menos las secciones: nombre del proyecto, problema y funcionalidades must-have
3. No existe ya un directorio `../{nombre-proyecto}/` (para evitar sobreescribir trabajo existente)

Si alguna de estas condiciones falla, reporta el problema y detente.

## Flujo de ejecución

```
1. Leer el brief completo
   ↓
2. Extraer nombre del proyecto y validar que existe
   ↓
3. Verificar que no hay conflicto de directorio destino
   ↓
4. Invocar al agente bootstrapper con el contenido del brief
   ↓
5. El bootstrapper crea el directorio y genera todos los archivos
   ↓
6. Mostrar reporte de bootstrap al usuario
   ↓
7. Sugerir próximos pasos
```

## Qué produce

Un directorio `../{nombre-proyecto}/` al mismo nivel que `spec-driven-framework/` con:

| Artefacto | Descripción |
|-----------|-------------|
| `CLAUDE.md` | Instrucciones de Claude adaptadas al proyecto |
| `MEMORY.md` | Índice de memoria con contexto inicial |
| `spec-manifest.yaml` | Manifest con datos reales del proyecto |
| `specs/01-negocio/` | Visión, stakeholders, propuesta de valor |
| `specs/02-producto/` | Requerimientos, historias, flujos, roadmap |
| `specs/03-diseno/` | Arquitectura de información, design system |
| `specs/04-arquitectura/` | Stack, arquitectura C4, integraciones |
| `docs/adr/` | ADR inicial del stack (`ADR-0001-stack-inicial.md`) |
| `specs/05-datos/` | Modelo de datos, flujos de datos |
| `specs/06-seguridad/` | Requisitos de seguridad, cumplimiento |
| `specs/07-infra/` | Infraestructura, CI/CD |
| `specs/08-calidad/` | Estrategia de tests, criterios de aceptación |
| `contracts/api/` | OpenAPI 3.1 skeleton por recurso |
| `contracts/schemas/` | JSON Schema por entidad de datos |
| `contracts/ddl/` | DDL PostgreSQL inicial |
| `.claude/settings.json` | Configuración copiada del framework |
| `.claude/agents/` | 12 agentes especializados (analyst, architect, data-engineer, designer, devops, implementer, iot-engineer, navigator, product, qa, reviewer, security-reviewer) — **NO incluye bootstrapper** |
| `.claude/agents-registry/` | 5 archivos: README.md + 4 agentes (spec-auditor, migration-planner, onboarding-guide, compliance-checker) |
| `graphify/` | Tooling graphify: `.graphify.yml`, `llm.config.yml` (Haiku), `GRAPHIFY.md`, `usage.md` |
| `.claude/commands/` | 19 comandos (analyze, approve, build, contract, explain, generate, graphify, graphifyllm, grill-brief, grill-spec, onboard, predeploy, resume, review, spec-changelog, spec-health, status, sync-issues, validate) — **NO incluye bootstrap** |
| `.claude/rules/` | 8 reglas (coding-conventions, api-patterns, security-patterns, testing-patterns, spec-sync, graphify-first, sesiones, tasks-discipline) |
| `.claude/hooks/` | 11 hooks git (setup-git-hooks.sh, setup-git-hooks.ps1, pre-commit-validate.sh, pre-commit-spec-sync.sh, validate-bash.sh, validate-frontmatter.sh, format-on-save.sh, rebuild-graph.sh, notify-done.sh, post-commit-changelog.sh, spec-lint.sh) |
| `.claude/skills/` | 3 skills: `caveman/` (compresión de tokens), `grill-me/` (motor de entrevistas), `graphify-specs/` (scripts predeploy) |

> El proyecto generado es **completamente autónomo**: no depende del framework plantilla una vez creado.
> Los únicos elementos que quedan exclusivamente en el framework son `/bootstrap` y el agente `bootstrapper`.

## Después del bootstrap

```bash
# 1. Entra al nuevo proyecto
cd ../{nombre-proyecto}

# 2. Construye el conectoma inicial (Haiku por default, configurable)
#    Requiere: pip install graphifyy
/graphify
# Opcional: /graphifyllm off   ← AST puro, cero tokens LLM

# 3. Revisa los gaps reportados y completa specs
# (editar manualmente los [PENDIENTE: ...] encontrados)

# 4. Valida consistencia
/validate all

# 5. Genera código
/generate all

# 6. Pipeline completo
/build
```

> `/graphify` genera `graphify-out/graph.json` usando la config en `graphify/.graphify.yml`.
> Claude Code y los agentes consultarán este grafo para ahorrar tokens en toda sesión futura.
> Cambia el modelo LLM con `/graphifyllm` o desactívalo con `/graphifyllm off`.

## Opciones

| Flag | Descripción |
|------|-------------|
| `--dry-run` | Muestra qué generaría sin crear archivos |
| `--overwrite` | Sobreescribe el directorio si ya existe (usar con cuidado) |
| `--lang en` | Genera specs en inglés en lugar de español |
| `--profile <nombre>` | Usa plantillas preconfiguradas para el tipo de proyecto (ver tabla abajo) |
| `--skip <dominios>` | Omite dominios opcionales separados por coma (ej: `--skip legal,hardware`) |

### Perfiles disponibles (`--profile`)

| Perfil | Dominios incluidos | Descripción |
|--------|-------------------|-------------|
| `default` | Todos (sin hardware) | Proyecto web/API estándar |
| `minimal` | negocio, producto, arquitectura, datos | Prototipo rápido o MVP sin infra propia |
| `saas` | Todos (sin hardware) + extras SaaS | Añade secciones de multi-tenancy, billing, planes en specs de negocio y datos |
| `iot` | Todos incluyendo hardware | Activa dominio 11-hardware y specs IoT por defecto |
| `api-only` | arquitectura, datos, seguridad, operaciones | Backend API sin frontend; omite diseno, calidad de UI |
| `fullstack` | Todos (sin hardware) | Igual a default pero con notas de component library en diseno |

Los perfiles solo pre-configuran qué secciones vienen más pobladas — el contenido sigue viniendo del brief. Un perfil `saas` con un brief de IoT generará un proyecto contradictorio; los perfiles son sugerencias de plantilla, no restricciones.

### Dominios skippeables (`--skip`)

Solo se pueden omitir dominios marcados como `optional: true` en `spec-manifest.yaml` o que no sean dependencia de otros. Los dominios `negocio`, `producto`, `arquitectura` y `datos` no son skippeables — son la base del proyecto.

| Dominio | Skippeable | Razón |
|---------|-----------|-------|
| legal | ✅ | No bloquea generación de código |
| hardware | ✅ | optional: true en el manifest |
| diseno | ⚠️ | Solo con `--profile api-only` |
| calidad | ❌ | Los tests son necesarios para el pipeline |

## Reglas

- Si el brief tiene información incompleta en campos críticos, el comando PREGUNTA antes de continuar — no asume
- Si el directorio destino ya existe sin `--overwrite`, el comando FALLA con mensaje descriptivo
- Los contratos generados son esqueletos — deben ser refinados por humanos antes de `/generate`
- Toda spec generada tiene `status: draft` en el frontmatter — nada se considera aprobado automáticamente

## Cuándo usarlo vs. cuándo llenarlo manualmente

| Situación | Recomendación |
|-----------|---------------|
| Proyecto nuevo, tienes un brief escrito | `/bootstrap` |
| Proyecto nuevo, sabes poco aún | Llenar `project-brief-template.md` primero |
| Proyecto existente migrando al framework | Llenar specs manualmente, luego `/validate` |
| Prototipo rápido | `/bootstrap` con brief mínimo, iterar con `/generate` |

## Ejemplo de sesión

<examples>
  <example>
    <input>/bootstrap ../crm-startup.md --profile saas</input>
    <output>
    ✅ Bootstrap completado: crm-startup/  [verificado: todos los artefactos presentes]

    📁 Estructura creada:
       - 28 specs pobladas
       - 4 contratos generados (2 OpenAPI, 3 JSON Schema, 1 DDL)
       - 12 historias de usuario (HU-001 a HU-012)
       - 8 requerimientos must-have, 4 should-have
       - graphify/ configurado (Haiku por default)
       - .claude/ completo: 12 agentes + 5 en registry, 19 comandos, 8 reglas, 11 hooks

    ⚠️  Gaps detectados:
       - specs/03-diseno/: color primario y tipografía no definidos en el brief
       - specs/07-infra/: región de deployment no especificada → [PENDIENTE]

    📋 Próximos pasos (desde crm-startup/):
       1. /grill-spec diseno   ← completar los [PENDIENTE] de diseño
       2. /validate all        ← verificar consistencia
       3. /generate all        ← producir código
    </output>
  </example>
  <example>
    <input>/bootstrap ../crm-startup.md --dry-run</input>
    <output>
    DRY-RUN — no se crearán archivos

    Se crearía: ../crm-startup/
       - 28 specs (negocio ×4, producto ×4, diseno ×3, arquitectura ×3, datos ×3,
                   seguridad ×3, infra ×3, calidad ×3, operaciones ×3, legal ×3)
       - 3 contratos: contracts/api/users.yaml, contracts/ddl/001_initial.sql,
                      contracts/schemas/user.json
       - 57 archivos totales en .claude/

    Gaps detectados en el brief (se crearían con [PENDIENTE]):
       - color primario y tipografía
       - región de deployment

    Ejecutar sin --dry-run para generar.
    </output>
  </example>
</examples>

## Agente que ejecuta

- [[bootstrapper]] — responsable de toda la lógica de generación

## Comandos relacionados

- [[graphify]] — construir el conectoma inicial después de bootstrap (paso 3 del flujo)
- [[grill-spec]] — completar los [PENDIENTE] de cada dominio generado (paso 4 del flujo)
- [[validate]] — siguiente paso después del bootstrap
- [[generate]] — genera código cuando las specs están listas
- [[analyze]] — diagnóstico de gaps en un proyecto ya iniciado
- [[onboard]] — genera guía para nuevos miembros del equipo
- [[grill-brief]] — genera el brief que este comando consume como input; el paso previo natural antes de /bootstrap
