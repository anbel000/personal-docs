---
name: sbom
description: "Genera, valida y compara el Software Bill of Materials (SBOM) del proyecto en formato SPDX 2.3 o CycloneDX 1.5. Uso: /sbom <subcomando>"
---

# Comando: /sbom

**Argumentos**: `$ARGUMENTS`

Genera y gestiona el Software Bill of Materials (SBOM) del proyecto. Un SBOM es el inventario completo de componentes de software (directos y transitivos) con sus licencias, versiones y vulnerabilidades conocidas. Requerido para SOC2 Type II, PCI-DSS v4 y buenas prácticas de supply chain security.

## Uso

```
/sbom generate [--format spdx|cyclonedx]  # Genera SBOM desde manifiestos de dependencias
/sbom validate [--profile soc2|pci-dss]   # Valida completitud para marcos regulatorios
/sbom diff                                 # Cambios en SBOM vs commit anterior
```

## Subcomandos en detalle

### `generate [--format spdx|cyclonedx]`

Lee los manifiestos de dependencias del proyecto y genera el SBOM completo:

**Fuentes de dependencias que lee**:
- `package.json` / `package-lock.json` — Node.js (directas + transitivas)
- `pyproject.toml` / `poetry.lock` / `requirements.txt` — Python
- `go.mod` / `go.sum` — Go
- `pom.xml` — Java/Maven
- `Gemfile.lock` — Ruby

**Metadata del proyecto** (desde `spec-manifest.yaml`):
- `name`, `version`, `description` para el header del SBOM

**Formato de salida**:

Con `--format spdx` (default): genera `docs/sbom.spdx.json`
```json
{
  "spdxVersion": "SPDX-2.3",
  "dataLicense": "CC0-1.0",
  "SPDXID": "SPDXRef-DOCUMENT",
  "name": "{proyecto}-{version}",
  "documentNamespace": "https://spdx.org/spdxdocs/{proyecto}-{version}",
  "packages": [
    {
      "SPDXID": "SPDXRef-Package-express-4.18.2",
      "name": "express",
      "versionInfo": "4.18.2",
      "downloadLocation": "https://registry.npmjs.org/express/-/express-4.18.2.tgz",
      "licenseConcluded": "MIT",
      "licenseDeclared": "MIT",
      "filesAnalyzed": false,
      "externalRefs": [
        {
          "referenceCategory": "PACKAGE-MANAGER",
          "referenceType": "purl",
          "referenceLocator": "pkg:npm/express@4.18.2"
        }
      ]
    }
  ],
  "relationships": [
    {
      "spdxElementId": "SPDXRef-DOCUMENT",
      "relationshipType": "DESCRIBES",
      "relatedSpdxElement": "SPDXRef-Package-{proyecto}"
    }
  ]
}
```

Con `--format cyclonedx`: genera `docs/sbom.cdx.json` (CycloneDX 1.5)

**Output en consola**:
```
SBOM GENERATED — mi-proyecto v1.2.0
══════════════════════════════════════════
Format:       SPDX 2.3
Output:       docs/sbom.spdx.json
Components:   142 (23 directos + 119 transitivos)
Licencias:    MIT (89), Apache-2.0 (31), BSD-3-Clause (18), UNKNOWN (4)
⚠️  4 componentes con licencia desconocida — verificar antes de /sbom validate
```

---

### `validate [--profile soc2|pci-dss]`

Verifica que el SBOM cumple con los requisitos de los marcos regulatorios.

**Sin perfil (general)**:
- SBOM presente en `docs/sbom.spdx.json` o `docs/sbom.cdx.json`
- Sin componentes con licencia `UNKNOWN` (auditoría de licencias)
- Sin componentes sin campo `version`
- Todos los componentes tienen `purl` (package URL) válido

**Con `--profile soc2`** (SOC 2 Type II):
- ✅ SBOM presente y con fecha de generación reciente (< 30 días)
- ✅ Ningún componente sin licencia conocida
- ✅ Todos los componentes directos tienen fuente documentada (downloadLocation)
- ⚠️  CVEs activos: avisa si no hay scanner configurado; si hay scanner → falla si CVE crítico encontrado

**Con `--profile pci-dss`** (PCI-DSS v4):
- Todo lo de SOC2 +
- ✅ Ninguna dependencia con CVE de severidad ALTA o CRÍTICA (requiere scanner)
- ✅ Todas las dependencias de procesamiento de pagos son verificables

**Output**:
```
SBOM VALIDATION — mi-proyecto — SOC2
══════════════════════════════════════════
✅ SBOM presente: docs/sbom.spdx.json (generado hace 2 días)
✅ 142/142 componentes con licencia conocida
✅ 142/142 componentes con purl válido
⚠️  Scanner de CVEs no configurado — instalar trivy o grype para verificación de vulnerabilidades
   Acción: añadir a CI/CD: trivy fs --format sarif --output trivy-results.sarif .

SCORE SOC2: 3/4 controles SBOM ✅ (75%)
```

---

### `diff`

Compara el SBOM actual contra el del commit anterior. Útil para revisar cambios antes de un PR.

```
SBOM DIFF — main..HEAD
══════════════════════════════════════════
Añadidos (3):
  + pkg:npm/zod@3.22.4             MIT
  + pkg:npm/@types/zod@3.22.4      MIT
  + pkg:npm/dayjs@1.11.10          MIT

Eliminados (1):
  - pkg:npm/moment@2.29.4          MIT  ⚠️ (reemplazado por dayjs — verificar compatibilidad)

Actualizados (2):
  ~ pkg:npm/express  4.18.1 → 4.18.2   (patch — OK)
  ~ pkg:npm/fastify  4.24.0 → 4.25.0   (minor — revisar changelog)

Cambios de licencia: ninguno
```

## Integración con /predeploy

En el pipeline de `/predeploy`, el SBOM se genera como paso 2.5 (opcional pero recomendado para proyectos con requisitos regulatorios):

```
Paso 2.5 (si sbom_enabled en spec-manifest.yaml):
  /sbom generate --format spdx
```

Para activar: añadir `sbom_enabled: true` al `spec-manifest.yaml` del proyecto.

## Agente que ejecuta

El propio Claude con permisos de lectura y escritura (Read, Write, Glob, Grep).

## Comandos relacionados

- [[predeploy]] — ejecuta /sbom generate como paso 2.5 del pipeline si sbom_enabled
- [[validate]] — /validate all reporta ausencia de SBOM como gap INFO si hay requisitos regulatorios
- [[compliance-checker]] — usa el SBOM para verificar controles de supply chain en SOC2/PCI-DSS
- [[security-reviewer]] — revisa los controles de supply chain que el SBOM expone; coordinación en auditorías de seguridad
- [[contract]] — los contratos de dependencias externas complementan el SBOM con interfaces formales
