---
name: contract
description: "Gestión de contratos formales: crear, validar, sincronizar y diff de OpenAPI/JSON Schema/DDL. Uso: /contract <acción> <recurso>"
---

# Comando: /contract

**Argumentos**: `$ARGUMENTS`

Gestiona los contratos formales del proyecto (`contracts/api/`, `contracts/schemas/`, `contracts/ddl/`). Permite crear contratos desde specs, validarlos sintácticamente y detectar desincronizaciones.

## Uso

```
/contract list                      # Lista todos los contratos presentes
/contract validate [archivo]        # Valida sintaxis (OpenAPI, JSON Schema, SQL)
/contract validate all              # Valida todos los contratos del proyecto
/contract sync [dominio]            # Verifica que el contrato coincide con la spec del dominio
/contract sync all                  # Verifica todos los dominios con contratos
/contract diff [archivo]            # Muestra diff del contrato vs la versión en git HEAD~1
/contract create api <recurso>      # Genera skeleton OpenAPI 3.1 para un recurso nuevo
/contract create schema <entidad>   # Genera JSON Schema para una entidad de datos
/contract create ddl <tabla>        # Genera DDL PostgreSQL para una tabla nueva
/contract create proto <servicio>   # Genera skeleton .proto (Protobuf 3) para servicio gRPC
/contract create asyncapi <canal>   # Genera skeleton AsyncAPI 2.6 para canal de eventos
/contract bump [archivo]            # Sube la versión del path (/api/v1/ → /api/v2/)
/contract test <archivo> [--pact|--prism]  # Verifica compatibilidad consumer-provider
```

## Qué es un contrato formal

En el framework, un contrato formal es un artefacto ejecutable que tiene prioridad sobre la prosa de las specs:

| Tipo | Ubicación | Válido si... |
|------|-----------|-------------|
| OpenAPI 3.1 | `contracts/api/*.yaml` | Pasa validación del parser YAML + estructura OpenAPI |
| JSON Schema | `contracts/schemas/*.json` | JSON válido + `$schema` declarado |
| DDL PostgreSQL | `contracts/ddl/*.sql` | SQL parseable (al menos sintaxis básica) |
| AsyncAPI 2.6 | `contracts/asyncapi/*.yaml` | Pasa validación de estructura AsyncAPI (channels, messages, schemas) |
| Protobuf 3 | `contracts/proto/*.proto` | Sintaxis proto3 válida (`syntax = "proto3"` declarado) |

**Regla de prioridad**: Si el código diverge de un contrato → el código está mal, no el contrato.

## Subcomandos en detalle

### `list`

```
contracts/
  api/       3 archivos
    users.yaml        (válido · 12 endpoints · v1)
    orders.yaml       (válido · 8 endpoints · v1)
    products.yaml     (⚠️ INVÁLIDO — YAML malformado en línea 47)
  schemas/   4 archivos
    user.json         (válido)
    order.json        (válido)
    product.json      (válido)
    payment.json      (válido)
  ddl/       2 archivos
    001_initial.sql   (válido · 5 tablas)
    002_add_audit.sql (válido · 2 tablas modificadas)
```

### `validate`

**Nivel sintáctico** (siempre):
- YAML/JSON malformado
- OpenAPI sin `info.version`, sin `paths`
- JSON Schema sin `$schema`
- SQL con sintaxis inválida (CREATE TABLE sin columnas, etc.)
- Referencias `$ref` rotas dentro del mismo contrato

**Nivel calidad** (solo contratos OpenAPI):
- `[WARN]` Endpoints sin `operationId` → confunde a generadores de SDK
- `[WARN]` Responses sin `example` → dificulta desarrollo de clientes
- `[WARN]` Campos sin `description` en schemas → docs.js generada es inútil
- `[ERROR]` `operationId` duplicados → error garantizado en generación de clientes
- `[WARN]` Paths en singular en lugar de plural (ej: `/user` → recomendado `/users`)

Ejemplo de output:
```
contracts/api/orders.yaml — calidad:
  ✅ Sintaxis válida
  ⚠️  3 endpoints sin operationId (GET /orders, POST /orders, DELETE /orders/{id})
  ⚠️  Respuesta 200 de GET /orders sin 'example'
  ✅ No hay operationIds duplicados
```

### `sync [dominio]`

Compara la prosa de las specs del dominio contra el contrato correspondiente:
- Campos en `modelo.md` pero ausentes en DDL/JSON Schema → `[SEV: MEDIA]`
- Endpoints en `integraciones.md` pero ausentes en OpenAPI → `[SEV: ALTA]`
- Coincidencias correctas → `✅`

### `diff [archivo]`

Muestra breaking vs non-breaking changes respecto a `git HEAD~1` (igual que el Nivel 3.6 de `/validate`):

```
contracts/api/users.yaml — cambios desde el último commit:

BREAKING:
  - campo 'role' eliminado de required[] en POST /users
  - tipo de 'created_at' cambiado: string → integer

NON-BREAKING:
  + nuevo endpoint: GET /users/:id/permissions
  + campo opcional 'metadata' añadido a User response
```

### `create api <recurso>`

Genera `contracts/api/{recurso}.yaml` con skeleton OpenAPI 3.1:
- `GET /{recurso}s` (list con paginación)
- `POST /{recurso}s` (create)
- `GET /{recurso}s/{id}` (get by id)
- `PUT /{recurso}s/{id}` (full update)
- `PATCH /{recurso}s/{id}` (partial update)
- `DELETE /{recurso}s/{id}` (delete)
- Schemas de request/response en `components/schemas`

### `create schema <entidad>`

Genera `contracts/schemas/{entidad}.json` con JSON Schema Draft 7:
- Tipo: `object`
- `required: []` (a rellenar)
- Campos base: `id` (UUID), `created_at`, `updated_at`

### `create ddl <tabla>`

Genera migración en `contracts/ddl/NNN_{tabla}.sql`:
- `CREATE TABLE {tabla} (...)` con columnas base (`id UUID PK`, `created_at`, `updated_at`)
- Índices base en `id`
- Naming convention para constraints: `pk_`, `fk_`, `uq_`, `idx_`

### `create asyncapi <canal>`

Genera `contracts/asyncapi/{canal}.yaml` con estructura AsyncAPI 2.6:
- Un canal `publish` (producer → broker) y un canal `subscribe` (broker → consumer) por defecto
- Message schemas derivados de `specs/05-datos/modelo.md` si existe; campos base si no
- Incluye: `asyncapi: "2.6.0"`, `info`, `channels`, `components/messages`, `components/schemas`
- Naming: kebab-case para el archivo y los canales, PascalCase para los schemas de mensajes

```yaml
# contracts/asyncapi/telemetry.yaml — ejemplo generado
asyncapi: "2.6.0"
info:
  title: Telemetry Events
  version: "1.0.0"
channels:
  device/telemetry/publish:
    publish:
      message:
        $ref: "#/components/messages/TelemetryEvent"
  device/telemetry/subscribe:
    subscribe:
      message:
        $ref: "#/components/messages/TelemetryEvent"
components:
  messages:
    TelemetryEvent:
      payload:
        $ref: "#/components/schemas/TelemetryPayload"
  schemas:
    TelemetryPayload:
      type: object
      required: [device_id, timestamp]
      properties:
        device_id: { type: string, format: uuid }
        timestamp: { type: string, format: date-time }
```

Con `--dry-run`: muestra el skeleton sin crear el archivo.

### `create proto <servicio>`

Genera `contracts/proto/{servicio}.proto` con skeleton Protobuf 3 para un servicio gRPC:
- `syntax = "proto3"` declarado
- `service {Servicio}` con los 4 métodos CRUD básicos (`Get`, `List`, `Create`, `Delete`)
- `message {Servicio}Request` y `{Servicio}Response` para cada método
- Campos base: `string id = 1` (UUID), `google.protobuf.Timestamp created_at = N`
- Import de `google/protobuf/timestamp.proto` y `google/protobuf/empty.proto`
- Naming: PascalCase para service y messages, snake_case para campos

```proto
// contracts/proto/user.proto — ejemplo generado
syntax = "proto3";

package user.v1;
option go_package = "gen/user/v1;userv1";

import "google/protobuf/timestamp.proto";
import "google/protobuf/empty.proto";

service UserService {
  rpc GetUser (GetUserRequest) returns (UserResponse);
  rpc ListUsers (ListUsersRequest) returns (ListUsersResponse);
  rpc CreateUser (CreateUserRequest) returns (UserResponse);
  rpc DeleteUser (DeleteUserRequest) returns (google.protobuf.Empty);
}

message UserResponse {
  string id = 1;
  string email = 2;
  string name = 3;
  google.protobuf.Timestamp created_at = 4;
}
```

Con `--dry-run`: muestra el skeleton sin crear el archivo.

### `bump [archivo]`

Inicia el flujo formal de deprecación de versión:

1. **Crea `contracts/api/{recurso}-v2.yaml`** con los nuevos paths (`/api/v2/`)
2. **Marca la versión anterior como deprecated**: añade `deprecated: true` a cada path de `/api/v1/` en el archivo original
3. **Genera un ADR automáticamente**: `docs/adr/NNNN-deprecation-{recurso}-api-v1.md` con contexto, fecha de corte sugerida (+4 semanas) y plan de migración
4. **Actualiza `info.version`** en ambos documentos (v1 y v2)
5. **Muestra la fecha de corte sugerida**: "Se recomienda mantener v1 hasta {fecha} para dar tiempo de migración"

```yaml
# contracts/api/users.yaml — ANTES (v1)
paths:
  /api/v1/users:
    get: ...

# contracts/api/users.yaml — DESPUÉS (v1 deprecated)
paths:
  /api/v1/users:
    get:
      deprecated: true  ← añadido por bump
      description: "DEPRECATED: Usar /api/v2/users. Fecha de corte: {fecha}"
      ...

# contracts/api/users-v2.yaml — NUEVO (v2)
paths:
  /api/v2/users:
    get: ...
```

Con `--dry-run`: muestra qué archivos crearía y modificaría sin hacer ningún cambio.

### `test <archivo> [--pact|--prism]`

Verifica compatibilidad consumer-provider del contrato indicado. Invoca al agente [[contract-tester]]:

- `--pact` (default): genera consumer tests en `tests/contracts/{recurso}.pact.ts` con `@pact-foundation/pact`. Produce archivos `.pact.json` para verificación provider-side.
- `--prism`: levanta un mock del contrato con `@stoplight/prism-cli` y ejecuta los tests de acceptance existentes contra él.

```
/contract test users.yaml --pact    # Genera tests/contracts/users.pact.ts
/contract test orders.yaml --prism  # Levanta mock y corre tests/acceptance/
```

Output:
```
CONTRACT TEST — users.yaml — PACT
  ✅ tests/contracts/users.pact.ts generado
  6 operaciones cubiertas / 6 total (100%)
  Siguiente: npx pact-js run tests/contracts/users.pact.ts
```

## Flag `--dry-run`

Todos los subcomandos que modifican o crean archivos soportan `--dry-run`:

| Comando | Sin --dry-run | Con --dry-run |
|---------|--------------|---------------|
| `create api users` | Crea `contracts/api/users.yaml` | Muestra el skeleton que crearía |
| `create schema User` | Crea `contracts/schemas/user.json` | Muestra el JSON Schema que generaría |
| `create ddl users` | Crea `contracts/ddl/NNN_users.sql` | Muestra el DDL que generaría |
| `bump users.yaml` | Crea v2, modifica v1, crea ADR | Lista todos los archivos que afectaría |

## Reglas

- Al crear un contrato nuevo, citar la spec fuente en un comentario header del archivo
- Al modificar un contrato existente, verificar si hay breaking changes con `diff` primero
- Si hay breaking changes, usar `bump` antes de hacer el cambio (evita SEV: ALTA en `/validate`)
- Todo `bump` genera automáticamente un ADR de deprecación

## Agente que ejecuta

El propio Claude con herramientas Read/Write/Edit/Glob/Grep. No invoca subagentes salvo para validaciones que requieran el agente `analyst`.

<examples>
  <example>
    <input>/contract list</input>
    <output>
contracts/
  api/       3 archivos
    users.yaml        (válido · 14 endpoints · v1)
    orders.yaml       (válido · 8 endpoints · v1)
    payments.yaml     (⚠️ INVÁLIDO — YAML malformado en línea 47)
  schemas/   3 archivos
    user.json         (válido)
    order.json        (válido)
    payment.json      (válido)
  ddl/       2 archivos
    001_initial.sql   (válido · 6 tablas)
    002_add_audit.sql (válido · 2 tablas modificadas)
    </output>
  </example>
  <example>
    <input>/contract validate orders.yaml</input>
    <output>
contracts/api/orders.yaml — validación:
  ✅ Sintaxis YAML válida
  ✅ Estructura OpenAPI 3.1 correcta
  ✅ No hay operationIds duplicados

  ⚠️  [WARN] 2 endpoints sin operationId:
        GET /orders, DELETE /orders/{id}
  ⚠️  [WARN] Respuesta 200 de GET /orders sin campo 'example'
  ⚠️  [WARN] Campo 'status' en OrderResponse sin description
        Recomendación: documentar valores válidos (pending|paid|cancelled)
    </output>
  </example>
  <example>
    <input>/contract create api invoice</input>
    <output>
Leyendo specs/02-producto/requerimientos.md para derivar campos...
Leyendo specs/05-datos/modelo.md → entidad Invoice encontrada

Creando contracts/api/invoice.yaml...

✅ contracts/api/invoice.yaml creado con 6 endpoints:
  GET    /api/v1/invoices           — list con paginación
  POST   /api/v1/invoices           — crear factura
  GET    /api/v1/invoices/{id}      — detalle
  PUT    /api/v1/invoices/{id}      — actualización completa
  PATCH  /api/v1/invoices/{id}      — actualización parcial
  DELETE /api/v1/invoices/{id}      — eliminación

  Spec fuente referenciada en header del archivo.
  Campos derivados de modelo.md: id, user_id, amount, status, created_at, updated_at
  status enum derivado de requerimientos.md: draft | sent | paid | cancelled

Siguiente paso: /contract validate invoice.yaml
    </output>
  </example>
  <example>
    <input>/contract bump users.yaml</input>
    <output>
Analizando contratos/api/users.yaml — versión actual: v1 (14 endpoints)

Archivos que se crearán/modificarán:
  CREAR   contracts/api/users-v2.yaml          (14 endpoints en /api/v2/)
  MODIFY  contracts/api/users.yaml             (añadir deprecated: true a cada path)
  CREAR   docs/adr/0004-deprecation-users-api-v1.md

Procediendo...

✅ contracts/api/users-v2.yaml creado con paths /api/v2/users
✅ contracts/api/users.yaml — todos los paths v1 marcados como deprecated
✅ docs/adr/0004-deprecation-users-api-v1.md generado

  Fecha de corte sugerida: 2026-06-26 (4 semanas desde hoy)
  Próximo paso: actualizar clientes para usar /api/v2/users
    </output>
  </example>
</examples>

## Comandos relacionados

- [[contract-tester]] — verifica compatibilidad consumer-provider con Pact o Prism (`/contract test` lo invoca)
- [[validate]] — incluye validación de contratos (Niveles 3, 3.5, 3.6)
- [[generate]] — usa los contratos como fuente de verdad para generar código
- [[review]] — puede incluir revisión de contratos antes de aprobar
- [[approve]] — verifica contratos sincronizados antes de aprobar un dominio
- [[migration-planner]] — para planificar la migración cuando `/contract diff` detecta breaking changes
- [[spec-sync]] — los archivos en contracts/ están en el Ámbito de esta regla; todo /contract create o /contract bump orientado a deploy debe acompañarse de update de spec
- [[sbom]] — el SBOM complementa los contratos con el inventario de dependencias; relevante en proyectos con requisitos SOC2/PCI-DSS
