---
name: resume
description: "Resume una sesión anterior de trabajo en este proyecto."
---

# Comando: /resume

**Argumentos**: `$ARGUMENTS`

Retoma una sesión anterior mostrando el estado completo del proyecto: memoria persistente, planes activos y estado git.

## Uso

```
/resume    # Retoma la sesión anterior mostrando estado del proyecto
```

## Pasos

### 0. Orientación en proyecto existente (si no hay contexto previo)

Si inicias sin contexto de la sesión anterior, lee estos archivos en orden para reorientarte:

```
1. docs/build-state.json       ← estado del último build y paso completado
2. memory/agent-log.md         ← últimas 5 sesiones (qué hizo cada agente)
3. spec-manifest.yaml          ← estado de specs por dominio (draft/review/approved)
4. MEMORY.md                   ← índice de memoria del proyecto
```

Después de leer estos 4 archivos, tienes suficiente contexto para continuar sin releer las specs completas. Si algo es ambiguo, usa graphify:
```bash
python -m graphify query "<pregunta>" --graph graphify-out/graph.json --budget 3000
```

### 1. Leer la memoria persistente

Lee `MEMORY.md` (índice) y los archivos relevantes de `memory/` según el contexto actual.

### 2. Listar planes recientes

Busca planes guardados en el directorio de planes de Claude Code.

**Linux / macOS:**
```bash
ls -t ~/.claude/plans/*.md 2>/dev/null | head -5
```

**Windows (PowerShell):**
```powershell
Get-ChildItem "$env:USERPROFILE\.claude\plans\*.md" -ErrorAction SilentlyContinue |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 5 -ExpandProperty FullName
```

Para cada plan encontrado, mostrar: nombre del archivo y primera línea de contenido.

### 3. Mostrar estado git

```bash
git status --short 2>/dev/null || echo "(sin repositorio git inicializado)"
git log --oneline -5 2>/dev/null || echo "(sin commits aún)"
```

Reportar: rama actual, último commit, archivos modificados sin commitear.

### 4. Sugerir siguiente paso

Con base en los planes abiertos y la memoria, recomendar la acción más lógica para continuar.

---

## Opciones para continuar

| Situación | Recomendación |
|-----------|---------------|
| Hay una tarea no terminada en un plan | Retomar desde el último paso incompleto |
| No hay planes pero hay cambios sin commitear | Revisar los cambios y decidir si commitear o continuar |
| Contexto fresco sin historia | `/clear` y empezar con las specs relevantes |
| Quieres la última sesión exacta | `claude --continue` en la terminal |
| Quieres elegir entre sesiones | `claude --resume` en la terminal |

<examples>
  <example>
    <input>/resume</input>
    <output>
Leyendo estado del proyecto...

📋 RESUMEN DE SESIÓN ANTERIOR
══════════════════════════════════════════════════════
Último plan activo: "Completar dominio seguridad"
  Paso completado:   ✅ Generar threat-model.md
  Paso en progreso:  🔄 Completar cumplimiento.md (3 [PENDIENTE] sin resolver)
  Paso pendiente:    ❌ /review seguridad
  ❌ /approve seguridad

Estado git:
  Rama: feat/seguridad-specs
  Último commit: "feat(seguridad): threat-model completo" (hace 2 horas)
  Archivos sin commitear: specs/06-seguridad/cumplimiento.md (3 cambios)

Estado del proyecto:
  Dominios aprobados: 4/11 (negocio, producto, arquitectura, datos)
  [PENDIENTE] totales: 31 (por /analyze)
  Build: ⚠️ último build falló en paso "tests de integración"

══════════════════════════════════════════════════════
🚀 Siguiente paso sugerido:
   Retomar cumplimiento.md — resolver los 3 [PENDIENTE]:
   - [PENDIENTE: regulación GDPR aplicable a usuarios EU]
   - [PENDIENTE: política de retención de datos de auditoría]
   - [PENDIENTE: proceso de portabilidad de datos]

   Luego: /validate seguridad → /review seguridad → /approve seguridad
    </output>
  </example>
</examples>

## Comandos relacionados

- [[status]] — health check rápido del proyecto (semáforo verde/amarillo/rojo en 5 segundos)
- [[validate]] — verificar estado de consistencia antes de continuar
- [[analyze]] — ver gaps en specs si el proyecto está en construcción
