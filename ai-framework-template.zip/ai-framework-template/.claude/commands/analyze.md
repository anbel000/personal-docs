---
name: analyze
description: "Dashboard de estado de specs y contratos. NO detecta drift de código — para eso usa /validate drift. Uso: /analyze"
---

# Comando: /analyze

**Argumentos**: `$ARGUMENTS`

Produce un dashboard de estado de las specs y contratos del proyecto Spec-Driven. Es un diagnóstico orientado a la sesión — responde "¿por dónde empiezo hoy?".

> **No detecta drift código↔spec.** Para auditar si el código implementado refleja las specs, usa `/validate drift` o `/predeploy`.

## Uso

```
/analyze                # Diagnóstico completo
/analyze gaps           # Solo gaps y specs faltantes
/analyze coverage       # Cobertura de specs vs código generado
/analyze dependencies   # Mapa de dependencias entre dominios
/analyze pendientes     # Solo conteo de [PENDIENTE] por dominio
```

## Qué analiza

### Estado de specs

- Cuántas specs existen vs cuántas define [[spec-manifest|el manifest]]
- Cuáles están completas, parciales (solo plantilla), o faltantes
- Progreso por dominio (% de completitud)
- **Conteo de `[PENDIENTE]`** por dominio y total del proyecto

### Conteo de `[PENDIENTE]`

Para cada dominio, contar todas las ocurrencias del placeholder `[PENDIENTE]` en los archivos de specs. Incluye variantes: `[PENDIENTE]`, `[PENDIENTE: ...]`.

Clasificar como:
- **Bloqueante** (impide generación): si aparece en campos obligatorios — nombre de entidad, endpoint principal, tipo de dato de clave primaria
- **Importante**: si aparece en tablas funcionales (requerimientos, SLOs, reglas)
- **Menor**: si aparece en secciones de proyección o "nice-to-have"

### Estado de contratos

- Contratos presentes en `contracts/` vs referenciados en el manifest
- Validez sintáctica (OpenAPI válido, JSON Schema válido, SQL parseable)
- Sincronización contratos ↔ specs (¿coinciden los campos, endpoints, tablas?)

### Estado de código generado

- Archivos generados vs esperados según el manifest
- Archivos huérfanos (generados pero ya no mapeados a ninguna spec)
- Archivos desactualizados (spec cambió después de la última generación)

### Mapa de dependencias

```
negocio ──▶ producto ──▶ arquitectura ──▶ datos ──▶ código
                │                │           │
                ▼                ▼           ▼
            calidad        seguridad     infra
```

## Output

Dashboard compacto en terminal:

```
📊 SPEC-DRIVEN PROJECT ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Specs:      8/11 dominios con contenido (73%)
Contratos:  3/5 presentes y válidos
Código:     42 archivos generados, 3 desactualizados
Tests:      28 tests, 85% coverage
Gaps:       5 (2 críticos, 3 menores)

Completitud por dominio (score = 100% - %[PENDIENTE]):
  negocio:         ░░░░░░░░░░  0%  (23 [PENDIENTE] — sin contenido real)
  producto:        ████████░░ 80%  ( 5 [PENDIENTE] — casi listo)
  diseno:          ████████░░ 80%  ( 4 [PENDIENTE])
  arquitectura:    █████████░ 95%  ( 1 [PENDIENTE])
  datos:           █████████░ 90%  ( 2 [PENDIENTE])
  seguridad:       ██████████100%  ( 0 [PENDIENTE]) ✅ aprobado
  infraestructura: ███████░░░ 70%  ( 7 [PENDIENTE])
  calidad:         ████████░░ 85%  ( 3 [PENDIENTE])
  operaciones:     ████████░░ 80%  ( 4 [PENDIENTE])
  legal:           ██░░░░░░░░ 20%  (18 [PENDIENTE])
  hardware:        N/A (optional: true)

Total [PENDIENTE] en el proyecto: 67
  Bloqueantes para /generate: 8
  Importantes:               41
  Menores:                   18

Top 3 acciones recomendadas:
  1. Completar specs/01-negocio/ (23 [PENDIENTE] — bloquea TODOS los dominios aguas abajo)
  2. Completar specs/07-infra/sla-slo.md (7 [PENDIENTE] — bloquea generación de infra)
  3. Agregar Gherkin a HU-005, HU-008 (bloquean generación de tests de aceptación)
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/analyze pendientes</input>
    <output>
📊 CONTEO DE [PENDIENTE] — crm-startup

  negocio:         23 (⚠️  bloqueante — sin contenido real)
  producto:         5 (3 en secciones de roadmap, 2 en criterios de aceptación)
  diseno:           4 (color primario, tipografía, espaciado base, radio de bordes)
  arquitectura:     1 (región de deployment — IMPORTANTE)
  datos:            2 (campo payment_status, índices de performance)
  seguridad:        0 ✅
  infraestructura:  7 (sizing de instancias, dominio, certificados)
  calidad:          3 (herramientas de E2E, coverage mínima, SLO de tests)
  operaciones:      4 (runbook de rollback, SLA de soporte)
  legal:           18 (todo el dominio — sin contenido real)
  hardware:        N/A (optional: true)

Total: 67 [PENDIENTE]
  Bloqueantes para /generate: 8
  Importantes:               41
  Menores:                   18

Top 3 acciones:
  1. /grill-spec negocio   ← 23 [PENDIENTE], bloquea todo aguas abajo
  2. /grill-spec legal     ← 18 [PENDIENTE], dominio sin contenido
  3. Completar specs/07-infra/infraestructura.md#region  ← bloquea deploy
    </output>
  </example>
</examples>

## Agente que ejecuta

Invoca al agente [[analyst]] con permisos de solo lectura.

El analyst debe:
1. Leer `spec-manifest.yaml` para obtener la lista de dominios y archivos
2. Para cada archivo, ejecutar `grep -c "\[PENDIENTE" <archivo>` y sumar por dominio
3. Clasificar los [PENDIENTE] según su contexto (sección bloqueante vs opcional)
4. Calcular score: `(total_secciones - secciones_con_pendiente) / total_secciones * 100`

## Comandos relacionados

- [[validate]] — validación formal (incluye Niveles 1-5)
- [[generate]] — genera código
- [[build]] — pipeline completo
- [[status]] — health check en 5 segundos (sin análisis profundo)
- [[spec-health]] — tendencia histórica de salud del proyecto
- [[approve]] — aprobar un dominio cuando su score es 100%
- [[grill-spec]] — completar [PENDIENTE] detectados por /analyze (siguiente paso natural tras el diagnóstico)
- [[explain]] — punto de entrada para entender cualquier artefacto individual detectado por /analyze
- [[onboard]] — generar guía de onboarding para nuevos miembros cuando el estado de specs es estable
- [[sync-issues]] — sincronizar REQ-FUNC con Linear/GitHub cuando el análisis revela qué requerimientos necesitan tracking externo
- [[doctor]] — autodiagnóstico del framework (.claude/ interno) cuando /analyze revela inconsistencias en la estructura del framework
- [[repair]] — auto-corrige referencias unidireccionales detectadas por /doctor
