---
name: grill-spec
description: "Entrevista guiada para completar los [PENDIENTE] de un dominio específico. Uso: /grill-spec [dominio]"
---

# Comando: /grill-spec

**Argumentos**: `$ARGUMENTS`

Conduce una entrevista guiada sobre un dominio específico para completar sus `[PENDIENTE]`. Convierte cada gap detectado en una pregunta clara, recopila las respuestas y actualiza las specs directamente.

## Uso

```
/grill-spec producto         # Completa [PENDIENTE] en specs/02-producto/
/grill-spec datos            # Focalizado en modelo de datos + entidades
/grill-spec seguridad        # Focalizado en controles SEC-*, threat model
/grill-spec negocio          # Completa visión, objetivos y modelo de negocio
/grill-spec arquitectura     # Completa stack, C4, integraciones
/grill-spec all              # Recorre todos los dominios con [PENDIENTE]
```

## Diferencia con `/grill-brief`

| Comando | Cuándo usar | Qué hace |
|---------|------------|----------|
| `/grill-brief` | Proyecto nuevo, brief incompleto | Entrevista completa del proyecto, genera brief desde cero |
| `/grill-spec [dominio]` | Proyecto ya bootstrappeado, dominio con [PENDIENTE] | Lee las specs existentes, pregunta solo lo que falta |

## Flujo de ejecución

```
1. Leer todas las specs del dominio solicitado
   ↓
2. Extraer todos los [PENDIENTE: ...] encontrados
   ↓
3. Ordenar por dependencia (preguntar primero lo que otros gaps necesitan)
   ↓
4. Hacer preguntas al usuario (1 a la vez, no dump de preguntas)
   ↓
5. Al responder cada pregunta, actualizar el [PENDIENTE] en la spec correspondiente
   ↓
6. Al terminar, ejecutar /validate [dominio] automáticamente
   ↓
7. Reporte: cuántos [PENDIENTE] resolvió, cuántos quedan (si los hay)
```

## Reglas de la entrevista

- **Preguntas de 1 en 1**: no presentar listas de 20 preguntas — máximo 3 preguntas a la vez
- **Contexto siempre visible**: antes de cada pregunta, mostrar la spec y línea que la originó
- **Escribir mientras se habla**: actualizar el archivo de spec en cuanto el usuario responde, no al final
- **Si el usuario no sabe**: añadir `[PENDIENTE: {razón de por qué no se pudo completar}]` con la respuesta parcial del usuario
- **Respetar lo que ya existe**: no reescribir secciones completas — solo reemplazar los `[PENDIENTE]`

## Formato de pregunta

```
📄 specs/02-producto/requerimientos.md — REQ-FUNC-005
   "[PENDIENTE: definir qué sucede cuando un usuario intenta registrarse con email ya existente]"

¿Qué debería ocurrir cuando un usuario intenta registrarse con un email que ya está en el sistema?
  a) Error con mensaje descriptivo y link a "recuperar contraseña"
  b) Error simple: "Email ya registrado"
  c) Otro comportamiento (describe)
```

## Modo `--dry-run`

Con `--dry-run`, el comando lista todos los `[PENDIENTE]` del dominio con su ubicación exacta pero **no hace preguntas ni modifica ningún archivo**:

```
DRY-RUN: /grill-spec producto
────────────────────────────────────────────
Dominio: producto (specs/02-producto/)

[PENDIENTE] encontrados: 7

1. specs/02-producto/requerimientos.md:23
   "REQ-FUNC-005: [PENDIENTE: definir comportamiento de email duplicado]"

2. specs/02-producto/historias-usuario.md:45
   "HU-007: [PENDIENTE: criterios de aceptación para el flujo de pago]"

3. specs/02-producto/flujos-usuario.md:12
   "[PENDIENTE: flujo de recuperación de contraseña no documentado]"

... (4 más)

Para completarlos: /grill-spec producto (sin --dry-run)
```

## Modo `all`

Con `/grill-spec all`:
1. Lista todos los dominios con al menos 1 `[PENDIENTE]`
2. Pregunta al usuario en qué orden quiere abordarlos
3. Procede dominio por dominio, terminando cada uno antes de pasar al siguiente

## Reporte final

```
✅ /grill-spec producto — completado

Resueltos:  7/9 [PENDIENTE]
Pendientes: 2/9 (requieren información de stakeholders externos)

Archivos actualizados:
  - specs/02-producto/requerimientos.md
  - specs/02-producto/historias-usuario.md
  - specs/02-producto/flujos-usuario.md

SPEC VALIDATION — producto (post-grill):
  ✅ Nivel 1: estructura OK
  ⚠️  Nivel 2: 2 gaps restantes (ver arriba)

Siguiente paso: /review producto → /approve producto
```

## Ejemplo de sesión

<examples>
  <example>
    <input>/grill-spec producto</input>
    <output>
Leyendo specs/02-producto/ — encontré 7 [PENDIENTE]

📄 specs/02-producto/requerimientos.md:23 — REQ-FUNC-005
   "[PENDIENTE: definir qué sucede cuando un usuario intenta registrarse con email ya existente]"

¿Qué debería ocurrir cuando un usuario intenta registrarse con un email que ya está en el sistema?
  a) Error con mensaje descriptivo y link a "recuperar contraseña"
  b) Error simple "Email ya registrado" sin más opciones
  c) Otro comportamiento

[usuario responde: a]

✅ Actualizado: specs/02-producto/requerimientos.md#REQ-FUNC-005

📄 specs/02-producto/historias-usuario.md:45 — HU-007
   "[PENDIENTE: criterios de aceptación para el flujo de pago con tarjeta]"

¿Cuándo el pago con tarjeta es exitoso, qué ve el usuario? ¿Y si el pago falla por fondos insuficientes?

[usuario responde: ve confirmación con número de orden; si falla, mensaje de error con opción de reintentar]

✅ Actualizado: specs/02-producto/historias-usuario.md#HU-007

[... continúa por los 5 [PENDIENTE] restantes ...]

✅ /grill-spec producto — completado

  Resueltos:  7/7 [PENDIENTE]
  Archivos actualizados: requerimientos.md, historias-usuario.md, flujos-usuario.md

Siguiente paso: /review producto → /approve producto
    </output>
  </example>
</examples>

## Agente que ejecuta

- [[analyst]] — localiza y extrae los [PENDIENTE]; Claude actualiza las specs directamente durante la entrevista

## Comandos relacionados

- **Skill subyacente**: [[grill-me]] — motor de entrevista una-pregunta-a-la-vez con recomendaciones
- [[grill-brief]] — entrevista completa de proyecto nuevo
- [[analyze]] — descubrir qué dominios tienen [PENDIENTE] antes de ejecutar grill-spec; también para verificar gaps resueltos
- [[spec-auditor]] — auditoría profunda del dominio (alternativa más exhaustiva que /analyze para identificar todos los problemas antes de ejecutar /grill-spec)
- [[validate]] — ejecutado automáticamente al terminar
- [[review]] — siguiente paso tras completar los [PENDIENTE]
- [[approve]] — aprobación del dominio cuando está listo
