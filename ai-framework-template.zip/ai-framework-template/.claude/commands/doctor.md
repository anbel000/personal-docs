---
name: doctor
description: "Autodiagnóstico del framework: verifica integridad de agentes, comandos, reglas, wikilinks y bidireccionalidad. Uso: /doctor"
---

# Comando: /doctor

**Argumentos**: `$ARGUMENTS`

Verifica la integridad estructural del propio framework `.claude/`. Responde "¿está el framework internamente consistente?".

> **Diferencia con `/validate`**: `/validate` verifica las specs y el código del proyecto. `/doctor` verifica los archivos del propio framework (agentes, comandos, reglas, wikilinks).

## Uso

```
/doctor                     # Diagnóstico completo
/doctor --scope agents      # Solo verifica agentes (.claude/agents/*.md)
/doctor --scope commands    # Solo verifica comandos (.claude/commands/*.md)
/doctor --scope rules       # Solo verifica reglas (.claude/rules/*.md)
/doctor --scope links       # Solo verifica bidireccionalidad de wikilinks
/doctor --fix               # Diagnóstico + delega correcciones a /repair
```

## Checks que ejecuta

### Check 1 — graphify-first completo

Verifica que los 12 agentes listados en `.claude/rules/graphify-first.md` (sección "Agentes que la aplican") tienen `[[graphify-first]]` en su sección `<rules>`.

### Check 2 — Estructura de agentes

Para cada archivo en `.claude/agents/*.md` verifica:
- Tiene sección `<rules>` con al menos una regla referenciada
- Tiene sección `<self_check>` con al menos un ítem de verificación
- Tiene línea `**Comandos que lo invocan**:` o equivalente en Comandos relacionados

### Check 3 — Comandos completos

Para cada archivo en `.claude/commands/*.md` verifica:
- Tiene sección `## Comandos relacionados`
- Tiene sección `## Uso` con al menos un ejemplo de sintaxis
- Tiene sección `## Agente que ejecuta`

### Check 4 — Reglas completas

Para cada archivo en `.claude/rules/*.md` verifica:
- Tiene sección `## Reglas que valida`
- La sección `## Reglas que valida` contiene `**Agentes que la aplican**:`

### Check 5 — Wikilinks sin objetivo

Para cada `[[nombre]]` en archivos `.claude/**/*.md`:
- Existe un archivo en `.claude/` cuyo `name:` en frontmatter coincide con el nombre del wikilink
- Reporta: archivo fuente, línea aproximada, wikilink roto

### Check 6 — Bidireccionalidad

Para cada referencia A → `[[B]]`, verifica que B tiene una referencia de retorno → `[[A]]`:
- Referencias en `## Comandos relacionados`
- Referencias en `**Comandos que lo invocan**`
- Referencias en `**Agentes relacionados**`
- Referencias en `<rules>`
- Referencias en `## Reglas que valida`

### Check 7 — Consistencia con CLAUDE.md

- Cada agente en `.claude/agents/*.md` tiene entrada en la tabla de agentes de `CLAUDE.md`
- Cada comando en `.claude/commands/*.md` aparece referenciado en alguna sección de comandos de `CLAUDE.md`

### Check 8 — Archivos huérfanos

Archivos en `.claude/agents/`, `.claude/commands/`, `.claude/rules/` que no son referenciados desde ningún otro archivo `.claude/**/*.md` ni desde `CLAUDE.md`.

## Output

```
DOCTOR REPORT — spec-driven-framework
══════════════════════════════════════════════════════════════════
✅ Check 1   graphify-first     [12/12 agentes tienen [[graphify-first]] en <rules>]
⚠️  Check 2   Estructura agentes [2 agentes sin <self_check>: iot-engineer, product]
✅ Check 3   Comandos completos  [24/24 tienen ## Comandos relacionados]
✅ Check 4   Reglas completas    [9/9 tienen ## Reglas que valida]
❌ Check 5   Wikilinks rotos     [3 wikilinks sin objetivo]
❌ Check 6   Bidireccionalidad   [4 referencias unidireccionales]
✅ Check 7   CLAUDE.md sync     [todos los agentes y comandos referenciados]
✅ Check 8   Sin huérfanos       [0 archivos sin referencias]

GAPS:
  [CHECK 5] .claude/commands/analyze.md → [[graphify]] (no existe name:graphify en commands/)
  [CHECK 6] .claude/commands/analyze.md → [[graphify]]: graphify.md no referencia analyze de vuelta
  [CHECK 6] .claude/commands/validate.md → [[graphify]]: graphify.md no referencia validate de vuelta
  [CHECK 6] .claude/commands/contract.md → [[analyst]]: analyst.md no referencia contract de vuelta

Estado global: ❌ GAPS ENCONTRADOS (4 items)
Acción: ejecutar /repair --fix para corregir referencias (checks 5 y 6)
        Resolver manualmente: check 2
```

## Semáforo global

| Estado | Condición |
|--------|-----------|
| ✅ OK | 0 gaps en todos los checks |
| ⚠️ ADVERTENCIA | Solo gaps de CHECK 2 o CHECK 7 (estructura incompleta, no rotura) |
| ❌ BLOQUEADO | Wikilinks rotos (CHECK 5) o referencias unidireccionales (CHECK 6) |

## Agente que ejecuta

El propio Claude con permisos de solo lectura (Read, Glob, Grep). No modifica archivos — para correcciones automáticas de bidireccionalidad, usar `/repair --fix`.

<examples>
  <example>
    <input>/doctor --scope links</input>
    <output>
DOCTOR REPORT — spec-driven-framework (scope: links)
══════════════════════════════════════════════════════════════════
✅ Check 5   Wikilinks rotos    [0 wikilinks sin objetivo]
✅ Check 6   Bidireccionalidad  [0 referencias unidireccionales]

Estado global: ✅ OK — todos los wikilinks son válidos y bidireccionales
    </output>
  </example>
  <example>
    <input>/doctor</input>
    <output>
DOCTOR REPORT — spec-driven-framework
══════════════════════════════════════════════════════════════════
✅ Check 1   graphify-first     [12/12 ✅]
✅ Check 2   Estructura agentes [14/14 tienen <rules> y <self_check>]
✅ Check 3   Comandos completos [24/24 tienen ## Comandos relacionados]
✅ Check 4   Reglas completas   [9/9 tienen ## Reglas que valida]
✅ Check 5   Wikilinks rotos    [0 rotos]
✅ Check 6   Bidireccionalidad  [0 unidireccionales]
✅ Check 7   CLAUDE.md sync     [todos los agentes y comandos referenciados]
✅ Check 8   Sin huérfanos      [0 archivos sin referencias]

Estado global: ✅ OK — framework internamente consistente
    </output>
  </example>
</examples>

## Comandos relacionados

- [[repair]] — corrige automáticamente los gaps de bidireccionalidad que /doctor detecta
- [[analyze]] — diagnóstico profundo del proyecto (specs y código del proyecto, no del framework)
- [[status]] — health check del proyecto (no del framework interno)
- [[validate]] — validación formal de specs (Niveles 1-5)
