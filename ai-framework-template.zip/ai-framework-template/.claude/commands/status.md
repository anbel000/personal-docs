---
name: status
description: "Health check rápido del proyecto en 5 segundos: estado de specs, contratos, build y drift. Uso: /status"
---

# Comando: /status

**Argumentos**: `$ARGUMENTS`

Health check rápido del proyecto — responde "¿está todo bien ahora mismo?" en menos de 5 segundos de lectura.

> **Diferencia con `/analyze`**: `/analyze` produce un diagnóstico profundo con conteo de [PENDIENTE] y recomendaciones. `/status` es un semáforo — verde / amarillo / rojo — sin análisis profundo.

## Uso

```
/status           # Health check completo
/status --json    # Output en JSON (para integración con CI/CD)
/status --brief   # Solo semáforo global (una línea)
```

## Qué verifica (en orden de velocidad)

### 1. Specs críticas (solo estructura)

- ¿Existen los 11 dominios en `specs/`?
- ¿Existe `spec-manifest.yaml`?
- ¿Tiene contenido real (no solo plantilla)?

### 2. Build state

- Lee `docs/build-state.json` si existe
- Reporta: última build exitosa, timestamp, pasos completados / fallados

### 3. Contratos

- ¿Existen archivos en `contracts/api/`, `contracts/schemas/`, `contracts/ddl/`?
- ¿Alguno tiene fecha de modificación posterior al último build? → advertencia de posible drift

### 4. Dominios aprobados vs pendientes

- Cuenta dominios con `status: approved` en sus specs
- Detecta dominios con `expires` vencida (si hay historial)

### 5. Git status rápido (si está disponible)

- Archivos de specs modificados sin commit
- Contratos modificados sin commit

## Output

```
🟢 SPEC-DRIVEN STATUS — mi-proyecto
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Specs:     11/11 dominios presentes
Build:     ✅ OK  (hace 2h · 2026-05-29 14:30)
Contratos: ✅ 9 archivos · ninguno modificado post-build
Aprobados: 5/11 dominios · 1 expirado (infraestructura)
Git:       2 specs modificadas sin commit (datos/, seguridad/)

Estado global: ⚠️ ADVERTENCIA
Acción urgente: /approve infraestructura (expiró hace 12 días)
```

```
🔴 SPEC-DRIVEN STATUS — mi-proyecto
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Specs:     8/11 dominios presentes (faltan: legal, hardware, calidad)
Build:     ❌ FALLIDA  (hace 3d · paso "test" fallido)
Contratos: ⚠️  3 archivos modificados después del último build
Aprobados: 2/11 dominios
Git:       7 archivos sin commit

Estado global: 🔴 BLOQUEADO
Acción urgente: /build --resume  (retomar build fallida)
```

## Output en `--json`

```json
{
  "project": "mi-proyecto",
  "timestamp": "2026-05-29T16:00:00Z",
  "global_status": "warning",
  "specs": { "present": 11, "total": 11, "ok": true },
  "build": {
    "status": "completed",
    "completed_at": "2026-05-29T14:30:22Z",
    "steps_ok": 5,
    "steps_failed": 0
  },
  "contracts": { "total": 9, "modified_post_build": 0 },
  "approved_domains": { "count": 5, "total": 11, "expired": 1 },
  "git": { "specs_uncommitted": 2 },
  "actions": ["Renovar aprobación de infraestructura (expiró 2026-05-17)"]
}
```

## Semáforo global

| Estado | Condición |
|--------|-----------|
| 🟢 OK | Build OK · todos los contratos en sync · ningún aprobado expirado · ningún uncommitted crítico |
| 🟡 ADVERTENCIA | Build OK pero: algún dominio expirado O contratos modificados O specs uncommitted |
| 🔴 BLOQUEADO | Build fallida O specs críticas faltantes O gaps de severidad ALTA pendientes |

## Rendimiento

`/status` NO lee el contenido de cada spec — solo verifica existencia, fecha de modificación y `build-state.json`. Su tiempo de ejecución es O(N archivos), no O(contenido).

Para análisis profundo → `/analyze`. Para validación completa → `/validate all`.

## Ejemplo de sesión

<examples>
  <example>
    <input>/status</input>
    <output>
🟡 SPEC-DRIVEN STATUS — crm-startup
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Specs:     11/11 dominios presentes
Build:     ✅ OK  (hace 4h · 2026-05-29 12:15)
Contratos: ✅ 7 archivos · ninguno modificado post-build
Aprobados: 6/11 dominios · 1 expirado (infraestructura — 2026-04-28)
Git:       2 specs modificadas sin commit (datos/modelo.md, seguridad/requisitos.md)

Estado global: ⚠️ ADVERTENCIA
Acción urgente: /approve infraestructura (expiró hace 31 días)
    </output>
  </example>
  <example>
    <input>/status --brief</input>
    <output>
🟢 OK — crm-startup (build: hace 2h · 11/11 specs · 8/11 aprobados · 0 expirados)
    </output>
  </example>
</examples>

## Agente que ejecuta

El propio Claude con permisos de solo lectura (Read, Glob, Grep). No invoca subagentes.

## Comandos relacionados

- [[analyze]] — diagnóstico profundo con [PENDIENTE] y recomendaciones
- [[validate]] — validación formal Niveles 1-5
- [[build]] — pipeline completo con `--resume` si el build está fallido
- [[approve]] — renovar aprobación de dominios expirados
- [[spec-health]] — tendencia histórica del proyecto (semanas de evolución)
- [[explain]] — entender cualquier artefacto específico que /status marque como problemático
- [[doctor]] — autodiagnóstico del framework cuando el problema es en .claude/ (no en las specs del proyecto)
