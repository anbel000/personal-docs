---
domain: 12-webapp
type: requerimientos
status: draft
last_updated: ""
---

# Requerimientos — Webapp

<!-- Generated from: specs/01-negocio/vision.md -->
<!-- Dominio: 12-webapp -->

## Stack

| Capa | Tecnología |
|------|-----------|
| Framework | Next.js 15 App Router |
| UI | Tailwind CSS |
| Estado | React hooks + fetch nativo |
| Auth | JWT en cookie httpOnly (access + refresh) |
| Deploy | Railway / Vercel / similar |

## REQ-WEBAPP-001 — Autenticación

**Como** usuario autenticado
**Quiero** iniciar sesión con email y contraseña
**Para** acceder a los datos de mi cuenta

Endpoint: `POST /api/v1/auth/login`
Redirección post-login: `/dashboard`

## REQ-WEBAPP-002 — Perfil y pacientes accesibles

Endpoint: `GET /api/v1/auth/me`
Devuelve: `{ user: { id, email, role }, patients: [{ id, nombre }] }`

## REQ-WEBAPP-003 — [Completar con secciones del producto]

<!-- Agregar secciones de la app: dashboard, listados, detalle, acciones -->

## Requerimientos No Funcionales

| ID | Requerimiento | Criterio |
|----|--------------|---------|
| RNF-WEBAPP-001 | Tiempo de carga inicial | < 3s en 3G |
| RNF-WEBAPP-002 | CSP | connect-src usar origin sin path (ver security-patterns.md) |
| RNF-WEBAPP-003 | Accesibilidad | WCAG 2.1 AA |

## Enlaces relacionados

- **Specs relacionadas**: [[vision]] · [[requerimientos]] · [[historias-usuario]]
- **Contratos**: [[contracts/api/example.yaml]] (adaptar por dominio)
- **Reglas**: [[security-patterns]] (CSP, JWT) · [[api-patterns]] (formato de respuestas)
- **Spec de rutas**: [[rutas]] (mapa de rutas de la webapp)
