---
domain: 12-webapp
type: rutas
status: draft
last_updated: ""
---

# Rutas — Webapp

<!-- Generated from: ejemplos/12-webapp/requerimientos.md -->

## Mapa de rutas

| Ruta | Componente | Auth requerida | Rol mínimo |
|------|-----------|---------------|-----------|
| `/login` | LoginPage | No | — |
| `/dashboard` | DashboardPage | Sí | paciente |
| `/dashboard/[section]` | SectionPage | Sí | paciente |

## Layouts

- `RootLayout` — providers globales (auth context, theme)
- `AuthenticatedLayout` — sidebar + topbar, redirige a /login si no hay sesión
- `PublicLayout` — solo para /login

## Convenciones Next.js

- App Router: `app/(authenticated)/` para rutas protegidas
- `middleware.ts` verifica JWT y redirige si expirado
- `'use client'` solo donde se necesita interactividad

## Protección de rutas

```typescript
// middleware.ts
export function middleware(request: NextRequest) {
  const token = request.cookies.get('access_token');
  const isPublicRoute = ['/login'].includes(request.nextUrl.pathname);

  if (!token && !isPublicRoute) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
}
```

## Enlaces relacionados

- **Spec previa**: [[requerimientos]] (dominio 12-webapp)
- **Specs relacionadas**: [[flujos-usuario]] · [[arquitectura-informacion]]
- **Reglas**: [[security-patterns]] (JWT, CSP) · [[coding-conventions]]
