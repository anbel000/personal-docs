---
domain: arquitectura
type: arquitectura
approver: "Tech Lead / Arquitecto"
status: draft
last_updated: ""
---

# Arquitectura de Software

## Diagrama de contexto (C4 - Nivel 1)

```mermaid
graph TB
    U[Usuario] -->|HTTPS| SYS[Sistema]
    SYS -->|API| EXT1[Servicio Externo 1]
    SYS -->|SMTP| EMAIL[Servicio de Email]
    ADMIN[Administrador] -->|HTTPS| SYS
```

## Diagrama de contenedores (C4 - Nivel 2)

```mermaid
graph TB
    subgraph Sistema
        WEB[Web App<br/>React/Next.js]
        API[API Server<br/>Node.js/Python]
        DB[(Base de Datos<br/>PostgreSQL)]
        CACHE[(Cache<br/>Redis)]
        QUEUE[Cola de mensajes<br/>RabbitMQ/SQS]
    end
    WEB -->|REST/GraphQL| API
    API --> DB
    API --> CACHE
    API --> QUEUE
```

## Componentes principales

| Componente | Tecnología | Responsabilidad | Puerto |
|------------|------------|-----------------|--------|
| Frontend | | Interfaz de usuario | 3000 |
| API Server | | Lógica de negocio + API | 8080 |
| Base de datos | | Persistencia | 5432 |
| Cache | | Sesiones + datos calientes | 6379 |
| Cola | | Procesamiento asíncrono | 5672 |

## Patrones arquitectónicos

| Patrón | Dónde aplica | Justificación |
|--------|-------------|---------------|
| MVC / Clean Architecture | API Server | Separación de concerns |
| Repository Pattern | Data access | Abstracción de persistencia |
| Event-driven | Notificaciones, procesos largos | Desacoplamiento |
| Circuit Breaker | Llamadas a servicios externos | Resiliencia |

## Comunicación entre componentes

| Origen | Destino | Protocolo | Formato | Auth |
|--------|---------|-----------|---------|------|
| Frontend | API | HTTPS | JSON | JWT |
| API | DB | TCP | SQL | Connection string |
| API | Cache | TCP | Redis protocol | Password |
| API | Cola | AMQP/SQS | JSON | Credentials |

## Decisiones clave

<!-- Referenciar ADRs formales en docs/adr/ -->

| Decisión | Alternativas consideradas | Elegida | Razón |
|----------|--------------------------|---------|-------|
| | | | |

## Enlaces relacionados

- **Specs previas**: [[vision]] (propósito) · [[requerimientos]] (qué construir)
- **Specs derivadas**: [[stack]] · [[integraciones]] · [[infraestructura]] · [[modelo]]
- **Contratos formales**: [[example.yaml|contracts/api/]] · [[example.sql|contracts/ddl/]]
- **Agente principal**: [[architect]] (genera scaffolding desde esta spec)
- **Agentes que la leen**: [[devops]] · [[security-reviewer]] · [[analyst]]
- **Comando relevante**: [[generate|/generate arquitectura]] (primer paso de generación)
