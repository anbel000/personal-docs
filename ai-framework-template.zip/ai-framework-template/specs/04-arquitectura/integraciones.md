---
domain: arquitectura
type: integraciones
approver: "Tech Lead / Arquitecto"
status: draft
last_updated: ""
contracts:
  - contracts/api/*.yaml
---

# Integraciones y APIs

## Mapa de integraciones

```mermaid
graph LR
    SYS[Nuestro Sistema] -->|REST| EXT1[Servicio Externo 1]
    SYS -->|Webhook| EXT2[Servicio Externo 2]
    EXT3[Servicio 3] -->|Callback| SYS
```

## APIs que consumimos

| Integración | Proveedor | Protocolo | Auth | Entorno sandbox | Contrato |
|-------------|-----------|-----------|------|-----------------|----------|
| | | REST/GraphQL/gRPC | API Key/OAuth | Sí/No | `contracts/api/[nombre].yaml` |

### Detalle por integración

#### [Nombre del servicio externo]

- **Base URL**: `https://api.example.com/v1`
- **Auth**: API Key en header `X-API-Key`
- **Rate limit**: 100 req/min
- **Timeout recomendado**: 10s
- **Retry policy**: 3 reintentos con exponential backoff
- **Contingencia si cae**: [queue + retry / fallback / degradación]

## APIs que exponemos

| Endpoint | Método | Propósito | Auth | Contrato |
|----------|--------|-----------|------|----------|
| `/api/v1/...` | GET/POST | | JWT | `contracts/api/[nombre].yaml` |

## Webhooks

| Evento | URL destino | Payload | Retry | Firma |
|--------|-------------|---------|-------|-------|
| | | JSON | 3x | HMAC-SHA256 |

## Enlaces relacionados

- **Spec previa**: [[arquitectura]] (diagrama de contexto muestra las integraciones)
- **Contratos formales**: [[example.yaml|contracts/api/]] (cada integración tiene su OpenAPI)
- **Agente principal**: [[implementer]] (genera clientes de API)
- **Regla de API**: [[api-patterns]] (patrones de consumo y retry)
- **Spec de seguridad**: [[requisitos]] (auth para APIs externas) · [[threat-model]] (superficie de ataque)
