# Instrucciones para el dominio de Arquitectura

> Estas instrucciones aplican cuando trabajas con archivos en `specs/04-arquitectura/`.

## Agente responsable

[[architect]] — genera scaffolding, Docker, configuraciones y ADRs. No implementa lógica de negocio.

## Prioridad de lectura en este dominio

1. `arquitectura.md` — diagrama C4 y decisiones estructurales
2. `stack.md` — tecnologías y versiones exactas (fuente de verdad para dependencias)
3. `integraciones.md` — sistemas externos y sus contratos
4. `docs/adr/` — decisiones ya tomadas (leer ANTES de proponer cambios)

## Reglas críticas

- **Versiones**: siempre usa las versiones EXACTAS declaradas en `stack.md`. No uses `latest`, `^`, `~` en archivos de configuración generados.
- **Nombres de componentes**: los nombres de servicios en `docker-compose.yml` y carpetas en `packages/` deben coincidir EXACTAMENTE con los nombres en el diagrama C4 de `arquitectura.md`.
- **ADRs antes de cambiar**: si vas a proponer un cambio de tecnología o estructura, primero verifica que no hay un ADR previo que lo prohíba.

## Cuándo crear un ADR

Crear un ADR en `docs/adr/` siempre que:
- Se elija una tecnología sobre otra
- Se decida un patrón de comunicación (REST vs GraphQL, sync vs async)
- Se establezca una estructura de monorepo/polyrepo
- Se tome una decisión que afecte a más de un agente o dominio

Usar el template en `docs/adr/0000-template.md`.

## Consistencia requerida

El [[architect]] debe verificar que:
- Los servicios en `docker-compose.yml` coinciden con los del diagrama C4
- El `stack.md` coincide con los `package.json` / `pyproject.toml` generados
- Las integraciones en `integraciones.md` tienen su contrato OpenAPI en `contracts/api/`
- Cada ADR nuevo queda referenciado en el README de `docs/adr/`
