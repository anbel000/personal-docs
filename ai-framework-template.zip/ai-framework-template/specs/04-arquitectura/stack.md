---
domain: arquitectura
type: stack
approver: "Tech Lead / Arquitecto"
status: draft
last_updated: ""
---

# Stack Tecnológico

## Stack principal

| Capa | Tecnología | Versión | Licencia | Justificación |
|------|------------|---------|----------|---------------|
| Frontend | | | | |
| Backend | | | | |
| Base de datos | | | | |
| Cache | | | | |
| Cola de mensajes | | | | |
| Hosting | | | | |

## Herramientas de desarrollo

| Herramienta | Versión | Propósito |
|-------------|---------|-----------|
| Node.js / Python | | Runtime |
| Docker | | Contenedores |
| Git | | Control de versiones |
| | | Linter |
| | | Formatter |
| | | Test runner |

## Versionado

- **Semantic versioning** para el producto: `MAJOR.MINOR.PATCH`
- **Lockfiles** obligatorios: `package-lock.json`, `poetry.lock`
- **Tool versions**: definidas en `.tool-versions` o equivalente

## Matriz de compatibilidad

| Navegador / OS | Versión mínima |
|----------------|----------------|
| Chrome | última - 2 |
| Firefox | última - 2 |
| Safari | última - 2 |
| Edge | última - 2 |
| iOS Safari | 15+ |
| Android Chrome | última - 2 |

## Enlaces relacionados

- **Spec previa**: [[arquitectura]] (componentes que usan este stack)
- **Agente principal**: [[architect]] (genera config de proyecto según el stack)
- **Regla de código**: [[coding-conventions]] (convenciones por lenguaje del stack)
- **Spec de infra**: [[infraestructura]] (sizing y hosting) · [[cicd]] (build tools)
