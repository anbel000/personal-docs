---
domain: legal
type: terminos
approver: "Legal"
status: draft
last_updated: ""
---

# Términos y Condiciones

## Documentos legales requeridos

| Documento | Estado | URL | Última revisión |
|-----------|--------|-----|----------------|
| Términos de servicio | | /terms | |
| Política de privacidad | | /privacy | |
| Política de cookies | | /cookies | |
| Acuerdo de nivel de servicio (SLA) | | /sla | |

## Temas clave en ToS

| Tema | Posición | Notas |
|------|----------|-------|
| Propiedad intelectual | | |
| Limitación de responsabilidad | | |
| Terminación del servicio | | |
| Jurisdicción | | |
| Modificaciones a los términos | Notificación 30 días antes | |

## Licencias de terceros

| Componente | Licencia | Compatible | Atribución requerida |
|------------|----------|------------|---------------------|
| | MIT / Apache 2.0 / GPL / etc. | Sí/No | Sí/No |

## Enlaces relacionados

- **Specs del dominio**: [[regulaciones]] · [[privacidad]]
- **Spec de producto**: [[requerimientos]] (funcionalidades reguladas)
- **Agente que lo consume**: [[analyst]]
