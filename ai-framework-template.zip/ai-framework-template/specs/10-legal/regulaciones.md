---
domain: legal
type: regulaciones
approver: "Legal / DPO"
status: draft
last_updated: ""
---

# Regulaciones Aplicables

## Inventario regulatorio

| Regulación | Jurisdicción | Área | Aplica | Impacto |
|------------|-------------|------|--------|---------|
| GDPR | UE | Datos personales | Sí/No | Alto/Medio/Bajo |
| Ley 1581/2012 | Colombia | Habeas Data | Sí/No | |
| PCI DSS v4.0 | Global | Pagos | Sí/No | |
| SOX | USA | Financiero | Sí/No | |
| HIPAA | USA | Salud | Sí/No | |
| LGPD | Brasil | Datos personales | Sí/No | |

## Acciones por regulación

### [Nombre de la regulación]

| Artículo / Requisito | Acción requerida | Responsable | Plazo | Estado |
|----------------------|------------------|-------------|-------|--------|
| | | | | Pendiente / En curso / Cumplido |

## Enlaces relacionados

- **Specs del dominio**: [[privacidad]] · [[terminos]]
- **Specs de seguridad**: [[cumplimiento]] · [[requisitos]] (controles por regulación)
- **Spec de datos**: [[gobernanza]] (clasificación y retención por regulación)
- **Agente que lo consume**: [[analyst]]
