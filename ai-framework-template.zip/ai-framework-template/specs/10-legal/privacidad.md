---
domain: legal
type: privacidad
approver: "Legal / DPO"
status: draft
last_updated: ""
---

# Privacidad de Datos

## Inventario de datos personales

| Dato | Categoría | Base legal | Retención | Encriptado |
|------|-----------|-----------|-----------|------------|
| Email | Contacto | Consentimiento | Mientras activo | Sí |
| Nombre | Identidad | Consentimiento | Mientras activo | No |
| IP | Técnico | Legítimo interés | 90 días | No |
| Ubicación | Sensible | Consentimiento explícito | Según uso | Sí |

## Consentimiento

- **Mecanismo**: Checkbox explícito (no pre-marcado) + link a política
- **Registro**: timestamp, versión de política, IP, texto aceptado
- **Revocación**: Disponible en configuración del usuario, efecto inmediato

## Derechos ARCO (Acceso, Rectificación, Cancelación, Oposición)

| Derecho | Endpoint / Mecanismo | SLA | Verificación de identidad |
|---------|---------------------|-----|--------------------------|
| Acceso | `GET /api/v1/me/data-export` | < 30 días | Auth + email confirm |
| Rectificación | `PUT /api/v1/me/profile` | Inmediato | Auth |
| Cancelación | `DELETE /api/v1/me` | < 30 días | Auth + email confirm + cooling period |
| Oposición | `PUT /api/v1/me/preferences` | Inmediato | Auth |
| Portabilidad | `GET /api/v1/me/data-export?format=json` | < 30 días | Auth + email confirm |

## Transferencias internacionales

| Destino | Mecanismo legal | Proveedor |
|---------|----------------|-----------|
| USA | Standard Contractual Clauses | [Cloud provider] |

## Enlaces relacionados

- **Specs del dominio**: [[regulaciones]] · [[terminos]]
- **Specs de datos**: [[gobernanza]] (clasificación PII) · [[modelo]] (campos personales)
- **Spec de seguridad**: [[requisitos]] (encriptación de PII) · [[cumplimiento]]
- **Agente que implementa**: [[implementer]] (endpoints ARCO)
- **Regla de seguridad**: [[security-patterns]] (logging sin PII)
