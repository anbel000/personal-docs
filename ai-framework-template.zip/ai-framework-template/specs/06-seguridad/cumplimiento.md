---
domain: seguridad
type: cumplimiento
approver: "Legal / DPO"
status: draft
last_updated: ""
---

# Cumplimiento Normativo

## Regulaciones aplicables

| Regulación | Jurisdicción | Aplica | Áreas afectadas |
|------------|-------------|--------|-----------------|
| GDPR | UE | Sí/No | Datos personales, consentimiento |
| Ley 1581 (Habeas Data) | Colombia | Sí/No | Datos personales |
| PCI DSS | Global | Sí/No | Pagos con tarjeta |
| SOC 2 Type II | Global | Sí/No | Seguridad, disponibilidad |
| HIPAA | USA | Sí/No | Datos de salud |

## Controles por regulación

| Regulación | Control requerido | Implementación | Estado |
|------------|-------------------|----------------|--------|
| GDPR Art. 7 | Consentimiento explícito | Consent banner + registro | |
| GDPR Art. 15-20 | Derechos ARCO | Endpoints de self-service | |
| GDPR Art. 33 | Notificación de breach | Runbook de incidentes | |

## Certificaciones objetivo

| Certificación | Fecha objetivo | Responsable | Estado |
|---------------|---------------|-------------|--------|
| | | | Pendiente / En proceso / Obtenida |

## Enlaces relacionados

- **Specs relacionadas**: [[requisitos]] (controles técnicos) · [[threat-model]]
- **Specs legales**: [[regulaciones]] · [[privacidad]] · [[terminos]]
- **Agente que lo consume**: [[security-reviewer]] · [[analyst]]
