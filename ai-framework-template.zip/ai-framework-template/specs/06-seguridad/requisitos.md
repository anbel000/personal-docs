---
domain: seguridad
type: requisitos
approver: "CISO / Security Lead"
status: draft
last_updated: ""
---

# Requisitos de Seguridad

## Autenticación

| ID | Control | Implementación | Prioridad |
|----|---------|----------------|-----------|
| SEC-AUTH-001 | Login con email + password | bcrypt hash, JWT tokens | Must |
| SEC-AUTH-002 | MFA opcional/obligatorio | TOTP (Google Authenticator) | Should |
| SEC-AUTH-003 | Expiración de sesión | Access: 15min, Refresh: 7d | Must |
| SEC-AUTH-004 | Bloqueo por intentos fallidos | 5 intentos → bloqueo 15min | Must |

## Autorización (RBAC)

| Rol | Permisos | Descripción |
|-----|----------|-------------|
| admin | CRUD completo + gestión de usuarios | Administrador del sistema |
| editor | CRUD sobre su contenido | Usuario con capacidad de edición |
| viewer | Solo lectura | Usuario de consulta |

## Encriptación

| Ámbito | Mecanismo | Detalle |
|--------|-----------|---------|
| En tránsito | TLS 1.3 | HTTPS obligatorio en todos los entornos |
| En reposo | AES-256 | Datos sensibles en DB |
| Passwords | bcrypt | Cost factor: 12 |
| Tokens | JWT RS256 | Claves rotadas cada 90 días |

## Seguridad de API

| Control | Implementación |
|---------|----------------|
| Rate limiting | [N] requests/min por usuario |
| Input validation | JSON Schema validation en middleware |
| CORS | Whitelist de orígenes permitidos |
| Headers de seguridad | HSTS, X-Content-Type-Options, CSP |

## Logging de auditoría

| Evento | Datos registrados | Retención |
|--------|-------------------|-----------|
| Login exitoso/fallido | userId, IP, timestamp, userAgent | 90 días |
| Cambio de permisos | userId, oldRole, newRole, changedBy | 1 año |
| Acceso a datos sensibles | userId, recurso, acción, timestamp | 1 año |
| Operaciones destructivas | userId, recurso, detalle, timestamp | 1 año |

## Enlaces relacionados

- **Specs relacionadas**: [[threat-model]] (amenazas que estos controles mitigan) · [[cumplimiento]] (regulaciones que requieren estos controles)
- **Specs que informa**: [[privacidad]] · [[gobernanza]] (clasificación de datos)
- **Agente principal**: [[security-reviewer]] (valida cumplimiento de SEC-*)
- **Agente que implementa**: [[implementer]] (middleware auth/authz)
- **Regla de seguridad**: [[security-patterns]] (patrones obligatorios derivados de esta spec)
- **Contratos**: [[example.yaml|contracts/api/]] (securitySchemes definidos aquí)
