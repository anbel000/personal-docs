---
domain: seguridad
type: threat-model
approver: "CISO / Security Lead"
status: draft
last_updated: ""
---

# Threat Model (STRIDE)

## Superficie de ataque

| Componente | Expuesto a | Puertos/Protocolos | Datos sensibles |
|------------|------------|-------------------|-----------------|
| Web App | Internet | HTTPS:443 | Cookies, JWT |
| API Server | Internet (vía LB) | HTTPS:443 | PII, credentials |
| Base de datos | Red interna | TCP:5432 | Todos los datos |
| Cache | Red interna | TCP:6379 | Sesiones |

## Análisis STRIDE por componente

### Web App (Frontend)

| Amenaza | Tipo STRIDE | Riesgo | Mitigación |
|---------|-------------|--------|------------|
| XSS | Tampering | Alto | CSP + sanitización + escape |
| CSRF | Spoofing | Medio | CSRF tokens + SameSite cookies |
| Clickjacking | Tampering | Bajo | X-Frame-Options: DENY |

### API Server

| Amenaza | Tipo STRIDE | Riesgo | Mitigación |
|---------|-------------|--------|------------|
| Inyección SQL | Tampering | Crítico | Parameterized queries + ORM |
| Broken auth | Spoofing | Crítico | JWT validation + refresh rotation |
| IDOR | Elevation of privilege | Alto | Ownership checks en cada endpoint |
| DoS | Denial of service | Alto | Rate limiting + WAF |

### Base de Datos

| Amenaza | Tipo STRIDE | Riesgo | Mitigación |
|---------|-------------|--------|------------|
| Data breach | Information disclosure | Crítico | Encriptación at-rest + acceso mínimo |
| Unauthorized access | Elevation of privilege | Crítico | Credenciales en vault, no en código |

## Resumen de riesgo

| Nivel | Cantidad | Acción |
|-------|----------|--------|
| Crítico | | Mitigar antes de producción |
| Alto | | Mitigar en MVP |
| Medio | | Mitigar en v1.0 |
| Bajo | | Aceptar con monitoreo |

## Enlaces relacionados

- **Spec previa**: [[arquitectura]] (componentes analizados por amenazas)
- **Specs relacionadas**: [[requisitos]] (controles que mitigan amenazas) · [[cumplimiento]]
- **Agente principal**: [[security-reviewer]] (valida mitigaciones implementadas)
- **Spec de infra**: [[infraestructura]] (firewall, WAF) · [[monitoreo]] (alertas de seguridad)
