# Instrucciones para el dominio de Seguridad

> Estas instrucciones aplican cuando trabajas con archivos en `specs/06-seguridad/` y `contracts/` relacionados con seguridad.

## Regla de oro de este dominio

**Nunca generes código de seguridad que no esté explícitamente definido en una spec de este dominio.** Si falta cobertura, reporta el gap — no inventes controles.

## Agente responsable

El [[security-reviewer]] es de **solo lectura** — audita, no genera. Para implementar controles de seguridad, el agente correcto es [[implementer]] usando estas specs como referencia.

## Prioridad de lectura en este dominio

1. `requisitos.md` — controles obligatorios (SEC-AUTH-*, SEC-AUTHZ-*, SEC-PRIV-*)
2. `threat-model.md` — amenazas STRIDE a considerar en el diseño
3. `cumplimiento.md` — regulaciones que imponen requisitos técnicos (GDPR, PCI DSS, etc.)

## Convenciones de IDs de controles

- `SEC-AUTH-NNN` — Autenticación
- `SEC-AUTHZ-NNN` — Autorización y control de acceso
- `SEC-INPUT-NNN` — Validación de entrada
- `SEC-CRYPTO-NNN` — Criptografía y cifrado
- `SEC-PRIV-NNN` — Privacidad y datos personales
- `SEC-AUDIT-NNN` — Logging de auditoría
- `SEC-INFRA-NNN` — Seguridad de infraestructura

## Lo que NO se puede hacer aquí

- Hardcodear secrets, tokens, passwords o claves en ningún archivo de specs
- Definir algoritmos de cifrado débiles (MD5, SHA1, DES, RC4)
- Establecer períodos de expiración de tokens mayores a 24h sin justificación documentada
- Omitir el threat model antes de definir controles

## Impacto en otros dominios

Los controles definidos aquí impactan directamente:
- `specs/04-arquitectura/` — middleware de seguridad debe estar en el diagrama C4
- `specs/05-datos/` — PII debe estar identificado en el modelo de datos
- `specs/07-infra/` — configuración de red y secrets management
- `contracts/api/` — endpoints de auth deben estar en el contrato OpenAPI
