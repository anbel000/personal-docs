---
domain: operaciones
type: despliegue
approver: "Operations Manager"
status: draft
last_updated: ""
---

# Plan de Despliegue

## Estrategia de rollout

| Fase | Audiencia | Duración | Criterio de avance |
|------|-----------|----------|-------------------|
| Alpha | Equipo interno | 1 semana | 0 bugs blocker/critical |
| Beta | Usuarios seleccionados | 2 semanas | NPS > [N], < [N] bugs major |
| GA | Todos los usuarios | Permanente | Métricas estables |

## Checklist pre-go-live

- [ ] Todos los quality gates pasados en CI/CD
- [ ] Staging probado por QA y stakeholders clave
- [ ] Migraciones de DB ejecutadas exitosamente en staging
- [ ] Monitoreo y alertas configuradas
- [ ] Runbook de operación documentado
- [ ] Rollback plan probado
- [ ] Comunicación a usuarios preparada
- [ ] Soporte briefeado sobre nuevas funcionalidades

## Plan de rollback

| Trigger | Acción | Tiempo máximo | Responsable |
|---------|--------|---------------|-------------|
| Error rate > 5% | Rollback automático | 5 min | CI/CD |
| Bug crítico reportado | Rollback manual | 30 min | On-call |
| Migración fallida | Ejecutar down migration | 15 min | DBA + On-call |

## Comunicación de lanzamiento

| Audiencia | Canal | Mensaje | Timing |
|-----------|-------|---------|--------|
| Equipo interno | Slack #releases | Release notes técnicos | Día del deploy |
| Usuarios | Email + in-app | Nuevas funcionalidades | Post-GA |
| Stakeholders | Reporte | Métricas de adopción | Semana 1 post-GA |

## Enlaces relacionados

- **Specs de infra**: [[infraestructura]] (entornos) · [[cicd]] (pipeline de deploy) · [[monitoreo]] (health checks)
- **Specs relacionadas**: [[roadmap]] (fases de rollout) · [[runbook]] (procedimientos post-deploy) · [[soporte]] (canales para incidentes)
- **Agente principal**: [[devops]] (genera scripts de deploy y rollback)
- **Spec de calidad**: [[criterios-aceptacion]] (checklist pre-go-live)
