---
domain: operaciones
type: soporte
approver: "Operations Manager"
status: draft
last_updated: ""
---

# Soporte y Escalamiento

## Canales de soporte

| Canal | Horario | Tipo de issues | SLA primera respuesta |
|-------|---------|----------------|----------------------|
| Email | 24/7 (respuesta en horario laboral) | General | < 4h hábiles |
| Chat in-app | Horario laboral | Rápidas, funcionales | < 1h |
| Teléfono | Horario laboral | Críticas, urgentes | Inmediato |
| Status page | 24/7 | Incidentes masivos | Actualización cada 30min |

## Niveles de soporte

| Nivel | Responsable | Tipo de issues | Escalamiento |
|-------|-------------|----------------|-------------|
| L1 | Soporte frontline | FAQ, configuración, bugs conocidos | Si no resuelve en 30 min → L2 |
| L2 | Soporte técnico | Bugs, integraciones, diagnóstico | Si necesita cambio de código → L3 |
| L3 | Engineering | Bugs complejos, hotfixes, root cause | Si impacto masivo → Incident Manager |

## SLA por severidad

| Severidad | Definición | Primera respuesta | Resolución |
|-----------|------------|-------------------|------------|
| P1 Crítica | Servicio caído o pérdida de datos | < 15 min | < 4h |
| P2 Alta | Funcionalidad core degradada | < 1h | < 24h |
| P3 Media | Funcionalidad secundaria afectada | < 4h | < 72h |
| P4 Baja | Cosmético o mejora | < 24h | Próximo release |

## Flujo de escalamiento

```mermaid
graph TD
    TICKET[Ticket recibido] --> TRIAGE{Severidad}
    TRIAGE -->|P1| ONCALL[On-call inmediato]
    TRIAGE -->|P2| L2[Soporte L2]
    TRIAGE -->|P3-P4| L1[Soporte L1]
    L1 -->|No resuelto 30min| L2
    L2 -->|Necesita código| L3[Engineering]
    ONCALL --> INCIDENT[Incident Manager]
```

## Enlaces relacionados

- **Specs relacionadas**: [[runbook]] (procedimientos que L2/L3 ejecutan) · [[despliegue]] (comunicación de lanzamiento) · [[monitoreo]] (alertas → tickets)
- **Spec de calidad**: [[estrategia]] (severidad de defectos)
- **Agente que lo consume**: [[analyst]] (validación de completitud)
