---
domain: operaciones
type: runbook
approver: "SRE Lead"
status: draft
last_updated: ""
---

# Runbook Operacional

## Incidente: [Nombre del incidente tipo]

### Diagnóstico

| Paso | Acción | Comando / Herramienta | Resultado esperado |
|------|--------|-----------------------|-------------------|
| 1 | Verificar estado del servicio | `curl -s https://api.example.com/health` | `{"status":"ok"}` |
| 2 | Revisar logs recientes | [Herramienta de logs] filtro: `level:error last:15m` | Identificar error |
| 3 | Verificar métricas | Dashboard de [monitoreo] | Identificar anomalía |
| 4 | Verificar deploys recientes | `git log --oneline -5` en main | ¿Deploy reciente? |

### Remediación

| Causa probable | Acción correctiva | Comando | Verificación |
|---------------|-------------------|---------|-------------|
| Deploy roto | Rollback | [comando de rollback] | Health check OK |
| DB saturada | Escalar + matar queries lentas | [comando] | Conexiones normales |
| Servicio externo caído | Activar circuit breaker | [acción] | Degradación graceful |

### Escalamiento

| Tiempo sin resolver | Escalar a | Canal |
|--------------------|-----------| ------|
| 15 min | Tech Lead on-call | PagerDuty |
| 30 min | Engineering Manager | Slack + teléfono |
| 1 hora | VP Engineering / CTO | Teléfono directo |

---

## Procedimiento: Rotación de secrets

### Pasos

1. Generar nuevo secret en [vault/secret manager]
2. Actualizar en entorno de staging → verificar
3. Actualizar en producción con deploy rolling
4. Invalidar secret anterior después de 24h
5. Documentar rotación en log de auditoría

## Enlaces relacionados

- **Specs relacionadas**: [[despliegue]] (rollback como procedimiento) · [[soporte]] (escalamiento) · [[monitoreo]] (alertas que disparan runbooks)
- **Spec de seguridad**: [[requisitos]] (rotación de secrets)
- **Agente principal**: [[devops]]
