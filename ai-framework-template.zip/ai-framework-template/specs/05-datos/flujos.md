---
domain: datos
type: flujos
approver: "Data Architect"
status: draft
last_updated: ""
---

# Flujos de Datos

## Diagrama de flujo de datos

```mermaid
graph LR
    SOURCE[Fuente] -->|Ingesta| STAGE[Staging]
    STAGE -->|Transformación| DW[Data Warehouse]
    DW -->|Serving| API[API / Dashboard]
```

## Pipelines

| Pipeline | Origen | Destino | Frecuencia | SLA |
|----------|--------|---------|------------|-----|
| | | | Real-time / Batch / Scheduled | |

### Detalle del pipeline: [Nombre]

| Paso | Acción | Validación | Error handling |
|------|--------|------------|----------------|
| 1. Extract | | | |
| 2. Transform | | | |
| 3. Load | | | |

## Volumen y rendimiento

| Métrica | Valor actual | Proyección 12 meses |
|---------|-------------|---------------------|
| Registros/día | | |
| Tamaño de DB | | |
| Queries/segundo pico | | |

## Enlaces relacionados

- **Spec previa**: [[modelo]] (entidades que fluyen por los pipelines)
- **Specs relacionadas**: [[gobernanza]] (calidad de datos) · [[monitoreo]] (métricas de pipeline)
- **Agente principal**: [[data-engineer]] (genera pipelines ETL)
- **Spec de infra**: [[infraestructura]] (recursos para procesamiento)
