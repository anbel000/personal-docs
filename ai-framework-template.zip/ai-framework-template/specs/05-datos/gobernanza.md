---
domain: datos
type: gobernanza
approver: "Data Architect / DPO"
status: draft
last_updated: ""
---

# Gobernanza de Datos

## Clasificación de datos

| Nivel | Descripción | Ejemplos | Controles |
|-------|-------------|----------|-----------|
| Público | Sin restricción | Landing page, docs públicos | Ninguno especial |
| Interno | Solo empleados | Métricas internas, roadmap | Auth requerida |
| Confidencial | Need-to-know | PII, datos financieros | Encriptación + RBAC |
| Restringido | Máxima protección | Passwords, tokens, claves | Encriptación + audit log + acceso mínimo |

## Ownership de datos

| Dominio de datos | Owner | Steward técnico |
|-----------------|-------|-----------------|
| Usuarios | | |
| Transacciones | | |
| Producto | | |

## Retención y eliminación

| Tipo de dato | Retención | Después de expirar | Base legal |
|--------------|-----------|-------------------|------------|
| Logs de acceso | 90 días | Eliminación automática | Legítimo interés |
| Datos de usuario | Mientras cuenta activa + 30 días | Anonimización | Consentimiento |
| Backups | 30 días | Rotación automática | Continuidad |

## Métricas de calidad

| Métrica | Definición | Umbral aceptable |
|---------|------------|-----------------|
| Completitud | % de campos no-null en campos obligatorios | > 99% |
| Unicidad | % de registros sin duplicados | 100% |
| Frescura | Tiempo desde última actualización | < [definir] |
| Validez | % de registros que pasan reglas de validación | > 99.5% |

## Enlaces relacionados

- **Specs relacionadas**: [[modelo]] (entidades gobernadas) · [[flujos]] (pipelines con validación)
- **Specs de seguridad**: [[requisitos]] (encriptación) · [[privacidad]] (clasificación de PII) · [[cumplimiento]]
- **Agente que lo consume**: [[data-engineer]] (genera validadores de calidad)
- **Regla de seguridad**: [[security-patterns]] (logging de acceso a datos)
