# Instrucciones para el dominio de Datos

> Estas instrucciones aplican cuando trabajas con archivos en `specs/05-datos/`.

## Agente responsable

[[data-engineer]] — genera modelos ORM, migraciones, repositorios y pipelines. El [[security-reviewer]] audita que los datos de PII estén protegidos.

## Prioridad de lectura en este dominio

1. `contracts/ddl/*.sql` — el DDL es la fuente de verdad del schema (tiene prioridad sobre `modelo.md`)
2. `contracts/schemas/*.json` — JSON Schema de cada entidad
3. `modelo.md` — contexto de negocio sobre las entidades
4. `flujos.md` — cómo fluyen los datos entre sistemas
5. `gobernanza.md` — reglas de calidad y retención de datos

## Reglas críticas

- **DDL primero**: si hay conflicto entre `modelo.md` y `contracts/ddl/`, el DDL gana. Reportar la discrepancia al usuario.
- **PII siempre marcado**: toda columna que contenga dato personal debe tener comentario `-- PII` en el DDL y estar documentada en `specs/06-seguridad/cumplimiento.md`.
- **Nombres consistentes**: los nombres de tablas en el DDL, entidades en el JSON Schema, y modelos ORM generados deben ser idénticos (snake_case singular para tablas, PascalCase singular para clases).
- **Sin migraciones destructivas sin advertencia**: si una migración elimina o renombra columnas, advertir explícitamente al usuario antes de generarla.

## Convenciones de migración

- Archivos nombrados: `NNN_descripcion_corta.sql` (ej: `001_initial_schema.sql`, `002_add_user_roles.sql`)
- Siempre incluir `-- Up migration` y `-- Down migration` (rollback)
- Las migraciones son append-only — nunca modificar una migración ya ejecutada

## Relación con otros dominios

- Las entidades del modelo deben ser consistentes con los endpoints en `contracts/api/`
- Los campos de PII impactan `specs/06-seguridad/cumplimiento.md` y `specs/10-legal/privacidad.md`
- Los flujos de datos en `flujos.md` deben poder trazarse hasta los pipelines en `src/pipelines/`
