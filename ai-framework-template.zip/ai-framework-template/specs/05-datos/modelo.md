---
domain: datos
type: modelo
approver: "Data Architect"
status: draft
last_updated: ""
contracts:
  - contracts/ddl/*.sql
  - contracts/schemas/*.json
---

# Modelo de Datos

## Diagrama entidad-relación

```mermaid
erDiagram
    USER ||--o{ ORDER : places
    ORDER ||--|{ ORDER_ITEM : contains
    PRODUCT ||--o{ ORDER_ITEM : "is in"
    USER {
        uuid id PK
        varchar email UK
        varchar name
        varchar role
        varchar status
        timestamptz created_at
        timestamptz updated_at
    }
    ORDER {
        uuid id PK
        uuid user_id FK
        varchar status
        decimal total
        timestamptz created_at
    }
```

## Catálogo de entidades

| Entidad | Descripción | DDL | JSON Schema | Volumen estimado |
|---------|-------------|-----|-------------|-----------------|
| User | Usuarios del sistema | `contracts/ddl/user.sql` | `contracts/schemas/user.json` | |
| | | | | |

## Estrategia de migraciones

- Versionado: `NNN_descripcion_corta.sql` (ej: `001_create_user_table.sql`)
- Tool: [Flyway / Alembic / Prisma Migrate / custom]
- Rollback: cada migración tiene su `down` correspondiente
- Datos semilla: en `seeders/` separados de migraciones

## Reglas de datos

| Regla | Entidad | Campo | Validación |
|-------|---------|-------|------------|
| Email único | User | email | UNIQUE constraint + app validation |
| | | | |

> **Fuente de verdad**: Los archivos en `contracts/ddl/` definen nombres y tipos exactos. El código DEBE coincidir.

## Enlaces relacionados

- **Specs previas**: [[arquitectura]] (componentes que persisten datos) · [[requerimientos]]
- **Contratos formales**: [[example.sql|contracts/ddl/]] (fuente de verdad) · [[example.json|contracts/schemas/]] (validación)
- **Specs derivadas**: [[flujos]] (pipelines que mueven estos datos) · [[gobernanza]] (clasificación y retención)
- **Agente principal**: [[data-engineer]] (genera migraciones, ORM, repositorios)
- **Agentes que lo leen**: [[implementer]] · [[analyst]] (consistencia modelo↔schema↔DDL)
- **Comando relevante**: [[generate|/generate datos]]
