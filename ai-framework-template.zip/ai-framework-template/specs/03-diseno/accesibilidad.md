---
domain: diseno
type: accesibilidad
approver: "UX Lead"
status: draft
last_updated: ""
---

# Accesibilidad (WCAG 2.1 AA)

## Criterios obligatorios

### Perceptible

| Criterio | Requisito | Cómo verificar |
|----------|-----------|----------------|
| 1.1.1 Texto alternativo | Todas las imágenes con `alt` descriptivo | Axe / Lighthouse |
| 1.3.1 Información y relaciones | Markup semántico (headings, landmarks, listas) | Lector de pantalla |
| 1.4.3 Contraste mínimo | 4.5:1 texto normal, 3:1 texto grande | Color contrast checker |
| 1.4.11 Contraste no textual | 3:1 para bordes, iconos, controles | Manual review |

### Operable

| Criterio | Requisito | Cómo verificar |
|----------|-----------|----------------|
| 2.1.1 Teclado | Todo funcional sin mouse | Tab through completo |
| 2.4.3 Orden de foco | Secuencia lógica de tab | Navegación manual |
| 2.4.7 Foco visible | Indicador visible en todos los elementos | Visual inspection |
| 2.5.5 Target size | Mínimo 44x44px en touch | DevTools measure |

### Comprensible

| Criterio | Requisito | Cómo verificar |
|----------|-----------|----------------|
| 3.1.1 Idioma de la página | `lang` en `<html>` | HTML validator |
| 3.3.1 Identificación de errores | Errores descritos en texto (no solo color) | Form testing |
| 3.3.2 Etiquetas o instrucciones | Todos los inputs con label visible | Axe |

### Robusto

| Criterio | Requisito | Cómo verificar |
|----------|-----------|----------------|
| 4.1.2 Nombre, función, valor | ARIA correctamente aplicado | Axe / WAVE |

## Herramientas de verificación

- **Automatizado**: axe-core, Lighthouse, WAVE
- **Manual**: Navegación solo teclado, lector de pantalla (VoiceOver/NVDA)
- **CI**: jest-axe o cypress-axe en pipeline

## Enlaces relacionados

- **Specs relacionadas**: [[design-system]] (contraste y focus visible) · [[arquitectura-informacion]]
- **Spec de calidad**: [[estrategia]] · [[criterios-aceptacion]] (a11y es parte del DoD)
- **Agente que genera tests**: [[qa]] (tests de accesibilidad con axe-core)
- **Regla de testing**: [[testing-patterns]] (tests a11y en la pirámide)
