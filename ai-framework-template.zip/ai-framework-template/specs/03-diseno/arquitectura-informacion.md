---
domain: diseno
type: arquitectura-informacion
approver: "UX Lead"
status: draft
last_updated: ""
---

# Arquitectura de Información

## Mapa de navegación

```mermaid
graph TD
    HOME[Home] --> AUTH[Auth]
    HOME --> DASH[Dashboard]
    AUTH --> LOGIN[Login]
    AUTH --> REGISTER[Registro]
    DASH --> MOD1[Módulo 1]
    DASH --> MOD2[Módulo 2]
    DASH --> SETTINGS[Configuración]
    SETTINGS --> PROFILE[Perfil]
    SETTINGS --> SECURITY[Seguridad]
```

## Estructura de rutas

| Ruta | Pantalla | Auth requerida | Rol mínimo | Componente |
|------|----------|----------------|------------|------------|
| `/` | Landing / Home | No | — | |
| `/login` | Login | No | — | |
| `/register` | Registro | No | — | |
| `/dashboard` | Dashboard | Sí | viewer | |
| `/settings` | Configuración | Sí | viewer | |
| `/admin` | Panel admin | Sí | admin | |

## Patrones de navegación

- **Desktop**: Sidebar fija + breadcrumbs
- **Mobile**: Bottom tabs + hamburger menu para secundarios
- **Navegación contextual**: Tabs dentro de cada módulo

## Reglas de responsive

| Breakpoint | Layout | Navegación | Contenido |
|------------|--------|------------|-----------|
| Mobile (<768px) | Stack vertical | Bottom tabs | Full width |
| Tablet (768-1024px) | 2 columnas | Sidebar colapsable | Grids adaptativos |
| Desktop (>1024px) | Sidebar + contenido | Sidebar fija | Max-width container |

## Enlaces relacionados

- **Specs relacionadas**: [[flujos-usuario]] · [[design-system]] · [[accesibilidad]]
- **Spec técnica**: [[arquitectura]] (rutas del frontend mapeadas a la IA)
- **Agente que lo consume**: [[designer]] (genera estructura de rutas)
