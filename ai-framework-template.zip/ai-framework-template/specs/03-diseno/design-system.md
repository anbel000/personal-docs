---
domain: diseno
type: design-system
approver: "UX Lead"
status: draft
last_updated: ""
---

# Design System

## Tokens de diseño

### Colores

| Token | Valor | Uso |
|-------|-------|-----|
| `--color-primary` | | Acciones principales, CTAs |
| `--color-secondary` | | Acciones secundarias |
| `--color-success` | | Estados exitosos |
| `--color-warning` | | Alertas |
| `--color-error` | | Errores, destructivo |
| `--color-neutral-100` | | Backgrounds |
| `--color-neutral-900` | | Texto principal |

### Tipografía

| Token | Valor | Uso |
|-------|-------|-----|
| `--font-family-primary` | | Textos generales |
| `--font-family-mono` | | Código |
| `--font-size-xs` | 12px | Captions |
| `--font-size-sm` | 14px | Body small |
| `--font-size-md` | 16px | Body default |
| `--font-size-lg` | 20px | Subtítulos |
| `--font-size-xl` | 24px | Títulos |
| `--font-size-2xl` | 32px | Headings |

### Espaciado

Escala base: 4px → `--space-1` = 4px, `--space-2` = 8px, ..., `--space-8` = 32px

### Breakpoints

| Token | Valor | Dispositivo |
|-------|-------|-------------|
| `--bp-mobile` | 480px | Móvil |
| `--bp-tablet` | 768px | Tablet |
| `--bp-desktop` | 1024px | Desktop |
| `--bp-wide` | 1280px | Desktop ancho |

## Componentes base

| Componente | Variantes | Estados | Accesibilidad |
|------------|-----------|---------|---------------|
| Button | primary, secondary, ghost, danger | default, hover, active, disabled, loading | aria-label, focus visible |
| Input | text, email, password, search | default, focus, error, disabled | aria-describedby para errores |
| Select | single, multi | default, open, error, disabled | keyboard navigation |
| Modal | info, confirm, form | open, closing | focus trap, aria-modal |
| Toast | success, error, warning, info | entering, visible, exiting | aria-live="polite" |
| Table | default, compact | loading, empty, error | scope headers, aria-sort |

## Accesibilidad

- Contraste mínimo: 4.5:1 (texto normal), 3:1 (texto grande / iconos)
- Focus visible en TODOS los elementos interactivos
- Touch targets mínimo 44x44px
- Soporte completo de navegación por teclado
- WCAG 2.1 AA como mínimo

## Enlaces relacionados

- **Specs relacionadas**: [[arquitectura-informacion]] · [[accesibilidad]] (contraste, focus, targets)
- **Spec de producto**: [[flujos-usuario]] (pantallas que usan los componentes)
- **Agente que lo consume**: [[designer]] (genera theme y componentes base)
- **Regla de código**: [[coding-conventions]] (naming de archivos de componentes)
