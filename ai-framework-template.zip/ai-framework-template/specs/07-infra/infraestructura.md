---
domain: infraestructura
type: infraestructura
approver: "SRE Lead"
status: draft
last_updated: ""
---

# Infraestructura

## Proveedor cloud

- **Principal**: [AWS / GCP / Azure / On-premise]
- **Región**: 
- **Estrategia IaC**: Terraform / Pulumi / CDK

## Diagrama de infraestructura

```mermaid
graph TB
    subgraph Cloud
        LB[Load Balancer] --> APP1[App Server 1]
        LB --> APP2[App Server 2]
        APP1 --> DB[(RDS / CloudSQL)]
        APP2 --> DB
        APP1 --> CACHE[(ElastiCache / Memorystore)]
        APP2 --> CACHE
    end
    CDN[CDN] --> LB
    USER[Usuarios] --> CDN
```

## Entornos

| Entorno | Propósito | Sizing | URL | Acceso |
|---------|-----------|--------|-----|--------|
| local | Desarrollo | Docker Compose | localhost:3000 | Desarrolladores |
| dev | Integración continua | Mínimo | dev.example.com | Equipo |
| staging | Pre-producción | = Prod | staging.example.com | Equipo + QA |
| production | Producción | Según SLA | app.example.com | Usuarios finales |

## Sizing y costos estimados

| Recurso | Tipo/Tamaño | Cantidad | Costo mensual estimado |
|---------|-------------|----------|----------------------|
| Compute | | | |
| Base de datos | | | |
| Cache | | | |
| Storage | | | |
| CDN | | | |
| **Total** | | | **$** |

## Networking

| CIDR | Subnet | Propósito |
|------|--------|-----------|
| 10.0.0.0/16 | VPC principal | |
| 10.0.1.0/24 | Pública | Load balancers |
| 10.0.10.0/24 | Privada | App servers |
| 10.0.20.0/24 | Aislada | Bases de datos |

## Gotchas por proveedor cloud

### Railway

- **`railway logs`**: solo muestra logs de startup del container, NO los logs runtime de la aplicación. Para logs en producción, usar el dashboard web o configurar un drain hacia un servicio externo (Datadog, Papertrail).
- **`railway variables`**: trunca valores largos en la tabla. Usar `railway variables --json` para obtener el valor completo (especialmente importante para JWT secrets y API keys largas).
- **Base de datos interna**: `*.railway.internal` solo es accesible desde dentro del container. `railway run <comando>` inyecta las env vars pero ejecuta localmente — no puede alcanzar la DB interna. Para scripts que necesitan la DB, usar `DATABASE_PUBLIC_URL` (TCP proxy).
- **`railway up --detach`**: alternativa al git push cuando el cache Docker está desactualizado o el webhook de GitHub no está configurado. Sube el código local directamente (~3-5 min).
- **Auto-deploy desde GitHub**: Railway requiere configurar explícitamente el branch trigger en Settings → Source por cada servicio. No se activa automáticamente al conectar el repo.

## Enlaces relacionados

- **Spec previa**: [[arquitectura]] (componentes a desplegar)
- **Specs del dominio**: [[cicd]] · [[monitoreo]]
- **Specs relacionadas**: [[stack]] (tecnologías a hostear) · [[despliegue]] (rollout plan)
- **Agente principal**: [[devops]] (genera Terraform, Dockerfiles)
- **Regla de seguridad**: [[security-patterns]] (secrets, networking)
