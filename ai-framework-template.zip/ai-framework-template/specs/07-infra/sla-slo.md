---
domain: infraestructura
type: sla-slo
approver: "Engineering Lead / SRE"
status: draft
last_updated: ""
---

# SLA / SLO

## Definiciones

- **SLI** (Service Level Indicator): métrica real medida
- **SLO** (Service Level Objective): objetivo interno del equipo
- **SLA** (Service Level Agreement): compromiso contractual con el cliente

## SLOs por servicio

| Servicio | SLI | SLO | Ventana de medición |
|----------|-----|-----|---------------------|
| API principal | Disponibilidad | [PENDIENTE]% | 30 días |
| API principal | Latencia p95 | [PENDIENTE] ms | 7 días |
| API principal | Tasa de error | < [PENDIENTE]% | 24 horas |
| [Servicio 2] | | | |

## SLAs contractuales

| Métrica | Compromiso | Penalización por incumplimiento |
|---------|-----------|--------------------------------|
| [PENDIENTE] | | |

## Error budget

<!-- Tiempo disponible de downtime dentro del SLO en un período de 30 días -->

| SLO | Error budget mensual |
|-----|---------------------|
| 99.9% disponibilidad | 43.8 minutos |
| [PENDIENTE]% | |

## Alertas y on-call

| Severidad | Tiempo de respuesta | Canal de notificación |
|-----------|--------------------|-----------------------|
| P0 — crítico | [PENDIENTE] | |
| P1 — alto | [PENDIENTE] | |
| P2 — medio | [PENDIENTE] | |

## Runbooks

<!-- Links a runbooks por tipo de incidente -->

[PENDIENTE]

## Enlaces relacionados

- **Spec padre**: [[infraestructura]]
- **Specs relacionadas**: [[cicd]] · [[monitoreo]]
- **Agente que lo consume**: [[devops]] · [[security-reviewer]]
