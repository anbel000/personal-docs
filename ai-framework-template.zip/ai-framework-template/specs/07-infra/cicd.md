---
domain: infraestructura
type: cicd
approver: "SRE Lead"
status: draft
last_updated: ""
---

# CI/CD Pipeline

## Diagrama del pipeline

```mermaid
graph LR
    PUSH[Push / PR] --> LINT[Lint + Format]
    LINT --> TEST[Unit Tests]
    TEST --> BUILD[Build]
    BUILD --> ITEST[Integration Tests]
    ITEST --> SCAN[Security Scan]
    SCAN --> DEPLOY_STG[Deploy Staging]
    DEPLOY_STG --> E2E[E2E Tests]
    E2E --> APPROVE{Aprobación}
    APPROVE -->|Sí| DEPLOY_PROD[Deploy Prod]
```

## Stages y gates

| Stage | Trigger | Gate (debe pasar para continuar) | Tiempo máximo |
|-------|---------|----------------------------------|---------------|
| Lint + Format | Push a cualquier rama | 0 errores de lint | 2 min |
| Unit Tests | Post-lint | Coverage ≥ [N]%, 0 fallos | 5 min |
| Build | Post-tests | Build exitoso | 5 min |
| Integration Tests | Post-build | 0 fallos | 10 min |
| Security Scan | Post-integration | 0 vulnerabilidades críticas/altas | 5 min |
| Deploy Staging | Merge a `develop` | Deploy exitoso + health check | 5 min |
| E2E Tests | Post-deploy staging | 0 fallos en flujos críticos | 15 min |
| Deploy Producción | Aprobación manual + merge a `main` | Health check + smoke tests | 10 min |

## Branching strategy

- **main**: producción — solo merges desde develop con PR aprobado
- **develop**: integración — merges desde feature branches
- **feature/xxx**: desarrollo de funcionalidades
- **hotfix/xxx**: correcciones urgentes en producción

## Estrategia de deploy

- **Tipo**: [Blue-Green / Canary / Rolling]
- **Rollback**: automático si health check falla en los primeros 5 minutos
- **Feature flags**: [LaunchDarkly / custom / ninguno]

## Enlaces relacionados

- **Specs del dominio**: [[infraestructura]] · [[monitoreo]]
- **Spec de calidad**: [[estrategia]] (quality gates) · [[criterios-aceptacion]] (DoD incluye CI/CD)
- **Agente principal**: [[devops]] (genera workflows de CI/CD)
- **Spec de seguridad**: [[requisitos]] (security scan en pipeline)
- **Regla de seguridad**: [[security-patterns]] (audit de dependencias en CI)
