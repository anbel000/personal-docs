---
domain: infraestructura
type: monitoreo
approver: "SRE Lead"
status: draft
last_updated: ""
---

# Monitoreo y Observabilidad

## Pilares

| Pilar | Herramienta | Propósito |
|-------|-------------|-----------|
| Logs | [ELK / CloudWatch / Datadog] | Diagnóstico y auditoría |
| Métricas | [Prometheus / CloudWatch / Datadog] | Rendimiento y alertas |
| Traces | [Jaeger / X-Ray / Datadog APM] | Latencia y dependencias |

## Golden Signals

| Signal | Métrica | Umbral de alerta | Umbral crítico |
|--------|---------|-------------------|----------------|
| Latencia | p95 response time | > 500ms | > 2s |
| Tráfico | Requests/segundo | > [N] (capacidad) | > [N] (saturación) |
| Errores | Error rate (5xx) | > 1% | > 5% |
| Saturación | CPU / Memory usage | > 70% | > 90% |

## Métricas de negocio

| Métrica | Fuente | Dashboard | Alerta |
|---------|--------|-----------|--------|
| Registros/hora | API logs | Sí | Si cae > 50% | 
| Conversiones | DB + eventos | Sí | No |
| Tiempo de onboarding | Frontend events | Sí | Si > [N] min |

## Política de alertas

| Severidad | Tiempo de respuesta | Notificación | Escalamiento |
|-----------|--------------------|--------------|--------------| 
| P1 Crítica | < 15 min | PagerDuty + Slack | Auto-escala a manager en 30 min |
| P2 Alta | < 1 hora | Slack #alerts | Si no se atiende en 2h |
| P3 Media | < 4 horas | Slack #monitoring | Revisión en standup |
| P4 Baja | Siguiente día hábil | Ticket automático | Ninguno |

## SLAs / SLOs / SLIs

| Servicio | SLI | SLO | SLA (externo) |
|----------|-----|-----|---------------|
| API | Disponibilidad (% requests exitosos) | 99.9% mensual | 99.5% |
| API | Latencia p95 | < 300ms | < 1s |
| Web App | Time to Interactive | < 3s | N/A |

## Error Budget

- **Budget mensual**: 100% - 99.9% = 0.1% = ~43 minutos de downtime permitido
- **Si se agota**: congelar deploys, enfocarse en estabilidad

## Enlaces relacionados

- **Specs del dominio**: [[infraestructura]] · [[cicd]]
- **Specs relacionadas**: [[arquitectura]] (componentes monitoreados) · [[soporte]] (alertas → escalamiento)
- **Agente principal**: [[devops]] (genera dashboards as code, alertas)
- **Spec de operaciones**: [[runbook]] (qué hacer cuando una alerta dispara)
