---
domain: negocio
type: vision
approver: "Business Owner / CPO"
status: draft  # draft | review | approved
last_updated: ""
---

# Visión y Propósito

## Problema que resolvemos

<!-- ¿Qué dolor o necesidad existe? ¿Para quién? -->

## Visión del producto

<!-- En una frase: ¿cómo se ve el mundo cuando este producto existe? -->

## Usuarios objetivo

| Segmento | Descripción | Necesidad principal | Tamaño estimado |
|----------|-------------|---------------------|-----------------|
|          |             |                     |                 |

## Objetivos de negocio

| ID | Objetivo | Métrica de éxito | Meta | Plazo |
|----|----------|-------------------|------|-------|
| OBJ-001 | | | | |
| OBJ-002 | | | | |

## Propuesta de valor

**Para** [segmento de usuario]
**Que** [necesidad o problema]
**Nuestro producto** [nombre]
**Es un** [categoría]
**Que** [beneficio clave]
**A diferencia de** [alternativa actual]
**Nosotros** [diferenciador único]

## Modelo de negocio (resumen)

- **Fuentes de ingreso**: 
- **Estructura de costos**: 
- **Canales**: 
- **Partners clave**: 

## Restricciones conocidas

<!-- Presupuesto, regulaciones, plazos, limitaciones técnicas heredadas -->

## Principios de diseño

<!-- 3-5 principios que guían todas las decisiones del producto -->

1. 
2. 
3. 

## Enlaces relacionados

- **Specs derivadas**: [[stakeholders]] · [[requerimientos]] · [[roadmap]]
- **Flujo de lectura**: Este es el punto de partida → siguiente: [[requerimientos]]
- **Agente que lo consume**: [[analyst]] (validación) · todos los agentes lo leen como contexto
- **Comando relevante**: [[validate]] · [[analyze]]
