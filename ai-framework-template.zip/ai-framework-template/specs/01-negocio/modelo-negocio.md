---
domain: negocio
type: modelo-negocio
approver: "Business Owner / CFO"
status: draft
last_updated: ""
---

# Modelo de Negocio

## Canvas resumido

| Bloque | Descripción |
|--------|-------------|
| **Segmentos de clientes** | [PENDIENTE] |
| **Propuesta de valor** | Ver [[propuesta-valor]] |
| **Canales** | [PENDIENTE] |
| **Relación con clientes** | [PENDIENTE] |
| **Fuentes de ingreso** | [PENDIENTE] |
| **Recursos clave** | [PENDIENTE] |
| **Actividades clave** | [PENDIENTE] |
| **Socios clave** | [PENDIENTE] |
| **Estructura de costos** | [PENDIENTE] |

## Fuentes de ingreso detalladas

| Fuente | Modelo | Precio estimado | % del total |
|--------|--------|----------------|-------------|
| [PENDIENTE] | | | |

## Estructura de costos

| Categoría | Tipo (fijo/variable) | Monto estimado | Notas |
|-----------|---------------------|----------------|-------|
| [PENDIENTE] | | | |

## Proyección financiera

<!-- Año 1, Año 2, Año 3 — ingresos, costos, margen -->

[PENDIENTE]

## Supuestos críticos

<!-- Supuestos que, si fallan, invalidan el modelo -->

[PENDIENTE]

## Enlaces relacionados

- **Spec padre**: [[vision]]
- **Specs derivadas**: [[roadmap]] · [[requerimientos]]
- **Agente que lo consume**: [[analyst]] · [[product]]
