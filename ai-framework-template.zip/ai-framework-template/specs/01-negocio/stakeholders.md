---
domain: negocio
type: stakeholders
approver: "Business Owner / CPO"
status: draft
last_updated: ""
---

# Mapa de Stakeholders

## Registro de stakeholders

| Nombre / Rol | Área | Poder | Interés | Estrategia | Canal de comunicación |
|--------------|------|-------|---------|------------|----------------------|
|              |      | Alto/Medio/Bajo | Alto/Medio/Bajo | Gestionar de cerca / Mantener informado / Monitorear | |

## RACI por dominio de spec

| Dominio | Responsible | Accountable | Consulted | Informed |
|---------|-------------|-------------|-----------|----------|
| Negocio | | | | |
| Producto | | | | |
| Diseño | | | | |
| Arquitectura | | | | |
| Datos | | | | |
| Seguridad | | | | |
| Infraestructura | | | | |
| Calidad | | | | |
| Operaciones | | | | |
| Legal | | | | |

## Cadencia de comunicación

| Audiencia | Formato | Frecuencia | Responsable |
|-----------|---------|------------|-------------|
| Sponsors | Reporte ejecutivo | Semanal | |
| Equipo técnico | Standup | Diario | |
| Stakeholders | Demo | Quincenal | |

## Enlaces relacionados

- **Specs del dominio**: [[vision]]
- **Specs que informa**: [[requerimientos]] (stakeholders definen prioridades) · [[despliegue]] (comunicación de lanzamiento)
- **Agente que lo consume**: [[analyst]]
- **Comando relevante**: [[validate]]
