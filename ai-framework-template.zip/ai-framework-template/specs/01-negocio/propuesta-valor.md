---
domain: negocio
type: propuesta-valor
approver: "Business Owner / CPO"
status: draft
last_updated: ""
---

# Propuesta de Valor

## Propuesta de valor principal

**Para** [segmento de usuario objetivo]
**Que** [necesidad o problema que enfrentan]
**Nuestro producto** [nombre del producto]
**Es un** [categoría del producto]
**Que** [beneficio clave que entrega]
**A diferencia de** [alternativa actual que usan]
**Nosotros** [diferenciador único y sostenible]

## Propuestas de valor por segmento

| Segmento | Pain point principal | Beneficio ofrecido | Diferenciador |
|----------|---------------------|-------------------|---------------|
| [PENDIENTE] | | | |

## Métricas de valor

| Métrica | Baseline actual | Meta | Plazo |
|---------|----------------|------|-------|
| [PENDIENTE] | | | |

## Validación

<!-- ¿Cómo se ha validado esta propuesta de valor? Entrevistas, prototipos, datos -->

[PENDIENTE]

## Enlaces relacionados

- **Spec padre**: [[vision]]
- **Specs derivadas**: [[requerimientos]] · [[historias-usuario]]
- **Agente que lo consume**: [[analyst]] · [[product]]
