# Instrucciones para el dominio de Producto

> Estas instrucciones aplican cuando trabajas con archivos en `specs/02-producto/`.

## Agente responsable

[[product]] — crea y actualiza requerimientos, historias y flujos. [[analyst]] — valida completitud y consistencia. [[implementer]] — consume estas specs para generar controllers y services.

## Prioridad de lectura en este dominio

1. `requerimientos.md` — fuente de verdad de qué debe hacer el sistema
2. `historias-usuario.md` — detalle funcional con criterios Gherkin
3. `flujos-usuario.md` — cómo navega el usuario por el producto
4. `roadmap.md` — qué va en qué versión

## Convenciones de IDs

- Requerimientos funcionales: `REQ-FUNC-NNN` (numerado, sin gaps)
- Requerimientos no funcionales: `REQ-NFR-NNN`
- Historias de usuario: `HU-NNN`
- Estos IDs deben ser consistentes en TODOS los archivos que los referencien

## Reglas críticas

- **No modificar criterios de aceptación** sin actualizar el test de aceptación correspondiente en `tests/acceptance/`
- **Cada Must-have tiene historia**: todo REQ-FUNC con prioridad "Must" debe tener al menos 1 HU con criterios Gherkin completos
- **Gherkin correcto**: Dado/Cuando/Entonces (o Given/When/Then). Sin pasos ambiguos como "Y el sistema funciona correctamente"
- **Roadmap consistente**: las funcionalidades en `roadmap.md` deben corresponder a REQ-FUNC existentes — no agregar funcionalidades al roadmap sin su requerimiento

## Cuándo actualizar estas specs

- Al cambiar prioridad de un requerimiento → actualizar también el roadmap
- Al agregar una historia → actualizar también `requerimientos.md` con el REQ-FUNC padre
- Al cambiar criterios Gherkin → notificar al agente [[qa]] para actualizar tests

## Trazabilidad obligatoria

El [[analyst]] verifica que exista trazabilidad completa:
```
Objetivo de negocio (vision.md)
  → Requerimiento (requerimientos.md REQ-FUNC-NNN)
    → Historia de usuario (historias-usuario.md HU-NNN)
      → Criterio Gherkin
        → Test de aceptación (tests/acceptance/)
```
