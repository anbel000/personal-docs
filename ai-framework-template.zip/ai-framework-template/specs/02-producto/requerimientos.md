---
domain: producto
type: requerimientos
approver: "Product Manager"
status: draft
last_updated: ""
---

# Requerimientos Funcionales

## Módulos del sistema

| ID | Módulo | Descripción | Objetivo de negocio |
|----|--------|-------------|---------------------|
| MOD-001 | | | OBJ-001 |

## Requerimientos funcionales

| ID | Módulo | Requerimiento | Prioridad | Criterio de aceptación |
|----|--------|---------------|-----------|----------------------|
| REQ-FUNC-001 | MOD-001 | | Must | |
| REQ-FUNC-002 | MOD-001 | | Should | |
| REQ-FUNC-003 | MOD-001 | | Could | |

> Prioridades MoSCoW: **Must** (obligatorio para MVP), **Should** (importante), **Could** (deseable), **Won't** (fuera de alcance)

## Requerimientos no funcionales

| ID | Categoría | Requerimiento | Métrica | Valor objetivo |
|----|-----------|---------------|---------|----------------|
| REQ-NFR-001 | Rendimiento | | Tiempo de respuesta | < 200ms p95 |
| REQ-NFR-002 | Disponibilidad | | Uptime | 99.9% |
| REQ-NFR-003 | Escalabilidad | | Usuarios concurrentes | |

## Matriz de trazabilidad

| Objetivo | Requerimiento | Historia | Test | Componente |
|----------|---------------|----------|------|------------|
| OBJ-001 | REQ-FUNC-001 | HU-001 | | |

## Enlaces relacionados

- **Spec previa**: [[vision]] (objetivos de negocio que los requerimientos atienden)
- **Specs derivadas**: [[historias-usuario]] (cada req se descompone en historias) · [[flujos-usuario]] · [[roadmap]]
- **Contratos relacionados**: [[example.yaml|contracts/api/]] (endpoints derivados de reqs)
- **Agente que lo consume**: [[implementer]] · [[analyst]] (trazabilidad)
- **Comando relevante**: [[generate|/generate producto]] · [[validate]]
