---
domain: producto
type: historias-usuario
approver: "Product Manager"
status: draft
last_updated: ""
---

# Historias de Usuario

## HU-001: [Título descriptivo]

**Como** [tipo de usuario]
**Quiero** [acción]
**Para** [beneficio]

- **Prioridad**: Must
- **Requerimiento**: REQ-FUNC-001
- **Estimación**: [S/M/L/XL]

### Criterios de aceptación

```gherkin
Escenario: [Nombre del escenario feliz]
  Dado que [contexto inicial]
  Cuando [acción del usuario]
  Entonces [resultado esperado]

Escenario: [Nombre del escenario alternativo]
  Dado que [contexto]
  Cuando [acción]
  Entonces [resultado]

Escenario: [Nombre del escenario de error]
  Dado que [contexto]
  Cuando [acción inválida]
  Entonces [manejo del error]
```

### Notas de diseño

<!-- Wireframes, restricciones UI, consideraciones de accesibilidad -->

### Dependencias

<!-- Otras historias, APIs externas, datos que deben existir -->

---

## HU-002: [Título]

**Como** [usuario]
**Quiero** [acción]
**Para** [beneficio]

- **Prioridad**: Should
- **Requerimiento**: REQ-FUNC-002
- **Estimación**: 

### Criterios de aceptación

```gherkin
Escenario: [Nombre]
  Dado que [contexto]
  Cuando [acción]
  Entonces [resultado]
```

## Enlaces relacionados

- **Spec previa**: [[requerimientos]] (cada historia traza a un requerimiento)
- **Specs relacionadas**: [[flujos-usuario]] (contexto visual) · [[criterios-aceptacion]] (DoD)
- **Generan tests**: [[qa]] genera tests de aceptación desde los escenarios Gherkin
- **Regla de testing**: [[testing-patterns]] (1 Gherkin = 1 test)
- **Agente que lo consume**: [[implementer]] · [[qa]] · [[analyst]]
