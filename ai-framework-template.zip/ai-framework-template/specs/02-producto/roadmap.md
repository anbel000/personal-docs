---
domain: producto
type: roadmap
approver: "Product Manager"
status: draft
last_updated: ""
---

# Roadmap del Producto

## Fases de desarrollo

| Fase | Nombre | Alcance | Duración | Entregable |
|------|--------|---------|----------|------------|
| 1 | MVP | Funcionalidades Must-have | | |
| 2 | v1.0 | + Should-have | | |
| 3 | v2.0 | + Could-have + integraciones | | |

## Now / Next / Later

### Now (Sprint actual)

| Historia | Prioridad | Responsable | Estado |
|----------|-----------|-------------|--------|
| HU-001 | Must | | |

### Next (Próximo sprint)

| Historia | Prioridad | Dependencia |
|----------|-----------|-------------|
| | | |

### Later (Backlog priorizado)

| Historia | Prioridad | Notas |
|----------|-----------|-------|
| | | |

## Dependencias y riesgos del roadmap

| Dependencia / Riesgo | Impacto | Mitigación |
|----------------------|---------|------------|
| | | |

## Enlaces relacionados

- **Spec previa**: [[vision]] (objetivos) · [[requerimientos]] (funcionalidades a priorizar)
- **Specs operativas**: [[despliegue]] (plan de rollout por fase) · [[cicd]] (pipeline para cada release)
- **Agente que lo consume**: [[analyst]]
