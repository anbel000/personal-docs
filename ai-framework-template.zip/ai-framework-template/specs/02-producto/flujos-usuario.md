---
domain: producto
type: flujos-usuario
approver: "Product Manager"
status: draft
last_updated: ""
---

# Flujos de Usuario

## Flujo principal: [Nombre del flujo]

### Diagrama de flujo

```mermaid
graph TD
    A[Inicio] --> B{¿Usuario autenticado?}
    B -->|Sí| C[Dashboard]
    B -->|No| D[Login]
    D --> E{¿Credenciales válidas?}
    E -->|Sí| C
    E -->|No| F[Error + Retry]
    F --> D
    C --> G[Acción principal]
    G --> H[Confirmación]
```

### Pasos detallados

| Paso | Actor | Acción | Pantalla | Reglas de negocio |
|------|-------|--------|----------|-------------------|
| 1 | Usuario | | | |
| 2 | Sistema | | | |
| 3 | Usuario | | | |

### Puntos de decisión

| Decisión | Opción A | Opción B | Criterio |
|----------|----------|----------|----------|
| | | | |

### Manejo de errores

| Error | Mensaje al usuario | Acción del sistema | Reintento |
|-------|--------------------|--------------------|-----------|
| | | | Sí/No |

---

## Flujo secundario: [Nombre]

<!-- Repetir estructura para cada flujo relevante -->

## Enlaces relacionados

- **Specs relacionadas**: [[historias-usuario]] · [[requerimientos]] · [[arquitectura-informacion]]
- **Spec de diseño**: [[design-system]] (componentes usados en pantallas)
- **Agente que lo consume**: [[implementer]] · [[qa]] (tests E2E siguen estos flujos)
