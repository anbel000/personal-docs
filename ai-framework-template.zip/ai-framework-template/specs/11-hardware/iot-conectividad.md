---
domain: hardware
type: iot-conectividad
approver: "Hardware Lead"
status: draft
last_updated: ""
optional: true
---

# IoT y Conectividad

## Topología de red

```mermaid
graph TB
    DEVICE1[Device 1] -->|MQTT| BROKER[MQTT Broker]
    DEVICE2[Device 2] -->|MQTT| BROKER
    BROKER -->|Bridge| CLOUD[Cloud Platform]
    CLOUD -->|API| APP[Aplicación Web]
```

## Protocolos de comunicación

| Protocolo | Uso | QoS | Payload máximo | Frecuencia |
|-----------|-----|-----|----------------|------------|
| MQTT | Telemetría | 1 | 256KB | Cada [N] seg |
| HTTPS | Config + OTA | N/A | 10MB | On-demand |
| BLE | Provisioning | N/A | 512B | Setup only |

## Gestión de dispositivos

| Capacidad | Implementación |
|-----------|----------------|
| Provisioning | [manual / auto-registro / certificados] |
| OTA Updates | [mecanismo] |
| Monitoreo | Heartbeat cada [N] segundos |
| Descomisionado | [proceso] |

## Manejo de conectividad intermitente

| Escenario | Comportamiento |
|-----------|---------------|
| Sin conexión | Almacenar en buffer local hasta [N] MB |
| Conexión restaurada | Enviar buffer en orden FIFO |
| Buffer lleno | Descartar datos más antiguos, alertar |

## Enlaces relacionados

- **Specs del dominio**: [[especificaciones]] (hardware que se conecta)
- **Specs de software**: [[arquitectura]] · [[integraciones]] (APIs MQTT/HTTP)
- **Spec de seguridad**: [[requisitos]] (auth de dispositivos) · [[threat-model]] (superficie IoT)
- **Spec de datos**: [[flujos]] (telemetría como pipeline de datos) · [[monitoreo]] (heartbeats)
