---
domain: hardware
type: infraestructura-fisica
approver: "Hardware Lead / Operations"
status: draft
last_updated: ""
---

# Infraestructura Física

## Topología física

<!-- Dónde viven los dispositivos, gateways, servidores edge, y cloud -->

[PENDIENTE]

## Dispositivos en campo

| Dispositivo | Modelo | Cantidad | Ubicación | Conectividad |
|-------------|--------|---------|-----------|--------------|
| [PENDIENTE] | | | | |

## Gateways y nodos edge

| Nodo | Rol | Hardware | SO | Conectividad upstream |
|------|-----|---------|----|-----------------------|
| [PENDIENTE] | | | | |

## Requisitos de energía

<!-- Alimentación, backup de batería, consumo promedio y máximo -->

[PENDIENTE]

## Requisitos ambientales

<!-- Temperatura de operación, humedad, protección IP, certificaciones -->

[PENDIENTE]

## Red física

| Segmento | Tecnología | Ancho de banda | Latencia máxima |
|----------|-----------|----------------|-----------------|
| [PENDIENTE] | | | |

## Mantenimiento y reemplazo

<!-- Ciclo de vida de dispositivos, política de reemplazo, acceso físico -->

[PENDIENTE]

## Seguridad física

<!-- Control de acceso a dispositivos, tamper detection, almacenamiento seguro de credenciales en hardware -->

[PENDIENTE]

## Proveedores y SLAs de hardware

| Proveedor | Componente | SLA de reemplazo | Contacto |
|-----------|-----------|-----------------|---------|
| [PENDIENTE] | | | |

## Enlaces relacionados

- **Spec padre**: [[especificaciones]]
- **Specs relacionadas**: [[iot-conectividad]] · [[infraestructura]]
- **Agente que lo consume**: [[iot-engineer]] · [[devops]]
