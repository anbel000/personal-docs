---
domain: hardware
type: especificaciones
approver: "Hardware Lead"
status: draft
last_updated: ""
optional: true
---

# Especificaciones de Hardware

> Este dominio es opcional. Solo rellenar si el proyecto incluye componentes físicos, IoT o infraestructura on-premise.

## Inventario de componentes

| Componente | Modelo | Cantidad | Función | Proveedor |
|------------|--------|----------|---------|-----------|
| | | | | |

## Especificaciones técnicas

### [Nombre del componente]

| Parámetro | Valor |
|-----------|-------|
| Procesador | |
| RAM | |
| Almacenamiento | |
| Conectividad | WiFi / Ethernet / BLE / LoRa / 4G |
| Alimentación | |
| Rango de temperatura | |
| Certificaciones | CE / FCC / IP67 / etc. |

## BOM (Bill of Materials)

| Item | Referencia | Cantidad | Costo unitario | Costo total | Lead time |
|------|-----------|----------|----------------|-------------|-----------|
| | | | | | |
| **Total** | | | | **$** | |

## Diagrama de conexiones

```mermaid
graph LR
    SENSOR[Sensor] -->|I2C/SPI| MCU[Microcontrolador]
    MCU -->|UART| MODEM[Módulo comunicación]
    MODEM -->|MQTT/HTTP| CLOUD[Cloud]
    MCU -->|GPIO| ACTUATOR[Actuador]
```

## Enlaces relacionados

- **Specs del dominio**: [[iot-conectividad]]
- **Specs de software**: [[arquitectura]] (integración HW↔SW) · [[integraciones]] (APIs de dispositivos)
- **Spec de infra**: [[infraestructura]] (hosting on-premise si aplica)
