---
domain: calidad
type: plan-pruebas
approver: "QA Lead / Engineering Lead"
status: draft
last_updated: ""
---

# Plan de Pruebas

## Alcance

<!-- Qué se prueba y qué no se prueba en este plan -->

[PENDIENTE]

## Estrategia de testing

Ver [[estrategia]] para la pirámide de tests y cobertura mínima requerida.

### Niveles de prueba

| Nivel | Herramienta | Cobertura mínima | Responsable |
|-------|-------------|-----------------|-------------|
| Unit | [PENDIENTE] | [PENDIENTE]% | Developer |
| Integration | [PENDIENTE] | [PENDIENTE]% | Developer |
| E2E | [PENDIENTE] | Flujos críticos | QA |
| Aceptación | Gherkin + [PENDIENTE] | Todos los criterios | QA |
| Accesibilidad | [PENDIENTE] | WCAG 2.1 AA | QA |

## Criterios de entrada y salida

### Criterios de entrada (para iniciar pruebas)

- [ ] [PENDIENTE]

### Criterios de salida (para considerar testing completo)

- [ ] Cobertura unit ≥ [PENDIENTE]%
- [ ] 0 bugs P0/P1 abiertos
- [ ] Todos los criterios de aceptación verificados
- [ ] [PENDIENTE]

## Entornos de prueba

| Entorno | URL | Datos | Propósito |
|---------|-----|-------|-----------|
| Local | localhost | Fixtures | Desarrollo |
| Staging | [PENDIENTE] | Anonimizados | QA / UAT |
| Production | [PENDIENTE] | Reales | Smoke tests post-deploy |

## Gestión de defectos

| Prioridad | Tiempo de resolución | Bloquea deploy |
|-----------|---------------------|----------------|
| P0 — crítico | Inmediato | Sí |
| P1 — alto | [PENDIENTE] | Sí |
| P2 — medio | [PENDIENTE] | No |
| P3 — bajo | [PENDIENTE] | No |

## Automatización

<!-- Estado actual de la automatización y roadmap -->

[PENDIENTE]

## Riesgos de calidad

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|-------------|---------|------------|
| [PENDIENTE] | | | |

## Enlaces relacionados

- **Spec padre**: [[estrategia]]
- **Specs relacionadas**: [[criterios-aceptacion]] · [[historias-usuario]]
- **Agente que lo consume**: [[qa]] · [[analyst]]
- **Comando relevante**: [[validate]] · [[build]]
