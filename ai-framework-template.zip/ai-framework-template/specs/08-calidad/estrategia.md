---
domain: calidad
type: estrategia
approver: "QA Lead"
status: draft
last_updated: ""
---

# Estrategia de Pruebas

## Pirámide de testing

| Nivel | Framework | Cobertura mínima | Responsable |
|-------|-----------|-----------------|-------------|
| Unit | Jest / pytest | 80% líneas | Desarrollador |
| Integration | supertest / httpx | Todos los endpoints | Desarrollador + QA |
| E2E | Cypress / Playwright | Flujos críticos | QA |
| Contract | basado en OpenAPI | Todos los contratos en `contracts/api/` | QA |
| A11y | axe-core / jest-axe | Todas las páginas | QA + Frontend |

## Quality gates en CI

| Gate | Métrica | Umbral | Bloquea merge |
|------|---------|--------|---------------|
| Unit tests | Pass rate | 100% | Sí |
| Coverage | Line coverage | ≥ 80% | Sí |
| Integration | Pass rate | 100% | Sí |
| Lint | Errores | 0 | Sí |
| Security scan | Vulns críticas | 0 | Sí |
| E2E | Flujos críticos pass | 100% | Sí (en staging) |

## Entornos de test

| Entorno | Datos | Base de datos | Servicios externos |
|---------|-------|---------------|-------------------|
| Unit | Mocks/fixtures | In-memory / mock | Mocks |
| Integration | Fixtures + seeds | DB real (contenedor) | Mocks o sandbox |
| E2E | Seeds completos | DB de staging | Sandbox o real |

## Gestión de defectos

| Severidad | Definición | SLA de resolución |
|-----------|------------|-------------------|
| Blocker | Funcionalidad core no funciona | Inmediato |
| Critical | Pérdida de datos o seguridad | < 24h |
| Major | Funcionalidad degradada con workaround | Sprint actual |
| Minor | Cosmético o edge case | Backlog |

## Enlaces relacionados

- **Specs relacionadas**: [[criterios-aceptacion]] (DoD global) · [[historias-usuario]] (Gherkin → tests)
- **Spec de diseño**: [[accesibilidad]] (tests a11y)
- **Contratos**: [[example.yaml|contracts/api/]] (contract testing)
- **Agente principal**: [[qa]] (genera tests según esta estrategia)
- **Regla de testing**: [[testing-patterns]] (pirámide, naming, trazabilidad)
- **Spec de infra**: [[cicd]] (quality gates en pipeline)
