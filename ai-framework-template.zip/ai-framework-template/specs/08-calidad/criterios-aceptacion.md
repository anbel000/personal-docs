---
domain: calidad
type: criterios-aceptacion
approver: "QA Lead"
status: draft
last_updated: ""
---

# Criterios de Aceptación (Definition of Done)

## DoD Global

Un feature se considera DONE cuando cumple TODOS estos criterios:

### Código
- [ ] Código revisado (PR aprobado por al menos 1 reviewer)
- [ ] Sin warnings de linter
- [ ] Sin TODOs sin ticket asociado
- [ ] Comentarios de spec fuente en archivos generados

### Testing
- [ ] Unit tests escritos y pasando (coverage ≥ 80%)
- [ ] Integration tests para endpoints nuevos/modificados
- [ ] Tests de aceptación Gherkin implementados y pasando
- [ ] Tests de accesibilidad pasando (si tiene UI)

### Seguridad
- [ ] Input validation en todos los inputs nuevos
- [ ] Auth/authz verificados en endpoints nuevos
- [ ] Sin secrets hardcoded
- [ ] Security scan limpio

### Documentación
- [ ] API documentada en OpenAPI (si endpoint nuevo)
- [ ] JSON Schema actualizado (si modelo nuevo/modificado)
- [ ] DDL actualizado (si cambio en DB)
- [ ] Changelog actualizado

### Despliegue
- [ ] Migración de DB probada en staging
- [ ] Feature flag configurado (si aplica)
- [ ] Rollback plan documentado (si cambio crítico)
- [ ] Health checks pasando en staging

## Criterios por tipo de cambio

| Tipo | Criterios adicionales |
|------|----------------------|
| Nuevo endpoint | Contract test + OpenAPI spec |
| Cambio de modelo | Migración reversible + schema JSON actualizado |
| Cambio de UI | Tests a11y + responsive verificado |
| Hotfix | Test de regresión que cubra el bug |

## Enlaces relacionados

- **Specs relacionadas**: [[estrategia]] · [[historias-usuario]] (criterios por historia)
- **Contratos**: [[example.yaml|contracts/api/]] · [[example.json|contracts/schemas/]] · [[example.sql|contracts/ddl/]] (todos deben estar actualizados según el DoD)
- **Agente que lo consume**: [[qa]] · [[analyst]] (valida completitud del DoD)
- **Todos los agentes**: Cada agente debe cumplir el DoD al generar artefactos
