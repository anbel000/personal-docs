-- ============================================================
-- Contrato DDL: Entidad User
-- Fuente: specs/05-datos/modelo.md
-- Schema: contracts/schemas/user.json
--
-- Este archivo es la fuente de verdad para:
--   - Migraciones SQL generadas por el agente data-engineer
--   - Modelos ORM / entidades
--   - Nombres de tablas y columnas en todo el código
--
-- REGLA: Si el código usa un nombre de tabla/columna distinto
--        al definido aquí, el código está mal.
--
-- REFERENCIAS:
--   - Spec: specs/05-datos/modelo.md
--   - Schema: contracts/schemas/example.json
--   - API: contracts/api/example.yaml
--   - Agente: .claude/agents/data-engineer.md
--   - Reglas: .claude/rules/coding-conventions.md (SQL section)
-- ============================================================

CREATE TABLE "user" (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    email       VARCHAR(255)    NOT NULL,
    name        VARCHAR(100)    NOT NULL,
    role        VARCHAR(20)     NOT NULL DEFAULT 'viewer',
    status      VARCHAR(20)     NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ,

    -- Constraints
    CONSTRAINT pk_user              PRIMARY KEY (id),
    CONSTRAINT uq_user_email        UNIQUE (email),
    CONSTRAINT chk_user_role        CHECK (role IN ('admin', 'editor', 'viewer')),
    CONSTRAINT chk_user_status      CHECK (status IN ('active', 'inactive', 'suspended'))
);

-- Índices
CREATE INDEX idx_user_email     ON "user" (email);
CREATE INDEX idx_user_status    ON "user" (status);
CREATE INDEX idx_user_role      ON "user" (role);

-- Comentarios (documentación en la DB)
COMMENT ON TABLE  "user"            IS 'Usuarios del sistema';
COMMENT ON COLUMN "user".id         IS 'UUID v4 autogenerado';
COMMENT ON COLUMN "user".email      IS 'Email único — usado para login';
COMMENT ON COLUMN "user".name       IS 'Nombre completo';
COMMENT ON COLUMN "user".role       IS 'Rol RBAC: admin, editor, viewer';
COMMENT ON COLUMN "user".status     IS 'Estado de la cuenta: active, inactive, suspended';
COMMENT ON COLUMN "user".created_at IS 'Timestamp de creación (UTC)';
COMMENT ON COLUMN "user".updated_at IS 'Última modificación (UTC, null si nunca editado)';
