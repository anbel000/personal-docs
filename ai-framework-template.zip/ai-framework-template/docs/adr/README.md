# Architecture Decision Records (ADRs)

Este directorio contiene el registro de decisiones de arquitectura del framework.

Un ADR documenta una decisión significativa de diseño o arquitectura: el contexto que la motivó, qué se decidió, y las consecuencias (positivas y negativas).

## Por qué ADRs

- Las decisiones de arquitectura tienen contexto que desaparece con el tiempo
- Evitan re-debatir lo mismo cuando el equipo crece o cambia
- Permiten entender por qué el sistema es como es, no solo cómo es
- Son especialmente útiles para Claude: le dan el "por qué" detrás del código

## Índice

| ID | Título | Estado | Fecha |
|----|--------|--------|-------|
| [0000](0000-template.md) | Template — no es una decisión real | Template | — |
| [0002](0002-ejemplo-webhook-auth.md) | Autenticación de webhook — HMAC vs Shared Secret in Path | Ejemplo | — |

<!-- Agrega una fila por cada ADR nuevo. El bootstrapper agrega aquí ADR-0001 automáticamente. -->

## Cómo crear un ADR

1. Copia `0000-template.md` con el próximo número secuencial: `0003-mi-decision.md`
2. Llena todas las secciones
3. Agrega una fila al índice de arriba
4. Referencia el ADR desde la spec de arquitectura correspondiente

## Convenciones de naming

- Número secuencial de 4 dígitos: `0001`, `0002`, ...
- Título en kebab-case, descriptivo: `0001-stack-inicial.md`, `0002-base-de-datos-postgresql.md`
- Un archivo por decisión — no agrupar decisiones no relacionadas

## Estados válidos

| Estado | Significado |
|--------|-------------|
| Propuesto | En discusión, no aprobado |
| Aceptado | Aprobado e implementado |
| Rechazado | Considerado y descartado |
| Deprecado | Fue válido, ya no aplica |
| Reemplazado por ADR-XXXX | Supersedido por una decisión posterior |
