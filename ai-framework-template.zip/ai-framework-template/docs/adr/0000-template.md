# ADR-XXXX: [Título de la decisión]

**Estado**: Propuesto | Aceptado | Rechazado | Deprecado | Reemplazado por ADR-YYYY
**Fecha**: YYYY-MM-DD
**Autor(es)**: [Nombre / Rol]
**Revisado por**: [Nombre / Rol]

---

## Contexto

<!-- ¿Qué situación o problema llevó a tomar esta decisión? ¿Qué restricciones existen?
     Describe el contexto sin mencionar la solución todavía. -->

## Decisión

<!-- ¿Qué decidimos hacer? Una sola oración principal, luego el detalle. -->

## Consecuencias

### Positivas
-
-

### Negativas / Trade-offs
-
-

### Neutrales / Notas
-

## Alternativas consideradas

### Alternativa 1: [Nombre]
**Descripción**: ...
**Por qué se descartó**: ...

### Alternativa 2: [Nombre]
**Descripción**: ...
**Por qué se descartó**: ...

## Referencias

- [Link a spec relacionada](../../specs/)
- [Link a contrato](../../contracts/)
- [Documentación externa]()
