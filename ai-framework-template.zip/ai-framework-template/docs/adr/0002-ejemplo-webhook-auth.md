# ADR-0002: Autenticación de webhook — HMAC vs Shared Secret in Path

**Estado**: Ejemplo (reemplazar con decisión real del proyecto)
**Fecha**: [fecha]
**Autor(es)**: [equipo]
**Revisado por**: [arquitecto / security reviewer]

---

## Contexto

El sistema recibe eventos de [proveedor externo] via webhook. Se necesita autenticar que los requests provienen efectivamente del proveedor y no de terceros.

Se evaluaron dos opciones:
1. **HMAC-SHA256**: el proveedor firma cada request con un secreto compartido; el servidor verifica la firma.
2. **Shared Secret in Path**: un UUID secreto único está embebido en la URL del webhook; el servidor verifica que existe en la DB.

La restricción clave: [el proveedor / el dispositivo] no soporta firma HMAC ni headers de autenticación customizados.

## Decisión

[Elegir la opción apropiada según el proveedor]

**Si el proveedor soporta HMAC** — usar HMAC (opción 1). Es criptográficamente más robusto y no expone la credencial en la URL.

**Si el proveedor NO soporta firma de requests** — usar Shared Secret in Path (opción 2). La URL completa actúa como credencial.

En este proyecto: se eligió **Shared Secret in Path** porque [razón específica].

## Consecuencias

### Positivas
- Simple de implementar: solo un lookup en DB por request
- Sin dependencia en timing (HMAC tiene ventana de tiempo)
- El dispositivo IoT no necesita capacidad criptográfica

### Negativas / Trade-offs
- La URL del webhook es una credencial: no loguearla, no compartirla, no commitearla
- Rotar el secreto desconecta el dispositivo físico hasta reconfiguración manual
- Si la URL es interceptada (ej: en logs de proxy), el secreto queda expuesto

### Neutrales / Notas
- Proveer endpoint `GET /{resource}/webhook-url` con JWT admin para leer la URL sin rotar
- Documentar en runbook: cuándo y cómo rotar el secreto de forma segura
- El campo `uid` del proveedor (si existe) es informacional — se auto-registra en el primer webhook pero NO se valida después

## Alternativas consideradas

### Alternativa 1: HMAC-SHA256 en header
**Descripción**: El proveedor firma el body con `X-Signature: sha256={hex}` usando un secreto compartido. El servidor verifica la firma antes de procesar.
**Por qué se descartó**: El proveedor no soporta headers de autenticación customizados ni firma de requests.

### Alternativa 2: API Key en query param
**Descripción**: `POST /webhooks/{provider}?key={secret}` — semánticamente equivalente al shared secret en path.
**Por qué se descartó**: Más verboso en logs de servidor (los query params aparecen en access logs más fácilmente que los segmentos de path). El path UUID es funcionalmente equivalente con mejor legibilidad en la URL de configuración del dispositivo.

### Alternativa 3: JWT de dispositivo en header
**Descripción**: El dispositivo presenta un JWT firmado en cada request.
**Por qué se descartó**: Requiere que el dispositivo gestione rotación de tokens y tenga acceso a un endpoint de renovación — complejidad innecesaria para dispositivos IoT de propósito fijo.

## Referencias

- [security-patterns.md — Webhooks sin firma HMAC](../../.claude/rules/security-patterns.md)
- [webhook-shared-secret.yaml — Contrato OpenAPI](../../contracts/api/webhook-shared-secret.yaml)
- [ADR-0000 Template](./0000-template.md)
