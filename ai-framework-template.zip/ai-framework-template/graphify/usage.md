# Graphify — Uso de tokens

> Regenerado automáticamente al terminar cada `/graphify`.

_Sin datos aún. Ejecuta `/graphify` para generar el primer reporte._
