# GRAPHIFY — Tooling de Desarrollo

> **Este directorio es TOOLING de desarrollo, no código del producto.**
> Si tu proyecto tiene un módulo llamado "graphify" en `packages/` (ej: para
> construir un grafo en runtime), ese módulo y este tooling son cosas distintas
> con el mismo nombre. Ver sección "Colisión de nombres" abajo.

## Qué es

El tooling de graphify construye un **conectoma** pre-computado del repositorio:
un grafo de conocimiento que enlaza specs ↔ contracts ↔ código fuente ↔ agentes ↔ reglas.

Claude y los agentes de desarrollo consultan este grafo **antes** de leer archivos
directamente, ahorrando ~80% de tokens en sesiones de codificación.

**Componentes:**
- `graphify/.graphify.yml` — define qué archivos indexar y cómo agruparlos en comunidades
- `graphify/llm.config.yml` — modelo LLM para el extractor semántico (default: Haiku)
- `graphify/usage.md` — resumen de consumo de tokens de la última ejecución
- `graphify-out/` — output del grafo (wiki navegable, JSON, HTML, Obsidian vault)

## Por qué importa

Sin el conectoma, cada agente hace `Read` + `Glob` + `Grep` masivos para entender
el contexto. Con el conectoma:
- `graphify query "autenticación"` → 2k tokens relevantes en lugar de leer 15k
- Los agentes llegan al contexto correcto en segundos, no minutos
- Drift detection specs↔código funciona sobre el grafo, no sobre lectura bruta

## Cómo usarlo día a día

```bash
# Reconstruir el grafo completo (después de cambios grandes)
/graphify

# Actualización incremental (después de editar specs o código)
/graphify --update

# Consultar el grafo directamente
python -m graphify query "autenticación JWT" --graph graphify-out/graph.json --budget 3000
python -m graphify path "requerimientos.md" "auth.service.ts" --graph graphify-out/graph.json
python -m graphify explain "UserGuard" --graph graphify-out/graph.json

# Ver modelo LLM activo
/graphifyllm

# Cambiar modelo
/graphifyllm claude-sonnet-4-6
/graphifyllm claude-haiku-4-5-20251001
/graphifyllm off   # AST puro, cero tokens
/graphifyllm on    # reactiva LLM
```

## Cómo leer el output

```
graphify-out/
├── wiki/
│   ├── index.md              ← entrada principal (leer primero)
│   ├── _COMMUNITY_specs.md
│   ├── _COMMUNITY_code-backend.md
│   └── ...
├── graph.json                ← para queries CLI
├── graph.html                ← visualización interactiva
└── GRAPH_REPORT.md           ← resumen: nodos, edges, comunidades
```

## Política para agentes

Antes de Read/Glob/Grep extensivos, **siempre** consultar el conectoma:

```bash
# Si graphify-out/graph.json no existe → ejecutar /graphify primero
python -m graphify query "<intención>" --graph graphify-out/graph.json --budget 3000
```

## Cómo ver el consumo de tokens

Después de cada `/graphify`, el skill actualiza `graphify/usage.md` con el resumen de tokens consumidos.

## Configuración multi-repo

Para proyectos distribuidos en múltiples repositorios, graphify puede construir un grafo **federado** que conecta specs entre repos distintos.

### Configurar `.graphify.yml` multi-repo

```yaml
# graphify/.graphify.yml
repos:
  - path: .                   # repo principal (siempre incluir)
    prefix: ""                # sin prefijo para nodos del repo principal
  - path: ../api-service      # path relativo al repo principal
    prefix: "api:"            # prefijo para referenciar desde otros repos
  - path: ../mobile-client
    prefix: "mobile:"
```

### Sintaxis de wikilink cross-repo

```
[[api:specs/02-producto/requerimientos]]   ← nodo en repo api-service
[[mobile:specs/ui/pantallas]]              ← nodo en repo mobile-client
[[api:contracts/api/users]]               ← contrato OpenAPI del repo api-service
```

El agente [[navigator]] entiende este prefijo y busca en `graphify-out/federated/` en lugar del wiki local.

### Output federado

El grafo federado se genera en `graphify-out/federated/` separado del grafo local:

```
graphify-out/
├── wiki/          ← grafo del repo principal (no cambia)
└── federated/
    ├── index.md          ← índice global con todos los repos
    ├── graph.json        ← grafo unificado con prefijos por repo
    └── GRAPH_REPORT.md   ← resumen: N repos, N nodos totales, M cross-repo edges
```

Generado con `/graphify --federated`.

---

## Colisión de nombres — tooling vs producto

El nombre "graphify" puede colisionar con un módulo de tu producto si este
necesita construir un grafo/wiki en runtime (ej: una wiki de conocimiento, un grafo
de entidades, un sistema de memoria).

**Si la colisión ya ocurrió** (ej: tienes `packages/backend/src/graphify/` en tu producto
para procesar wikis en runtime):
- El tooling los trata como código fuente normal — los indexa pero no los modifica
- Documenta la distinción claramente en tu CLAUDE.md y en este GRAPHIFY.md

**Si puedes evitarla** (proyecto nuevo):
- Renombra el módulo de producto: `memory-graph`, `wiki-builder`, `entity-extractor`, etc.
- Reserva "graphify" para el tooling del framework

El agente [[navigator]] y las reglas de [[graphify-first]] siempre se refieren
al tooling, no a ningún módulo de producto.
