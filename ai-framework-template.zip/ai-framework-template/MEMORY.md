# Memory Index — Spec-Driven Framework

> Este archivo es el índice de memoria persistente del framework. Cada línea apunta a un archivo en `memory/`.
> Claude lo carga automáticamente para mantener contexto entre sesiones.
> No escribas contenido aquí — solo punteros. El contenido va en los archivos referenciados.

## Framework

- [Propósito del framework](memory/framework-purpose.md) — Qué es, para qué sirve y cómo se usa como base para nuevos proyectos
- [Flujo de trabajo principal](memory/workflow.md) — Grill-Brief → Bootstrap → Validate → Generate → Build
- [Flujo grill-brief](memory/grill-brief-workflow.md) — Por qué la entrevista guiada produce mejores briefs que llenar el template manualmente

## Conectoma / Grafo de conocimiento

- [Graphify integration](memory/graphify-integration.md) — cómo funciona el wiki de archivos, qué produce, cómo navegar por él

## Decisiones de diseño

- [Estructura de tres capas](memory/three-layer-design.md) — Por qué specs/contracts/.claude y no otra organización
- [Contratos como fuente de verdad](memory/contracts-over-prose.md) — Por qué los contratos formales tienen prioridad sobre la prosa

## Proyectos generados

<!-- Aquí se agregan entradas por cada proyecto bootstrapped con este framework -->
<!-- Ejemplo: - [nombre-proyecto](memory/project-nombre-proyecto.md) — Descripción corta del proyecto y estado -->
