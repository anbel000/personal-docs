# Spec-Driven Framework

Framework para construir software (y hardware) de forma **repetible y determinista** a partir de especificaciones formales, usando Claude Code y agentes IA.

La apuesta central: si las specs son precisas y los contratos son formales, el código se puede generar — no improvisar. El mismo brief produce siempre el mismo proyecto.

---

## Tabla de contenidos

1. [Requisitos](#requisitos)
2. [Primer uso — setup](#primer-uso--setup)
3. [Glosario](#glosario)
4. [Las 3 capas](#las-3-capas)
5. [Cómo funciona cada pieza](#cómo-funciona-cada-pieza)
6. [Flujo completo: de idea a deploy](#flujo-completo-de-idea-a-deploy)
7. [Referencia rápida de comandos](#referencia-rápida-de-comandos)
8. [Para equipos multi-área](#para-equipos-multi-área)
9. [Estructura del framework](#estructura-del-framework)
10. [Índice de archivos](#índice-de-archivos)

---

## Requisitos

- [Claude Code](https://claude.ai/code) CLI instalado y autenticado
- Git
- (Opcional) Python 3.9+ — solo si usas `/graphify` con LLM o `/graphify-specs`

Verificar instalación:
```bash
claude --version
git --version
```

---

## Primer uso — setup

**Paso 1 — Clonar el framework**

```bash
git clone <url-del-repo> spec-driven-framework
cd spec-driven-framework
```

**Paso 2 — Configurar overrides locales** (opcional)

Copia el template para tu configuración local (no se commitea):

```bash
cp .claude/settings.local.json.template .claude/settings.local.json
# Edita .claude/settings.local.json con tu modelo preferido, rutas, etc.
```

**Paso 3 — Instalar git hooks**

Los git hooks validan tus specs antes de cada commit:

```bash
bash .claude/hooks/setup-git-hooks.sh     # Linux / macOS / Git Bash
.\.claude\hooks\setup-git-hooks.ps1       # Windows PowerShell
```

**Paso 4 — Verificar que todo está bien**

Abre Claude Code en la carpeta del framework:

```bash
claude .
```

Luego en el chat:

```
/doctor
```

Debe reportar ✅ en todos los checks. Si hay ❌, ejecuta `/repair --fix`.

---

## Glosario

Términos que encontrarás en el framework y en los comandos:

| Término | Significado |
|---------|-------------|
| **Spec** | Archivo Markdown con frontmatter YAML que describe un aspecto del sistema (qué construir, qué datos manejar, qué reglas de seguridad aplican...). Viven en `specs/`. |
| **Contrato** | Archivo formal ejecutable (OpenAPI `.yaml`, JSON Schema `.json`, SQL DDL `.sql`, AsyncAPI `.yaml`, Protobuf `.proto`) que el código DEBE cumplir. Si la spec dice una cosa y el contrato dice otra, **el contrato gana**. |
| **Dominio** | Área temática del proyecto: `negocio`, `producto`, `datos`, `seguridad`, etc. Cada dominio tiene su carpeta en `specs/` y puede tener contratos en `contracts/`. |
| **`[PENDIENTE]`** | Marcador en una spec que indica que esa sección no está completa. `/grill-spec [dominio]` te entrevista para completarlos. `/validate` los detecta como gaps. |
| **Aprobado / `status: approved`** | Un dominio aprobado tiene todas sus specs revisadas y marcadas con `status: approved` en el frontmatter. `/approve [dominio]` hace eso. Las specs aprobadas bloquean ediciones sin nueva revisión. |
| **Conectoma** | Grafo de conocimiento que conecta specs ↔ contratos ↔ código ↔ agentes. Se genera con `/graphify` o `/graphify-specs`. Se guarda en `graphify-out/wiki/`. Los agentes lo consultan para navegar el proyecto sin leer todos los archivos. |
| **Drift** | Divergencia entre lo que dicen las specs y lo que hace el código. `/validate drift` y `/predeploy` lo detectan. El objetivo es siempre drift = 0 antes de deploy. |
| **Brief** | Documento de descripción inicial del proyecto. Lo genera `/grill-brief` mediante entrevista y lo guarda como `../mi-proyecto.md`. Es el input de `/bootstrap`. |

---

## Las 3 capas

```
┌─────────────────────────────────────────────────────────────┐
│  SPECS  ·  specs/                                           │
│  Markdown + YAML  ·  escrito por humanos                    │
│  Define QUÉ construir, para quién, con qué restricciones    │
└───────────────────────────┬─────────────────────────────────┘
                            │  formaliza en
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  CONTRATOS  ·  contracts/                                   │
│  OpenAPI · JSON Schema · DDL · AsyncAPI · Protobuf          │
│  Define los CONTRATOS verificables que el código debe cumplir│
└───────────────────────────┬─────────────────────────────────┘
                            │  genera con
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  AGENTES + REGLAS + COMANDOS  ·  .claude/                   │
│  Instrucciones para Claude Code                             │
│  Define CÓMO construirlo: qué código generar, cómo validar  │
└─────────────────────────────────────────────────────────────┘
```

**Regla de prioridad**: spec (prosa) < contrato (formal). Si el código diverge de un contrato, el código está mal.

---

## Cómo funciona cada pieza

### Comandos — `/comando argumentos`

Archivos `.md` en `.claude/commands/`. Se invocan escribiendo `/nombre` en el chat de Claude Code. Claude lee el archivo y ejecuta los pasos que contiene. `$ARGUMENTS` recibe todo lo que escribes después del nombre.

```
/validate all          → Claude lee commands/validate.md y ejecuta los 5 niveles
/contract create api users  → argumentos: "create api users"
/doctor --scope agents → argumentos: "--scope agents"
```

### Skills — `/skill argumentos`

Subdirectorios en `.claude/skills/`. Misma sintaxis de invocación que los comandos, pero encapsulan comportamiento persistente o interactivo.

```
/caveman              → comprime respuestas ~75%, persiste hasta "stop caveman"
/grill-me             → modo interrogatorio: una pregunta a la vez con recomendación
/graphify-specs       → construye el conectoma AST sin gastar tokens LLM
```

La diferencia con comandos: los skills pueden activarse/desactivarse como modo, o mantener estado a lo largo de una conversación.

### Agentes — invocados internamente

Archivos `.md` en `.claude/agents/`. **No se invocan directamente por el usuario**. Los comandos los llaman internamente con `Agent(...)`. Cada agente tiene herramientas y reglas específicas.

```
/review producto    → el comando /review invoca al agente "reviewer"
/generate all       → /generate invoca "implementer", "data-engineer", "qa"...
/bootstrap brief.md → /bootstrap invoca al agente "bootstrapper" (el más crítico)
```

Los agentes de `.claude/agents-registry/` (compliance-checker, contract-tester, etc.) son especializados y se usan solo en flujos puntuales como auditorías o migraciones.

### Reglas — siempre activas

Archivos `.md` en `.claude/rules/`. **No se invocan**. Claude las carga desde `CLAUDE.md` al inicio de cada sesión y todos los agentes las siguen.

| Regla | Cuándo aplica |
|-------|---------------|
| `coding-conventions` | Siempre, al generar cualquier código |
| `spec-sync` | Cuando se modifica código orientado a deploy |
| `feature-flags` | Cuando hay flags de feature en código o specs |
| `testing-patterns` | Al generar o revisar tests |
| `security-patterns` | En todo endpoint, auth y manejo de datos |
| `graphify-first` | Antes de hacer búsquedas masivas de archivos |

### Hooks — automatización sin intervención del usuario

**Hooks de Claude Code** — configurados en `.claude/settings.json`, se disparan automáticamente:

| Cuándo | Script | Qué hace |
|--------|--------|----------|
| Antes de cada `Bash` | `validate-bash.sh` | Bloquea `rm -rf`, `git push --force` y otros comandos destructivos |
| Después de cada `Write` / `Edit` | `format-on-save.sh` | Formatea TypeScript, JS y Python automáticamente |
| Después de cada `Write` / `Edit` | `validate-frontmatter.sh` | Verifica que el frontmatter YAML de la spec es válido |
| Después de cada `Write` / `Edit` | `check-spec-freshness.sh` | Alerta si la spec editada está próxima a expirar (`expires:`) |
| Después de cada `Write` / `Edit` | `rebuild-graph.sh` | Actualiza el conectoma de forma incremental |
| Cuando Claude termina una respuesta | `notify-done.sh` | Notificación de escritorio |

**Git hooks** — se instalan una vez con `setup-git-hooks.sh`, luego actúan en cada operación git:

| Cuándo | Script | Qué hace |
|--------|--------|----------|
| `git commit` (antes) | `pre-commit-validate.sh` | Valida YAML/JSON y frontmatter de specs en stage |
| `git commit` (antes) | `pre-commit-spec-sync.sh` | Bloquea commit si hay `[PENDIENTE]` en spec `approved` |
| `git commit` (después) | `post-commit-changelog.sh` | Auto-actualiza `memory/spec-changelog.md` |

---

## Flujo completo: de idea a deploy

### Contexto de carpetas

```
mi-workspace/
├── spec-driven-framework/   ← aquí vive el framework (no se toca)
└── mi-proyecto/             ← aquí vive tu proyecto (generado por /bootstrap)
```

Trabajas dentro de `spec-driven-framework/` para crear el brief y hacer bootstrap. Luego abres `mi-proyecto/` con Claude Code para el ciclo de specs → código → deploy.

---

### Fase 1 — Crear el brief (dentro de `spec-driven-framework/`)

```
/grill-brief
```

Claude te entrevista: una pregunta a la vez, con su recomendación incluida. Al terminar escribe `../mi-proyecto.md` con el brief completo.

---

### Fase 2 — Generar la estructura del proyecto (dentro de `spec-driven-framework/`)

```
/bootstrap ../mi-proyecto.md
```

Genera `../mi-proyecto/` con:
- Todas las specs pobladas (con `[PENDIENTE]` donde falta info)
- Contratos iniciales en `contracts/`
- Configuración de Claude Code copiada (`.claude/`)
- `spec-manifest.yaml` configurado

Perfiles disponibles: `--profile saas` · `--profile iot` · `--profile api-only` · `--profile minimal`

---

### Fase 3 — Completar specs (dentro de `mi-proyecto/`)

```
cd ../mi-proyecto
claude .
```

```
/graphify              ← construye el conectoma inicial para navegación rápida
/grill-spec producto   ← entrevista guiada para completar [PENDIENTE] del dominio
/grill-spec datos      ← idem para otro dominio
/validate all          ← detecta gaps, inconsistencias y specs vacías
/analyze               ← diagnóstico profundo: [PENDIENTE] por dominio, cobertura
```

Iterar hasta que `/validate all` no reporte gaps de severidad ALTA.

---

### Fase 4 — Revisar y aprobar specs

```
/review producto       ← revisión de calidad: claridad, completitud semántica, Gherkin
/review datos          ← idem por dominio
/approve producto      ← marca todas las specs del dominio como aprobadas
/approve datos
```

`/review` puede recomendar APROBAR, NECESITA CAMBIOS o RECHAZAR. Solo aprobar tras resolver los BLOCKERs.

---

### Fase 5 — Generar código

```
/generate all          ← genera código para todos los dominios aprobados
/generate producto     ← solo un dominio (--diff para incremental, --fingerprint para detectar ediciones manuales)
```

---

### Fase 6 — Build y tests

```
/build                 ← pipeline completo: lint → tests → build
/build --resume        ← retoma desde el último paso completado si falla
```

---

### Fase 7 — Deploy

```
/predeploy             ← OBLIGATORIO: drift check + refresh del conectoma
```

Si `/predeploy` pasa sin errores, puedes deployar. Si detecta drift, corregir antes.

---

### Monitoreo y diagnóstico (en cualquier momento)

```
/status                ← semáforo verde/amarillo/rojo del proyecto en 5 segundos
/spec-health           ← tendencia histórica: dominios aprobados, [PENDIENTE] totales
/explain REQ-FUNC-003  ← dónde está implementado este requerimiento
/spec-changelog        ← historial de cambios de specs por dominio
```

---

## Referencia rápida de comandos

### "Quiero..."

| Quiero... | Comando |
|-----------|---------|
| Empezar un proyecto nuevo | `/grill-brief` |
| Generar estructura del proyecto desde brief | `/bootstrap ../mi-proyecto.md` |
| Completar specs incompletas con entrevista | `/grill-spec [dominio]` |
| Construir el grafo de navegación del proyecto | `/graphify` |
| Ver qué falta y qué está inconsistente | `/validate all` |
| Diagnóstico profundo con conteo de gaps | `/analyze` |
| Ver el estado del proyecto en 5 segundos | `/status` |
| Revisar calidad de specs antes de aprobar | `/review [dominio]` |
| Marcar un dominio como aprobado | `/approve [dominio]` |
| Generar código desde specs | `/generate all` |
| Pipeline completo con tests | `/build` |
| Verificar antes de deploy | `/predeploy` |
| Entender qué hace un archivo o requerimiento | `/explain [archivo\|ID]` |
| Gestionar contratos formales (crear/validar/diff) | `/contract [subcomando]` |
| Gestionar feature flags | `/flags [subcomando]` |
| Generar SBOM (inventario de dependencias) | `/sbom generate` |
| Ver historial de cambios de specs | `/spec-changelog` |
| Ver tendencia histórica de salud | `/spec-health` |
| Sincronizar reqs con Linear o GitHub Issues | `/sync-issues` |
| Verificar integridad del framework mismo | `/doctor` |
| Corregir referencias rotas automáticamente | `/repair --fix` |
| Retomar trabajo de sesión anterior | `/resume` |
| Onboarding para nuevo miembro del equipo | `/onboard [rol]` |

### Comandos de contrato frecuentes

```
/contract list                    ← lista todos los contratos y su estado
/contract validate all            ← valida sintaxis de todos los contratos
/contract create api usuarios     ← skeleton OpenAPI 3.1 para recurso "usuarios"
/contract create schema Usuario   ← skeleton JSON Schema para entidad
/contract create ddl usuarios     ← migración DDL PostgreSQL
/contract create asyncapi eventos ← skeleton AsyncAPI 2.6 para canal de eventos
/contract create proto pagos      ← skeleton Protobuf 3 para servicio gRPC
/contract diff usuarios.yaml      ← breaking vs non-breaking changes vs git HEAD~1
/contract bump usuarios.yaml      ← depreca v1, crea v2, genera ADR automático
```

### Flags de validación frecuentes

```
/validate all --profile quick       ← solo estructura (más rápido)
/validate all --profile pre-commit  ← para pre-commit hooks
/validate all --profile pre-deploy  ← completo, igual que /predeploy
/validate drift                     ← detecta divergencias código ↔ spec
/validate freshness                 ← specs aprobadas próximas a expirar
/validate all --fix                 ← auto-corrige gaps de baja/media severidad
```

---

## Para equipos multi-área

El framework no es solo para desarrollo. Cada dominio de spec tiene un `approver` que puede ser de negocio, producto, diseño, legal u operaciones.

| Área | Dominios que gestiona | Specs principales |
|------|-----------------------|-------------------|
| Negocio / C-Level | `specs/01-negocio/` | vision, propuesta-valor, modelo-negocio, stakeholders |
| Producto | `specs/02-producto/` | requerimientos, historias-usuario, flujos, roadmap |
| Diseño / UX | `specs/03-diseno/` | design-system, arquitectura-informacion, accesibilidad |
| Arquitectura | `specs/04-arquitectura/` | arquitectura, stack, integraciones |
| Data | `specs/05-datos/` | modelo, flujos, gobernanza |
| Seguridad | `specs/06-seguridad/` | requisitos, threat-model, cumplimiento |
| SRE / DevOps | `specs/07-infra/`, `specs/09-operaciones/` | infraestructura, cicd, monitoreo, runbook |
| Legal / Compliance | `specs/10-legal/` | regulaciones, privacidad, terminos |
| Hardware / IoT | `specs/11-hardware/` | especificaciones, iot-conectividad |

Cada área puede revisar y aprobar sus dominios de forma independiente. El código no se genera de un dominio hasta que está aprobado.

---

## Estructura del framework

### Directorios principales

| Directorio | Propósito |
|------------|-----------|
| `specs/` | Especificaciones del proyecto en Markdown (generadas por `/bootstrap`, completadas con `/grill-spec`) |
| `contracts/` | Contratos formales: OpenAPI, JSON Schema, DDL, AsyncAPI, Protobuf |
| `.claude/` | Infraestructura del framework: agentes, comandos, reglas, hooks, skills |
| `graphify/` | Configuración del conectoma (`.graphify.yml`, modelo LLM) |
| `graphify-out/` | Conectoma generado — wiki navegable, grafo HTML (ignorado por git) |
| `memory/` | Memoria persistente entre sesiones (spec-changelog, notas de contexto) |
| `docs/adr/` | Architecture Decision Records |
| `ejemplos/` | Implementaciones de referencia (no templates) |

### Infraestructura `.claude/`

| Subcarpeta | Contenido | Cómo se usa |
|------------|-----------|-------------|
| `agents/` | 14 agentes especializados | Invocados internamente por comandos |
| `agents-registry/` | 5 agentes de uso puntual | Auditorías, compliance, migraciones, onboarding, contract testing |
| `commands/` | 24 comandos invocables | `/nombre` en el chat de Claude Code |
| `rules/` | 9 reglas siempre activas | Cargadas automáticamente, aplican a todos los agentes |
| `hooks/` | 13 scripts de automatización | Auto-ejecutados (Claude Code hooks) o git hooks instalados |
| `skills/` | 3 skills invocables | `/nombre` — comportamiento persistente o interactivo |
| `settings.json` | Configuración del equipo | Permisos, hooks de Claude Code, configuración compartida |

### Agentes disponibles

| Agente | Modelo | Rol |
|--------|--------|-----|
| `bootstrapper` | Opus | Genera proyectos completos desde un brief — el más crítico |
| `architect` | Opus | Scaffolding, ADRs y decisiones técnicas de alto impacto |
| `implementer` | Sonnet | Lógica de negocio, endpoints, services |
| `data-engineer` | Sonnet | Modelos, migraciones, repositorios |
| `product` | Sonnet | Requerimientos, historias de usuario, flujos |
| `designer` | Sonnet | Rutas, design tokens, componentes UI |
| `iot-engineer` | Sonnet | Conectividad IoT, clientes MQTT |
| `devops` | Sonnet | Infraestructura y CI/CD |
| `security-reviewer` | Sonnet | Auditoría de seguridad |
| `analyst` | Sonnet | Validación de specs y drift detection |
| `performance-engineer` | Sonnet | SLOs, scripts de carga (k6/locust) |
| `reviewer` | Sonnet | Revisión de calidad de specs antes de aprobar |
| `qa` | Haiku | Tests automatizados |
| `navigator` | Haiku | Navega el conectoma del proyecto |

**Agentes del registry** (`.claude/agents-registry/`):

| Agente | Cuándo usarlo |
|--------|---------------|
| `spec-auditor` | Auditoría profunda de un dominio — combina analyst + reviewer |
| `compliance-checker` | Verifica cumplimiento de GDPR, SOC2, HIPAA, PCI-DSS |
| `contract-tester` | Consumer-driven contract testing con Pact o Prism |
| `migration-planner` | Planifica migraciones de contratos con breaking changes |
| `onboarding-guide` | Genera guía de onboarding personalizada por rol |

---

## Índice de archivos

### Archivos clave del framework

| Archivo | Propósito |
|---------|-----------|
| [`CLAUDE.md`](CLAUDE.md) | Instrucciones maestras — define todo el comportamiento del framework |
| [`spec-manifest.yaml`](spec-manifest.yaml) | Manifiesto central: mapea specs → agentes → artefactos |
| [`project-brief-template.md`](project-brief-template.md) | Template de brief para proyectos nuevos |
| [`mcp.json`](mcp.json) | Template de servidores MCP (GitHub, DB, Linear, Jira...) |
| [`MEMORY.md`](MEMORY.md) | Índice de memoria persistente del framework |
| [`docs/adr/README.md`](docs/adr/README.md) | Índice de decisiones arquitectónicas |
| [`graphify/GRAPHIFY.md`](graphify/GRAPHIFY.md) | Documentación del conectoma y política de uso |
| [`.claude/settings.json`](.claude/settings.json) | Configuración compartida del equipo (permisos y hooks) |

### Comandos (`.claude/commands/`)

| Comando | Archivo |
|---------|---------|
| `/grill-brief` | [commands/grill-brief.md](.claude/commands/grill-brief.md) |
| `/grill-spec` | [commands/grill-spec.md](.claude/commands/grill-spec.md) |
| `/bootstrap` | [commands/bootstrap.md](.claude/commands/bootstrap.md) |
| `/graphify` | [commands/graphify.md](.claude/commands/graphify.md) |
| `/validate` | [commands/validate.md](.claude/commands/validate.md) |
| `/review` | [commands/review.md](.claude/commands/review.md) |
| `/approve` | [commands/approve.md](.claude/commands/approve.md) |
| `/generate` | [commands/generate.md](.claude/commands/generate.md) |
| `/build` | [commands/build.md](.claude/commands/build.md) |
| `/predeploy` | [commands/predeploy.md](.claude/commands/predeploy.md) |
| `/contract` | [commands/contract.md](.claude/commands/contract.md) |
| `/flags` | [commands/flags.md](.claude/commands/flags.md) |
| `/sbom` | [commands/sbom.md](.claude/commands/sbom.md) |
| `/status` | [commands/status.md](.claude/commands/status.md) |
| `/doctor` | [commands/doctor.md](.claude/commands/doctor.md) |
| `/repair` | [commands/repair.md](.claude/commands/repair.md) |
| `/analyze` | [commands/analyze.md](.claude/commands/analyze.md) |
| `/explain` | [commands/explain.md](.claude/commands/explain.md) |
| `/spec-changelog` | [commands/spec-changelog.md](.claude/commands/spec-changelog.md) |
| `/spec-health` | [commands/spec-health.md](.claude/commands/spec-health.md) |
| `/onboard` | [commands/onboard.md](.claude/commands/onboard.md) |
| `/resume` | [commands/resume.md](.claude/commands/resume.md) |
| `/sync-issues` | [commands/sync-issues.md](.claude/commands/sync-issues.md) |
| `/graphifyllm` | [commands/graphifyllm.md](.claude/commands/graphifyllm.md) |

### Reglas (`.claude/rules/`)

| Regla | Archivo |
|-------|---------|
| `coding-conventions` | [rules/coding-conventions.md](.claude/rules/coding-conventions.md) |
| `api-patterns` | [rules/api-patterns.md](.claude/rules/api-patterns.md) |
| `testing-patterns` | [rules/testing-patterns.md](.claude/rules/testing-patterns.md) |
| `security-patterns` | [rules/security-patterns.md](.claude/rules/security-patterns.md) |
| `spec-sync` | [rules/spec-sync.md](.claude/rules/spec-sync.md) |
| `feature-flags` | [rules/feature-flags.md](.claude/rules/feature-flags.md) |
| `graphify-first` | [rules/graphify-first.md](.claude/rules/graphify-first.md) |
| `sesiones` | [rules/sesiones.md](.claude/rules/sesiones.md) |
| `tasks-discipline` | [rules/tasks-discipline.md](.claude/rules/tasks-discipline.md) |
