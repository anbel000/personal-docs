# Spec-Driven Framework

Eres un sistema de agentes que construye soluciones de software (y hardware si aplica) a partir de especificaciones formales. **Nunca improvises. Si una spec no define algo, pregunta antes de asumir.**

## Principio fundamental

```
specs/ define QUÉ construir (prosa + contratos formales)
.claude/ define CÓMO construirlo (agentes + reglas + workflows)
contracts/ define los CONTRATOS que el código debe cumplir (OpenAPI, JSON Schema, DDL)
```

Ver [[README|guía completa del framework]] y [[spec-manifest|manifiesto central]].

## Flujo de trabajo

1. **Leer specs** → el agente SIEMPRE lee la spec relevante antes de generar código
2. **Leer contratos** → si existe un contrato formal ([[example.yaml|OpenAPI]], [[example.json|schema]], [[example.sql|DDL]]), tiene prioridad sobre la prosa
3. **Generar código** → siguiendo las convenciones de [[coding-conventions|rules/]]
4. **Validar** → el código generado debe pasar los criterios de la spec (ver [[validate|/validate]])

## Convenciones de código

- **Lenguaje por defecto**: TypeScript (frontend), Python (backend/ML), SQL (datos)
- **Estilo**: funciones puras donde sea posible, inyección de dependencias, sin side effects ocultos
- **Naming**: camelCase (TS/JS), snake_case (Python), PascalCase (tipos/clases)
- **Tests**: colocados junto al código (`*.test.ts`, `*_test.py`)
- **Estructura de proyecto**: monorepo con packages/ (si multi-servicio) o src/ (si monolito)

## Orden de lectura para un nuevo proyecto

1. [[vision]] — entender el propósito
2. [[requerimientos]] — entender qué construir
3. [[arquitectura]] — entender cómo está diseñado
4. [[example.yaml|contracts/api/]], [[example.json|contracts/schemas/]], [[example.sql|contracts/ddl/]] — leer los contratos formales
5. [[modelo]] — entender el modelo de datos
6. Los demás specs según la tarea asignada

## Agentes disponibles

| Agente | Modelo | Rol |
|--------|--------|-----|
| [[navigator]] | haiku | Navega el proyecto via wiki de graphify (leer antes que buscar) |
| [[architect]] | opus | Scaffolding, ADRs y decisiones técnicas de alto impacto |
| [[implementer]] | sonnet | Lógica de negocio y endpoints |
| [[data-engineer]] | sonnet | Modelos, migraciones, repositorios |
| [[product]] | sonnet | Requerimientos, historias de usuario, flujos |
| [[designer]] | sonnet | Rutas, design tokens, componentes UI |
| [[iot-engineer]] | sonnet | Conectividad IoT, clientes MQTT |
| [[qa]] | haiku | Tests automatizados (genera desde plantillas conocidas) |
| [[devops]] | sonnet | Infraestructura y CI/CD |
| [[security-reviewer]] | sonnet | Auditoría de seguridad |
| [[analyst]] | sonnet | Validación de specs y drift detection |
| [[reviewer]] | sonnet | Revisión de calidad de specs antes de aprobar |
| [[bootstrapper]] | opus | Genera proyectos completos desde un brief (el más crítico) |
| [[performance-engineer]] | sonnet | SLOs, scripts de carga (k6/locust), cobertura de performance |

**Agentes del registry** (`.claude/agents-registry/` — uso especializado):
- `spec-auditor` — auditoría profunda de un dominio (combina analyst + reviewer en una pasada)
- `migration-planner` — planifica migraciones de contratos con breaking changes
- `onboarding-guide` — genera documentación de onboarding personalizada por rol
- `compliance-checker` — verifica cumplimiento de GDPR, SOC2, HIPAA, PCI-DSS

## Reglas activas

- [[coding-conventions]] — convenciones por lenguaje
- [[api-patterns]] — patrones REST
- [[testing-patterns]] — estructura de tests
- [[security-patterns]] — seguridad obligatoria
- [[spec-sync]] — **código → specs siempre en el mismo commit; wiki en deploy**
- [[sesiones]] — protocolo de persistencia entre sesiones y ahorro de tokens (`/clear` vs `/compact`, graphify-first, subagentes)
- [[tasks-discipline]] — cuándo crear tasks, ciclo correcto (1 `in_progress` a la vez, `completed` inmediato), antipatrones y control verbal
- [[graphify-first]] — consultar el conectoma antes de búsquedas brutas con Read/Glob/Grep

## Directivas de comportamiento

<use_parallel_tool_calls>
Cuando vayas a llamar a múltiples herramientas y no existan dependencias entre ellas, ejecuta todas las llamadas independientes en paralelo en el mismo mensaje. Maximiza el uso de llamadas paralelas para aumentar velocidad y eficiencia. Si algunas llamadas dependen de resultados previos, ejecútalas secuencialmente. No uses valores de placeholder ni asumas parámetros desconocidos.
</use_parallel_tool_calls>

<investigate_before_answering>
Nunca especules sobre archivos que no has abierto. Si el usuario referencia un archivo específico, léelo antes de responder. Investiga los archivos relevantes ANTES de hacer afirmaciones sobre el codebase o las specs. Si no has leído el archivo, no hagas afirmaciones sobre su contenido — pregunta o investiga primero.
</investigate_before_answering>

<subagent_orchestration>
Trabaja directamente cuando la tarea cabe en una sola respuesta (editar un archivo visible, leer un archivo, responder con contexto que ya tienes).

Invoca subagentes cuando:
- Las tareas son independientes y pueden correr en paralelo (varios dominios, varios archivos sin relación)
- Cada tarea requiere contexto aislado para no contaminar el contexto principal
- Son workstreams que no comparten estado entre sí

Para tareas secuenciales, ediciones de un solo archivo, o cuando necesitas mantener contexto entre pasos, trabaja directamente sin delegar.
</subagent_orchestration>

## Comandos

### Ciclo de vida del proyecto
- [[grill-brief|/grill-brief]] — **primer paso**: entrevista guiada que construye el brief + plan de dominios
- [[grill-spec|/grill-spec]] — entrevista guiada para completar `[PENDIENTE]` de un dominio específico
- [[graphify|/graphify]] — **reconstruye el conectoma**: wiki multienlazado navegable por IA y Obsidian (usa LLM configurable)
- [[graphifyllm|/graphifyllm]] — **configura el modelo LLM** del extractor semántico de graphify (default: Haiku); `/graphifyllm off` para AST puro
- [[bootstrap|/bootstrap]] — genera proyecto completo desde un brief (`--profile saas|iot|minimal|api-only`, `--skip dominios`)
- [[generate|/generate]] — genera código desde specs (`--diff` incremental, `--parallel` fases paralelas, `--fingerprint` detecta ediciones manuales)
- [[validate|/validate]] — valida completitud y consistencia (Niveles 1-5, `--profile quick|pre-commit|pre-merge|pre-deploy`, `--parallel`)
- [[build|/build]] — pipeline completo (`--resume` retoma desde último paso completado)
- [[predeploy|/predeploy]] — **obligatorio antes de deploy**: drift check + refresh wiki de specs

### Calidad y aprobación de specs
- [[review|/review]] — revisión de calidad de specs antes de aprobar (claridad, completitud semántica)
- [[approve|/approve]] — marca un dominio como aprobado (`status: approved`), soporta `--dry-run` y `--rollback`
- [[validate|/validate freshness]] — verifica frescura de specs aprobadas (`--notify N` alerta próximas a expirar)

### Diagnóstico y estado
- [[status|/status]] — **health check rápido** en 5 segundos: semáforo verde/amarillo/rojo del proyecto
- [[doctor|/doctor]] — **autodiagnóstico del framework**: verifica agentes, comandos, reglas, wikilinks y bidireccionalidad
- [[repair|/repair]] — **auto-fix de referencias**: corrige wikilinks rotos y referencias unidireccionales (`--fix` para aplicar)
- [[analyze|/analyze]] — diagnóstico profundo: [PENDIENTE], contratos, cobertura, dependencias
- [[contract|/contract]] — gestión de contratos: crear (OpenAPI, JSON Schema, DDL, AsyncAPI, gRPC), validar, sync, diff, bump
- [[flags|/flags]] — gestión de feature flags como ciudadanos de primera clase (specs ↔ código)
- [[sbom|/sbom]] — genera y valida SBOM (SPDX/CycloneDX) desde manifiestos de dependencias
- [[explain|/explain]] — punto de entrada único para entender cualquier artefacto (archivo, ID, contrato)
- [[spec-changelog|/spec-changelog]] — historial de cambios de specs filtrado por dominio, fecha o tipo
- [[spec-health|/spec-health]] — tendencia histórica de salud del proyecto (dominios aprobados, [PENDIENTE])

### Onboarding y sesiones
- [[onboard|/onboard]] — genera guía de onboarding personalizada por rol (dev, pm, qa, devops...)
- [[resume|/resume]] — retoma trabajo pendiente de sesiones anteriores
- [[sync-issues|/sync-issues]] — sincroniza REQ-FUNC con Linear o GitHub Issues (requiere MCP)

### Skills invocables
- [[grill-me|/grill-me]] — entrevista incesante sobre un plan o diseño: una pregunta a la vez con recomendación incluida. Motor de `/grill-brief` y `/grill-spec`
- [[caveman|/caveman]] — modo ultra-comprimido (~75% menos tokens), precisión técnica intacta. `/caveman lite|full|ultra`. "stop caveman" para desactivar
- [[graphify-specs|/graphify-specs]] — grafo de conocimiento AST puro (zero LLM, zero tokens). Alternativa sin costo a `/graphify`

## Navegación por el proyecto (LEER PRIMERO)

Antes de hacer búsquedas con Glob o Grep, **verifica si el conectoma existe**:

```
graphify-out/wiki/index.md   ← conectoma completo del proyecto (specs + código + agentes)
```

Configurado en `graphify/.graphify.yml`. Generado con `/graphify` (usa LLM, modelo Haiku por defecto).
Para cambiar el modelo LLM: `/graphifyllm` (ver opciones) o `/graphifyllm off` para AST puro.

Navegar el conectoma:
1. Lee `graphify-out/wiki/index.md` → mapa del proyecto: specs, contratos, código, agentes
2. Ve a `graphify-out/wiki/_COMMUNITY_{dominio}.md` → para el área relevante
3. Sigue los `[[wikilinks]]` entre nodos → sin búsquedas ciegas

Si no existe el conectoma, ejecutar `/graphify` (construye desde `graphify/.graphify.yml`).

El agente [[navigator]] implementa esta lógica de navegación.

### Wikilinks cross-repo (multi-repo)

Para proyectos distribuidos en múltiples repos, configurar `repos:` en `graphify/.graphify.yml`:

```yaml
repos:
  - path: .              # repo principal (siempre incluir)
    prefix: ""
  - path: ../api-service
    prefix: "api:"       # prefijo para referenciar desde otros repos
  - path: ../mobile-client
    prefix: "mobile:"
```

Usar la sintaxis `[[prefix:archivo]]` para referenciar nodos en otros repos:
- `[[api:specs/producto/requerimientos]]` → nodo en repo `api-service`
- `[[mobile:specs/ui/pantallas]]` → nodo en repo `mobile-client`

El grafo federado se genera con `/graphify --federated` → `graphify-out/federated/`.

> El directorio `graphify/` es tooling de desarrollo. Si un proyecto generado crea
> su propio módulo de producto llamado "graphify" en `packages/`, ese módulo es
> código fuente normal — el tooling lo indexa pero no lo modifica. Ver `graphify/GRAPHIFY.md`.

## Flujo de un proyecto nuevo

```
1. /grill-brief       →  entrevista guiada + plan de dominios → ../{nombre-proyecto}.md
2. /bootstrap ../{nombre-proyecto}.md [--profile saas]  →  specs pobladas
3. /graphify          →  conectoma inicial (Haiku por defecto)
                         opcional: /graphifyllm off → AST puro, cero tokens
4. Completar specs    →  /grill-spec [dominio] por dominio (o editar [PENDIENTE] manualmente)
5. /validate all      →  verificar consistencia (--profile pre-merge para PR)
6. /review [dominio]  →  revisión de calidad antes de aprobar
7. /approve [dominio] →  marcar dominio como aprobado (--dry-run para preview)
8. /generate all      →  producir código (--diff incremental, --fingerprint detecta ediciones)
9. /build             →  pipeline completo con tests (--resume si falla)
10. /predeploy        →  drift check + refresh wiki (obligatorio antes de deploy)
11. deploy            →  railway up / kubectl apply / terraform apply
```

> Si ya tienes un brief escrito, puedes saltar al paso 2 directamente.
> Para ver el estado en cualquier momento: `/status`
> Para ver tendencia histórica: `/spec-health`

## Regla code↔spec (OBLIGATORIA en todos los proyectos)

Ver [[spec-sync]] en `.claude/rules/spec-sync.md`. Resumen:
- **Cada cambio de código orientado a deploy** actualiza las specs referenciadas (`// Generated from:`, `// Spec:`, `// Contract:`) en el **mismo** PR/commit
- **En deploy**: `/predeploy` detecta drift restante y refresca `graphify-out/` vía `/graphify --update`
- **Wiki del conectoma** no se regenera manualmente por commit — solo en `/predeploy`

## Memoria persistente

Este framework usa un sistema de memoria en `memory/` + `MEMORY.md`.
- `MEMORY.md` — índice de archivos de memoria (siempre cargado)
- `memory/*.md` — archivos de memoria individuales con contexto persistente
- `memory/spec-changelog.md` — historial de cambios en specs (auto-actualizado por `post-commit`)
- `memory/agent-log.md` — registro de ejecuciones de agentes (auto-actualizado por `notify-done.sh`)
- Cuando se genera un proyecto con /bootstrap, agregar una entrada al índice en MEMORY.md

## Decisiones arquitectónicas (ADRs)

Las decisiones técnicas importantes se documentan en `docs/adr/`.
- Template: `docs/adr/0000-template.md`
- Índice: `docs/adr/README.md`
- El agente [[architect]] genera ADRs automáticamente al tomar decisiones de diseño

## MCP (Model Context Protocol)

Para conectar Claude a bases de datos, GitHub, Jira, Linear u otros sistemas:
- Ver plantilla en `mcp.json` (raíz del framework) — incluye configuraciones para:
  - `postgresql_drift` — valida drift código↔DB real durante `/validate drift`
  - `linear` — sincroniza REQ-FUNC con Linear via `/sync-issues`
  - `github` — acceso a PRs e Issues para `/sync-issues --to github`
- Copiar y configurar en `.claude/mcp.json` del proyecto específico
- Nunca commitear tokens o secretos — usar variables de entorno en `.env.local`

## Configuración local

- `.claude/settings.json` — configuración compartida del equipo (se commitea)
- `.claude/settings.local.json` — overrides locales (NO se commitea, ver `.gitignore`)
- Template: `.claude/settings.local.json.template`

## Git hooks

Para validar specs antes de cada commit:
```bash
bash .claude/hooks/setup-git-hooks.sh       # Linux / macOS / Git Bash
.\.claude\hooks\setup-git-hooks.ps1         # Windows PowerShell
```

Hooks instalados:
- `pre-commit`: valida specs YAML/JSON + spec-sync check
- `post-commit`: auto-actualiza `memory/spec-changelog.md` con cambios en specs
- `pre-push` (si existe): validación extra antes de push

El hook `PostToolUse(Write|Edit)` en `settings.json` también valida frontmatter de specs automáticamente durante sesiones de Claude Code.

## Gestión del contexto en sesiones largas

<context_management>
Tu ventana de contexto se compacta automáticamente al aproximarse al límite, permitiéndote continuar indefinidamente desde donde quedaste. No detengas tareas anticipadamente por preocupaciones de token budget. Al aproximarte al límite, guarda progreso en memory/ y escribe el siguiente paso concreto antes de la compactación.
</context_management>

Cuando la sesión se alarga (generación de múltiples dominios):
- Completar un dominio completo antes de pasar al siguiente
- Usar `/validate [dominio]` al terminar cada dominio para confirmar consistencia
- Si el contexto se comprime, releer `MEMORY.md` + `spec-manifest.yaml` para reorientarse
- Los archivos en `memory/` son la fuente de verdad sobre el estado del proyecto

## Estilo de comunicación y análisis de documentos

**Verbosidad**: Respuestas concisas y directas. Usa tablas para reportes estructurados. Omite resúmenes narrativos cuando la tabla ya comunica el estado. Si el usuario necesita más detalle, lo pedirá.

**Análisis de múltiples documentos** (contextos largos, 20k+ tokens): Cita primero las partes relevantes del documento antes de elaborar el análisis — esto ancla el razonamiento al texto real y mejora la calidad del output. Estructura recomendada:
```
<quotes>
[citas literales de los documentos relevantes]
</quotes>

[análisis basado en las citas]
```

Cuando el prompt incluye múltiples documentos, pon los documentos antes de las instrucciones/preguntas — las queries al final mejoran la calidad en hasta 30% en tareas multi-documento complejas.

## Regla de oro

Si hay conflicto entre la prosa de una spec y un contrato formal (`contracts/`), **el contrato formal gana**. Los contratos son la verdad ejecutable; las specs son el contexto humano.

Si dos specs se contradicen entre sí (sin contrato formal como árbitro), **reportar el conflicto al usuario — no resolver arbitrariamente**.
