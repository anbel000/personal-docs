---
name: workflow
description: Flujo de trabajo principal del framework — Brief → Bootstrap → Validate → Generate → Build
metadata:
  type: project
---

El flujo canónico para arrancar un proyecto nuevo con este framework:

1. **Escribir brief** → Copiar `project-brief-template.md` y llenarlo con la idea del proyecto
2. **Bootstrap** → `/bootstrap <ruta-al-brief>` genera el directorio del proyecto con specs pobladas
3. **Revisar gaps** → Completar manualmente los `[PENDIENTE: ...]` encontrados en las specs
4. **Validar** → `/validate all` verifica consistencia entre dominios
5. **Generar código** → `/generate all` produce src/, tests/, infra/ desde las specs
6. **Pipeline completo** → `/build` hace validate + generate + tests en secuencia

**Why:** Este orden evita que Claude genere código sin contexto y garantiza trazabilidad desde negocio hasta código.

**How to apply:** Cuando el usuario pida "hacer el proyecto", verificar en qué paso está antes de ejecutar cualquier comando.
