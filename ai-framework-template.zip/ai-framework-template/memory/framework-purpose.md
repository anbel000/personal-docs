---
name: framework-purpose
description: Qué es el spec-driven-framework, para qué sirve y cómo se usa como base para nuevos proyectos
metadata:
  type: project
---

El spec-driven-framework es una plantilla de trabajo para Claude Code que permite construir cualquier tipo de proyecto de software a partir de especificaciones formales.

**Por qué existe:** Estandarizar la forma en que Claude recibe contexto de negocio y genera código, evitando que improvise sin base documental.

**Cómo se usa:**
1. El usuario escribe un brief genérico del proyecto (usando `project-brief-template.md`)
2. Coloca el brief en la raíz del workspace, junto a la carpeta `spec-driven-framework/`
3. Ejecuta `/bootstrap <ruta-al-brief>` desde dentro del framework
4. El bootstrapper genera un directorio nuevo con todas las specs pobladas
5. Se revisan los gaps, se ejecuta `/validate all` y luego `/generate all`

**How to apply:** Cuando el usuario traiga un nuevo proyecto, sugerir este flujo. No asumir que ya conoce el proceso.
