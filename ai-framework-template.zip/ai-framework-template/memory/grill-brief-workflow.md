---
name: grill-brief-workflow
description: Por qué grill-me + bootstrap es el flujo canónico para arrancar proyectos nuevos — mejor que llenar el template manualmente
metadata:
  type: project
---

El flujo canónico para arrancar un proyecto nuevo es:

```
/grill-brief → ../{nombre}.md → /bootstrap → specs pobladas → /validate → /generate
```

**Por qué no llenar el template manualmente:**
Los briefs llenados en blanco producen specs débiles. El usuario tiende a dejar campos vacíos, ser vago en las funcionalidades, y omitir dependencias entre decisiones (el stack depende del tipo de producto, los controles de seguridad dependen de si hay PII, etc.).

**Por qué grill-me:**
La entrevista incesante fuerza una decisión explícita por campo. Al dar la recomendación con cada pregunta, el usuario puede confirmar o redirigir en lugar de inventar desde cero. Las respuestas anteriores condicionan las siguientes, respetando dependencias.

**Why:** Un brief sólido produce specs pobladas de calidad, lo que produce código generado correcto. El garbage in, garbage out aplica completamente aquí.

**How to apply:** Cuando el usuario quiera empezar un proyecto nuevo, sugerir `/grill-brief` antes de `/bootstrap`. Si ya tiene un brief escrito, ir directo a `/bootstrap`. Si el brief está parcialmente lleno, también puede ir directo a `/bootstrap` — el bootstrapper maneja los `[PENDIENTE: ...]`.
