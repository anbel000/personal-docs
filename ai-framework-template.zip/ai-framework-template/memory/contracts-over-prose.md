---
name: contracts-over-prose
description: Por qué los contratos formales tienen prioridad sobre la prosa de las specs
metadata:
  type: project
---

Regla de oro del framework: si un contrato formal (OpenAPI, JSON Schema, DDL) contradice la prosa de una spec, **el contrato gana**.

**Why:** Los contratos son ejecutables — pueden validarse, testearse, generarse código desde ellos. La prosa es interpretable y ambigua. Cuando hay conflicto, la prosa suele estar desactualizada.

**How to apply:** Antes de generar código, siempre leer `contracts/` primero. Si hay discrepancia con la spec en prosa, reportarla al usuario pero usar el contrato. Nunca actualizar el contrato para que coincida con prosa desactualizada sin confirmación humana.
