---
name: three-layer-design
description: Por qué el framework se organiza en specs/contracts/.claude y no de otra forma
metadata:
  type: project
---

El framework separa en tres capas con responsabilidades distintas:

- **`specs/`** — QUÉ construir (lenguaje humano, prosa, contexto de negocio)
- **`contracts/`** — LA VERDAD EJECUTABLE (OpenAPI, JSON Schema, DDL — estos ganan sobre la prosa)
- **`.claude/`** — CÓMO construirlo (agentes, reglas, comandos — orquestación de Claude)

**Why:** Separa el conocimiento del dominio (negocio) de los contratos formales (técnicos) de la orquestación (proceso). Permite que distintos roles trabajen en su capa sin interferir. Un PM edita specs/, un backend engineer edita contracts/, un tech lead edita .claude/.

**How to apply:** Si alguien pide cambiar cómo funciona un agente → `.claude/agents/`. Si quiere cambiar qué hace el producto → `specs/`. Si quiere cambiar la API → `contracts/api/`.
