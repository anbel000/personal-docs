---
name: graphify-integration
description: Cómo funciona el conectoma de archivos con graphify — wiki multienlazado navegable por IA y Obsidian
metadata:
  type: project
---

El framework integra [graphify](https://github.com/safishamsi/graphify) para mantener un grafo de conocimiento vivo del proyecto — un "conectoma" donde cada archivo es un nodo y las referencias entre archivos son aristas con confianza explícita.

## Config activa

La configuración de graphify vive en `graphify/.graphify.yml` (no en la raíz).
El modelo LLM del extractor semántico se configura en `graphify/llm.config.yml` (default: Haiku).
Para ver o cambiar el modelo: `/graphifyllm`.
El consumo de tokens de la última ejecución está en `graphify/usage.md`.

El scope del conectoma incluye:
- specs/, contracts/, docs/adr/ — documentación y contratos
- ejemplos/ — implementaciones de referencia
- .claude/agents/, .claude/commands/, .claude/rules/ — agentes y reglas
- memory/ — memoria persistente
- packages/*/src/**, packages/*/test/** — código fuente (cuando existe)
- scripts/, packages/*/scripts/ — scripts del proyecto

## Qué produce

- `graphify-out/wiki/index.md` → punto de entrada del wiki (leer primero para navegar)
- `graphify-out/wiki/_COMMUNITY_*.md` → un archivo por dominio/cluster temático
- `graphify-out/wiki/{nodo}.md` → un archivo por cada spec/contrato/agente/archivo fuente
- `graphify-out/graph.html` → visualización interactiva en browser
- `graphify-out/graph.json` → para queries programáticos vía CLI
- `graphify-out/GRAPH_REPORT.md` → nodos centrales, gaps, sorpresas

## Cómo navegar (para IA)

1. Leer `graphify-out/wiki/index.md` primero
2. Ir a `_COMMUNITY_{dominio}.md` para el área relevante
3. Seguir `[[wikilinks]]` entre nodos
4. Solo leer el archivo fuente si se necesita el contenido exacto

**Esto es más eficiente que Glob/Grep** porque las relaciones ya están pre-computadas.

Queries útiles:
```bash
python -m graphify query "autenticación JWT" --graph graphify-out/graph.json --budget 3000
python -m graphify path "requerimientos.md" "auth.service.ts" --graph graphify-out/graph.json
python -m graphify explain "UserGuard" --graph graphify-out/graph.json
```

## Cómo se mantiene actualizado

- **PostToolUse hook**: después de cada Write/Edit en specs/ o contracts/, `rebuild-graph.sh`
  corre `python -m graphify update . --config graphify/.graphify.yml` en background
- **Manual**: `/graphify --update` para rebuild incremental, `/graphify` para rebuild completo
- **Watch mode**: `/graphify --watch` para sincronización continua

## Obsidian

El directorio `graphify-out/wiki/` se abre directamente como vault de Obsidian. El Graph View
muestra el conectoma con colores por comunidad (definidos en `graphify/.graphify.yml`).

## Instalación de graphify

```bash
pip install graphifyy
```

**Why:** La IA necesita un mapa pre-computado del proyecto para navegar eficientemente sin hacer
múltiples búsquedas. El wiki de graphify reduce el número de tool calls necesarios para entender
la estructura del proyecto.

**How to apply:** Antes de Glob/Grep, verificar si `graphify-out/wiki/index.md` existe.
Si sí, usarlo. Si no, sugerir `/graphify`.
