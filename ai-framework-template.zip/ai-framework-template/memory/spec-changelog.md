---
name: spec-changelog
description: Historial de cambios en specs y contratos del proyecto. Auto-actualizado por hook post-commit.
metadata:
  type: project
---

# Spec Changelog

Registro de cambios en specs y contratos. Generado automáticamente por `.claude/hooks/post-commit-changelog.sh`.

| Fecha | Commit | Tipo | Dominio/Archivo | Autor | Descripción |
|-------|--------|------|-----------------|-------|-------------|
| *(auto-actualizado en cada commit que toca specs/ o contracts/)* | | | | | |
